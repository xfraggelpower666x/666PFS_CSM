# Initial Audit

PRECHANGE_HEAD=f043804b82a2993341e743223bd1cd8fb8ff09dd

Findings:
- Child Inventory reported ACTIVE_REGISTERED=31.
- Current State, Migration Queue and Dashboard still reported 29.
- PFSPLUGIN-44001 is VERIFIED_BOUND_BACKUP_RECOVERY, so READY/BOUND is 28 rather than 27.
- Current Pointer was last mutation, but carried stale internal blob references.
- ACTIVE_REMAINING=2 is preserved as a semantic blocker count, not arithmetic registered-ready.
