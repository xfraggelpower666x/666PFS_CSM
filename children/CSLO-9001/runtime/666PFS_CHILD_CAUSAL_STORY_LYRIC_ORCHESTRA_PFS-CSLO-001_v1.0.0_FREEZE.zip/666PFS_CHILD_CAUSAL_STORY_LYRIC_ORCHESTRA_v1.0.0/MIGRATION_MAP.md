# MIGRATION MAP

## Quelle → Child

- VOLLTEXT STORY & LYRIC ENGINE v2.2.0 → PFS-CSLO-001 v1.0.0
- fachliche Runtime: unverändert eingebettet
- 666PFS-Governance: neu ergänzt
- Child Entry: CSLO-9001
- Autoload: verboten
- LYVRA: unverändert und nicht verbunden

## Versionslogik

Die neue Child-Version startet bei 1.0.0. Die fachliche Herkunftsversion v2.2.0 bleibt als Source-Version im Manifest erhalten und wird nicht als Child-SemVer weitergeführt.
