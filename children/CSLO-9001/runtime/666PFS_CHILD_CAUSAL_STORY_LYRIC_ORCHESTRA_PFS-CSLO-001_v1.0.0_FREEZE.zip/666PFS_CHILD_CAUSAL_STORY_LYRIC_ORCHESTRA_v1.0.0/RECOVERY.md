# RECOVERY

1. PFS-CSLO-001 nicht aus Fremdquellen rekonstruieren.
2. `PRE_CHANGE_SOURCE_VOLLTEXT_STORY_LYRIC_ENGINE_v2.2.0_FREEZE.zip` und `SOURCE_SYSTEM_V2.2.0/` als fachliche Ausgangsquelle verwenden.
3. SHA-256 und ZIP-CRC gegen `SHA256SUMS.txt` und `FREEZE.json` prüfen.
4. Bei Registry-/Pointer-Konflikt fail-closed arbeiten und Pointer nicht veröffentlichen.
5. LYVRA niemals laden oder verändern.
6. Child ausschließlich über 666PFS-Core und explizite Auswahl laden.
