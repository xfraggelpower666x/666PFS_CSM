# VOLLTEXT STORY & LYRIC ENGINE v2.2.0

## Release

**MULTILINGUAL LENGTH & RESUME**

## Zweck

Das System erzeugt aus einem Wort, wenigen Seeds, Lyrikfragmenten oder zwei Volltexten einen kausal aufgebauten Fulltext. Vor dem Schreibstart werden Zielsprache und Zielumfang festgelegt. Spätere Eingaben in der jeweils anderen Sprache werden intern bedeutungstreu übertragen. Unterbrechungen werden verarbeitet und der aktive Vorgang setzt danach am letzten verifizierten Absatz-, Szenen- oder Kapitelcheckpoint fort.

## Neue Kernfunktionen

- verbindliche Sprachauswahl vor dem Schreibstart
- nachfolgende Längenauswahl
- ULTRA SHORT als Fulltext-Grundlage für normale Song-Lyrics
- SHORT STORY
- NORMAL mit ungefähr 10 A4-Seiten
- LONG mit ungefähr 30 A4-Seiten und Kapitel-Checkpointing
- AUTOMATIC und CUSTOM
- Pending-Input Buffer: frühe Seeds gehen während Setup-Fragen nicht verloren
- bidirektionale interne Übersetzung Deutsch ↔ Englisch
- Interruption Ingestion & Exact Resume
- Story-Resume mit Causal Ledger, Motiven und Figurenstatus
- Long-Form Chapter Handoff

## Erhalten

- Fulltext First
- Short Seed ab einem sinntragenden Wort
- kausal verflochtener Story Mode
- Cyber-Neon Causal Story Fusion Core
- Psychoakustik und Psychovisualität
- funktionale Cybertechnik
- optionale Standard-Lyrics
- Adult Tattoo Representation
- Maximum Allowed Dark Erotic mit Erwachsenen- und Consent-Hardlocks
- Clean Backup, Audit, Freeze und Recovery

## Hauptdatei

`VOLLTEXT_STORY_LYRIC_ENGINE_v2.2.0.md`

## Quellen

Der vollständige Cyber-Neon-Quelltext bleibt unverändert unter `SOURCE_MODULES/` erhalten.
