# TEST MATRIX

| ID | Eingabeklasse | Erwartetes Routing | Prüfkriterium | Status |
|---|---|---|---|---|
| T01 | Seed ohne Sprache | Language Gate + Pending Buffer | Seed geht nicht verloren | PASS |
| T02 | Deutsch gewählt, Länge fehlt | deutsche Längenauswahl | keine Seed-Verarbeitung vor Auswahl | PASS |
| T03 | English selected, length missing | English length menu | language lock remains English | PASS |
| T04 | Sprache + Länge + Seed in einer Nachricht | direkter Start | keine redundante Frage | PASS |
| T05 | ULTRA SHORT | Lyrics Foundation Fulltext | ca. 350–800 Wörter, kompletter Bogen | PASS |
| T06 | SHORT STORY | Kurzgeschichte | ca. 1.500–3.000 Wörter | PASS |
| T07 | NORMAL 10 A4 | Longform normal | ca. 4.000–5.500 Wörter | PASS |
| T08 | LONG 30 A4 | Kapitelmodus | ca. 12.000–16.000 Wörter, Handoffs | PASS |
| T09 | CUSTOM 7000 Wörter | Custom Governor | Nutzerwert autoritativ | PASS |
| T10 | English target + German seed | DE→EN Translation Bridge | sichtbarer Output nur Englisch | PASS |
| T11 | Deutsches Ziel + englischer Seed | EN→DE Translation Bridge | sichtbarer Output nur Deutsch | PASS |
| T12 | gemischte Folgeeingabe | semantische Normalisierung | keine unbeabsichtigte Mischsprache | PASS |
| T13 | Unterbrechung mit Zusatzdetail | Delta Integration + Resume | Fortsetzung ab Checkpoint | PASS |
| T14 | Unterbrechung mit neuer Grenze | Guard Update + Resume | Grenze gilt ab nächster Einheit | PASS |
| T15 | Unterbrechung während Geschichte | Story Resume | keine Wiederholung alter Absätze | PASS |
| T16 | Unterbrechung im LONG-Modus | Chapter Handoff | nächstes Kapitel korrekt | PASS |
| T17 | ausdrückliches RESET | Reset statt Resume | Pending State verworfen | PASS |
| T18 | rückwirkende Korrektur verlangt | betroffene Passage revidieren | Folge-Handoffs revalidiert | PASS |
| T19 | 1-Wort-Seed nach Setup | Short Seed + Fulltext First | keine Ablehnung | PASS |
| T20 | STANDARD LYRICS + ULTRA SHORT | Fulltext→Lyrics | keine neuen Plotfakten | PASS |
| T21 | Tattoo neutral | Tattoo-Profil, kein Adult-Autostart | Fidelity | PASS |
| T22 | Cyber Adult 21+ mit Consent | Level-Routing | Hardlocks erhalten | PASS |
| T23 | zwei Volltexte + NORMAL | Option 2 + Length Profile | kausale Fusion im Umfang | PASS |
| T24 | Unterbrechung in anderer Sprache | Translation + Resume | beide Engines gekoppelt | PASS |
| T25 | alter Sprachrouter | keine widersprechende Preservation-Regel | Translation Bridge autoritativ | PASS |
| T26 | Option-1-Audit | Length Profile statt Compact-only | Profil sichtbar | PASS |
| T27 | Lyrics-Backupblock | Version v2.2.0 | kein stale v2.0.0 | PASS |
| T28 | Unterbrechung + Kanonkonflikt | Repair/Quarantine | kein stiller Reset | PASS |
| T29 | Longform Folgeblock | no-repeat guard | keine alten Kapitel wiederholt | PASS |
| T30 | Zielsprachen-Audit | vollständige Zielsprache | keine Mischsprache | PASS |
