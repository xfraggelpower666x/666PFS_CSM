# INTEGRATION MATRIX

## Ziel

- Zielsystem: VOLLTEXT STORY & LYRIC ENGINE v2.2.0
- Quellbasis: VOLLTEXT STORY & LYRIC ENGINE v2.1.0 CYBER-NEON CAUSAL FUSION
- Integrationsart: zustandsbehaftete Setup-, Übersetzungs-, Längen- und Resume-Erweiterung

| Anforderung | Zielmodul | Status |
|---|---|---|
| zuerst Sprache wählen | 1.3 Language Setup Gate | INTEGRIERT |
| danach Umfang wählen | 1.3A Output-Length Setup Gate | INTEGRIERT |
| Ultra-Kurz für Lyrics-Grundlage | Multi-Length Story Governor | INTEGRIERT |
| Kurzgeschichte | Multi-Length Story Governor | INTEGRIERT |
| normal ca. 10 A4 | NORMAL-Profil | INTEGRIERT |
| lang ca. 30 A4 | LONG-Profil + Chapter Handoff | INTEGRIERT |
| früh eingegebenen Seed erhalten | Pending-Input Buffer | INTEGRIERT |
| Unterbrechung aufnehmen und fortsetzen | 1.3B Exact Resume Engine | INTEGRIERT |
| gleiches Verhalten innerhalb Story | Story-Resume-Hardlock | INTEGRIERT |
| Englisch gewählt, deutsche Eingabe | Translation Bridge DE→EN | INTEGRIERT |
| Deutsch gewählt, englische Eingabe | Translation Bridge EN→DE | INTEGRIERT |
| keine Wiederholung nach Unterbrechung | Checkpoint + Phrase Exclusion | INTEGRIERT |

## Konfliktentscheidungen

1. Die frühere Direktverarbeitung ohne Sprachauswahl wird ersetzt: Fehlt eine eindeutige Zielsprache, wird zuerst gefragt; vorhandener Seed bleibt gepuffert.
2. Die frühere pauschale Compact-Story-Ausrichtung wird zu einem wählbaren Umfangsprofil.
3. A4-Seiten werden nur angenähert; interner Planungswert ist etwa 450 Wörter je A4-Seite.
4. Fremdsprachige Folgeeingaben ändern den Target-Language Lock nicht.
5. Unterbrechungen gelten als Deltas. Nur explizite Stop-/Reset-/Neustartbefehle heben die automatische Fortsetzung auf.
6. Rückwirkende Kanonänderungen erfolgen nur auf ausdrücklichen Auftrag; sonst werden neue Angaben kausal ab dem nächsten möglichen Checkpoint integriert.

## Quellenintegrität

- v2.1.0 Pre-Change-ZIP SHA-256: `45c1cd55ef0004042fb3572ba99c5d5b0b599804f0b77878b8412769d9665710`
- Cyber-Neon-Quellmodul unverändert erhalten: `SOURCE_MODULES/CYBER_NEON_DARK_EROTIC_STORY_ENGINE_v2.0_SOURCE.md`
