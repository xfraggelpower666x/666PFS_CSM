# CHANGELOG

## v2.2.0 — MULTILINGUAL LENGTH & RESUME

### Integriert

- Language Setup Gate als verbindlicher erster Setup-Schritt
- Output-Length Setup Gate nach der Sprachauswahl
- Profile ULTRA SHORT, SHORT STORY, NORMAL 10 A4, LONG 30 A4, AUTOMATIC und CUSTOM
- Pending-Input Buffer für Seeds und Regeln, die vor Abschluss des Setups eingegeben werden
- Bidirectional Input Translation Bridge Deutsch ↔ Englisch
- Target-Language Lock für den vollständigen kreativen Output
- Interruption Ingestion & Exact Resume Engine
- Story-Resume-Hardlock
- Long-Form Chapter Resume und Chapter Handoff
- Resume- und Translation-Transparenz im Audit

### Geändert

- bisheriger Compact Story Length Governor durch profilgesteuerten Multi-Length Story Governor ersetzt
- kompakte Ausgabe ist nicht mehr pauschaler Standard; das gewählte Profil ist autoritativ
- 10- und 30-A4-Ausgaben werden über Wortziele und Kapitel geplant
- fremdsprachige Folgeeingaben wechseln nicht mehr ungewollt die Ausgabesprache
- Unterbrechungen führen nicht mehr zu Neustart, Wiederholung oder Verlust des laufenden Zustands

### Erhalten

- CYBER-NEON CAUSAL FUSION v2.1.0 vollständig als Basis
- OPTION 1 / OPTION 2
- Fulltext First und optionale Standard-Lyrics
- Short-Seed Expansion und Causal Story
- Adult Mode Level 1–5, Tattoo-Fidelity und Consent-Hardlocks
- Continuation Handoff, Freshness Guards und Clean Backup
