# RECOVERY

## Aktiver Stand

- VOLLTEXT STORY & LYRIC ENGINE v2.2.0
- Hauptdatei: `VOLLTEXT_STORY_LYRIC_ENGINE_v2.2.0.md`

## Rückfallbasis

Die unveränderte Freeze-ZIP v2.1.0 wurde separat als `PRE_CHANGE_BACKUP_VOLLTEXT_STORY_LYRIC_ENGINE_v2.1.0_CYBER_NEON_CAUSAL_FUSION.zip` gesichert.

## Wiederherstellung

1. SHA-256 der v2.2.0 Freeze-ZIP prüfen.
2. ZIP vollständig entpacken.
3. `SHA256SUMS.txt` prüfen.
4. Hauptdatei laden.
5. `MANIFEST.json`, `FREEZE.json`, `INTEGRATION_MATRIX.md` und `TEST_MATRIX.md` vergleichen.
6. Cyber-Neon-Quelltext unter `SOURCE_MODULES/` prüfen.
7. Bei Abweichung v2.2.0 nicht als verifiziert behandeln und auf das Pre-Change-Backup v2.1.0 zurückfallen.

## Resume-Recovery

Ein Laufzeit-Checkpoint gehört nicht in die Clean-Systemsicherung. Beim aktiven Einsatz muss der Host die im System definierten Felder für Sprache, Länge, Pending Input, Causal Ledger und letzte vollständige Ausgabe innerhalb des laufenden Kontexts halten.
