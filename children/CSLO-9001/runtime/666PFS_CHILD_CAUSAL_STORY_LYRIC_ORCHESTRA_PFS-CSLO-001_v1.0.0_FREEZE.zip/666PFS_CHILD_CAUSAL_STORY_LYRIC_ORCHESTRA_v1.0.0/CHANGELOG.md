# CHANGELOG

## v1.0.0 — NEW CHILD FREEZE

- neue 666PFS-Child-Identität PFS-CSLO-001 angelegt
- Registry-Nummer CSLO-9001 vergeben
- VOLLTEXT STORY & LYRIC ENGINE v2.2.0 vollständig eingebettet
- Fulltext First, Short Seed, Kausalität, Sprach-/Längenwahl und Resume erhalten
- Adult Tattoo und maximal zulässige Dark-Erotik mit Adult-/Consent-Hardlocks erhalten
- Child-Autoload, zweiter Bootstrap, zweiter Updateweg und LYVRA-Verbindung verboten
