# Candidate Promotion and Baseline Overlay Gate

Status: ACTIVE IN UCCF v1.3.0

A review PASS is not a canonical promotion.

```text
BASELINE=LAST_VERIFIED_FREEZE
CANDIDATE=NEW_AUDITED_DELTA
REVIEW_PASS != CANONICAL_PROMOTION
```

## Two-phase lifecycle

1. Build candidate overlay without overwriting the baseline.
2. Run collision, dependency, scope, payload and recovery audits.
3. Mark `PROMOTION_READY` or `HOLD`.
4. Promote only after explicit authority and successful readback.
5. Update canonical pointer last.

Possible states:

```text
CANDIDATE_CREATED
CANDIDATE_AUDITED
PROMOTION_READY
PROMOTION_HOLD
PROMOTED_CANONICAL
REJECTED_ARCHIVED
```

A candidate package may be a valid systemsicherung while the prior canonical freeze remains unchanged.
