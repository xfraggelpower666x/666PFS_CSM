# Functional Visual Output Governance

Status: ACTIVE IN UCCF v1.3.0  
Scope: Audit / Repair / Handoff / Freeze / Completion

## Pflicht

- Status verständlich als Text.
- Farbe und Emoji nur ergänzend.
- Prozentwerte nur als Measured, Estimated, Pending oder N/A.
- Keine Fake-Präzision.
- Balken und Scoreboards nur bei realer Bewertungsgrundlage.
- Plaintext und maschinenlesbare Ausgabe bleiben zulässig.
- Bei signifikanten Systemausgaben: Status, Scope, Risiken, Decision Gate.
