# Large-System and No-Habituation Guard

Status: ACTIVE IN UCCF v1.3.0  
Scope: Preservation / Dependency Safety / Structural Memory

## Kernregeln

- Komplexität ist nicht automatisch ein Defekt.
- Alte Regeln bleiben aktiv, bis eine belegte Entfernung freigegeben ist.
- Wiederholung kann Schutzverstärkung darstellen.
- Versteckte Abhängigkeiten werden bis zum Audit angenommen.
- Keine aggressive Vereinfachung oder stille Kompression.
- Entfernen nur mit Nutzerauftrag, Dependency-Audit, Rollback und ReAudit.
