# Three-Pillar Self-Governance and Assembly Gate

Status: ACTIVE IN UCCF v1.3.0

UCCF release completeness is checked across three equal pillars:

1. **Boot and State Recovery** — entry classification, authority, registry and checkpoint loading.
2. **Audit and Controlled Repair** — scope, dependencies, self-agreement, self-healing and ReAudit.
3. **Backup, Recovery and Portable Handoff** — manifest, artifact inventory, hashes, readback and restart instructions.

The Self-Governance Gate verifies that the real user intent, system boundaries and all three pillars remain coherent.

The Assembly Gate blocks exports built from disconnected chat fragments, stale snippets, unowned rules or missing dependencies. Every exported module must declare identity, purpose, position, dependencies, guards, audit status and rollback path where applicable.
