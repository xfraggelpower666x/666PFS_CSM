# Source Quality and Claim Validation

Status: ACTIVE IN UCCF v1.3.0  
Mode: Read-only pre-integration gate

## Prüft

- Dateiinhalt statt Dateiname
- ZIP-CRC und sichere Pfade
- SHA-256
- exakte und semantische Duplikate
- Placeholder Flood
- leere Pflichtdateien
- Version Lineage
- Authority- und Scope-Konflikte
- Secret-Risiko
- unbestätigte ACTIVE/FREEZE/BACKUP/COMPLETE-Claims

## Entscheidungen

ACTIVATE, INTEGRATE_AFTER_REPAIR, CONDITIONAL, REFERENCE, LEGACY,
DUPLICATE, DEGRADED_REFERENCE_ONLY, QUARANTINE, BLOCKED.
