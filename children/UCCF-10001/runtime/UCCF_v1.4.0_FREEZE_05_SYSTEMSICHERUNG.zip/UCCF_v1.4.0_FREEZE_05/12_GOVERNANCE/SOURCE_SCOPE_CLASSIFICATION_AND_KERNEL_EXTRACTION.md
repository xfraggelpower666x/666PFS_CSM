# Source Scope Classification and Kernel Extraction Gate

Status: ACTIVE IN UCCF v1.3.0  
Scope: Imported files, project reuse, handoffs and system candidates

## Rule

No source is merged wholesale merely because it is relevant. First name the audit target and classify each source:

- `CORE_RELEVANT` — directly supports the current UCCF task.
- `PARTIAL_RELEVANT` — only named rules or schemas may be extracted.
- `REFERENCE_ONLY` — useful evidence, not active logic.
- `FOREIGN_SCOPE` — belongs to another domain or system.
- `QUARANTINE` — conflict, unclear authority, unsafe content or unverified claims.
- `SUPERSEDED` — older lineage retained, not activated.

## Kernel extraction

For every accepted kernel record:

```text
SOURCE_ID
SOURCE_VERSION
SOURCE_HASH
EXTRACTED_RULE
TARGET_MODULE
ADAPTATION_SCOPE
EXCLUDED_CONTENT
CONFLICTS
VALIDATION_METHOD
```

Project-specific identities, triggers, private data and domain payloads remain outside UCCF unless separately authorized.
