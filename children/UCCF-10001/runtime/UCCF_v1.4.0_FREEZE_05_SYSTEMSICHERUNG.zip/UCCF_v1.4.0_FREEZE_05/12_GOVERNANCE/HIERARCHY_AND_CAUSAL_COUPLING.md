# Hierarchy and Causal Coupling — UCCF 1.4.0

The canonical stage registry, module DAG, manager contracts and state-transition table jointly define the system. No single prose chain may override them.

```text
INTERRUPTION → CAUSAL ANALYSIS → SELF AGREEMENT → WORKING COPY → AUDIT
→ SELF HEALING IF REQUIRED → REAUDIT → AGREEMENT REVALIDATION
→ CHECKPOINT → CURRENT CHAT RESUME
```
