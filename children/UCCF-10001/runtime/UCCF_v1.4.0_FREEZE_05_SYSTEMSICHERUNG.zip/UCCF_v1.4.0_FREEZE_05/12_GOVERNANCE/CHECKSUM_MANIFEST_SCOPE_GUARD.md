# Checksum Manifest Scope Guard

Status: ACTIVE IN UCCF v1.3.0

## Requirements

- Checksum targets use package-relative paths unless the manifest is explicitly `DETACHED`.
- A package manifest does not hash itself.
- External artifacts are listed in a detached receipt with target name, size and hash.
- Missing, stale or mismatched targets are visible warnings or blockers according to artifact role.
- Hash PASS never proves semantic completeness by itself.

```text
SELF_REFERENTIAL_CHECKSUM=FORBIDDEN
UNDECLARED_ABSOLUTE_PATHS=FORBIDDEN
CHECKSUM_SCOPE_REQUIRED=true
```
