# Changelog

## 1.4.0 — FREEZE_05

### Repaired

- duplicate section numbering,
- conflicting bootstrap/source ordering,
- flat module registry,
- informal non-JSON schemas,
- artifact inventory mismatch,
- stale active version metadata,
- ambiguous duplicate active audit aliases,
- foreign PDF embedding in system-only package,
- shallow verification and incomplete handoff.

### Added

- canonical boot stage registry,
- dependency DAG and capability matrix,
- continuity transaction and state machine,
- manager contracts and invariants,
- checkpoint/resume/runtime/host-adapter schemas,
- artifact ownership and migration map,
- semantic verification and external evidence index.
