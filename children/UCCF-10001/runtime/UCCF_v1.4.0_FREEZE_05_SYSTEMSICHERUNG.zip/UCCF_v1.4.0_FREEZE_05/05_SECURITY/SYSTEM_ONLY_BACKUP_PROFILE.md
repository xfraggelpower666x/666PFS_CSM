# UCCF System-only Backup Profile

Enthalten: Spezifikation, Bootstrap, Registries, Schemata, Audit, Repair Ledger, ReAudit, Freeze, Handoff, Verifikation und Prüfsummen.

Ausgeschlossen: Chatverlauf, Suchverlauf, Caches, temporäre Dateien, Nutzerinhalte, Medien, Laufzeitexporte, extrahierte Fremdarchive, Credentials und alte Releasearchive.

Source-Provenienz bleibt über `SOURCE_INVENTORY.json`, Hashes und das Integrationsledger erhalten.
