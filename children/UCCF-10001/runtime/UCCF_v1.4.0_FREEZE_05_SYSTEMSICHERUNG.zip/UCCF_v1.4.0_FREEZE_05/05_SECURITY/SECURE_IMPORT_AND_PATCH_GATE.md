# Secure Import and Exact Patch Gate

## Import

1. Original unverändert erhalten.
2. Archiv vor Extraktion auf CRC, Pfadtraversal, Dateianzahl, Gesamtgröße, Einzelgröße, Verschachtelung und Kompressionsverhältnis prüfen.
3. Keine Installer, Hooks, Package-Lifecycle-Skripte, Modelle oder fremden Binaries ausführen.
4. Textquellen auf Secrets prüfen; Trefferwerte niemals in Berichte kopieren.
5. Fremdidentitäten, Trigger, Drive-IDs und Hostregeln als `FOREIGN_MATERIAL` markieren.

## Pfade

Lexikalische und reale Pfadprüfung sind Pflicht. Symlink-Ausbrüche und Ziele außerhalb der Allowlist werden blockiert.

## Patch

```text
EXPLICIT_TARGET
→ EXPECTED_BASE_HASH
→ EXACTLY_ONE_SEARCH_MATCH
→ WORK_COPY
→ DIFF_REVIEW
→ VALIDATION
→ ATOMIC_REPLACE
→ READBACK
```

Null oder mehrere Treffer führen zu `BLOCKED`; es gibt keine mehrdeutige Regex-Ersatzlogik.
