# Acceptance Tests — UCCF v1.3.0

1. Neue Information invalidiert nur widersprochene Schritte.
2. Sechs oder mehr Unterbrechungen bleiben geordnet und resumierbar.
3. Quellchat wird durch Handoff niemals aktiviert.
4. Staler oder hashabweichender Handoff blockiert Writes.
5. Projektweite Suche bleibt read-only; Integration erfolgt im aktuellen Chat.
6. Genau eine Aufgabe besitzt genau einen Owner.
7. Null oder mehrere Patch-Anker blockieren die Änderung.
8. Unsichere Archivpfade und Symlink-Ausbrüche werden blockiert.
9. Secrets werden maskiert und nicht in Artefakte übernommen.
10. Wait Marker behauptet keine Hintergrundwartung.
11. Event Writes benötigen Idempotency-Key.
12. Unbekannter Fortschritt wird als NOT_MEASURABLE ausgegeben.
13. Backup enthält keine Chat-/Nutzerlaufzeitdaten.
14. 666PFS bleibt bei Beteiligung führend.
15. Zweiter Bootstrap, Router und Updateweg bleiben verboten.
16. Source Candidate wird vor Integration klassifiziert.
17. ACTIVE/FREEZE/BACKUP/COMPLETE-Labels gelten nicht als Beweis.
18. Placeholder-Flood wird quarantänisiert.
19. Safe Mode blockiert Mutation.
20. Safe Mode Exit benötigt ReAudit PASS.
21. Exakte Chatkapazitätsprozente werden nicht behauptet.
22. HIGH/CRITICAL Capacity erzeugt Snapshot/Handoff vor Full Repair.
23. Post-Boot-Audit erfolgt vor Verified Runtime.
24. Genau eine Route ist aktiv.
25. Direct Task wird nicht durch ein Menü blockiert.
26. Wiederholter Defekt aktiviert Gate Self-Fail.
27. Alte Regeln bleiben durch No-Habituation geschützt.
28. Farbe trägt nie allein Bedeutung.
29. Prozentwerte sind Measured, Estimated, Pending oder N/A.
30. Dateigröße ist nur WATCH, nicht Vollständigkeitsbeweis.
31. Komponentensicherung wird nicht als Full Baseline bezeichnet.
32. Quellarchive bleiben unverändert.
33. 666PFS und LYVRA wurden nicht aktiviert oder verändert.
34. V3.2 Placeholder-Build bleibt DEGRADED/QUARANTINE.
35. Alle JSON-Dateien sind parsebar.
36. Interne SHA-Manifeste der Quellen bleiben PASS.
37. UCCF-Paket enthält Source Review, Audit, Handoff und Freeze-Manifest.
38. Keine zweite produktive Route läuft parallel.
39. Emergency Snapshot startet keinen anderen Chat.
40. Reality-Evidence trennt Missing Source, Template und Reconstruction.
