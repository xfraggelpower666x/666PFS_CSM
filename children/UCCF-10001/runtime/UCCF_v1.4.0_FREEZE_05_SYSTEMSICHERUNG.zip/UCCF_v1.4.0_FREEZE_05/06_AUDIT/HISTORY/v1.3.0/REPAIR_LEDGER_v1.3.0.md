# UCCF v1.3.0 Repair Ledger

1. **Checksum scope defect** — introduced package-relative checksum policy; self-hash prohibited; external artifacts require detached receipts.
2. **Control-state ambiguity** — separated desired GUI state, command generation and verified runtime execution.
3. **Review/promotion ambiguity** — separated candidate audit, systemsicherung and canonical promotion.
4. **Payload regression risk** — added uncompressed payload, content-count and artifact-parity checks.
5. **Whole-source merge risk** — added source classification and kernel extraction.
6. **Prompt-service coupling** — retained reusable prompt schema but removed mandatory prompts.chat dependency.
7. **Visual overclaim risk** — retained functional visual structure but rejected forced percentages and domain color coupling.
8. **Legacy collision** — marked General Audit v1.1.0 as superseded reference; v1.1.3 used for current repair logic.
9. **Domain leakage** — excluded music/adult/lyrics content and source-specific triggers.
10. **Missing-artifact ambiguity** — added explicit recovery holds and recovery mode classification.
