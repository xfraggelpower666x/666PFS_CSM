# Repair Ledger — UCCF v1.2.0

| Defekt/Risiko | Reparatur |
|---|---|
| Placeholder-Dateien könnten als Module gelten | Source Quality Gate + Quarantine |
| ACTIVE/FREEZE/BACKUP-Text könnte als Beweis gelten | Claim Validation |
| Große Reparatur trotz unsicherer Chatkapazität | Capacity/Feasibility Gate |
| Wiederholt fehlerhafter Output löst Full-Rebuild-Schleife aus | Defect-Gate Self-Fail |
| Zwei Boot-Systeme könnten als zwei Wurzeln interpretiert werden | One Root + Route Resolver |
| Größenvergleich könnte Vollständigkeit vortäuschen | Semantische Completeness Gate |
| Visuelle Balken könnten Fake-Präzision erzeugen | Measured/Estimated/Pending/N/A |
| Alte Regeln könnten durch Gewöhnung wegfallen | No-Habituation Guard |
