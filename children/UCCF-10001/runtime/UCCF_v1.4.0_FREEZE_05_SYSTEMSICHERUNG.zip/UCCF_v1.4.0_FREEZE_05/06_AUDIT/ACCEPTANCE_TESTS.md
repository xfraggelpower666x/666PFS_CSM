# Acceptance Tests — UCCF 1.4.0

The executable verifier covers required artifacts, JSON parsing, JSON-Schema meta-validation and fixtures, section hierarchy, active version consistency, module DAG and stage order, event ownership, state transitions, manager contracts, current-chat invariants, artifact inventory, SHA-256, duplicate active artifacts, external evidence policy and secrets.
