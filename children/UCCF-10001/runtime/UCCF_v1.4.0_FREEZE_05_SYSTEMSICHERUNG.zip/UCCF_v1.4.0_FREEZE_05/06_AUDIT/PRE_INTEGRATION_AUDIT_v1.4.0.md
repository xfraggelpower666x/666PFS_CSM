# UCCF v1.3.0 → v1.4.0 Complete Pre-Repair Audit

Status: REPAIR_REQUIRED
Scope: hierarchy, bootstrap, state contracts, manager coupling, registers, artifacts, recovery, handoff and verification

## Measured baseline

```text
BASELINE_FILES=78
BASELINE_SHA256_ENTRIES=77
ZIP_CRC=PASS
CHECKSUM_MISMATCHES=0
ARTIFACT_INVENTORY_DECLARED=75
ACTUAL_FILES_EXCLUDING_SHA256SUMS=77
ARTIFACT_INVENTORY_MISSING=2
DUPLICATE_SECTION_NUMBERS=10
ACTIVE_BYTE_DUPLICATE_GROUPS=6
CUSTOM_NON_JSON_SCHEMAS=4
```

## Findings

### F01 — MAJOR

**Finding:** Duplicate section numbers 45-54 in the active master specification.

**Repair:** Renumber second block to 55-64 and enforce continuous 0-75 headings.

### F02 — MAJOR

**Finding:** Textual bootstrap chains placed source classification at conflicting positions.

**Repair:** Split source safety preflight from post-authority relevance classification and add canonical stage registry.

### F03 — MAJOR

**Finding:** Module registry was flat and lacked dependencies, stages, mutability and authority.

**Repair:** Rebuild registry v2 with a validated DAG and stage ownership.

### F04 — MAJOR

**Finding:** Four active state files were field lists rather than JSON Schema contracts.

**Repair:** Convert all active state contracts to JSON Schema 2020-12 and validate fixtures.

### F05 — MAJOR

**Finding:** No machine-readable continuity transaction or state-transition contract existed.

**Repair:** Add transaction, manager contract and transition table.

### F06 — MAJOR

**Finding:** Artifact inventory declared 75 files but actual package had 77 files excluding SHA256SUMS; two generated reports were omitted.

**Repair:** Redefine inventory scope and validate exact parity.

### F07 — MODERATE

**Finding:** Active Bootstrap, GPT Instructions and Operating Modes carried stale v1.1.0 metadata.

**Repair:** Update all active metadata to 1.4.0 and test version consistency.

### F08 — MODERATE

**Finding:** Byte-identical active audit and evidence aliases created ambiguous current truth.

**Repair:** Move prior copies to history and use explicit current pointers.

### F09 — MODERATE

**Finding:** System-only backup embedded a foreign LYVRA PDF despite its own exclusion policy.

**Repair:** Externalize foreign evidence and retain hash/size/provenance only.

### F10 — MODERATE

**Finding:** Verifier checked mostly file presence and token existence, not semantic hierarchy.

**Repair:** Add schema, DAG, stage, event, transition, inventory, duplicate and evidence-policy tests.

### F11 — MODERATE

**Finding:** Handoff Markdown lacked a complete machine descriptor.

**Repair:** Add validated handoff descriptor with checkpoint, actions, conflicts and source hash.

### F12 — MODERATE

**Finding:** Event catalog had no handler/validator ownership and omitted newer governance events.

**Repair:** Add one primary handler, one final validator and expanded event set.

### F13 — MODERATE

**Finding:** Register pickup zones lacked providers and consumers.

**Repair:** Add ownership and scope validation.

### F14 — MODERATE

**Finding:** Background execution truth rule lacked a receipt schema.

**Repair:** Add Runtime Job Receipt contract.

### F15 — MODERATE

**Finding:** 666PFS/host integration lacked a machine host-adapter contract.

**Repair:** Add host adapter schema and firewall-coupled contract.
