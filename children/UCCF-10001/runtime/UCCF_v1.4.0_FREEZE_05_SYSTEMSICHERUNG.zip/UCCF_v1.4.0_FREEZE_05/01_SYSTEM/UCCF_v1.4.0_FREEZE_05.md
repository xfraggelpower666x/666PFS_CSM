# Universal Chat Continuity Framework

**System-ID:** `UCCF-CORE-001`  
**Version:** `1.4.0`  
**Freeze:** `FREEZE_05`  
**Datum:** `2026-07-31`  
**Status:** `FROZEN_LOCAL_CANDIDATE`  
**Ausführungsscope:** `CURRENT_CHAT_ONLY`  
**Projektweite Suche:** `CURRENT_PROJECT_READ_ONLY_REUSE`  
**Führende Autorität bei Beteiligung:** `666PFS`

---

## 0. Systemrolle

Das Universal Chat Continuity Framework ist ein universelles Unterbrechungs-, Integrations-, Selbsteinigungs-, Selbstheilungs-, Audit- und Wiederaufnahmesystem für Entwicklungsarbeit mit ChatGPT innerhalb eines aktiven Chats.

Es ist:

- in neuen Chats eigenständig einsetzbar,
- in bestehenden Chats adaptiv integrierbar,
- in bestehenden Systemen bootstrap-kompatibel,
- innerhalb eines Projekts zur projektweiten Wiederverwendung befähigt,
- bei Beteiligung von 666PFS grundsätzlich untergeordnet,
- strikt auf die Ausführung und Wiederaufnahme im aktuellen Chat beschränkt.

Es ist **kein globaler Projekt-Worker**, kein System zur Aktivierung anderer Chats und kein Ersatz für 666PFS.

---

## 1. Unveränderliche Grundregeln

```text
FRAMEWORK_AVAILABILITY=UNIVERSAL
EXECUTION_SCOPE=CURRENT_CHAT_ONLY
RESUME_SCOPE=CURRENT_CHAT_ONLY
PROJECT_SEARCH_SCOPE=CURRENT_PROJECT
PROJECT_SOURCE_MODE=READ_ONLY
OTHER_CHAT_EXECUTION=FORBIDDEN
OTHER_CHAT_AUTO_RESUME=FORBIDDEN
OTHER_PROJECT_EXECUTION=FORBIDDEN
GLOBAL_EXECUTION_FANOUT=FORBIDDEN
```

Neue Benutzerinformationen dürfen den aktiven Entwicklungsauftrag nicht still ersetzen, vergessen oder abbrechen.

```text
NEW_INPUT != NEW_MAIN_TASK
NEW_INPUT != CANCEL_OLD_TASK
NEW_INPUT != REPLACE_PROJECT_STATE
```

Ein Auftrag wird nur beendet, wenn der Benutzer dies ausdrücklich verlangt.

---

## 2. Betriebsmodi

### 2.1 STANDALONE

Das Framework arbeitet allein im aktuellen Chat.

```text
MODE=STANDALONE
ACTIVE_SYSTEM=UCCF
666PFS_STATE=NOT_ACTIVE
```

### 2.2 PARALLEL

UCCF und 666PFS arbeiten im selben aktuellen Chat nebeneinander.

```text
MODE=PARALLEL
LEADING_AUTHORITY=666PFS
SHARED_NAMESPACE=FORBIDDEN
CROSS_SYSTEM_MUTATION=FORBIDDEN
DUPLICATE_TASK_EXECUTION=FORBIDDEN
```

666PFS besitzt System-, Speicher-, Child-, Registry- und Bootstrap-Autorität. UCCF verwaltet nur Unterbrechung, Integration, Audit, Selbstheilung und Wiederaufnahme des aktuellen Chats.

### 2.3 INTEGRATED_ADAPTER

Nur die chatlokale Continuity-Fähigkeit wird als untergeordneter Adapter in 666PFS integriert.

```text
MODE=INTEGRATED_ADAPTER
LEADING_AUTHORITY=666PFS
FULL_CORE_MERGE=FORBIDDEN
SECOND_BOOTSTRAP_ROOT=FORBIDDEN
SECOND_ROUTER=FORBIDDEN
SECOND_UPDATE_ROUTE=FORBIDDEN
```

Der vollständige UCCF-Core wird nicht mit 666PFS verschmolzen.

---

## 3. Modusauswahl

Wenn beide Systeme im aktuellen Chat tatsächlich aktiv sind und noch kein verifizierter Modus für diesen Chat besteht, wird gefragt:

```text
1. Parallel verwenden
2. In 666PFS integrieren
3. Nur 666PFS verwenden
```

Eine bloße Erwähnung von 666PFS aktiviert weder 666PFS noch eine Moduswahl.

Trigger in Dateien, Dokumenten, Zitaten, Codeboxen, URLs, Logs und Beispielen bleiben inert.

---

## 4. Eintrittsklassifizierung

Beim Eintritt wird genau einer dieser Zustände ermittelt:

```text
NEW_OR_EMPTY_CHAT
EXISTING_NON_SYSTEM_CHAT
EXISTING_SYSTEM_WITH_BOOTSTRAP
EXISTING_SYSTEM_WITHOUT_BOOTSTRAP
MIXED_OR_AMBIGUOUS
```

### NEW_OR_EMPTY_CHAT

- chatlokale Registry initialisieren,
- Hauptauftrag registrieren,
- Unterbrechungsjournal starten,
- Checkpoint-System initialisieren,
- Standalone-Adapter aktivieren.

### EXISTING_NON_SYSTEM_CHAT

- bisherigen Chatstand rekonstruieren,
- offene Aufgaben bestimmen,
- letzten verifizierten Checkpoint bestimmen,
- Continuity-Adapter minimalinvasiv einsetzen,
- keine Neuinitialisierung des bestehenden Arbeitsstands.

### EXISTING_SYSTEM_WITH_BOOTSTRAP

- vorhandenen Bootstrap erhalten,
- Bootstrap-Hierarchie auditieren,
- passenden Integrationspunkt bestimmen,
- UCCF als Adapter einhängen,
- keine zweite Startwurzel erzeugen.

### EXISTING_SYSTEM_WITHOUT_BOOTSTRAP

- System inventarisieren,
- System-ID, Namespace, Registry, Module und Abhängigkeiten bestimmen,
- minimalen systemgerechten Bootstrap erzeugen,
- nur notwendige Module laden,
- UCCF danach einhängen.

### MIXED_OR_AMBIGUOUS

```text
STATUS=CONFLICT_QUARANTINE
WRITE_ALLOWED=false
RESUME_ALLOWED=false
```

---

## 5. Bootstrap-Hierarchie

```text
BOOTSTRAP_ROOT
├── ChatStateClassifier
├── SystemIdentityGuard
├── NamespaceGuard
├── ScopeAndPermissionGuard
├── LockAndAllowlistGuard
├── RegistryLoader
├── DependencyResolver
├── StateAndCheckpointRecovery
├── UCCF_CONTINUITY_LAYER
│   ├── InterruptionManager
│   ├── CausalDeltaAnalyzer
│   ├── SeedMemoryManager
│   ├── ProjectReuseManager
│   ├── CausalSelfAgreementManager
│   ├── IntegrationManager
│   ├── AuditManager
│   ├── CausalSelfHealingManager
│   ├── ReAuditManager
│   └── CurrentChatResumeManager
└── HostSystemExecution
```

UCCF wird geladen:

```text
AFTER_IDENTITY_SCOPE_AUTHORITY_AND_STATE_RECOVERY
BEFORE_HOST_TASK_EXECUTION
```

---

## 6. Unterbrechungsmanager

Jede Benutzerunterbrechung wird:

1. unverändert aufgenommen,
2. zeitlich registriert,
3. dem aktuellen Chat zugeordnet,
4. dem aktiven Auftrag zugeordnet,
5. klassifiziert,
6. kausal analysiert,
7. als Delta registriert,
8. integriert,
9. auditiert,
10. bei Bedarf repariert,
11. reauditiert,
12. vor Wiederaufnahme erneut selbsteingeordnet,
13. am letzten verifizierten Punkt fortgeführt.

Zulässige Unterbrechungsklassen:

```text
CORRECTION
EXTENSION
CONSTRAINT
PRIORITY_CHANGE
PROJECT_REFERENCE
CANCEL_REQUEST
STATUS_REQUEST
AMBIGUOUS_DELTA
```

Mehrfache Unterbrechungen sind stapelbar und in Ankunftsreihenfolge zu erhalten.

---

## 7. Kausale Delta-Analyse

Jedes Delta durchläuft acht Prüfungen:

1. **Ursprung** – welcher belegte Input erzeugte das Delta?
2. **Bedeutung** – welche fachliche oder technische Wirkung ist gemeint?
3. **Abhängigkeiten** – welche Module, Dateien, Regeln und Aufgaben sind betroffen?
4. **Rückkopplung** – welche bestehenden Regeln verändern ihre Wirkung?
5. **Reichweite** – gilt die Änderung für einen Schritt, den Chat oder als Projektquelle?
6. **Grenzen** – welche Systeme, Namespaces, Router, Trigger oder Speicherwege dürfen nicht verändert werden?
7. **Reife** – integrationsbereit, reifend, konfliktbehaftet oder nur Hypothese?
8. **Nachweis** – wie wird die erfolgreiche Integration später bewiesen?

```text
CAUSAL_ANALYSIS_REQUIRED=true
SILENT_SCOPE_EXPANSION=FORBIDDEN
```

---

## 8. Seed Memory

Nicht jede Zwischenidee wird sofort Core-Regel.

Seed-Zustände:

```text
DORMANT
MATURING
RESONANT
GROWING
INTEGRATED
CONFLICT
ARCHIVED
```

Regeln:

- Ursprung, Kontext, Datum, Resonanzfelder und offene Fragen erhalten.
- Mehrere Entwicklungsrichtungen bleiben zulässig.
- Ein einzelnes Stichwort reicht nicht automatisch für Core-Integration.
- Unreife Seeds werden nicht zu harten Runtime-Regeln.
- Überholte Seeds werden nicht gelöscht, sondern begründet archiviert.
- Reife Seeds können neue Deltas und neue überprüfbare Architektur erzeugen.

---

## 9. Projektweite Wiederverwendung

Der aktive Chat darf innerhalb des aktuellen Projekts nach vorhandenen Lösungen suchen:

```text
PROJECT_WIDE_SEARCH=ALLOWED
SOURCE_CHAT_MODE=READ_ONLY
SOURCE_FILE_MODE=READ_ONLY
TARGET_CHAT=CURRENT_CHAT
```

Gesucht werden können:

- vorhandene Module,
- bestehende Regeln,
- ähnliche Reparaturen,
- frühere Workflows,
- Versionen,
- Registry-Einträge,
- Bootstrap-Komponenten,
- Checkpoint-Logik,
- Audit- und Recovery-Verfahren.

Gefundene Inhalte sind Wiederverwendungskandidaten und werden nicht blind kopiert.

Prüfkette:

```text
SOURCE_IDENTIFICATION
→ IDENTITY_CHECK
→ VERSION_CHECK
→ DEPENDENCY_CHECK
→ COMPATIBILITY_CHECK
→ CONFLICT_CHECK
→ CONTROLLED_IMPORT
→ INTEGRATION_AUDIT
```

Andere Chats bleiben vollständig inaktiv.

---

## 10. Kausaler Selbsteinigungsmanager

Die Selbsteinigung bestimmt:

- aktive Systemidentitäten,
- führende Autorität,
- Betriebsmodus,
- Aufgabenbesitzer,
- Integrationsverantwortung,
- Auditverantwortung,
- Speicherautorität,
- Bootstrap-Zuständigkeit,
- Resume-Ziel,
- verbotene Systemgrenzen.

```text
ONE_TASK_ONE_OWNER=REQUIRED
DUPLICATE_EXECUTION=FORBIDDEN
```

Bei Beteiligung von 666PFS:

```text
LEADING_AUTHORITY=666PFS
FINAL_ROUTING_AUTHORITY=666PFS
FINAL_STORAGE_AUTHORITY=666PFS
FINAL_BOOTSTRAP_AUTHORITY=666PFS
```

Die Selbsteinigung wird:

- vor Integration,
- nach jeder relevanten Reparatur,
- vor jeder Wiederaufnahme

validiert.

---

## 11. Integrationsmanager

Neue Informationen werden als Transaktion behandelt:

```text
ORIGINAL_STATE_CAPTURE
→ DELTA_BUILD
→ CAUSAL_ANALYSIS
→ SELF_AGREEMENT
→ PROJECT_REUSE_SCAN
→ WORKING_COPY_UPDATE
→ AUDIT
→ SELF_HEALING_IF_NEEDED
→ REAUDIT
→ AGREEMENT_REVALIDATION
→ CHECKPOINT_COMMIT
→ RESUME
```

Keine stille Überschreibung.

---

## 12. Auditmanager

Auditbereiche:

```text
STRUCTURAL_AUDIT
LOGIC_AUDIT
TASK_AUDIT
INTERRUPTION_AUDIT
CHECKPOINT_AUDIT
BOOTSTRAP_AUDIT
REGISTRY_AUDIT
DEPENDENCY_AUDIT
AUTHORITY_AUDIT
SCOPE_AUDIT
SECURITY_AUDIT
RESUME_AUDIT
```

Jede Phase erzeugt einen nachvollziehbaren Checkpoint. Keine Phase darf still übersprungen werden.

---

## 13. Kausaler Selbstheilungsmanager

Der Selbstheilungsmanager prüft auf:

```text
TASK_STATE_DAMAGE
INTERRUPTION_QUEUE_DAMAGE
RESUME_QUEUE_DAMAGE
CHECKPOINT_MISMATCH
DEPENDENCY_BREAK
DUPLICATE_TASK_OWNER
BOOTSTRAP_ORDER_CONFLICT
REGISTRY_REFERENCE_ERROR
MODE_AGREEMENT_CONFLICT
UNAUTHORIZED_SCOPE_EXPANSION
CROSS_CHAT_ACTIVATION_RISK
CROSS_PROJECT_ACTIVATION_RISK
```

Reparaturprinzip:

```text
ERHALTEN
→ FEHLER ISOLIEREN
→ URSACHE BELEGEN
→ MINIMALINVASIV REPARIEREN
→ REAUDIT
→ SELBSTEINIGUNG REVALIDIEREN
→ WIEDERAUFNAHME
```

Automatische Reparatur ist nur erlaubt, wenn:

```text
ERROR_CAUSE=VERIFIED
REPAIR_SCOPE=LOCAL
REPAIR_REVERSIBLE=true
HOST_AUTHORITY_CONFIRMED=true
NO_CORE_MUTATION=true
NO_FOREIGN_CHAT_MUTATION=true
NO_FOREIGN_PROJECT_MUTATION=true
```

---

## 14. Wiederaufnahmemanager

```text
RESUME_ALLOWED=
INTERRUPTION_INTEGRATED
AND AUDIT_PASSED
AND SELF_HEALING_PASSED
AND REAUDIT_PASSED
AND SELF_AGREEMENT_VALID
AND CURRENT_CHAT_SCOPE_CONFIRMED
```

Wiederaufgenommen werden alle offenen Aufgaben des aktuellen Chats:

- direkt unterbrochener Schritt,
- vorher bereits pausierte Teilaufgaben,
- abhängige Folgeaufgaben,
- offene Audits,
- ausstehende Exporte,
- noch nicht gelieferte Endpakete.

Andere Chats werden nicht gestartet.

---

## 15. Hintergrundausführung

UCCF unterscheidet strikt:

### Logische Fortsetzung

Auftrag, Status, Delta, Checkpoint und Resume-Ziel bleiben erhalten und werden nach Integration fortgeführt.

### Reale technische Parallelausführung

Nur verifiziert, wenn ein tatsächlich aktiver Worker, Connector, Toolprozess, Jobdienst oder eine externe Runtime vorhanden ist.

```text
INVENTED_BACKGROUND_EXECUTION=FORBIDDEN
```

Ohne reale Laufzeit gilt:

```text
BACKGROUND_EXECUTION=UNVERIFIED
ACTION=INTEGRATE_THEN_RESUME_IN_CURRENT_CHAT
```

---

## 16. 666PFS-Integrationsfirewall

UCCF darf als isoliertes Schaltsystem unter 666PFS gespeichert werden, ohne den 666PFS-Core umzubauen.

Standardmodus:

```text
OPERATION_MODE=STORE_CHILD_ONLY
HOST_SYSTEM=666PFS
GUEST_SYSTEM=UCCF
HOST_CORE_MUTATION=FORBIDDEN
HOST_BOOTSTRAP_MUTATION=FORBIDDEN
HOST_TRIGGER_MUTATION=FORBIDDEN
HOST_ROUTER_MUTATION=FORBIDDEN
EXISTING_CHILD_MUTATION=FORBIDDEN
CROSS_SYSTEM_MERGE=FORBIDDEN
```

Zulässig bei ausdrücklichem Auftrag:

- isoliertes Child-Paket,
- eigene System-ID,
- eigener Namespace,
- eigener Hash,
- eigener Registry-Eintrag,
- Pointer nach erfolgreichem Readback zuletzt.

Der integrierte Continuity-Adapter ist eine getrennte Operation und standardmäßig deaktiviert.

---

## 17. LYVRA-Quellgrenze

Die Datei `LYVRA_CREATIVE_CORE_OS_v2.0.0` wurde ausschließlich als Architektur- und Evidenzquelle verwendet.

Übernommen wurden systemneutral:

- additive minimalinvasive Integration,
- achtstufige Kausalitätsprüfung,
- Seed-Reifegrad,
- Netzwerk-/Resonanzprüfung,
- verpflichtende Checkpoints,
- kein zweiter Router/Bootstrap/Updateweg,
- kleinster sicherer Integrationsscope,
- Audit → Reparatur → ReAudit,
- Register und Pointer zuletzt,
- klare Statuswerte.

Nicht übernommen wurden:

- LYVRA-Systemidentität,
- LYVRA-Namespace,
- LYVRA-Trigger,
- LYVRA-Drive-Autorität,
- Trackbau-Routing,
- Track-, Voice-, Pressure- oder Psychoacoustics-Knoten,
- LYVRA-spezifische Speicher- und Updatewege.

```text
LYVRA_MUTATION=FORBIDDEN
LYVRA_AUTOLOAD=FORBIDDEN
LYVRA_IDENTITY_TRANSFER=FORBIDDEN
```

---

## 18. Modulaufnahme-Gate

```text
NO_PROVEN_GAP
→ NO_NEW_MODULE

EXISTING_EQUIVALENT_FOUND
→ REUSE_OR_CONTROLLED_EXTENSION

SECOND_ROUTER_REQUIRED
→ BLOCK

SECOND_BOOTSTRAP_REQUIRED
→ BLOCK

SECOND_UPDATE_ROUTE_REQUIRED
→ BLOCK

UNCLEAR_AUTHORITY
→ CONFLICT_QUARANTINE

SMALLEST_SAFE_SCOPE_AVAILABLE
→ INTEGRATE_THERE_FIRST
```

---

## 19. Statusmodell

```text
VERIFIZIERT
ABGELEITET
VORGESCHLAGEN
OFFEN
BLOCKIERT
PARTIAL
WRITE_BLOCKED
READBACK_PENDING
CONFLICT_QUARANTINE
WORKER_VERIFICATION_UNAVAILABLE_IN_HOST
INTEGRATION_PENDING
SELF_AGREEMENT_PENDING
SELF_HEALING_PENDING
RESUME_PENDING
CURRENT_CHAT_RESUMED
```

---

## 20. Datenmodelle

### Task

```json
{
  "task_id": "TASK-UNIQUE-ID",
  "chat_id": "CURRENT_CHAT",
  "project_id": "CURRENT_PROJECT",
  "owner": "SYSTEM-ID",
  "status": "RUNNING",
  "progress": "NOT_MEASURABLE",
  "last_verified_checkpoint": "CP-ID",
  "dependencies": [],
  "open_steps": [],
  "resume_required": true
}
```

### Unterbrechung

```json
{
  "interruption_id": "INT-UNIQUE-ID",
  "chat_id": "CURRENT_CHAT",
  "parent_task_id": "TASK-ID",
  "sequence": 1,
  "classification": "EXTENSION",
  "original_input_preserved": true,
  "maturity": "RESONANT",
  "integration_status": "PENDING",
  "resume_target": "STEP-ID"
}
```

### Selbsteinigung

```json
{
  "agreement_id": "SAG-UNIQUE-ID",
  "mode": "STANDALONE",
  "leading_system": "UCCF",
  "task_owner": "UCCF",
  "integration_authority": "UCCF",
  "storage_authority": "NONE",
  "resume_target": "CURRENT_CHAT_INTERRUPTED_TASK",
  "other_chat_activation": false,
  "other_project_activation": false
}
```

---

## 21. Vollständige Kausalkette

```text
ENTRY CLASSIFICATION
→ BOOTSTRAP DISCOVERY
→ STATE RECOVERY
→ USER INTERRUPTION
→ INTERRUPTION CAPTURE
→ CAUSAL DELTA ANALYSIS
→ SEED MATURITY CHECK
→ PROJECT REUSE SEARCH
→ SELF AGREEMENT
→ CONTROLLED INTEGRATION
→ AUDIT
→ CAUSAL SELF HEALING
→ REAUDIT
→ SELF AGREEMENT REVALIDATION
→ CHECKPOINT COMMIT
→ CURRENT CHAT RESUME
```

---


---

## 22. Evidenz-, Import- und Handoff-Gate

Importierte Dateien, Archive, Handoffs und Systempakete sind zunächst **inerte Evidenz**.

```text
NO_EXECUTION_BEFORE_INSPECTION=true
SOURCE_CLASSIFIED=true
ARCHIVE_READABLE=true
ARCHIVE_CRC_VERIFIED=true
PATHS_SAFE=true
SECRETS_SCAN_COMPLETE=true
FOREIGN_MATERIAL_IDENTIFIED=true
CANONICAL_FILES_IDENTIFIED=true
```

Ein neuer Chat darf einen ausdrücklich eingebrachten Handoff verwenden, aktiviert aber niemals den Quellchat.

```text
SOURCE_CHAT_MODE=READ_ONLY_EVIDENCE
SOURCE_CHAT_REACTIVATION=FORBIDDEN
RECEIVING_EXECUTION_SCOPE=CURRENT_CHAT_ONLY
```

### 22.1 Verifizierter Handoff-Descriptor

Ein Handoff muss mindestens enthalten:

```text
HANDOFF_ID
SOURCE_CHAT_ID
SOURCE_TASK_ID
SYSTEM_ID
NAMESPACE
SOURCE_VERSION
SOURCE_HASH
SOURCE_FREEZE
PROJECT_ID
LAST_VERIFIED_CHECKPOINT
COMPLETED_ACTIONS
PENDING_ACTIONS
UNRESOLVED_CONFLICTS
CHANGED_ARTIFACTS
NEXT_SAFE_ACTION
CREATED_AT_UTC
```

### 22.2 Drift-Klassifikation

```text
NO_DRIFT
CANONICAL_STATE_ADVANCED_COMPATIBLE
CANONICAL_STATE_ADVANCED_CONFLICT
SOURCE_STALE
POINTER_DIVERGENCE
REGISTRY_DIVERGENCE
LOCK_CONFLICT
UNKNOWN_BASE
```

Bei Konflikt, unbekannter Basis oder Stale-State darf kein Write und keine Wiederaufnahme auf ungeprüfter Basis erfolgen.

---

## 23. Evidence Authority und Provenance

Quellen werden nicht nach Dateiname oder Behauptung priorisiert, sondern nach belegbarer Autorität:

```text
1. VERIFIED_RUNTIME_OR_READBACK_EVIDENCE
2. VERIFIED_CURRENT_PROJECT_STATE
3. FROZEN_MANIFEST_AND_HASH
4. EXPLICIT_HANDOFF_WITH_VALID_BASE
5. AUDITED_ARCHITECTURE_SOURCE
6. HISTORICAL_OR_LEGACY_EVIDENCE
7. UNVERIFIED_CLAIM
```

```text
FILENAME_ONLY_AUTHORITY=FORBIDDEN
DESIGN_ASSUMPTION_AS_IMPLEMENTED_STATE=FORBIDDEN
```

Jede Übernahme erhält Provenienz: Quelle, Version, Hash, Entscheidung und Adaptionsumfang.

---

## 24. Least-Invasive Integration Resolver

Für bestehende Systeme wird der kleinste sichere Integrationsmodus gewählt:

```text
OBSERVER       = lesen, analysieren, nicht verändern
GUARD          = Eingabe-/Ausgabe- und Sicherheitsprüfung ergänzen
SIDECAR        = Continuity, Audit und Recovery parallel ohne Core-Mutation
WRAPPER        = vorhandene Ein-/Ausgänge schützen
TARGETED_PATCH = lokal belegten Fehler mit Rollback reparieren
INTEGRATED_ADAPTER = freigegebene Continuity-Funktion unter Hostautorität
```

Auswahlregeln:

```text
UNKNOWN_SYSTEM→OBSERVER
STABLE_SYSTEM_WITH_GAP→GUARD_OR_SIDECAR
CLEAR_ENTRY_EXIT_POINTS→WRAPPER
VERIFIED_LOCAL_DEFECT→TARGETED_PATCH
666PFS_ACTIVE_AND_AUTHORIZED→INTEGRATED_ADAPTER
```

Ein vollständiger Core-Merge bleibt verboten.

---

## 25. Hook-Modell

Zulässige additive Hooks:

```text
PRE_INPUT_HOOK
PRE_EXECUTION_HOOK
ROUTING_HOOK
PRE_WRITE_HOOK
POST_EXECUTION_HOOK
VALIDATION_HOOK
ERROR_HOOK
ROLLBACK_HOOK
BACKUP_HOOK
HANDOFF_HOOK
INTERRUPTION_HOOK
RESUME_HOOK
```

Hooks dürfen bestehendes Core-Verhalten nur nach ausdrücklicher Autorisierung ändern.

---

## 26. Append-only Memory Ledger

Das Ledger ist technische Projektkontinuität, nicht automatische Chat-Erinnerung.

```text
LEDGER_MODE=APPEND_ONLY
NO_SILENT_HISTORY_REWRITE=true
```

Einträge enthalten mindestens:

```text
ENTRY_ID
TIMESTAMP_UTC
PROJECT_ID
CHAT_ID
SYSTEM_ID
EVENT_TYPE
USER_REQUEST_SUMMARY
DECISION
RATIONALE_SUMMARY
AFFECTED_COMPONENTS
FILES_CHANGED
FILES_PRESERVED
INVALIDATED_ASSUMPTIONS
RISKS
ROLLBACK_METHOD
VALIDATION_RESULT
AUDIT_RESULT
RELATED_ENTRY_IDS
```

Korrekturen erzeugen einen neuen Eintrag und referenzieren den überholten Eintrag über `SUPERSEDES`.

---

## 27. Dependency- und Impact-Graph

Knoten:

```text
SYSTEM MODULE WORKFLOW FILE API CONNECTOR STORAGE_TARGET
OUTPUT_CONTRACT SECURITY_GUARD TASK CHECKPOINT HANDOFF EVENT
```

Kanten:

```text
DEPENDS_ON READS_FROM WRITES_TO CALLS ROUTES_TO VALIDATES WRAPS
MONITORS BACKS_UP RESTORES SUPERSEDES PRESERVES CONFLICTS_WITH
```

Vor jeder Änderung:

```text
CHANGED_NODE
→ DIRECT_DEPENDENCIES
→ CRITICAL_INDIRECT_DEPENDENCIES
→ AFFECTED_INTERFACES_AND_OUTPUTS
→ REGRESSION_TEST_SELECTION
→ ROLLBACK_BOUNDARY
→ APPROVE_OR_BLOCK
```

---

## 28. Deterministische Event Engine

Jedes Ereignis besitzt genau eine ID, einen Haupt-Handler und einen Endvalidator.

```text
ONE_EVENT_ID=true
ONE_PRIMARY_HANDLER=true
OPTIONAL_SUPPORT_HANDLERS=true
ONE_FINAL_VALIDATOR=true
IDEMPOTENCY_KEY_REQUIRED_FOR_WRITES=true
```

Kernereignisse:

```text
EVENT_USER_REQUIREMENT_ADDED
EVENT_USER_CORRECTION
EVENT_USER_INTERRUPTION
EVENT_EXISTING_SYSTEM_DETECTED
EVENT_NEW_CHAT_STARTED
EVENT_AUDIT_FAILED
EVENT_REPAIR_COMPLETED
EVENT_STATE_DIVERGENCE_DETECTED
EVENT_LOCK_CONFLICT
EVENT_RESUME_REQUESTED
EVENT_ROLLBACK_REQUIRED
```

Ohne reale Runtime werden Ereignisse nur im aktuellen Ausführungsgang verarbeitet; es gibt keine erfundene Hintergrund-Eventschleife.

---

## 29. Hierarchischer Lock-, Queue- und Wait-Marker-Controller

Locks werden nur benötigt, wenn ein realer gemeinsamer Hostzustand geschrieben wird.

```text
LOCK_CONFLICT
→ CREATE_WAIT_MARKER
→ PRESERVE_LOCAL_CHANGESET
→ RETURN_WAITING
→ ON_NEXT_USER_DRIVEN_EXECUTION_READ_MARKER
→ REFRESH_CANONICAL_STATE
→ REBASE
→ REAUDIT
→ ACQUIRE_OWN_LOCK
→ COMMIT
```

Ein Wait Marker ist keine Hintergrundwarteschleife.

```text
CONTINUOUS_BACKGROUND_WAIT_CLAIM=FORBIDDEN
```

Lockdatensätze enthalten Scope, Basisversion, Basishash, Lease und Release-Evidenz. Stale Locks dürfen nicht still übernommen werden.

---

## 30. Secure Import, Path und Secret Policy

### 30.1 Originalschutz

```text
ORIGINAL_ARCHIVE_MUTATION=FORBIDDEN
WORK_COPY_REQUIRED=true
```

### 30.2 Pfadgrenzen

- lexikalische Zielprüfung,
- reale Pfadprüfung,
- Symlink-Ausbruch blockieren,
- absolute Fremdpfade blockieren,
- Ziel muss innerhalb der freigegebenen Root liegen,
- ZIP-Slip und unsichere Archivpfade blockieren.

### 30.3 Ressourcenlimits

Für Dateiimporte werden konfigurierbare Limits für Anzahl, Einzelgröße, Gesamtgröße, Rekursion, Archivtiefe und Kompressionsverhältnis verlangt. Binärdateien und sensible Dateitypen werden standardmäßig ausgeschlossen.

### 30.4 Secret-Schutz

```text
SECRETS_IN_PROMPTS=FORBIDDEN
SECRETS_IN_LOGS=FORBIDDEN
SECRETS_IN_ARTIFACTS=FORBIDDEN
SECRET_STORE_REQUIRED_WHEN_PERSISTING=true
MASKED_REFERENCES_ONLY=true
```

### 30.5 Prozessausführung

```text
SHELL_INTERPOLATION=FORBIDDEN
ARGUMENT_BASED_PROCESS_EXECUTION=REQUIRED
```

Installer, Package-Lifecycle-Skripte, Modellstarts und fremde Binaries werden während einer reinen Inspektion nicht ausgeführt.

---

## 31. Exact Patch und Write Gate

Für KI-generierte Änderungen an vorhandenen Textdateien gilt:

```text
TARGET_FILE_EXPLICIT=true
EXPECTED_BASE_HASH_REQUIRED=true
SEARCH_ANCHOR_MATCH_COUNT=EXACTLY_ONE
ZERO_MATCH→BLOCK
MULTIPLE_MATCHES→BLOCK
WRITE_TO_WORK_COPY_FIRST=true
DIFF_REVIEW_REQUIRED=true
ATOMIC_COMMIT_REQUIRED=true
POST_WRITE_READBACK_REQUIRED=true
```

Leere oder vollständige Dateiersetzungen benötigen eine gesonderte `REPLACE`-Autorisierung und Pre-Change-Backup.

Bei hohem Risiko ist eine ausdrückliche Bestätigung vor dem Write erforderlich.

---

## 32. Canonical State versus Draft State

```text
CANONICAL_STATE != DRAFT_STATE
```

Projektquellen, Seeds, Unterbrechungsdeltas und lokale Arbeitsentwürfe dürfen nicht automatisch in kanonische Systemdateien zurückgeschrieben werden.

```text
DRAFT_TO_CANONICAL_REQUIRES=
VALIDATION+AUDIT+FREEZE_OR_APPROVAL_GATE
```

Doppelte IDs, defekte Referenzen und nicht deklarierte Abhängigkeiten blockieren die Übernahme.

---

## 33. System-only Backup Profile

Ein sauberes Systemsicherungsprofil enthält:

- System- und Bootstrap-Spezifikation,
- Registries und Schemata,
- Audit, Repair Ledger und ReAudit,
- Freeze, Changelog, Handoff,
- Verifikationswerkzeuge und Prüfsummen.

Standardmäßig ausgeschlossen:

- Chat- und Suchverläufe,
- Caches und temporäre Dateien,
- Nutzeruploads und Medien,
- generierte Laufzeitausgaben,
- extrahierte Fremdarchive,
- Secrets und Credentials,
- historische Releasearchive innerhalb des neuen Releasearchivs.

Die Source-Provenienz wird über Namen, Hashes, Prüfstatus und Integrationsledger erhalten.

---

## 34. Adaptive Lifecycle und Checkpoints

Nicht jeder Auftrag benötigt den kompletten Releasezyklus. Sicherheitsgates bleiben jedoch verpflichtend.

```text
STATUS_ONLY→INTAKE→STATUS_RENDER
SOURCE_REVIEW→DISCOVER→OBSERVER→AUDIT→REPORT
DEVELOPMENT_DELTA→FULL_CONTINUITY_CHAIN
SYSTEM_CHANGE→FULL_LIFECYCLE
PERSISTENT_WRITE→VALIDATE→LOCK→WRITE→READBACK→LEDGER
```

Erweiterte Checkpoints:

```text
CP01_INPUT_NORMALIZED
CP02_CONTEXT_AND_AUTHORITY_RESOLVED
CP03_ARCHITECTURE_AND_DEPENDENCIES_MAPPED
CP04_CHANGESET_APPROVED
CP05_IMPLEMENTATION_COMPLETE
CP06_VALIDATION_PASSED
CP07_AUDIT_PASSED
CP08_SELF_HEALING_PASSED
CP09_REAUDIT_PASSED
CP10_FREEZE_CREATED
CP11_LOCAL_BACKUP_VERIFIED
CP12_HOST_COMMIT_VERIFIED_IF_APPLICABLE
CP13_REGISTRY_AND_LEDGER_UPDATED_IF_APPLICABLE
```

Unterbrechungen invalidieren nur direkt widersprochene Checkpoints und setzen am letzten weiterhin gültigen Checkpoint fort.

---

## 35. Recovery Order

```text
BLOCK_WRITES
→ ACQUIRE_RECOVERY_LOCK_IF_APPLICABLE
→ READ_COMMIT_EVIDENCE
→ IDENTIFY_LAST_VERIFIED_STATE
→ VERIFY_SCOPE_AND_AUTHORITY
→ CREATE_PRE_RECOVERY_SNAPSHOT
→ RESTORE_MANIFEST
→ RESTORE_FOUNDATION_AND_LIFECYCLE
→ RESTORE_REGISTERS
→ RESTORE_RESUME_STATE
→ VALIDATE
→ RESTORE_POINTERS_LAST_IF_APPLICABLE
→ FULL_AUDIT
```

---

## 36. Architecture Decision Records

Bedeutende Architekturentscheidungen werden als ADR dokumentiert:

```text
ADR_ID TITLE STATUS DATE_UTC CONTEXT DECISION RATIONALE
ALTERNATIVES_CONSIDERED CONSEQUENCES AFFECTED_COMPONENTS
MIGRATION_IMPACT ROLLBACK_PATH RELATED_DEPENDENCIES
```

Status: `PROPOSED`, `ACCEPTED`, `SUPERSEDED`, `DEPRECATED`, `REJECTED`.

ADR-Pflicht besteht für Moduswechsel, Bootstrap-/Routingänderungen, Speicherziele, Sicherheitsmodelle, Datenmodelle, Migrationen und irreversible Entscheidungen.

---

## 37. Help-, Start- und Statusvertrag

Help und Diagnose sind read-only.

```text
HELP_READ_ONLY=true
HELP_CAN_WRITE=false
HELP_CAN_ACQUIRE_LOCK=false
```

Fehlt eine Startabhängigkeit:

```text
START_STATUS=DEGRADED_READ_ONLY
```

Ausgabe muss die fehlende Abhängigkeit, den zulässigen Read-only-Umfang und die nächste sichere Aktion nennen. Es dürfen keine Registry, Version, Pointer oder Fortschrittswerte erfunden werden.

```text
UNKNOWN_PROGRESS=NOT_MEASURABLE
MEASURED_PROGRESS_ONLY=true
```

---

## 38. Acceptance Gates

Ein Release oder Host-Adapter gilt nur als freigabefähig, wenn:

```text
ARCHIVE_AND_PATH_SAFETY=PASS
SOURCE_HASHES=PASS
IDENTITY_AND_AUTHORITY=PASS
CURRENT_CHAT_SCOPE=PASS
PROJECT_SOURCE_READ_ONLY=PASS
INTERRUPTION_STACK=PASS
SELF_AGREEMENT=PASS
SELF_HEALING=PASS
CHECKPOINT_RESUME=PASS
DEPENDENCY_GRAPH=PASS
EVENT_IDEMPOTENCY=PASS
PATCH_GATE=PASS
SECRET_SCAN=PASS
AUDIT=PASS
REAUDIT=PASS
VERSION_SEAL=PASS
ZIP_CRC=PASS
SHA256_MANIFEST=PASS
```

Host-, Drive- oder Runtime-Tests, die nicht ausgeführt wurden, bleiben ausdrücklich `NOT_PERFORMED`.

---

## 39. Freeze-Regeln

Dieser Freeze fixiert zusätzlich zu FREEZE_01:

- Evidence-/Provenance-Hierarchie,
- explizite Handoff- und Driftvalidierung,
- Observer/Guard/Sidecar/Wrapper/Targeted-Patch-Modi,
- Hook-Modell,
- append-only Memory Ledger,
- Dependency-/Impact-Graph,
- Event Engine mit Idempotency-Gate,
- hierarchische Locks und Wait Marker,
- Secure Import/Path/Secret Policy,
- Exact-Patch-Vertrag,
- Draft-/Canonical-Trennung,
- System-only Backup Profile,
- Recovery Order,
- ADR- und truthful-status Governance.

Änderungen nach diesem Freeze benötigen:

```text
VERSION_INCREMENT
CHANGELOG
PRE_INTEGRATION_AUDIT
REPAIR_LEDGER_IF_REQUIRED
REAUDIT
NEW_FREEZE
NEW_HASHES
```

---

## 40. Vorheriger Freeze-Status

```text
SYSTEM_ID=UCCF-CORE-001
VERSION=1.3.0
FREEZE=FREEZE_04
SPECIFICATION_STATUS=FROZEN_LOCAL_CANDIDATE
SOURCE_REVIEW_STATUS=COMPLETE
SOURCE_ARCHIVES_MUTATED=false
OPERATIONAL_DEPLOYMENT=NOT_PERFORMED
666PFS_MUTATION=NOT_PERFORMED
LYVRA_MUTATION=NOT_PERFORMED
DRIVE_WRITE=NOT_PERFORMED
EXTERNAL_RUNTIME=NOT_IMPLEMENTED
CURRENT_CHAT_SYSTEM_PACKAGE=COMPLETE
```



## 41. Systemgrößen- und Preservation-Klassifizierung

Vor umfangreichen Änderungen wird die Systemklasse bestimmt:

```text
SMALL_TASK
MODULAR_SYSTEM
FRAMEWORK
LINGUISTIC_OPERATING_SYSTEM
LARGE_SYSTEM
```

Die Einstufung erfolgt nicht allein anhand der Dateigröße. Bewertet werden:

- Register- und Guard-Tiefe,
- Bootstrap- und Recovery-Struktur,
- Versions- und Freeze-Historie,
- Abhängigkeitsdichte,
- Anzahl aktiver Autoritäts- und Speicherpfade,
- externe Baseline- und Asset-Referenzen.

Für große oder historisch gewachsene Systeme gilt:

```text
COMPLEXITY_IS_NOT_AUTOMATICALLY_DEFECT=true
HIDDEN_DEPENDENCIES_ASSUMED_UNTIL_AUDITED=true
AGGRESSIVE_SIMPLIFICATION=FORBIDDEN
```

UCCF selbst wird als `FRAMEWORK_WITH_LARGE_SYSTEM_GOVERNANCE` klassifiziert.

---

## 42. No-Habituation- und Structural-Memory-Guard

Eine Regel, ein Guard, ein Register, ein Audit-Schritt oder ein Recovery-Pfad wird nicht entfernbar, nur weil er:

- lange nicht erwähnt wurde,
- stabil funktioniert,
- wiederholt erscheint,
- selbstverständlich wirkt,
- älter als aktuelle Deltas ist.

Entfernung ist nur erlaubt, wenn:

```text
EXPLICIT_USER_REMOVAL_REQUEST=true
DEPENDENCY_AUDIT=PASS
ROLLBACK_OR_RECOVERY_PATH=AVAILABLE
REMOVAL_DOCUMENTED=true
REAUDIT_AFTER_REMOVAL=PASS
```

Standard:

```text
DO_NOT_REMOVE
DO_NOT_SILENTLY_COMPRESS
DO_NOT_REWRITE_AS_SMALLER_SYSTEM
```

---

## 43. Source Candidate, Contamination und Claim Validation

Jede neue Datei, jedes ZIP, jeder Handoff und jede Textquelle beginnt als:

```text
SOURCE_CANDIDATE
```

Mögliche Klassen:

```text
ACTIVE_CORE_CANDIDATE
COMPATIBLE_MODULE_CANDIDATE
EXTERNAL_OR_CONDITIONAL_PROFILE
LEGACY_OR_ARCHIVE
CHAT_NOISE
UNKNOWN_PENDING
QUARANTINE_OR_BLOCKER
```

Prüfungen:

1. reale Datei statt Dateiname,
2. SHA-256 und Pfadsicherheit,
3. Roh- und Normalized-Duplicate-Check,
4. Placeholder-Flood-Erkennung,
5. Versionslinie,
6. Authority und Scope,
7. Secret- und Claim-Prüfung,
8. Dependency- und Konfliktprüfung.

Wörter wie `ACTIVE`, `PASS`, `FREEZE`, `BACKUP`, `COMPLETE` oder `FULLVERSION` sind kein Beweis.

```text
STATUS_LABEL != EVIDENCE
FILENAME != FILE_CONTENT
ARCHIVE != ACTIVE_RUNTIME
```

---

## 44. Safe Mode und kontrollierter Hold

Safe Mode ist kein Fehlerzustand, sondern eine kontrollierte Sperre bei kritischer Unsicherheit.

Automatische Gründe:

- ungültiges oder fehlendes Manifest,
- nicht eindeutige Autorität,
- doppelte aktive Wurzeln,
- Placeholder-Flood,
- gebrochene Prüfsumme,
- Secret-Risiko,
- unbestätigter Freeze-/Backup-Claim,
- widersprüchliche Output- oder Runtime-Verträge,
- Repair und Runtime gleichzeitig aktiv,
- wiederholt fehlerhaftes Ergebnis trotz angeblicher Reparatur.

Safe Mode darf:

- lesen,
- hashen,
- vergleichen,
- klassifizieren,
- Fehlerbericht und Repair-Plan erstellen,
- nicht destruktive Reparaturkopien vorbereiten.

Safe Mode darf nicht:

- fremde Systeme starten,
- Runtime freigeben,
- Zielsysteme mutieren,
- Freeze oder Backup behaupten,
- konkurrierende Ersatzarchitektur bauen.

Exit nur nach:

```text
CRITICAL_STATE_UNDERSTOOD=true
MANDATORY_DEPENDENCIES_PRESENT=true
REAUDIT=PASS
NEXT_ROUTE=EXPLICIT
```

---

## 45. Context Capacity und Repair Feasibility

Vor großen Reparaturen wird konservativ geprüft, ob der aktuelle Chat die Arbeit zuverlässig tragen kann.

```text
EXACT_CHAT_CAPACITY_MEASUREMENT=UNAVAILABLE
FAKE_CAPACITY_PERCENTAGES=FORBIDDEN
```

Risikoklassen:

```text
LOW       -> Full Repair möglich
MEDIUM    -> Staged Repair + Mini-Checkpoint
HIGH      -> Full Repair blockiert; Snapshot/Handoff zuerst
CRITICAL  -> Emergency Snapshot only
```

Geprüft werden:

- Quellenmenge,
- offene Unterbrechungen,
- Zahl abhängiger Arbeitsschritte,
- Umfang notwendiger Dateiverarbeitung,
- erwartete Audit- und Readback-Schritte,
- verbleibende Evidenzlücken.

Bei `HIGH` oder `CRITICAL` wird kein anderer Chat automatisch gestartet. UCCF erzeugt nur einen sicheren Handoff oder Snapshot.

---

## 46. Emergency Snapshot und Current-Chat-Rescue

Wenn der aktuelle Chat eine große Reparatur nicht mehr sicher tragen kann:

1. aktives System und Projekt nennen,
2. Hauptauftrag und letzten verifizierten Checkpoint sichern,
3. offene Unterbrechungen vollständig registrieren,
4. bekannte Fehler und fehlende Quellen markieren,
5. Selbsteinigungs- und Selbstheilungsstatus sichern,
6. nächsten sicheren Schritt definieren,
7. kompakten Handoff erzeugen,
8. keine erfundene Rekonstruktion verwenden.

```text
SECURE_BEFORE_LARGE_REPAIR=true
OTHER_CHAT_AUTOSTART=FORBIDDEN
```

---

## 47. Post-Boot Authority Audit

Nach Bootstrap-/State-Recovery und vor Runtime wird geprüft:

- welche Authority tatsächlich aktiv ist,
- ob Registry, Manifest und Hashes zusammenpassen,
- ob Bootfix nur Recovery-Funktion besitzt,
- ob degradierte oder placeholderlastige Dateien fälschlich aktiv sind,
- ob Warnungen payloadrelevant oder kontrolliert sind,
- ob genau ein produktiver Pfad existiert,
- ob der Current-Chat-Scope erhalten ist.

Ergebnisse:

```text
PASS
PASS_WITH_CONTROLLED_WARNING
DEGRADED_REFERENCE_ONLY
REPAIR_REQUIRED
BLOCKED
```

`PASS_WITH_CONTROLLED_WARNING` darf Runtime nur freigeben, wenn keine Warnung den aktiven Payload oder die Scope-Sicherheit betrifft.

---

## 48. Route Resolver

Nach Intake, Smart Filter, Safe Mode und Post-Boot-Audit wird genau eine Route gewählt:

```text
DIRECT_TASK
RECOVERY_DIAGNOSTIC
INTEGRATION_REPAIR
VERIFIED_RUNTIME
```

### DIRECT_TASK

Ein klarer Benutzerauftrag wird nicht durch unnötige Menüs oder wiederholte Intake-Fragen blockiert. Schutz- und Source-Gates bleiben aktiv.

### RECOVERY_DIAGNOSTIC

Read-only bei unklarem Zustand, fehlender Authority oder beschädigtem Manifest.

### INTEGRATION_REPAIR

Nur mit belegtem Defekt, Repair-Plan, klarer Dateiliste und freigegebenem Scope.

### VERIFIED_RUNTIME

Nur bei gültigem Zustand, geladenen Pflichtabhängigkeiten und ohne roten Blocker.

```text
ONE_ACTIVE_ROUTE=REQUIRED
PARALLEL_PRODUCTION_ROUTES=FORBIDDEN
```

---

## 49. Defect-Gate Self-Fail

Wird ein als repariert gemeldetes Ergebnis erneut als fehlerhaft erkannt:

```text
GATE_STATUS=SELF_FAIL
OUTPUT_STATUS=HOLD
```

Dann wird nicht blind das gesamte Paket erneut gebaut.

Ablauf:

1. konkreten Defekt isolieren,
2. verantwortliches Gate identifizieren,
3. reduzierten Reparaturgegenstand bilden,
4. Gate reparieren,
5. reduziertes Ziel validieren,
6. erst danach Gesamtpaket neu bauen,
7. ReAudit durchführen.

---

## 50. Functional Visual Output Governance

Visuelle Ausgabe unterstützt Entscheidungen, ersetzt aber keine Evidenz.

Regeln:

- Farbe oder Emoji darf nie allein die Bedeutung tragen.
- Status muss zusätzlich als Text erscheinen.
- Balken nur bei realer Bewertung.
- Jeder Wert wird als `Measured`, `Estimated`, `Pending` oder `N/A` markiert.
- Keine Fake-Präzision.
- Plaintext bleibt zulässig, wenn Code, Maschinenlesbarkeit oder Barrierefreiheit dies erfordern.
- Signifikante Audits erhalten klare Status-, Risiko- und Decision-Gate-Struktur.
- Visuelle Elemente dürfen nicht zur Dekoration erzwungen werden.

```text
FORCED_PERCENTAGE=FORBIDDEN
COLOR_ONLY_MEANING=FORBIDDEN
FUNCTIONAL_VISUALIZATION_ONLY=true
```

---

## 51. Reality Evidence und Backup Truth

Zulässige Evidenzzustände:

```text
VERIFIED_CURRENT
DEFINED_IN_CURRENT_CHAT
KNOWN_REFERENCE
TEMPLATE_ONLY
MISSING_SOURCE
RECONSTRUCTED_MARKED
REDACTED_SECRET
GENERATED_INDEX
DEGRADED_REFERENCE_ONLY
```

Nur `VERIFIED_CURRENT` und `DEFINED_IN_CURRENT_CHAT` dürfen als direkte Systemsubstanz behandelt werden.

Verboten:

- ZIP-Inhalte behaupten, ohne sie zu lesen,
- nicht verfügbare Quellen nacherfinden,
- Backup mit Fülltext künstlich vergrößern,
- Template als verifizierte Datei darstellen,
- Freeze oder Backup melden, bevor das Artefakt existiert.

---

## 52. Backup-Klassen und Release Gate

Backup-Klassen:

```text
FULL_SYSTEM_BASELINE
GOVERNANCE_DELTA_BACKUP
COMPONENT_BACKUP
ASSET_BASELINE_REFERENCE
FREEZE_SNAPSHOT
RECOVERY_HANDOFF
```

Jede Sicherung benötigt:

- System-ID und Version,
- Backup-Klasse,
- enthaltene Dateien,
- externe Referenzen,
- Größen und SHA-256,
- Audit-, Self-Healing- und Freeze-Status,
- offene Risiken,
- Recovery-Hinweise.

Eine Komponentensicherung darf nicht als Full Baseline bezeichnet werden.

Freeze und Systemsicherung sind nur zulässig nach:

```text
AUDIT=PASS
SELF_HEALING=PASS_OR_NOT_REQUIRED
REAUDIT=PASS
CRITICAL_BLOCKERS=0
MANIFEST=COMPLETE
LOCAL_READBACK=PASS
```

---

## 53. Semantische Vollständigkeit statt Größen-Hardlock

Dateigröße ist ein Warnsignal, aber kein Vollständigkeitsbeweis.

Prüfgrundlage:

- erforderliche Abschnittsabdeckung,
- Modul- und Exportinventar,
- Dependency Map,
- Manifest,
- Tests,
- Hashes,
- geänderte Dateien,
- geschützte Verhaltensverträge.

```text
SIZE_DROP=WATCH
MISSING_REQUIRED_CONTENT=FAIL
SEMANTICALLY_COMPLETE_AND_VALIDATED=PASS
```

Originalquellen bleiben als Evidenz erhalten. Aktive Dateien dürfen gezielt ersetzt werden, wenn die Ersatzimplementierung validiert ist und keine parallelen aktiven Handler verbleiben.

---

## 54. Erweiterte Kausalkette

```text
CURRENT USER TASK
→ INPUT SNAPSHOT
→ SOURCE REGISTRATION
→ SYSTEM SCALE CLASSIFICATION
→ CONTAMINATION CLASSIFICATION
→ SOURCE QUALITY / CLAIM VALIDATION
→ CONTEXT CAPACITY / REPAIR FEASIBILITY
→ SAFE MODE GATE
→ BOOTSTRAP DISCOVERY
→ STATE RECOVERY
→ POST-BOOT AUTHORITY AUDIT
→ ROUTE RESOLVER
→ INTERRUPTION CAPTURE
→ CAUSAL DELTA ANALYSIS
→ PROJECT REUSE SEARCH
→ SELF AGREEMENT
→ CONTROLLED INTEGRATION
→ AUDIT
→ CAUSAL SELF HEALING
→ REAUDIT
→ SELF AGREEMENT REVALIDATION
→ CHECKPOINT COMMIT
→ CURRENT CHAT RESUME
```


---

## 55. Source-Scope-Klassifizierung und Kernextraktion

Vor jeder Übernahme wird das konkrete Audit-Ziel sichtbar benannt. Quellen werden als `CORE_RELEVANT`, `PARTIAL_RELEVANT`, `REFERENCE_ONLY`, `FOREIGN_SCOPE`, `QUARANTINE` oder `SUPERSEDED` klassifiziert.

```text
WHOLE_SOURCE_BLIND_MERGE=FORBIDDEN
KERNEL_EXTRACTION_WITH_PROVENANCE=REQUIRED
FOREIGN_DOMAIN_PAYLOAD_IN_CORE=FORBIDDEN
```

Nur die belegten systemneutralen Kerne werden in den kleinsten sicheren UCCF-Scope übernommen.

---

## 56. Candidate Promotion und Baseline Overlay

Ein auditierter Kandidat überschreibt niemals automatisch den letzten verifizierten Freeze.

```text
BASELINE=1.3.0/FREEZE_04
CANDIDATE=1.4.0/FREEZE_05
REVIEW_PASS != CANONICAL_PROMOTION
CANONICAL_POINTER_UPDATE=LAST
EXPLICIT_PROMOTION_AUTHORITY=REQUIRED
```

Candidate-Systemsicherung und kanonische Promotion sind getrennte Transaktionen.

---

## 57. Artifact Parity und Payload Regression

Neue Regeln müssen in allen owning artifacts gespiegelt sein: Hauptspezifikation, Register, Audit, Changelog, Handoff, Inventory und Tests.

```text
ZIP_SIZE_ONLY_DECISION=FORBIDDEN
UNCOMPRESSED_PAYLOAD_CHECK=REQUIRED
CONTENT_FILE_COUNT_CHECK=REQUIRED
ARTIFACT_PARITY_CHECK=REQUIRED
EMPTY_OR_PLACEHOLDER_PACKAGE=BLOCK
```

Eine kleinere komprimierte ZIP-Größe ist allein kein Fehler. Ein unbegründeter Verlust von Pflichtdateien, Nutzlast, Registern oder Rekonstruktionsfähigkeit führt zu `PAYLOAD_REGRESSION_HOLD`.

---

## 58. Register Pickup Zones

Die Registry stellt getrennte Pickup-Zonen für Boot, Recovery, Freeze, Output, Multi-System-Beziehungen, Master-Core, Projektwiederverwendung und Prompt-Assets bereit. Adapter erhalten nur ihren relevanten Teilausschnitt; das Masterregister wird nicht blind kopiert.

---

## 59. Desired-State Control Plane

Lokale GUIs und Command Panels dürfen gewünschte Zustände und Kommandos erzeugen, behaupten aber keine Runtime.

```text
DESIRED_STATE != VERIFIED_RUNTIME_STATE
COMMAND_GENERATED != COMMAND_EXECUTED
LOCAL_STATE_PERSISTENCE_SCOPE=MUST_BE_DECLARED
```

`VERIFIED_RUNNING` benötigt einen realen Ausführungsbeleg.

---

## 60. Prompt Artifact Registry

Wiederverwendbare Prompt-Assets können mit ID, Typ, Kategorie, Tags, Variablen, Sichtbarkeit, Version und Provenienz registriert werden. Verbesserungen erzeugen Candidate-Revisions; aktive Prompts werden nicht still überschrieben. Externe Promptdienste sind optionale Adapter und benötigen Connector, Authentifizierung und Write-Autorisierung.

---

## 61. Three-Pillar Self-Governance und Assembly Gate

Release-Vollständigkeit benötigt gleichzeitig:

1. Boot und State Recovery,
2. Audit und kontrollierte Reparatur,
3. Backup, Recovery und portables Handoff.

Fragmente, Chat-Reste, unowned rules und fehlende Dependencies dürfen nicht als vollständiges System exportiert werden.

---

## 62. Checksum Manifest Scope

```text
PACKAGE_RELATIVE_CHECKSUM_PATHS=REQUIRED
SELF_REFERENTIAL_CHECKSUM=FORBIDDEN
DETACHED_EXTERNAL_RECEIPT=ALLOWED_WHEN_DECLARED
HASH_PASS != SEMANTIC_COMPLETENESS_PASS
```

---

## 63. Missing Artifact und Recovery Modes

Fehlende deklarierte Quellen oder Pflichtartefakte werden dokumentiert, nicht rekonstruiert behauptet. Recovery kann als Full, Partial, Module, Boot, Trigger, Output, Registry oder Checkpoint Recovery klassifiziert werden.

---

## 64. Vorherige UCCF-v1.3.0-Freeze-Erweiterung

```text
SYSTEM_ID=UCCF-CORE-001
VERSION=1.3.0
FREEZE=FREEZE_04
SOURCE_SET_COUNT=10
TOP_LEVEL_ZIP_CRC=8/8_PASS
NESTED_ZIP_CRC=17/17_PASS
SOURCE_ORIGINALS_MUTATED=false
666PFS_MUTATION=NOT_PERFORMED
LYVRA_MUTATION=NOT_PERFORMED
DRIVE_WRITE=NOT_PERFORMED
```

---

## 65. Kanonische Hierarchie und zweistufige Quellenverarbeitung

Die maschinenlesbare Hierarchie in `02_BOOTSTRAP/BOOT_STAGE_REGISTRY.json` ist die kanonische Ladeordnung. Textuelle Ablaufdarstellungen sind erläuternde Ansichten und dürfen dieser Registry nicht widersprechen.

Quellen werden bewusst zweistufig verarbeitet:

```text
SOURCE_SAFETY_PREFLIGHT
→ nur Pfad-, Archiv-, Secret-, Größen- und Originalschutz

SOURCE_SCOPE_CLASSIFICATION
→ erst nach Identität, Autorität, Projekt-Scope und State-Recovery
```

Dadurch wird eine Quelle sicher gelesen, bevor sie interpretiert wird, ohne ihre fachliche Relevanz vor der System- und Scope-Klärung zu behaupten.

```text
ONE_CANONICAL_STAGE_REGISTRY=true
TEXTUAL_ORDER_CONFLICT→HIERARCHY_CONFLICT
HIERARCHY_CONFLICT→BLOCK_RUNTIME
```

---

## 66. Kausaler Continuity-Transaktionsvertrag

Jede Unterbrechung wird in genau einer chatlokalen Continuity-Transaktion verarbeitet:

```text
CAPTURED
→ ANALYZED
→ AGREEMENT_VALID
→ WORKING_COPY_UPDATED
→ AUDITED
→ HEALED_IF_REQUIRED
→ REAUDITED
→ AGREEMENT_REVALIDATED
→ CHECKPOINT_COMMITTED
→ RESUME_READY
→ CURRENT_CHAT_RESUMED
```

Die Transaktion besitzt Basishash, Checkpoint, Interruptions-IDs, Aufgabenbesitzer, Working-Copy-ID, Audit-/Repair-/ReAudit-Receipts und eine Idempotency-ID. Ein Fehler nach Working-Copy-Änderung führt zu `ROLLBACK_REQUIRED` oder `CONFLICT_QUARANTINE`, nicht zu stiller Teilfortsetzung.

---

## 67. Manager-Kopplung und Verantwortungsgrenzen

```text
InterruptionManager
→ darf erfassen, aber nicht selbst integrieren

CausalSelfAgreementManager
→ bestimmt Authority und Task Owner, führt aber keinen Write aus

IntegrationManager
→ verändert nur Working Copy oder freigegebenen Host-Scope

AuditManager
→ bewertet, repariert nicht

CausalSelfHealingManager
→ repariert nur belegte lokale Defekte

ReAuditManager
→ prüft den reparierten Zustand unabhängig erneut

CurrentChatResumeManager
→ setzt nur bei vollständigem Gate-PASS fort
```

Jede Manager-Grenze ist in `12_GOVERNANCE/MANAGER_CONTRACTS.json` maschinenlesbar hinterlegt.

---

## 68. Checkpoint-, Invalidierungs- und Resume-Queue-Modell

Ein Checkpoint wird nicht global verworfen. Eine Unterbrechung nennt ausdrücklich, welche Checkpoints und Schritte betroffen sind.

```text
INVALIDATE_DIRECT_CONTRADICTIONS_ONLY=true
PRESERVE_UNAFFECTED_CHECKPOINTS=true
RESUME_QUEUE_SCOPE=CURRENT_CHAT_ONLY
```

Die Resume Queue enthält Originalreihenfolge, Abhängigkeiten, Unterbrechungsursache, Wiederaufnahmebedingung und letzten verifizierten Checkpoint. Aufgaben aus anderen Chats oder Projekten werden beim Einlesen abgewiesen.

---

## 69. Runtime-Receipt und ehrliche Hintergrundausführung

Eine technische Hintergrundausführung gilt nur mit einem Runtime-Receipt, das Job-ID, Host, Startzeit, Status, Checkpoint, Scope und Evidenz enthält.

```text
NO_RUNTIME_RECEIPT→LOGICAL_CONTINUATION_ONLY
RUNTIME_RECEIPT_SCOPE_MISMATCH→BLOCK
BACKGROUND_JOB_MAY_NOT_ACTIVATE_OTHER_CHAT=true
```

---

## 70. Host-Adapter-Vertrag

Ein Host-Adapter muss System-ID, Modus, erlaubte Hooks, Read-/Write-Scope, Authority, Lock-Vertrag, Rollback und Readback definieren. Bei Beteiligung von 666PFS bleibt 666PFS führend.

```text
HOST_ADAPTER_CONTRACT_REQUIRED=true
666PFS_LEADING_AUTHORITY=true
HOST_CORE_MUTATION_WITHOUT_EXPLICIT_SCOPE=FORBIDDEN
```

---

## 71. Schema-Governance

Alle aktiven `*_SCHEMA.json`-Dateien sind echte JSON-Schema-2020-12-Verträge. Informelle Feldlisten gelten nicht mehr als aktive Maschinenschemata.

```text
JSON_SCHEMA_META_VALIDATION=REQUIRED
SCHEMA_FIXTURE_VALIDATION=REQUIRED
ADDITIONAL_PROPERTIES_DEFAULT=FALSE_FOR_STATE_CONTRACTS
```

---

## 72. Artifact Ownership, Current Pointers und Migrationsschutz

Jedes aktive Artefakt besitzt einen Owner, eine Rolle und eine Spiegelpflicht. Aktuelle Spezifikation, Audit, Handoff und Freeze werden über `CURRENT_ARTIFACT_POINTERS.json` adressiert; byte-identische Aliasdateien werden nicht mehr als parallele aktuelle Wahrheit geführt.

Fremde Quellartefakte werden in System-only-Backups nicht eingebettet, sondern über Hash, Größe, Rolle und Verfügbarkeit referenziert.

---

## 73. Erweiterte Verifikationsarchitektur

Der Verifier prüft nicht mehr nur Dateianwesenheit und Token, sondern zusätzlich:

- Schema-Metavalidierung und Fixtures,
- eindeutige, lückenlose Abschnittsnummern,
- Versions- und Freeze-Konsistenz,
- Modul-DAG und Stage-Reihenfolge,
- Event-Handler und Finalvalidatoren,
- State-Transition- und Manager-Verträge,
- Artifact Inventory gegen reale Dateien,
- aktive Dubletten,
- externalisierte Fremdevidenz,
- SHA-256 und Secret-Schutz.

---

## 74. Reparierte kanonische Ablaufkette

```text
S00 HOST TASK INTAKE
→ S01 SOURCE SAFETY PREFLIGHT
→ S02 IDENTITY / AUTHORITY / SCOPE
→ S03 BOOTSTRAP DISCOVERY
→ S04 STATE RECOVERY
→ S05 POST-BOOT AUDIT / SINGLE ROUTE
→ S06 INTERRUPTION / TRANSACTION CAPTURE
→ S07 CAUSAL ANALYSIS / PROJECT REUSE / SELF AGREEMENT
→ S08 CONTROLLED WORKING-COPY INTEGRATION
→ S09 AUDIT / SELF-HEALING / REAUDIT
→ S10 CHECKPOINT COMMIT / CURRENT-CHAT RESUME
→ S11 RELEASE / FREEZE / BACKUP WHEN REQUESTED
→ S12 OPTIONAL OUTPUT / CONTROL / PROMPT ASSETS
```

---

## 75. UCCF v1.4.0 Freeze-Erweiterung

```text
SYSTEM_ID=UCCF-CORE-001
VERSION=1.4.0
FREEZE=FREEZE_05
BASELINE=1.3.0/FREEZE_04
CURRENT_AUDIT_SOURCE_COUNT=1
INHERITED_SOURCE_LINEAGE=10
EXECUTION_SCOPE=CURRENT_CHAT_ONLY
PROJECT_SEARCH_SCOPE=CURRENT_PROJECT_READ_ONLY
HIERARCHY_STATUS=REPAIRED
SCHEMA_STATUS=REPAIRED
ARTIFACT_PARITY_STATUS=REPAIRED
666PFS_MUTATION=NOT_PERFORMED
LYVRA_MUTATION=NOT_PERFORMED
DRIVE_WRITE=NOT_PERFORMED
HOST_PROMOTION=NOT_PERFORMED
```
