# Prompt Artifact Registry — UCCF 1.4.0

Prompt assets use stable IDs, type, category, tags, variables, visibility, version and provenance. Improvements create candidate revisions; active prompts are not silently overwritten. External prompt services remain optional adapters requiring connector and write authorization.
