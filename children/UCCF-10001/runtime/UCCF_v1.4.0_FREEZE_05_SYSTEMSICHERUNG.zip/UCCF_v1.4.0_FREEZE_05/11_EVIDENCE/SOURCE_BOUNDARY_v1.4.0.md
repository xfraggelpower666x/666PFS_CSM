# Source Boundary — UCCF 1.4.0

Foreign source systems and user uploads are not embedded in this system-only baseline. They remain external read-only evidence referenced by name, size and SHA-256.

```text
FOREIGN_IDENTITY_TRANSFER=FORBIDDEN
FOREIGN_TRIGGER_AUTOLOAD=FORBIDDEN
SOURCE_ORIGINAL_MUTATION=FORBIDDEN
```
