# Missing Artifact and Recovery Mode Controller

Status: ACTIVE IN UCCF v1.3.0

## Missing artifact rule

Mentioned or declared artifacts that are not present are recorded; they are never invented from memory.

```text
MISSING_REQUIRED_ARTIFACT→RECOVERY_HOLD
MISSING_OPTIONAL_ARTIFACT→PARTIAL_WITH_WARNING
DECLARED_SOURCE_MISSING→PARTIAL_ONLY
```

## Recovery modes

```text
FULL_RECOVERY
PARTIAL_RECOVERY
MODULE_RECOVERY
BOOT_RECOVERY
TRIGGER_RECOVERY
OUTPUT_RECOVERY
REGISTRY_RECOVERY
CHECKPOINT_RECOVERY
```

Recovery scope remains the current chat. Other chats are read-only sources and are never reactivated.
