# Artifact Parity and Payload Regression Gate

Status: ACTIVE IN UCCF v1.3.0

A portable release is evaluated by declared content, not compressed ZIP size alone.

## Primary comparisons

- required artifact presence,
- main specification size and semantic section set,
- uncompressed package payload,
- content-file count,
- registry/module/guard coverage,
- manifest and changelog parity,
- artifact inventory,
- ZIP CRC and readback hashes.

Compressed ZIP byte size is informational because compression ratios vary.

## Parity rule

A new module or rule must be reflected in every declared artifact that owns that information: master specification, module registry, audit, changelog, handoff, artifact inventory and verification tests.

Empty folders, `.keep`-only packages, placeholder files and root-document-only “full systems” fail the gate.

```text
PAYLOAD_REGRESSION_WITHOUT_REASON=HOLD
ARTIFACT_PARITY_FAILURE=HOLD
ZIP_SIZE_ONLY_DECISION=FORBIDDEN
```
