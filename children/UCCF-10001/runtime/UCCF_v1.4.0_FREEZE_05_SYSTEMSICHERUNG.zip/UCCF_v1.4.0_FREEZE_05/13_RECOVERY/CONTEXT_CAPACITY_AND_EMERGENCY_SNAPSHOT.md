# Context Capacity and Emergency Snapshot

Status: ACTIVE IN UCCF v1.3.0

Exakte verbleibende Chat-Kapazität ist nicht messbar und darf nicht
als Prozentwert behauptet werden.

LOW: Full Repair  
MEDIUM: Staged Repair + Mini-Checkpoint  
HIGH: Snapshot/Handoff vor Full Repair  
CRITICAL: Emergency Snapshot only

Andere Chats werden niemals automatisch gestartet.
