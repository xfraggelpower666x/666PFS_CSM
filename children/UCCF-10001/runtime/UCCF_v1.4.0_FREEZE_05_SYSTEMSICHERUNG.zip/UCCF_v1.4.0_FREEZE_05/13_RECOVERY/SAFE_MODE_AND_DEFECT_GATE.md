# Safe Mode and Defect-Gate Self-Fail

Status: ACTIVE IN UCCF v1.3.0

Safe Mode ist ein read-only Hold bei kritischer Unsicherheit.

## Defect-Gate Self-Fail

Wird ein repariertes Ergebnis erneut als fehlerhaft erkannt:

- Gesamt-Output halten,
- verantwortliches Gate isolieren,
- reduziertes Reparaturziel validieren,
- erst danach Gesamtpaket neu bauen,
- ReAudit verpflichtend.
