# UCCF Bootstrap-System v1.4.0

## Kanonische Quelle

Die verbindliche Reihenfolge steht in `BOOT_STAGE_REGISTRY.json`. Textuelle Abläufe dürfen sie nur erläutern.

## Reparierte Stage-Reihenfolge

```text
S00 HOST TASK INTAKE
→ S01 SOURCE SAFETY PREFLIGHT
→ S02 IDENTITY / AUTHORITY / SCOPE
→ S03 BOOTSTRAP DISCOVERY
→ S04 STATE RECOVERY
→ S05 POST-BOOT AUTHORITY AUDIT / ROUTE
→ S06 CONTINUITY CAPTURE
→ S07 CAUSAL REUSE / SELF AGREEMENT
→ S08 CONTROLLED INTEGRATION
→ S09 AUDIT / SELF-HEALING / REAUDIT
→ S10 CHECKPOINT / CURRENT-CHAT RESUME
→ S11 RELEASE / FREEZE / BACKUP WHEN REQUESTED
→ S12 OPTIONAL OUTPUT / CONTROL / PROMPT ASSETS
```

## Zweistufige Quellenlogik

`S01` prüft nur sichere Lesbarkeit, Pfade, Archive, Secrets und Ressourcen. Fachliche Source-Scope-Klassifizierung findet erst in `S07` nach Authority- und State-Klärung statt.

## One-root- und One-route-Regel

```text
ONE_BOOTSTRAP_ROOT=true
SECOND_BOOTSTRAP_ROOT=FORBIDDEN
SECOND_ROUTER=FORBIDDEN
SECOND_UPDATE_ROUTE=FORBIDDEN
ONE_ACTIVE_ROUTE=true
BOOTFIX_ROLE=RECOVERY_ONLY
```

## Host-System

Ein bestehender Bootstrap bleibt erhalten. UCCF wird nach Identity/Authority/State-Recovery und vor Host-Task-Ausführung über einen kontrollierten Adapter eingehängt. Bei 666PFS bleibt 666PFS führend.
