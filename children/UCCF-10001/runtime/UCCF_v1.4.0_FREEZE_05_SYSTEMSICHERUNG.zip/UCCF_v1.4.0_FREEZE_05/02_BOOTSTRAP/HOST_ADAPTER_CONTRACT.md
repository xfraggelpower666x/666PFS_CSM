# Host Adapter Contract — UCCF 1.4.0

Ein Adapter muss Host-ID, Modus, Authority, erlaubte Hooks, Read-/Write-Scope, Lock, Rollback und Readback deklarieren.

```text
CURRENT_CHAT_ONLY=true
OTHER_CHAT_AUTOSTART=FORBIDDEN
FULL_CORE_MERGE=FORBIDDEN
666PFS_LEADING_AUTHORITY_WHEN_ACTIVE=true
HOST_WRITE_REQUIRES_EXPLICIT_AUTHORIZATION=true
```
