# START HERE — UCCF 1.4.0 FREEZE_05

1. Read `01_SYSTEM/UCCF_v1.4.0_FREEZE_05.md`.
2. Load `02_BOOTSTRAP/BOOT_STAGE_REGISTRY.json` as canonical hierarchy.
3. Confirm current-chat-only execution and project-read-only reuse.
4. Recover state through validated schemas and checkpoints.
5. Process interruptions through a Continuity Transaction.
6. Audit, self-heal when required, ReAudit and resume only the current chat.
7. Treat this local baseline as a candidate until explicitly promoted by the relevant host authority.
8. Do not start other chats or projects.
