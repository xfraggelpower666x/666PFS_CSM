#!/usr/bin/env python3
from pathlib import Path
import json,re,hashlib,sys,collections
from jsonschema import Draft202012Validator, validators
ROOT=Path(__file__).resolve().parents[1]
WRITE='--write' in sys.argv
R=[]
def c(name,ok,detail=''):R.append({'name':name,'passed':bool(ok),'detail':str(detail)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(rel):return json.loads((ROOT/rel).read_text(encoding='utf-8'))
PROFILE=j('03_REGISTRY/ARTIFACT_PROFILE.json')
for x in PROFILE['required']:c('required:'+x,(ROOT/x).is_file())
# JSON parse
json_files=list(ROOT.rglob('*.json')); parsed={}; bad=[]
for p in json_files:
 try: parsed[p]=json.loads(p.read_text(encoding='utf-8'))
 except Exception as e: bad.append(f'{p.relative_to(ROOT)}:{e}')
c('all json parse',not bad,len(json_files) if not bad else bad)
# Schema meta + fixtures
schema_files=[p for p in json_files if p.name.endswith('_SCHEMA.json')]
meta_bad=[]
for p in schema_files:
 try: Draft202012Validator.check_schema(parsed[p])
 except Exception as e: meta_bad.append(f'{p.relative_to(ROOT)}:{e}')
c('all active schemas are JSON Schema 2020-12',not meta_bad,len(schema_files) if not meta_bad else meta_bad)
fixture_map={
 'CURRENT_CHAT_STATE_SCHEMA.json':'CURRENT_CHAT_STATE_VALID.json','CONTINUITY_TRANSACTION_SCHEMA.json':'CONTINUITY_TRANSACTION_VALID.json','INTERRUPTION_ENTRY_SCHEMA.json':'INTERRUPTION_ENTRY_VALID.json','SELF_AGREEMENT_CONTRACT_SCHEMA.json':'SELF_AGREEMENT_CONTRACT_VALID.json','SELF_HEALING_RECEIPT_SCHEMA.json':'SELF_HEALING_RECEIPT_VALID.json','RESUME_QUEUE_SCHEMA.json':'RESUME_QUEUE_VALID.json','HANDOFF_DESCRIPTOR_SCHEMA.json':'HANDOFF_DESCRIPTOR_VALID.json','RUNTIME_JOB_RECEIPT_SCHEMA.json':'RUNTIME_JOB_RECEIPT_VALID.json','HOST_ADAPTER_CONTRACT_SCHEMA.json':'HOST_ADAPTER_CONTRACT_VALID.json','CHECKPOINT_REGISTRY_SCHEMA.json':'CHECKPOINT_REGISTRY_VALID.json','PROJECT_REUSE_CANDIDATE_SCHEMA.json':'PROJECT_REUSE_CANDIDATE_VALID.json'}
for sn,fn in fixture_map.items():
 sp=ROOT/'04_STATE'/sn; fp=ROOT/'10_TOOLS/FIXTURES'/fn
 try: Draft202012Validator(json.loads(sp.read_text())).validate(json.loads(fp.read_text())); c('fixture:'+sn,True)
 except Exception as e:c('fixture:'+sn,False,e)
# Version consistency active metadata
for rel in ['03_REGISTRY/MODULE_REGISTRY.json','03_REGISTRY/OPERATING_MODES.json','03_REGISTRY/EVENT_CATALOG.json','03_REGISTRY/REGISTER_PICKUP_ZONES.json','03_REGISTRY/STATUS_MODEL.json','07_FREEZE/FREEZE_MANIFEST.json']:
 o=j(rel); c('version:'+rel,o.get('version')=='1.4.0',o.get('version'))
for rel in ['02_BOOTSTRAP/BOOTSTRAP_SYSTEM.md','08_DEPLOYMENT/GPT_INSTRUCTIONS.md','00_START_HERE.md','README.md']:
 t=(ROOT/rel).read_text(); c('active title version:'+rel,'1.4.0' in t and 'FREEZE_04' not in t.splitlines()[0],t.splitlines()[0])
# master hierarchy
main=(ROOT/'01_SYSTEM/UCCF_v1.4.0_FREEZE_05.md').read_text()
heads=[int(m.group(1)) for m in re.finditer(r'^##\s+(\d+)\.',main,re.M)]
c('master section numbers unique',len(heads)==len(set(heads)),heads)
c('master section sequence 0..75',heads==list(range(76)),heads[-10:])
# module registry / DAG / stage
mods=j('03_REGISTRY/MODULE_REGISTRY.json'); module_ids=[m['id'] for m in mods['modules']]; mmap={m['id']:m for m in mods['modules']}
c('module ids unique',len(module_ids)==len(set(module_ids)),len(module_ids))
stages=j('02_BOOTSTRAP/BOOT_STAGE_REGISTRY.json'); sids=[s['id'] for s in stages['stages']]; sorder={s['id']:s['order'] for s in stages['stages']}
c('stage ids unique',len(sids)==len(set(sids)),len(sids))
c('stage order continuous',[sorder[s] for s in sids]==list(range(len(sids))))
for m in mods['modules']:
 c('module stage:'+m['id'],m['stage_id'] in sorder,m['stage_id'])
 c('module deps exist:'+m['id'],all(d in mmap for d in m['depends_on']),m['depends_on'])
 c('module deps not later:'+m['id'],all(sorder[mmap[d]['stage_id']]<=sorder[m['stage_id']] for d in m['depends_on']),m['depends_on'])
# cycle detection
ind={i:0 for i in module_ids}; graph={i:[] for i in module_ids}
for m in mods['modules']:
 for d in m['depends_on']: graph[d].append(m['id']); ind[m['id']]+=1
q=collections.deque([i for i,v in ind.items() if v==0]); topo=[]
while q:
 n=q.popleft();topo.append(n)
 for x in graph[n]:
  ind[x]-=1
  if ind[x]==0:q.append(x)
c('module dependency DAG acyclic',len(topo)==len(module_ids),f'{len(topo)}/{len(module_ids)}')
c('stage registry modules complete',set(stages['load_order'])==set(module_ids),f"{len(stages['load_order'])}/{len(module_ids)}")
# events and transitions
ecat=j('03_REGISTRY/EVENT_CATALOG.json'); eids=[e['id'] for e in ecat['events']]
c('event ids unique',len(eids)==len(set(eids)),len(eids))
for e in ecat['events']:
 c('event handler:'+e['id'],e['primary_handler'] in mmap,e['primary_handler'])
 c('event validator:'+e['id'],e['final_validator'] in mmap,e['final_validator'])
 c('write event idempotency:'+e['id'],(not e['write_event']) or e['idempotency_key_required'])
st=j('12_GOVERNANCE/STATE_TRANSITION_TABLE.json'); states=set(st['states'])
for i,t in enumerate(st['transitions']):
 c(f'transition states:{i}',t['from'] in states and t['to'] in states,f"{t['from']}->{t['to']}")
 c(f'transition event:{i}',t['event'] in eids,t['event'])
 c(f'transition owner:{i}',t['owner'] in mmap,t['owner'])
# manager contracts
mc=j('12_GOVERNANCE/MANAGER_CONTRACTS.json')
for x in mc['contracts']:c('manager contract:'+x['module_id'],x['module_id'] in mmap,x['module_id'])
c('causal manager chain complete',all(x in mmap for x in mc['causal_chain']),mc['causal_chain'])
# invariants/tokens
inv=(ROOT/'12_GOVERNANCE/GLOBAL_INVARIANTS.md').read_text()
for tok in ['EXECUTION_SCOPE=CURRENT_CHAT_ONLY','OTHER_CHAT_AUTOSTART=FORBIDDEN','ONE_BOOTSTRAP_ROOT=true','ONE_ACTIVE_ROUTE=true','ONE_TASK_ONE_OWNER=true','666PFS_LEADING_AUTHORITY_WHEN_ACTIVE=true','NO_REAUDIT→NO_RESUME']:
 c('invariant:'+tok,tok in inv)
# no active duplicate content (exclude history)
hmap=collections.defaultdict(list)
for p in ROOT.rglob('*'):
 rel=str(p.relative_to(ROOT))
 if p.is_file() and '/HISTORY/' not in '/'+rel and not rel.startswith('10_TOOLS/FIXTURES/') and rel not in ['SHA256SUMS.txt','07_FREEZE/ARTIFACT_INVENTORY.json']:
  hmap[sha(p)].append(rel)
dup=[v for v in hmap.values() if len(v)>1]
c('no active byte-identical artifact aliases',not dup,dup)
# inventory parity
art=j('07_FREEZE/ARTIFACT_INVENTORY.json'); excl=set(art['scope_exclusions'])
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in excl}
listed={x['path'] for x in art['files']}
c('artifact inventory path parity',actual==listed,{'missing':sorted(actual-listed),'extra':sorted(listed-actual)})
mis=[]
for x in art['files']:
 p=ROOT/x['path']
 if not p.is_file() or p.stat().st_size!=x['size_bytes'] or sha(p)!=x['sha256']:mis.append(x['path'])
c('artifact inventory hash and size parity',not mis,mis)
# checksums
sumfile=ROOT/'SHA256SUMS.txt'; lines=sumfile.read_text().splitlines(); smap={}
badline=[]
for line in lines:
 parts=line.split('  ',1)
 if len(parts)!=2:badline.append(line);continue
 smap[parts[1]]=parts[0]
actual_sum={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
c('checksum manifest scope',set(smap)==actual_sum,{'missing':sorted(actual_sum-set(smap)),'extra':sorted(set(smap)-actual_sum)})
mm=[r for r,h in smap.items() if not (ROOT/r).is_file() or sha(ROOT/r)!=h]
c('checksum hashes pass',not mm,mm)
c('checksum excludes itself','SHA256SUMS.txt' not in smap)
c('checksum paths package-relative',all(not Path(r).is_absolute() and '..' not in Path(r).parts for r in smap))
# evidence policy
pdfs=[str(p.relative_to(ROOT)) for p in ROOT.rglob('*.pdf')]
c('foreign PDFs externalized',not pdfs,pdfs)
ext=j('11_EVIDENCE/EXTERNAL_EVIDENCE_INDEX.json')
c('external evidence not embedded',all(x.get('embedded') is False for x in ext['external_evidence']))
# current pointers
ptr=j('07_FREEZE/CURRENT_ARTIFACT_POINTERS.json')
for k,v in ptr.items():
 if k not in {'system_id','version','freeze'}:c('pointer:'+k,(ROOT/v).is_file(),v)
# handoff actual validates
try: Draft202012Validator(j('04_STATE/HANDOFF_DESCRIPTOR_SCHEMA.json')).validate(j('09_HANDOFF/HANDOFF_DESCRIPTOR.json'));c('actual handoff validates',True)
except Exception as e:c('actual handoff validates',False,e)
# active package claims
fm=j('07_FREEZE/FREEZE_MANIFEST.json')
c('candidate not host promoted',fm['canonical_host_promotion'] is False)
c('no runtime claim',fm['external_runtime_implemented'] is False)
c('no pfs mutation',fm['pfs_mutation'] is False)
c('no lyvra mutation',fm['lyvra_mutation'] is False)
# no empty and secret patterns
empty=[str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.stat().st_size==0];c('no empty files',not empty,empty)
patterns=[re.compile(r'\bsk-(?:proj-)?[A-Za-z0-9_-]{16,}\b'),re.compile(r'\bgh[pousr]_[A-Za-z0-9]{20,}\b'),re.compile(r'\bAKIA[0-9A-Z]{16}\b'),re.compile(r'BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY')]
hits=[]
for p in ROOT.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.md','.txt','.json','.py','.csv'} and p.stat().st_size<2_000_000:
  t=p.read_text('utf-8',errors='ignore')
  if any(rx.search(t) for rx in patterns):hits.append(str(p.relative_to(ROOT)))
c('secret scan',not hits,hits)
summary={'system_id':'UCCF-CORE-001','version':'1.4.0','freeze':'FREEZE_05','total':len(R),'passed':sum(x['passed'] for x in R),'failed':sum(not x['passed'] for x in R),'results':R}
if WRITE:(ROOT/'10_TOOLS/verification_results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['total','passed','failed']},indent=2))
raise SystemExit(1 if summary['failed'] else 0)
