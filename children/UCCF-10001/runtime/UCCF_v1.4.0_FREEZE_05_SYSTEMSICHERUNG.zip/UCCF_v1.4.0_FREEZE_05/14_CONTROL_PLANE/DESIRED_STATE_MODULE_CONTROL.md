# Desired-State Module Control — UCCF 1.4.0

Desired state, generated command and verified runtime state remain separate. A `VERIFIED_RUNNING` state requires `RUNTIME_JOB_RECEIPT_SCHEMA.json` evidence.
