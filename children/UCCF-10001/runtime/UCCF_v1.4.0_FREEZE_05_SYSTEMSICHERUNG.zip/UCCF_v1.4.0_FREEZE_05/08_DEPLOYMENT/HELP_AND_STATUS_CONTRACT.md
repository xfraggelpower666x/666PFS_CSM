# Help and Status Contract — UCCF 1.4.0

Help is read-only. Missing dependencies produce `DEGRADED_READ_ONLY`. Status must distinguish measured evidence, local candidate freeze, host promotion, external runtime and pending writes.
