@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
set "PYTHONPATH=%CD%\src"
%PY% scripts\verify.py
exit /b %errorlevel%
