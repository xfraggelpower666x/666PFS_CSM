from __future__ import annotations

from typing import Any

from .base import ProviderCapabilities


class GitHubHostExecutionCandidateProvider:
    """Registrierter Adapterkandidat; ohne Host-Invoker und exakte Freigabe niemals schreibfähig."""

    name = "github_host_execution_candidate"
    capabilities = ProviderCapabilities(read=False, propose=True, execute=False, remote=True)

    def status(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-provider-status-v1",
            "name": self.name,
            "capabilities": {"read": False, "propose": True, "execute": False, "remote": True},
            "mode": "HOST_BOUND_CANDIDATE_DEFAULT_OFF",
            "requires_exact_head_action": "GitHub.read_branch_head",
            "requires_external_host_invoker": True,
            "radio_first_target_forbidden": True,
            "status": "WRITE_BLOCKED",
        }

    def execute(self, **_: Any) -> dict[str, Any]:
        return {
            "schema": "codeforge-provider-execution-v1",
            "provider": self.name,
            "status": "WRITE_BLOCKED",
            "mutation_performed": False,
            "reason": "HOST_INVOKER_AND_EXACT_SINGLE_USE_AUTHORIZATION_REQUIRED",
        }
