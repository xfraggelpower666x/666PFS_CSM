from __future__ import annotations
from typing import Any
from urllib.parse import urlsplit
from .remote_contract_only import RemoteContractOnlyProvider
from ..hashchain import seal_document

class CloudflareRemoteAdapterContract(RemoteContractOnlyProvider):
    def __init__(self):super().__init__("cloudflare")
    def deployment_contract(self,*,source_repository:str,source_commit:str,production_origin:str,identity_path:str="/666pfs-deployed-commit.json")->dict[str,Any]:
        parsed=urlsplit(production_origin); reasons=[]
        if parsed.scheme!="https" or not parsed.netloc:reasons.append("HTTPS_PRODUCTION_ORIGIN_REQUIRED")
        if len(source_commit)<7:reasons.append("SOURCE_COMMIT_INVALID")
        if not identity_path.startswith("/"):reasons.append("IDENTITY_PATH_INVALID")
        return seal_document({"schema":"codeforge-cloudflare-deployment-contract-v1","source_repository":source_repository,"source_commit":source_commit,"production_origin":production_origin.rstrip("/"),"identity_path":identity_path,"execution_enabled":False,"status":"PROPOSED" if not reasons else "WRITE_BLOCKED","reasons":reasons})
