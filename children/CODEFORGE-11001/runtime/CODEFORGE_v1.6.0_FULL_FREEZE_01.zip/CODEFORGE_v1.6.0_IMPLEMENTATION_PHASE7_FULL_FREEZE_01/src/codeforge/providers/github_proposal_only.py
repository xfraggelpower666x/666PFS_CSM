from __future__ import annotations

from typing import Any

from ..controlled_writer import ControlledWriter


class GitHubProposalOnlyProvider:
    """No POST/PATCH/PUT/DELETE transport exists in Phase 2."""

    transport_methods = ("GET",)
    write_methods = ()

    def submit(self, proposal: dict[str, Any]) -> dict[str, Any]:
        return ControlledWriter().execute(proposal)
