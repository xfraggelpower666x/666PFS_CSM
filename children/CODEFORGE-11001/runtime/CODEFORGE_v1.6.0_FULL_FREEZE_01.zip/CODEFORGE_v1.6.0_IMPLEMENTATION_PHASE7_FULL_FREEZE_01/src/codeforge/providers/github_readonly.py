from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class GitHubReadOnlyProvider:
    owner: str
    repository: str
    token_env: str = "GITHUB_TOKEN"
    api_origin: str = "https://api.github.com"

    def _get(self, path: str) -> Any:
        url = f"{self.api_origin.rstrip('/')}/{path.lstrip('/')}"
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "CodeForge-ReadOnly/1.0",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        token = os.getenv(self.token_env)
        if token:
            headers["Authorization"] = f"Bearer {token}"
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"GitHub read failed: HTTP {exc.code}: {body[:500]}") from exc

    def repository_metadata(self) -> dict[str, Any]:
        return self._get(f"repos/{self.owner}/{self.repository}")

    def branch(self, branch: str) -> dict[str, Any]:
        encoded = urllib.parse.quote(branch, safe="")
        return self._get(f"repos/{self.owner}/{self.repository}/branches/{encoded}")

    def tree(self, ref: str, recursive: bool = True) -> dict[str, Any]:
        encoded = urllib.parse.quote(ref, safe="")
        suffix = "?recursive=1" if recursive else ""
        return self._get(f"repos/{self.owner}/{self.repository}/git/trees/{encoded}{suffix}")

    def file(self, path: str, ref: str | None = None) -> dict[str, Any]:
        encoded = urllib.parse.quote(path, safe="/")
        suffix = f"?ref={urllib.parse.quote(ref, safe='')}" if ref else ""
        return self._get(f"repos/{self.owner}/{self.repository}/contents/{encoded}{suffix}")
