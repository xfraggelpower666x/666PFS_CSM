from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class ProviderCapabilities:
    read: bool
    propose: bool
    execute: bool
    remote: bool


class RepositoryProvider(Protocol):
    name: str
    capabilities: ProviderCapabilities

    def status(self) -> dict[str, Any]: ...
    def execute(self, **kwargs: Any) -> dict[str, Any]: ...
