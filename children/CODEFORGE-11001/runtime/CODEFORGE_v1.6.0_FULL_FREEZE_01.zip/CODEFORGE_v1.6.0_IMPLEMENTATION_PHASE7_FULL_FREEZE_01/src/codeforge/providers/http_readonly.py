from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class HttpReadOnlyProvider:
    allowed_origins: tuple[str, ...]

    def _validate(self, url: str) -> None:
        parsed = urllib.parse.urlsplit(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        if parsed.scheme != "https":
            raise PermissionError("Only HTTPS readback is allowed")
        if origin not in self.allowed_origins:
            raise PermissionError(f"Origin not allowlisted: {origin}")

    def get_bytes(self, url: str, *, max_bytes: int = 5_000_000) -> tuple[bytes, dict[str, str]]:
        self._validate(url)
        request = urllib.request.Request(url, method="GET", headers={"User-Agent": "CodeForge-ReadOnly/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                data = response.read(max_bytes + 1)
                if len(data) > max_bytes:
                    raise ValueError("Readback exceeded configured size limit")
                return data, dict(response.headers.items())
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"HTTP readback failed: {exc.code}") from exc

    def get_json(self, url: str) -> dict[str, Any]:
        data, _headers = self.get_bytes(url)
        parsed = json.loads(data.decode("utf-8"))
        if not isinstance(parsed, dict):
            raise TypeError("Expected a JSON object")
        return parsed
