from __future__ import annotations

from typing import Any

from .base import RepositoryProvider


class ProviderRegistry:
    def __init__(self):
        self._providers: dict[str, RepositoryProvider] = {}

    def register(self, provider: RepositoryProvider) -> None:
        if provider.name in self._providers:
            raise KeyError(f"PROVIDER_ALREADY_REGISTERED:{provider.name}")
        self._providers[provider.name] = provider

    def get(self, name: str) -> RepositoryProvider:
        if name not in self._providers:
            raise KeyError(f"PROVIDER_NOT_REGISTERED:{name}")
        return self._providers[name]

    def inventory(self) -> dict[str, Any]:
        return {name: provider.status() for name, provider in sorted(self._providers.items())}
