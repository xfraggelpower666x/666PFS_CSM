from __future__ import annotations

from typing import Any

from .base import ProviderCapabilities
from ..local_executor import AtomicLocalSandboxExecutor


class LocalSandboxProvider:
    name = "local_sandbox"
    capabilities = ProviderCapabilities(read=True, propose=True, execute=True, remote=False)

    def __init__(self, workspace: str):
        self.executor = AtomicLocalSandboxExecutor(workspace)

    def status(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-provider-status-v1",
            "name": self.name,
            "capabilities": {
                "read": True, "propose": True, "execute": True, "remote": False,
            },
            "status": "PASS",
            "scope": "MARKED_LOCAL_SANDBOX_ONLY",
        }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        return self.executor.execute(**kwargs)
