from __future__ import annotations

from typing import Any
from .base import ProviderCapabilities


class RemoteContractOnlyProvider:
    capabilities=ProviderCapabilities(read=True,propose=True,execute=False,remote=True)
    def __init__(self,name:str):self.name=name
    def status(self)->dict[str,Any]:return {"schema":"codeforge-provider-status-v1","name":self.name,"capabilities":{"read":True,"propose":True,"execute":False,"remote":True},"status":"WRITE_BLOCKED","reason":"REAL_REMOTE_TRANSPORT_NOT_IMPLEMENTED"}
    def execute(self,**kwargs:Any)->dict[str,Any]:return {"schema":"codeforge-provider-execution-v1","provider":self.name,"status":"WRITE_BLOCKED","mutation_performed":False,"reason":"REAL_REMOTE_TRANSPORT_NOT_IMPLEMENTED"}
