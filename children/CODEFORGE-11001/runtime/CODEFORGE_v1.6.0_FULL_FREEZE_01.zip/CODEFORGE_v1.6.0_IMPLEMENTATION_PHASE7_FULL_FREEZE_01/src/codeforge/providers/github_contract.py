from __future__ import annotations
from typing import Any
from .remote_contract_only import RemoteContractOnlyProvider

class GitHubRemoteAdapterContract(RemoteContractOnlyProvider):
    def __init__(self):super().__init__("github")
    def plan(self,contract:dict[str,Any])->dict[str,Any]:
        return {"schema":"codeforge-github-adapter-plan-v1","contract_id":contract.get("contract_id"),"ordered_actions":["fresh-permission-read","fresh-head-read","create-isolated-branch","create-blobs","create-tree","create-commit","compare-and-swap-ref","remote-readback"],"transport_available":False,"status":"PROPOSED"}
