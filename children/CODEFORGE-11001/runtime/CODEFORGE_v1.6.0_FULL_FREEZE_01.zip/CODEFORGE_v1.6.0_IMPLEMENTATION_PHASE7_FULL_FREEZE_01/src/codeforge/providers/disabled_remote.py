from __future__ import annotations

from typing import Any

from .base import ProviderCapabilities


class DisabledRemoteProvider:
    capabilities = ProviderCapabilities(read=True, propose=True, execute=False, remote=True)

    def __init__(self, name: str):
        self.name = name

    def status(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-provider-status-v1",
            "name": self.name,
            "capabilities": {
                "read": True, "propose": True, "execute": False, "remote": True,
            },
            "status": "WRITE_BLOCKED",
            "reason": "REMOTE_EXECUTION_NOT_ENABLED_IN_PHASE3",
        }

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        return {
            "schema": "codeforge-provider-execution-v1",
            "provider": self.name,
            "mutation_performed": False,
            "status": "WRITE_BLOCKED",
            "reason": "REMOTE_EXECUTION_NOT_ENABLED_IN_PHASE3",
        }
