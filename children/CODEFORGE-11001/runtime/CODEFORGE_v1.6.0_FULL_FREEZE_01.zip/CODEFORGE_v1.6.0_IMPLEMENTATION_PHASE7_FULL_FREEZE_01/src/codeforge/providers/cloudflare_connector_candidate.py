from __future__ import annotations

from typing import Any

from .base import ProviderCapabilities
from ..connector_plan import CloudflareConnectorPlanBuilder
from ..connector_transport import NullConnectorTransport


class CloudflareConnectorCandidateProvider:
    name = "cloudflare_connector_candidate"
    capabilities = ProviderCapabilities(read=True, propose=True, execute=False, remote=True)

    def status(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-provider-status-v1",
            "name": self.name,
            "capabilities": {"read": True, "propose": True, "execute": False, "remote": True},
            "connector_backed": True,
            "readback_plan": True,
            "network_write": False,
            "real_execution": False,
            "status": "READBACK_PLAN_ONLY",
        }

    def plan_readback(self, **kwargs: Any) -> dict[str, Any]:
        return CloudflareConnectorPlanBuilder().build_readback_plan(**kwargs)

    def execute(self, **kwargs: Any) -> dict[str, Any]:
        return NullConnectorTransport().execute(kwargs.get("plan", {}))
