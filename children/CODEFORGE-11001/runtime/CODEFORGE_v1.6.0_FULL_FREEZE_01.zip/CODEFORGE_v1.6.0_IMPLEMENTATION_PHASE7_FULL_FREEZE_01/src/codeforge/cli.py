from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .authorization import ExecutionAuthorizationRegistry
from .core import CoreKernel
from .governance import MutationGate
from .local_executor import AtomicLocalSandboxExecutor, TransactionBlocked
from .package_verify import PortablePackageVerifier
from .proposal import DryRunProposalEngine, ProposalBlocked
from .readback import ProposalReadbackVerifier
from .release_manager import DeterministicReleaseManager
from .targets import AllowlistPolicy, RemoteHeadClaim, RepositoryTarget
from .transaction_recovery import TransactionRecovery
from .writer_models import ProposalPrerequisites


def emit(data) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True))


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="codeforge", description="CodeForge evidence-first engineering framework")
    sub = root.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="Initialize a workspace")
    init.add_argument("--workspace", default=".codeforge-workspace")
    status = sub.add_parser("status", help="Show workspace state")
    status.add_argument("--workspace", default=".codeforge-workspace")
    audit = sub.add_parser("audit-local", help="Audit a local repository without mutation")
    audit.add_argument("repository")
    audit.add_argument("--workspace", default=".codeforge-workspace")
    radio = sub.add_parser("audit-radio", help="Audit a WebRadio repository with the radio plugin")
    radio.add_argument("repository")
    radio.add_argument("--workspace", default=".codeforge-workspace")

    checkpoint = sub.add_parser("checkpoint", help="Create a sealed checkpoint")
    checkpoint.add_argument("--workspace", default=".codeforge-workspace")
    checkpoint.add_argument("--phase", required=True)
    checkpoint.add_argument("--state", required=True)
    checkpoint.add_argument("--block-from", type=int, required=True)
    checkpoint.add_argument("--block-to", type=int, required=True)
    checkpoint.add_argument("--payload", default="{}", help="JSON object")

    interrupt = sub.add_parser("interrupt", help="Record interruption information")
    interrupt.add_argument("message")
    interrupt.add_argument("--classification", default="USER_INFORMATION")
    interrupt.add_argument("--workspace", default=".codeforge-workspace")
    integrate = sub.add_parser("integrate-interruptions", help="Integrate pending interruption records")
    integrate.add_argument("--workspace", default=".codeforge-workspace")
    resume = sub.add_parser("resume", help="Resume from last verified checkpoint")
    resume.add_argument("--workspace", default=".codeforge-workspace")

    gate = sub.add_parser("mutation-gate", help="Evaluate proposal/execution preconditions")
    gate.add_argument("claims", nargs="*")
    gate.add_argument("--phase", type=int, default=3)
    gate.add_argument("--operation", choices=["proposal", "execute"], default="execute")
    gate.add_argument("--provider", default="remote")

    propose = sub.add_parser("propose", help="Create a verified dry-run change proposal")
    propose.add_argument("baseline")
    propose.add_argument("candidate")
    propose.add_argument("--repository", required=True)
    propose.add_argument("--branch", required=True)
    propose.add_argument("--expected-head", required=True)
    propose.add_argument("--observed-head", required=True)
    propose.add_argument("--evidence-id", required=True)
    propose.add_argument("--allowlist", required=True)
    propose.add_argument("--prerequisites", required=True)
    propose.add_argument("--owner", required=True)
    propose.add_argument("--workspace", default=".codeforge-workspace")

    readback = sub.add_parser("verify-proposal", help="Verify a proposal against a post-state directory")
    readback.add_argument("proposal")
    readback.add_argument("post_state")

    authorize = sub.add_parser("authorize-local", help="Issue one-time authorization for a sealed proposal")
    authorize.add_argument("proposal")
    authorize.add_argument("--phrase", required=True)
    authorize.add_argument("--issued-by", required=True)
    authorize.add_argument("--ttl", type=int, default=900)
    authorize.add_argument("--workspace", default=".codeforge-workspace")

    execute = sub.add_parser("execute-local", help="Execute a sealed proposal in a marked local sandbox")
    execute.add_argument("proposal")
    execute.add_argument("candidate")
    execute.add_argument("target")
    execute.add_argument("--authorization-id", required=True)
    execute.add_argument("--expected-head", required=True)
    execute.add_argument("--observed-head", required=True)
    execute.add_argument("--evidence-id", required=True)
    execute.add_argument("--workspace", default=".codeforge-workspace")

    recover = sub.add_parser("recover-transaction", help="Recover an interrupted local transaction")
    recover.add_argument("transaction_root")

    freeze = sub.add_parser("freeze-release", help="Create deterministic local release ZIP")
    freeze.add_argument("source")
    freeze.add_argument("archive")
    freeze.add_argument("--root-name", required=True)

    package = sub.add_parser("verify-package", help="Verify ZIP/CRC/hash independent of current directory")
    package.add_argument("archive")
    package.add_argument("--checksum-file")
    package.add_argument("--readback-file")
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    workspace = getattr(args, "workspace", ".codeforge-workspace")
    core = CoreKernel(workspace)
    try:
        if args.command == "init":
            emit(core.initialize())
        elif args.command == "status":
            core.initialize(); emit(core.status())
        elif args.command == "audit-local":
            core.initialize(); emit(core.engineering.audit_local_repository(args.repository, radio=False))
        elif args.command == "audit-radio":
            core.initialize(); emit(core.engineering.audit_local_repository(args.repository, radio=True))
        elif args.command == "checkpoint":
            core.initialize(); payload = json.loads(args.payload)
            if not isinstance(payload, dict): raise ValueError("--payload must decode to a JSON object")
            emit(core.create_checkpoint(args.phase, args.state, args.block_from, args.block_to, payload).to_dict())
        elif args.command == "interrupt":
            core.initialize(); emit(core.continuation.interrupt(args.message, args.classification))
        elif args.command == "integrate-interruptions":
            core.initialize(); emit({"integrated": core.continuation.integrate_pending()})
        elif args.command == "resume":
            core.initialize(); emit(core.continuation.resume())
        elif args.command == "mutation-gate":
            result = MutationGate().evaluate(args.claims, phase=args.phase, operation=args.operation, provider=args.provider)
            emit({"allowed": result.allowed, "status": result.status.value, "reasons": result.reasons})
        elif args.command == "propose":
            core.initialize(); target = RepositoryTarget(args.repository, args.branch)
            head = RemoteHeadClaim(target, args.expected_head, args.observed_head, args.evidence_id)
            policy = AllowlistPolicy.from_file(args.allowlist)
            prereq_doc = json.loads(Path(args.prerequisites).read_text(encoding="utf-8"))
            prerequisites = ProposalPrerequisites(
                evidence=prereq_doc.get("evidence", {}),
                reconciliation=prereq_doc.get("reconciliation", {}),
                repair_plan=prereq_doc.get("repair_plan", {}),
            )
            emit(DryRunProposalEngine(args.workspace).prepare(
                args.baseline, args.candidate, target=target, remote_head=head,
                policy=policy, owner=args.owner, prerequisites=prerequisites,
            ))
        elif args.command == "verify-proposal":
            emit(ProposalReadbackVerifier().verify(args.proposal, args.post_state))
        elif args.command == "authorize-local":
            emit(ExecutionAuthorizationRegistry(Path(args.workspace) / "authorizations").issue(
                args.proposal, phrase=args.phrase, issued_by=args.issued_by, ttl_seconds=args.ttl,
            ))
        elif args.command == "execute-local":
            core.initialize(); proposal = json.loads(Path(args.proposal).read_text(encoding="utf-8"))
            target_identity = RepositoryTarget(proposal["target"]["repository"], proposal["target"]["branch"])
            head = RemoteHeadClaim(target_identity, args.expected_head, args.observed_head, args.evidence_id)
            config = json.loads((Path(args.workspace) / "workspace.json").read_text(encoding="utf-8"))
            emit(AtomicLocalSandboxExecutor(args.workspace).execute(
                proposal=proposal, authorization_id=args.authorization_id,
                candidate=args.candidate, target=args.target, remote_head=head,
                runtime_config=config,
            ))
        elif args.command == "recover-transaction":
            emit(TransactionRecovery().recover(args.transaction_root))
        elif args.command == "freeze-release":
            emit(DeterministicReleaseManager().freeze(args.source, args.archive, root_name=args.root_name))
        elif args.command == "verify-package":
            result = PortablePackageVerifier().verify(args.archive, checksum_file=args.checksum_file, readback_file=args.readback_file)
            emit(result); return 0 if result["status"] == "PASS" else 1
        return 0
    except (ProposalBlocked, TransactionBlocked) as exc:
        print(json.dumps({"status": "WRITE_BLOCKED", "code": exc.code, "receipt": exc.receipt}, ensure_ascii=False), file=sys.stderr)
        return 2
    except Exception as exc:
        print(json.dumps({"status": "BLOCKED", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
