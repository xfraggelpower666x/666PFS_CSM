from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
import hashlib
import json
import os
import uuid

from .models import utc_now
from .status import Status
from .targets import RepositoryTarget


@dataclass(slots=True)
class LockReceipt:
    acquired: bool
    status: str
    target: str
    owner: str
    token: str | None
    path: str
    reasons: list[str]
    acquired_at: str | None = None
    expires_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-repository-lock-v1",
            "acquired": self.acquired,
            "status": self.status,
            "target": self.target,
            "owner": self.owner,
            "token": "REDACTED" if self.token else None,
            "path": self.path,
            "reasons": self.reasons,
            "acquired_at": self.acquired_at,
            "expires_at": self.expires_at,
        }


class RepositoryLockManager:
    """Atomic local planning lock. Stale locks require explicit administrative cleanup."""

    def __init__(self, root: str | Path):
        self.root = Path(root)

    def _path(self, target: RepositoryTarget) -> Path:
        digest = hashlib.sha256(target.identity.encode("utf-8")).hexdigest()[:24]
        return self.root / f"{digest}.lock.json"

    def acquire(self, target: RepositoryTarget, owner: str, *, ttl_seconds: int = 1800) -> LockReceipt:
        if not owner.strip():
            raise ValueError("lock owner is required")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        self.root.mkdir(parents=True, exist_ok=True)
        path = self._path(target)
        acquired_at = datetime.now(timezone.utc).replace(microsecond=0)
        expires_at = acquired_at + timedelta(seconds=ttl_seconds)
        token = uuid.uuid4().hex
        payload = {
            "schema": "codeforge-repository-lock-v1",
            "target": target.identity,
            "owner": owner,
            "token": token,
            "acquired_at": acquired_at.isoformat(),
            "expires_at": expires_at.isoformat(),
        }
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            existing = self.inspect(target)
            reasons = ["LOCK_ALREADY_EXISTS"]
            if existing.get("expired"):
                reasons.append("STALE_LOCK_REQUIRES_EXPLICIT_CLEAR")
            return LockReceipt(False, Status.WRITE_BLOCKED.value, target.identity, owner, None, str(path), reasons)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        return LockReceipt(
            True, Status.PASS.value, target.identity, owner, token, str(path), [],
            acquired_at.isoformat(), expires_at.isoformat(),
        )

    def inspect(self, target: RepositoryTarget) -> dict[str, Any]:
        path = self._path(target)
        if not path.exists():
            return {"exists": False, "path": str(path), "status": "CLEAR", "expired": False}
        data = json.loads(path.read_text(encoding="utf-8"))
        try:
            expiry = datetime.fromisoformat(data["expires_at"])
            expired = expiry <= datetime.now(timezone.utc)
        except (KeyError, ValueError, TypeError):
            expired = True
        return {"exists": True, "path": str(path), "status": "LOCKED", "expired": expired, "record": data}

    def release(self, target: RepositoryTarget, token: str) -> dict[str, Any]:
        path = self._path(target)
        if not path.exists():
            return {"released": False, "status": Status.BLOCKED.value, "reason": "LOCK_NOT_FOUND"}
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("token") != token:
            return {"released": False, "status": Status.BLOCKED.value, "reason": "LOCK_TOKEN_MISMATCH"}
        path.unlink()
        return {"released": True, "status": Status.PASS.value, "path": str(path), "released_at": utc_now()}

    def clear_stale(self, target: RepositoryTarget, *, acknowledgement: str) -> dict[str, Any]:
        state = self.inspect(target)
        if acknowledgement != "CLEAR_STALE_LOCK_CONFIRMED":
            return {"cleared": False, "status": Status.WRITE_BLOCKED.value, "reason": "EXPLICIT_ACK_REQUIRED"}
        if not state.get("exists"):
            return {"cleared": False, "status": Status.OPEN.value, "reason": "LOCK_NOT_FOUND"}
        if not state.get("expired"):
            return {"cleared": False, "status": Status.WRITE_BLOCKED.value, "reason": "ACTIVE_LOCK"}
        Path(state["path"]).unlink()
        return {"cleared": True, "status": Status.PASS.value, "path": state["path"]}
