from __future__ import annotations

from pathlib import Path
from typing import Iterable
import fnmatch
import hashlib
import os

from .targets import normalize_relative_path
from .writer_models import ProposalOperation


class ScopeDiffEngine:
    """Computes an exact hash diff without reading or writing remote systems."""

    DEFAULT_IGNORES = (
        ".git/**", "**/.git/**", "__pycache__/**", "**/__pycache__/**",
        "*.pyc", "**/*.pyc", ".codeforge-workspace/**", "**/.codeforge-workspace/**",
    )

    def __init__(self, ignore: Iterable[str] = DEFAULT_IGNORES):
        self.ignore = tuple(ignore)

    @staticmethod
    def _sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def _ignored(self, relative: str) -> bool:
        return any(fnmatch.fnmatchcase(relative, pattern) for pattern in self.ignore)

    def inventory(self, root: str | Path) -> dict[str, dict[str, int | str]]:
        base = Path(root).resolve()
        if not base.is_dir():
            raise NotADirectoryError(base)
        records: dict[str, dict[str, int | str]] = {}
        for current, dirs, files in os.walk(base, followlinks=False):
            dirs[:] = sorted(d for d in dirs if not (Path(current) / d).is_symlink())
            for name in sorted(files):
                path = Path(current) / name
                relative = normalize_relative_path(path.relative_to(base).as_posix())
                if self._ignored(relative):
                    continue
                if path.is_symlink():
                    raise ValueError(f"Symlink is not proposal-safe: {relative}")
                stat = path.stat()
                records[relative] = {"sha256": self._sha256(path), "size": stat.st_size}
        return records

    def compare(self, baseline: str | Path, candidate: str | Path) -> list[ProposalOperation]:
        before = self.inventory(baseline)
        after = self.inventory(candidate)
        operations: list[ProposalOperation] = []
        for path in sorted(set(before) | set(after)):
            old = before.get(path)
            new = after.get(path)
            if old is None:
                operations.append(ProposalOperation("create", path, None, str(new["sha256"]), None, int(new["size"])))
            elif new is None:
                operations.append(ProposalOperation("delete", path, str(old["sha256"]), None, int(old["size"]), None))
            elif old["sha256"] != new["sha256"]:
                operations.append(ProposalOperation(
                    "update", path, str(old["sha256"]), str(new["sha256"]),
                    int(old["size"]), int(new["size"]),
                ))
        return operations
