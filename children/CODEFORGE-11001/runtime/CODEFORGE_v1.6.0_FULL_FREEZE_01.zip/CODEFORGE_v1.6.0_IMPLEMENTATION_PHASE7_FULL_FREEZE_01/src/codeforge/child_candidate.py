from __future__ import annotations

import hashlib
import json
from typing import Any


def _digest(payload: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def build_universal_child_candidate(*, version: str, freeze_sha256: str, checkpoint: str) -> dict[str, Any]:
    candidate = {
        "schema": "666pfs-child-candidate-v1",
        "system_id": "PFS-CODEFORGE-UNIVERSAL-001",
        "name": "CodeForge Universal Coding Agent",
        "namespace": "666PFS/Child_Systems/CODEFORGE_UNIVERSAL",
        "version": version,
        "checkpoint": checkpoint,
        "freeze_sha256": freeze_sha256,
        "status": "PREPARE_ONLY",
        "activation": "EXACT_666PFS_LIFECYCLE_REQUIRED",
        "child_autoload": False,
        "registry_write_allowed": False,
        "menu_write_allowed": False,
        "pointer_write_allowed": False,
        "identity_scope": "UNIVERSAL_CODING_AGENT",
        "capabilities": [
            "repository_analysis", "evidence_reconciliation", "minimal_repair_planning",
            "continuation_and_recovery", "project_graph", "plugin_runtime"
        ],
        "specializations": {
            "radio": {
                "type": "EXTERNAL_PLUGIN_REFERENCE",
                "repository_path": "engineering/codeforge/plugins/radio",
                "part_of_child_identity": False,
            }
        },
        "guards": {
            "shared_namespace": False,
            "cross_system_mutation": False,
            "production_radio_write": False,
        },
    }
    candidate["digest"] = _digest(candidate)
    return candidate


def verify_universal_child_candidate(candidate: dict[str, Any]) -> bool:
    material = {k: v for k, v in candidate.items() if k != "digest"}
    if candidate.get("digest") != _digest(material):
        return False
    return (
        candidate.get("status") == "PREPARE_ONLY"
        and candidate.get("identity_scope") == "UNIVERSAL_CODING_AGENT"
        and candidate.get("child_autoload") is False
        and candidate.get("registry_write_allowed") is False
        and candidate.get("specializations", {}).get("radio", {}).get("part_of_child_identity") is False
    )
