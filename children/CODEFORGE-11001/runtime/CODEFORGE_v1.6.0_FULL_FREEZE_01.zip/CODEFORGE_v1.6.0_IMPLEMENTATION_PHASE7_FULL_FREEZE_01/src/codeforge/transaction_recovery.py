from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import os
import shutil

from .storage import AtomicJsonStore
from .transaction_journal import TransactionJournal
from .transaction_models import TransactionManifest, TransactionState


class TransactionRecovery:
    """Fail-safe recovery: incomplete swaps restore the retained baseline."""

    def inspect(self, transaction_root: str | Path) -> dict[str, Any]:
        root = Path(transaction_root).resolve()
        manifest_path = root / "manifest.json"
        if not manifest_path.is_file():
            return {"status": "BLOCKED", "reason": "MANIFEST_MISSING", "root": str(root)}
        try:
            manifest = TransactionManifest.from_dict(json.loads(manifest_path.read_text(encoding="utf-8")))
        except (ValueError, KeyError, json.JSONDecodeError) as exc:
            return {"status": "CONFLICT_QUARANTINE", "reason": str(exc), "root": str(root)}
        journal = TransactionJournal(root / "journal.jsonl").verify()
        return {
            "schema": "codeforge-transaction-recovery-inspection-v1",
            "root": str(root),
            "manifest": manifest.to_dict(),
            "journal": journal,
            "target_exists": Path(manifest.target_path).is_dir(),
            "baseline_exists": (root / "replaced-baseline").is_dir(),
            "staging_exists": (root / "staging").is_dir(),
            "status": "PASS" if journal["status"] == "PASS" else "CONFLICT_QUARANTINE",
        }

    def recover(self, transaction_root: str | Path) -> dict[str, Any]:
        inspection = self.inspect(transaction_root)
        if inspection["status"] != "PASS":
            return inspection
        root = Path(transaction_root).resolve()
        manifest = TransactionManifest.from_dict(inspection["manifest"])
        target = Path(manifest.target_path)
        baseline = root / "replaced-baseline"
        staging = root / "staging"
        if manifest.state in {TransactionState.COMMITTED, TransactionState.ROLLED_BACK}:
            return {
                "schema": "codeforge-transaction-recovery-v1",
                "transaction_id": manifest.transaction_id,
                "action": "NONE_TERMINAL_STATE",
                "state": manifest.state.value,
                "status": "PASS",
            }
        if baseline.is_dir():
            failed = root / "recovery-displaced-state"
            if target.exists():
                if failed.exists():
                    shutil.rmtree(failed)
                os.replace(target, failed)
            os.replace(baseline, target)
            if staging.exists():
                shutil.rmtree(staging)
            journal = TransactionJournal(root / "journal.jsonl")
            if manifest.state != TransactionState.ROLLBACK_REQUIRED:
                if manifest.state in {TransactionState.APPLIED, TransactionState.READBACK_PASS, TransactionState.PREPARED}:
                    manifest.transition(TransactionState.ROLLBACK_REQUIRED)
                    journal.append(manifest.transaction_id, manifest.state.value, {"recovery": True})
            if manifest.state == TransactionState.ROLLBACK_REQUIRED:
                manifest.transition(TransactionState.ROLLED_BACK)
                journal.append(manifest.transaction_id, manifest.state.value, {"recovery": True, "target_restored": str(target)})
            AtomicJsonStore(root / "manifest.json").write(manifest.to_dict())
            receipt = {
                "schema": "codeforge-transaction-recovery-v1",
                "transaction_id": manifest.transaction_id,
                "action": "RESTORE_RETAINED_BASELINE",
                "state": manifest.state.value,
                "target_restored": target.is_dir(),
                "journal": journal.verify(),
                "status": "PASS" if target.is_dir() else "FAIL",
            }
            AtomicJsonStore(root / "recovery-receipt.json").write(receipt)
            return receipt
        return {
            "schema": "codeforge-transaction-recovery-v1",
            "transaction_id": manifest.transaction_id,
            "action": "HOLD_NO_RETAINED_BASELINE",
            "state": manifest.state.value,
            "status": "HOLD",
        }
