from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any
import hashlib

from .connector_models import ConnectorActionPlan
from .hashchain import digest_document, seal_document


def content_sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class NullConnectorTransport:
    name = "null_connector"
    test_only = False
    network = False

    def execute(self, _: dict[str, Any], **__: Any) -> dict[str, Any]:
        return {
            "schema": "codeforge-null-connector-execution-v1",
            "status": "WRITE_BLOCKED",
            "reasons": ["REAL_CONNECTOR_TRANSPORT_NOT_AVAILABLE"],
            "mutation_performed": False,
        }


@dataclass(slots=True)
class ConnectorRefSnapshot:
    branch: str
    existed: bool
    head: str | None


class RecordingGitHubConnectorTransport:
    """Deterministic, in-memory connector test double. It never uses a network."""

    name = "recording_github_connector"
    test_only = True
    network = False

    def __init__(self, repository: str, default_branch: str = "main"):
        self.repository = repository
        self.default_branch = default_branch
        self.refs: dict[str, str] = {}
        self.trees: dict[str, dict[str, bytes]] = {}
        self.parents: dict[str, str | None] = {}
        self.actions: list[dict[str, Any]] = []

    @staticmethod
    def _tree_digest(tree: dict[str, bytes]) -> str:
        return digest_document({path: content_sha256(data) for path, data in sorted(tree.items())})

    @staticmethod
    def _commit(parent: str, tree: dict[str, bytes], message: str) -> str:
        return hashlib.sha1(f"{parent}\n{RecordingGitHubConnectorTransport._tree_digest(tree)}\n{message}".encode()).hexdigest()

    def seed(self, files: dict[str, bytes], branch: str | None = None) -> str:
        branch = branch or self.default_branch
        tree = {path: bytes(data) for path, data in files.items()}
        commit = self._commit("0" * 40, tree, "seed")
        self.trees[commit] = tree
        self.parents[commit] = None
        self.refs[branch] = commit
        return commit

    def head(self, branch: str) -> str | None:
        return self.refs.get(branch)

    def branch_exists(self, branch: str) -> bool:
        return branch in self.refs

    def tree(self, branch_or_commit: str) -> dict[str, bytes]:
        commit = self.refs.get(branch_or_commit, branch_or_commit)
        if commit not in self.trees:
            raise KeyError(f"CONNECTOR_TREE_NOT_FOUND:{branch_or_commit}")
        return deepcopy(self.trees[commit])

    def snapshot_ref(self, branch: str) -> ConnectorRefSnapshot:
        return ConnectorRefSnapshot(branch, branch in self.refs, self.refs.get(branch))

    def restore_ref(self, snapshot: ConnectorRefSnapshot) -> None:
        if snapshot.existed and snapshot.head:
            self.refs[snapshot.branch] = snapshot.head
        else:
            self.refs.pop(snapshot.branch, None)

    def execute(
        self,
        plan_document: dict[str, Any],
        *,
        content_by_path: dict[str, bytes],
        inject_failure: str | None = None,
    ) -> dict[str, Any]:
        plan = ConnectorActionPlan.from_dict(plan_document)
        validation = plan.validate()
        if validation["status"] != "PASS":
            return {"status": "WRITE_BLOCKED", "reasons": validation["reasons"], "mutation_performed": False}
        if not plan.test_only:
            return {"status": "WRITE_BLOCKED", "reasons": ["RECORDING_CONNECTOR_REQUIRES_TEST_ONLY_PLAN"], "mutation_performed": False}
        if plan.provider != "github":
            return {"status": "WRITE_BLOCKED", "reasons": ["RECORDING_CONNECTOR_PROVIDER_MISMATCH"], "mutation_performed": False}
        if self.repository != plan.repository:
            return {"status": "WRITE_BLOCKED", "reasons": ["RECORDING_CONNECTOR_REPOSITORY_MISMATCH"], "mutation_performed": False}
        if self.head(plan.base_branch) != plan.expected_base_head_sha:
            return {"status": "WRITE_BLOCKED", "reasons": ["CONNECTOR_HEAD_RECHECK_FAILED"], "mutation_performed": False}
        if self.branch_exists(plan.target_branch):
            return {"status": "WRITE_BLOCKED", "reasons": ["CONNECTOR_TARGET_BRANCH_ALREADY_EXISTS"], "mutation_performed": False}

        snapshot = self.snapshot_ref(plan.target_branch)
        tree = self.tree(plan.expected_base_head_sha)
        try:
            for action in plan.actions:
                self.actions.append(action.to_dict())
                if action.action == "create_branch":
                    continue
                assert action.path is not None
                current = tree.get(action.path)
                current_sha = content_sha256(current) if current is not None else None
                if action.action == "create_file":
                    if current is not None:
                        raise RuntimeError(f"CONNECTOR_CREATE_PATH_EXISTS:{action.path}")
                    data = content_by_path[action.path]
                    if content_sha256(data) != action.content_sha256:
                        raise RuntimeError(f"CONNECTOR_CREATE_CONTENT_MISMATCH:{action.path}")
                    tree[action.path] = data
                elif action.action == "update_file":
                    if current is None:
                        raise RuntimeError(f"CONNECTOR_UPDATE_PATH_MISSING:{action.path}")
                    if current_sha != action.expected_sha256:
                        raise RuntimeError(f"CONNECTOR_UPDATE_EXPECTED_SHA_MISMATCH:{action.path}")
                    data = content_by_path[action.path]
                    if content_sha256(data) != action.content_sha256:
                        raise RuntimeError(f"CONNECTOR_UPDATE_CONTENT_MISMATCH:{action.path}")
                    tree[action.path] = data
                elif action.action == "delete_file":
                    if current is None:
                        raise RuntimeError(f"CONNECTOR_DELETE_PATH_MISSING:{action.path}")
                    if current_sha != action.expected_sha256:
                        raise RuntimeError(f"CONNECTOR_DELETE_EXPECTED_SHA_MISMATCH:{action.path}")
                    del tree[action.path]
            commit = self._commit(plan.expected_base_head_sha, tree, f"CodeForge connector test {plan.plan_id}")
            self.trees[commit] = deepcopy(tree)
            self.parents[commit] = plan.expected_base_head_sha
            self.refs[plan.target_branch] = commit
            if inject_failure == "after_commit":
                raise RuntimeError("INJECTED_CONNECTOR_AFTER_COMMIT_FAILURE")
            return seal_document({
                "schema": "codeforge-recording-connector-execution-receipt-v1",
                "provider": "github",
                "transport": self.name,
                "repository": self.repository,
                "plan_id": plan.plan_id,
                "plan_digest": plan.digest,
                "base_head": plan.expected_base_head_sha,
                "target_branch": plan.target_branch,
                "commit_sha": commit,
                "tree_digest": self._tree_digest(tree),
                "action_count": len(plan.actions),
                "mutation_performed": True,
                "network_used": False,
                "status": "PASS",
            })
        except Exception as exc:
            self.restore_ref(snapshot)
            return seal_document({
                "schema": "codeforge-recording-connector-execution-receipt-v1",
                "provider": "github",
                "transport": self.name,
                "repository": self.repository,
                "plan_id": plan.plan_id,
                "target_branch": plan.target_branch,
                "mutation_performed": False,
                "network_used": False,
                "rollback_performed": True,
                "status": "ROLLED_BACK",
                "reason": str(exc),
            })
