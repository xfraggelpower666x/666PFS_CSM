from __future__ import annotations

from pathlib import Path
from typing import Any
import json

from .hashchain import seal_document, verify_document
from .models import stable_id, utc_now
from .storage import AtomicJsonStore

_FORBIDDEN = ("token", "secret", "password", "credential", "private_key", "api_key")


def _secret_field_paths(value: Any, prefix: str = "") -> list[str]:
    findings: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            if any(fragment in str(key).lower() for fragment in _FORBIDDEN):
                findings.append(path)
            findings.extend(_secret_field_paths(item, path))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            findings.extend(_secret_field_paths(item, f"{prefix}[{index}]"))
    return findings


def create_connector_evidence(
    *,
    provider: str,
    operation: str,
    subject: str,
    locator: str,
    payload: dict[str, Any],
    observed_at: str | None = None,
) -> dict[str, Any]:
    forbidden = _secret_field_paths(payload)
    if forbidden:
        raise ValueError(f"CONNECTOR_EVIDENCE_SECRET_FIELDS_FORBIDDEN:{','.join(forbidden)}")
    material = {
        "schema": "codeforge-connector-evidence-v1",
        "provider": provider,
        "operation": operation,
        "subject": subject,
        "locator": locator,
        "payload": payload,
        "observed_at": observed_at or utc_now(),
        "status": "VERIFIED",
    }
    material["evidence_id"] = stable_id("EVD", material)
    return seal_document(material)


class ConnectorEvidenceStore:
    def __init__(self, root: str | Path):
        self.root = Path(root)

    def write(self, receipt: dict[str, Any]) -> dict[str, Any]:
        if not verify_document(receipt):
            return {"status": "WRITE_BLOCKED", "reason": "CONNECTOR_EVIDENCE_DIGEST_MISMATCH"}
        if _secret_field_paths(receipt):
            return {"status": "WRITE_BLOCKED", "reason": "CONNECTOR_EVIDENCE_SECRET_FIELDS_FORBIDDEN"}
        evidence_id = str(receipt.get("evidence_id", ""))
        if not evidence_id:
            return {"status": "WRITE_BLOCKED", "reason": "CONNECTOR_EVIDENCE_ID_MISSING"}
        path = self.root / f"{evidence_id}.json"
        AtomicJsonStore(path).write(receipt)
        readback = json.loads(path.read_text(encoding="utf-8"))
        return {
            "schema": "codeforge-connector-evidence-store-receipt-v1",
            "evidence_id": evidence_id,
            "path": str(path),
            "readback": "PASS" if readback == receipt and verify_document(readback) else "FAIL",
            "status": "PASS" if readback == receipt and verify_document(readback) else "FAIL",
        }
