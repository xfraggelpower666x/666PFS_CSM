from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
import json
import uuid

from .hashchain import seal_document, verify_document
from .models import stable_id, utc_now
from .storage import AtomicJsonStore
from .writer_models import proposal_digest


AUTHORIZATION_PREFIX = "AUTHORIZE_LOCAL_SANDBOX"


class AuthorizationBlocked(RuntimeError):
    def __init__(self, code: str, receipt: dict[str, Any]):
        super().__init__(code)
        self.code = code
        self.receipt = receipt


def expected_authorization_phrase(proposal: dict[str, Any]) -> str:
    return f"{AUTHORIZATION_PREFIX}::{proposal.get('proposal_id')}::{proposal.get('digest')}"


class ExecutionAuthorizationRegistry:
    """One-time authorization receipts bound to one sealed proposal digest.

    The receipt is deliberately not a replacement for connector authentication.
    It only proves that CodeForge received the exact local authorization phrase.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root)

    def _path(self, authorization_id: str) -> Path:
        return self.root / f"{authorization_id}.json"

    @staticmethod
    def _load_proposal(proposal: dict[str, Any] | str | Path) -> dict[str, Any]:
        if isinstance(proposal, (str, Path)):
            return json.loads(Path(proposal).read_text(encoding="utf-8"))
        return proposal

    @staticmethod
    def verify_proposal(proposal: dict[str, Any]) -> dict[str, Any]:
        proposal_id = str(proposal.get("proposal_id", ""))
        expected = str(proposal.get("digest", ""))
        actual = proposal_digest(proposal, proposal_id)
        valid = (
            proposal.get("schema") == "codeforge-change-proposal-v1"
            and bool(proposal_id)
            and expected == actual
        )
        return {
            "schema": "codeforge-proposal-integrity-v1",
            "proposal_id": proposal_id,
            "expected_digest": expected,
            "actual_digest": actual,
            "status": "PASS" if valid else "FAIL",
        }

    def issue(
        self,
        proposal: dict[str, Any] | str | Path,
        *,
        phrase: str,
        issued_by: str,
        ttl_seconds: int = 900,
    ) -> dict[str, Any]:
        document = self._load_proposal(proposal)
        integrity = self.verify_proposal(document)
        if integrity["status"] != "PASS":
            raise AuthorizationBlocked("PROPOSAL_INTEGRITY_FAIL", integrity)
        if phrase != expected_authorization_phrase(document):
            raise AuthorizationBlocked("EXACT_AUTHORIZATION_PHRASE_REQUIRED", {
                "schema": "codeforge-authorization-gate-v1",
                "status": "WRITE_BLOCKED",
                "proposal_id": document.get("proposal_id"),
                "reason": "EXACT_AUTHORIZATION_PHRASE_REQUIRED",
            })
        if not issued_by.strip():
            raise ValueError("issued_by is required")
        if ttl_seconds < 30 or ttl_seconds > 3600:
            raise ValueError("ttl_seconds must be between 30 and 3600")

        self.root.mkdir(parents=True, exist_ok=True)
        issued_at = datetime.now(timezone.utc).replace(microsecond=0)
        expires_at = issued_at + timedelta(seconds=ttl_seconds)
        authorization_id = stable_id("AUT", {
            "proposal_id": document["proposal_id"],
            "proposal_digest": document["digest"],
            "issued_by": issued_by,
            "issued_at": issued_at.isoformat(),
            "nonce": uuid.uuid4().hex,
        })
        receipt = seal_document({
            "schema": "codeforge-execution-authorization-v1",
            "authorization_id": authorization_id,
            "proposal_id": document["proposal_id"],
            "proposal_digest": document["digest"],
            "target": document.get("target"),
            "issued_by": issued_by,
            "issued_at": issued_at.isoformat(),
            "expires_at": expires_at.isoformat(),
            "single_use": True,
            "consumed": False,
            "consumed_at": None,
            "status": "PASS",
        })
        AtomicJsonStore(self._path(authorization_id)).write(receipt)
        return receipt

    def inspect(self, authorization_id: str) -> dict[str, Any]:
        path = self._path(authorization_id)
        if not path.is_file():
            return {"status": "WRITE_BLOCKED", "reason": "AUTHORIZATION_NOT_FOUND"}
        receipt = json.loads(path.read_text(encoding="utf-8"))
        reasons: list[str] = []
        if not verify_document(receipt):
            reasons.append("AUTHORIZATION_DIGEST_MISMATCH")
        try:
            expired = datetime.fromisoformat(receipt["expires_at"]) <= datetime.now(timezone.utc)
        except (KeyError, TypeError, ValueError):
            expired = True
        if expired:
            reasons.append("AUTHORIZATION_EXPIRED")
        if receipt.get("consumed"):
            reasons.append("AUTHORIZATION_ALREADY_CONSUMED")
        return {
            "schema": "codeforge-authorization-inspection-v1",
            "authorization": receipt,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
        }

    def consume(self, authorization_id: str, proposal: dict[str, Any]) -> dict[str, Any]:
        inspection = self.inspect(authorization_id)
        if inspection["status"] != "PASS":
            raise AuthorizationBlocked("AUTHORIZATION_NOT_USABLE", inspection)
        receipt = inspection["authorization"]
        if receipt.get("proposal_id") != proposal.get("proposal_id") or receipt.get("proposal_digest") != proposal.get("digest"):
            raise AuthorizationBlocked("AUTHORIZATION_PROPOSAL_MISMATCH", {
                "status": "WRITE_BLOCKED",
                "authorization_id": authorization_id,
                "proposal_id": proposal.get("proposal_id"),
            })
        updated = dict(receipt)
        updated["consumed"] = True
        updated["consumed_at"] = utc_now()
        updated["status"] = "CONSUMED"
        updated = seal_document(updated)
        AtomicJsonStore(self._path(authorization_id)).write(updated)
        return {
            "schema": "codeforge-authorization-consumption-v1",
            "authorization_id": authorization_id,
            "proposal_id": proposal.get("proposal_id"),
            "status": "PASS",
            "consumed_at": updated["consumed_at"],
        }
