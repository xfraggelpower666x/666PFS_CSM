from __future__ import annotations

from enum import StrEnum


class Status(StrEnum):
    VERIFIED = "VERIFIED"
    DERIVED = "DERIVED"
    PROPOSED = "PROPOSED"
    OPEN = "OPEN"
    BLOCKED = "BLOCKED"
    PARTIAL = "PARTIAL"
    WRITE_BLOCKED = "WRITE_BLOCKED"
    READBACK_PENDING = "READBACK_PENDING"
    CONFLICT_QUARANTINE = "CONFLICT_QUARANTINE"
    PASS = "PASS"
    FAIL = "FAIL"
    HOLD = "HOLD"
