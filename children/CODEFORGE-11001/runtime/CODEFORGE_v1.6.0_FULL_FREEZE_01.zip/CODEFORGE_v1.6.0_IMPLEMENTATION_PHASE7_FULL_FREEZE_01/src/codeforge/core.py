from __future__ import annotations

from pathlib import Path
from typing import Any

from .continuation import ContinuationKernel
from .engineering import EngineeringKernel
from .models import Checkpoint
from .pidb import ProjectIntelligenceDatabase
from .providers.disabled_remote import DisabledRemoteProvider
from .providers.local_sandbox import LocalSandboxProvider
from .providers.registry import ProviderRegistry
from .providers.github_connector_candidate import GitHubConnectorCandidateProvider
from .providers.cloudflare_connector_candidate import CloudflareConnectorCandidateProvider
from .providers.github_host_execution_candidate import GitHubHostExecutionCandidateProvider
from .registry import CapabilityRegistry, StageRegistry
from .storage import AtomicJsonStore


class CoreKernel:
    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self.continuation = ContinuationKernel(self.workspace)
        self.engineering = EngineeringKernel(self.workspace)
        self.pidb = ProjectIntelligenceDatabase(self.workspace / "pidb")
        self.stage_registry = StageRegistry(self.workspace / "registry" / "stages.json", "codeforge-stage-registry-v1")
        self.capability_registry = CapabilityRegistry(self.workspace / "registry" / "capabilities.json", "codeforge-capability-registry-v1")
        self.providers = ProviderRegistry()
        self.providers.register(LocalSandboxProvider(str(self.workspace)))
        self.providers.register(DisabledRemoteProvider("github"))
        self.providers.register(DisabledRemoteProvider("cloudflare"))
        self.providers.register(GitHubConnectorCandidateProvider())
        self.providers.register(CloudflareConnectorCandidateProvider())
        self.providers.register(GitHubHostExecutionCandidateProvider())

    def initialize(self) -> dict[str, Any]:
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.continuation.initialize()
        self.pidb.initialize()
        self.stage_registry.seed()
        self.capability_registry.seed()
        sandbox_root = (self.workspace / "sandboxes").resolve()
        sandbox_root.mkdir(parents=True, exist_ok=True)
        config = AtomicJsonStore(self.workspace / "workspace.json")
        desired = {
            "schema": "codeforge-workspace-v1",
            "framework_version": "1.6.0",
            "mode": "REPOSITORY_INTEGRATED_RADIO_CODING_AGENT_PHASE_7",
            "pipeline": [
                "analysis", "evidence", "reconciliation", "repair_plan",
                "pre_change_backup", "proposal", "authorization", "transaction_prepare",
                "local_sandbox_execute", "remote_contract", "branch_isolation",
                "capability_receipt", "remote_lock", "mock_remote_execute",
                "remote_readback", "connector_session_receipt", "connector_head_receipt",
                "connector_candidate_gate", "connector_action_plan", "connector_readback",
                "rollback_or_commit",
                "re_audit", "checkpoint", "resume",
            ],
            "execution": {
                "mode": "HOST_BOUND_CONNECTOR_ADAPTER_DESIGN",
                "local_sandbox_enabled": False,
                "mock_remote_execution_enabled": False,
                "real_remote_execution_enabled": False,
                "real_connector_execution_enabled": False,
                "sandbox_root": str(sandbox_root),
                "github_write_enabled": False,
                "cloudflare_write_enabled": False,
                "connector_candidate_test_execution_enabled": False,
                "connector_network_write_enabled": False,
                "host_adapter_test_execution_enabled": False,
                "exact_head_read_action_required": True,
                "real_target_allowlist_empty": True,
                "real_target_allowlist": [],
            },
        }
        existing = config.read()
        if not isinstance(existing, dict):
            config.write(desired)
        else:
            merged = desired
            if existing.get("execution", {}).get("local_sandbox_enabled") is True:
                merged["execution"]["local_sandbox_enabled"] = True
            if existing != merged:
                config.write(merged)
        return self.status()

    def create_checkpoint(self, phase: str, state: str, block_from: int, block_to: int, payload: dict[str, Any]) -> Checkpoint:
        current = self.continuation.status().get("last_checkpoint")
        checkpoint = Checkpoint(
            phase=phase, state=state, block_from=block_from, block_to=block_to,
            payload=payload, previous_checkpoint=(current or {}).get("checkpoint_id"),
        )
        return self.continuation.checkpoint(checkpoint)

    def status(self) -> dict[str, Any]:
        config = AtomicJsonStore(self.workspace / "workspace.json").read({})
        return {
            "workspace": str(self.workspace.resolve()),
            "framework_version": "1.6.0",
            "mode": "REPOSITORY_INTEGRATED_RADIO_CODING_AGENT_PHASE_7",
            "execution": config.get("execution", {}),
            "continuation": self.continuation.status(),
            "stages": self.stage_registry.all(),
            "capabilities": self.capability_registry.all(),
            "providers": self.providers.inventory(),
        }
