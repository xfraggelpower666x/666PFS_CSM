from __future__ import annotations

from pathlib import Path
from typing import Any

from ..project_graph import ProjectGraphBuilder
from ..scanner import RepositoryScanner


class ProjectIntelligenceKernel:
    """Koppelt Repository-Scan und Project Graph ohne Projektmutation."""

    def analyse(self, root: str | Path) -> dict[str, Any]:
        scan = RepositoryScanner().scan(root)
        graph = ProjectGraphBuilder().build(scan)
        return {"scan": scan.to_dict(), "graph": graph}


__all__ = ["ProjectIntelligenceKernel"]
