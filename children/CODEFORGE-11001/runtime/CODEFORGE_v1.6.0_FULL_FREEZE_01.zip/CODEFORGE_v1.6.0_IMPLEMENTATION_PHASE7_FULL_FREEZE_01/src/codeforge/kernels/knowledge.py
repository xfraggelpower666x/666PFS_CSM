from pathlib import Path

from ..pidb import ProjectIntelligenceDatabase


class KnowledgeKernel(ProjectIntelligenceDatabase):
    """Explizite Kernel-Oberfläche für die Project Intelligence Database."""

    def __init__(self, root: str | Path):
        super().__init__(root)


__all__ = ["KnowledgeKernel"]
