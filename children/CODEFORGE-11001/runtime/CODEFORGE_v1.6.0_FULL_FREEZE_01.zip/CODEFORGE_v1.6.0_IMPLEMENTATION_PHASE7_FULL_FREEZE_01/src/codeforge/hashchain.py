from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_json(data: Any) -> str:
    return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)


def digest_document(data: Any) -> str:
    return hashlib.sha256(canonical_json(data).encode("utf-8")).hexdigest()


def seal_document(document: dict[str, Any], *, digest_field: str = "digest") -> dict[str, Any]:
    sealed = dict(document)
    sealed.pop(digest_field, None)
    sealed[digest_field] = digest_document(sealed)
    return sealed


def verify_document(document: dict[str, Any], *, digest_field: str = "digest") -> bool:
    expected = str(document.get(digest_field, ""))
    material = dict(document)
    material.pop(digest_field, None)
    return bool(expected) and expected == digest_document(material)
