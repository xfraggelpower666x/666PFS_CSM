from __future__ import annotations

from pathlib import Path
from typing import Any, Callable
import json
import os
import shutil

from .authorization import ExecutionAuthorizationRegistry
from .execution_gate import ExecutionGate
from .models import utc_now
from .readback import ProposalReadbackVerifier
from .snapshot import DirectorySnapshot
from .storage import AtomicJsonStore
from .targets import RemoteHeadClaim
from .transaction_journal import TransactionJournal
from .transaction_models import TransactionManifest, TransactionState
from .verification import VerificationLayer


class TransactionBlocked(RuntimeError):
    def __init__(self, code: str, receipt: dict[str, Any]):
        super().__init__(code)
        self.code = code
        self.receipt = receipt


class AtomicLocalSandboxExecutor:
    """Atomic local sandbox executor. Remote providers remain hard disabled."""

    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace).resolve()
        self.transactions_root = self.workspace / "transactions"
        self.authorizations = ExecutionAuthorizationRegistry(self.workspace / "authorizations")

    @staticmethod
    def _load(value: dict[str, Any] | str | Path) -> dict[str, Any]:
        if isinstance(value, (str, Path)):
            return json.loads(Path(value).read_text(encoding="utf-8"))
        return value

    @staticmethod
    def _copy_candidate_file(candidate: Path, staging: Path, rel: str) -> None:
        source = candidate / rel
        if not source.is_file():
            raise FileNotFoundError(f"CANDIDATE_FILE_MISSING:{rel}")
        target = staging / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    def execute(
        self,
        *,
        proposal: dict[str, Any] | str | Path,
        authorization_id: str,
        candidate: str | Path,
        target: str | Path,
        remote_head: RemoteHeadClaim,
        runtime_config: dict[str, Any],
        failure_hook: Callable[[str, TransactionManifest], None] | None = None,
    ) -> dict[str, Any]:
        document = self._load(proposal)
        candidate_root = Path(candidate).resolve()
        target_root = Path(target).resolve()
        inspection = self.authorizations.inspect(authorization_id)
        if inspection["status"] != "PASS":
            raise TransactionBlocked("AUTHORIZATION_BLOCKED", inspection)
        authorization = inspection["authorization"]
        gate = ExecutionGate().evaluate(
            proposal=document,
            authorization=authorization,
            candidate=candidate_root,
            target=target_root,
            remote_head=remote_head,
            runtime_config=runtime_config,
        )
        if gate["status"] != "PASS":
            raise TransactionBlocked("EXECUTION_GATE_BLOCKED", gate)

        manifest = TransactionManifest(
            proposal_id=document["proposal_id"],
            proposal_digest=document["digest"],
            authorization_id=authorization_id,
            target_identity=f"{document['target']['repository']}@{document['target']['branch']}",
            target_path=str(target_root),
            candidate_path=str(candidate_root),
            operation_count=len(document.get("operations", [])),
        ).seal()
        tx_root = self.transactions_root / manifest.transaction_id
        staging = tx_root / "staging"
        replaced_baseline = tx_root / "replaced-baseline"
        manifest_path = tx_root / "manifest.json"
        journal = TransactionJournal(tx_root / "journal.jsonl")
        tx_root.mkdir(parents=True, exist_ok=False)
        AtomicJsonStore(manifest_path).write(manifest.to_dict())
        journal.append(manifest.transaction_id, manifest.state.value, {"gate": gate})

        try:
            consumption = self.authorizations.consume(authorization_id, document)
            manifest.transition(TransactionState.AUTHORIZED)
            AtomicJsonStore(manifest_path).write(manifest.to_dict())
            journal.append(manifest.transaction_id, manifest.state.value, {"authorization": consumption})

            snapshot = DirectorySnapshot().create(target_root, tx_root / "pre-change-full.zip")
            if snapshot["status"] != "PASS":
                raise RuntimeError("TRANSACTION_SNAPSHOT_FAILED")
            shutil.copytree(target_root, staging)
            for operation in document.get("operations", []):
                rel = operation["path"]
                stage_path = staging / rel
                if operation["operation"] in {"create", "update"}:
                    self._copy_candidate_file(candidate_root, staging, rel)
                elif operation["operation"] == "delete":
                    if stage_path.exists():
                        stage_path.unlink()
                else:
                    raise RuntimeError(f"UNSUPPORTED_OPERATION:{operation['operation']}")
            stage_readback = ProposalReadbackVerifier().verify(document, staging)
            if stage_readback["status"] != "PASS":
                raise RuntimeError("STAGING_READBACK_FAILED")
            manifest.transition(TransactionState.PREPARED)
            AtomicJsonStore(manifest_path).write(manifest.to_dict())
            journal.append(manifest.transaction_id, manifest.state.value, {
                "snapshot": snapshot, "staging_readback": stage_readback,
            })
            if failure_hook:
                failure_hook("PREPARED", manifest)

            os.replace(target_root, replaced_baseline)
            try:
                os.replace(staging, target_root)
            except BaseException:
                os.replace(replaced_baseline, target_root)
                raise
            manifest.transition(TransactionState.APPLIED)
            AtomicJsonStore(manifest_path).write(manifest.to_dict())
            journal.append(manifest.transaction_id, manifest.state.value, {"swapped_at": utc_now()})
            if failure_hook:
                failure_hook("APPLIED", manifest)

            final_readback = ProposalReadbackVerifier().verify(document, target_root)
            if final_readback["status"] != "PASS":
                raise RuntimeError("FINAL_READBACK_FAILED")
            manifest.transition(TransactionState.READBACK_PASS)
            AtomicJsonStore(manifest_path).write(manifest.to_dict())
            journal.append(manifest.transaction_id, manifest.state.value, {"readback": final_readback})
            if failure_hook:
                failure_hook("READBACK_PASS", manifest)

            manifest.transition(TransactionState.COMMITTED)
            AtomicJsonStore(manifest_path).write(manifest.to_dict())
            journal.append(manifest.transaction_id, manifest.state.value, {
                "baseline_retained": str(replaced_baseline),
            })
            journal_receipt = journal.verify()
            receipt = {
                "schema": "codeforge-local-transaction-receipt-v1",
                "transaction_id": manifest.transaction_id,
                "proposal_id": document["proposal_id"],
                "target": str(target_root),
                "state": manifest.state.value,
                "mutation_performed": True,
                "remote_mutation_performed": False,
                "readback": final_readback,
                "snapshot": snapshot,
                "journal": journal_receipt,
                "status": "PASS" if journal_receipt["status"] == "PASS" else "FAIL",
            }
            AtomicJsonStore(tx_root / "receipt.json").write(receipt)
            return receipt
        except BaseException as exc:
            rollback = self._rollback(target_root, staging, replaced_baseline, manifest, journal, str(exc))
            AtomicJsonStore(manifest_path).write(manifest.to_dict())
            AtomicJsonStore(tx_root / "rollback-receipt.json").write(rollback)
            raise TransactionBlocked("TRANSACTION_ROLLED_BACK", rollback) from exc

    @staticmethod
    def _rollback(
        target: Path,
        staging: Path,
        replaced_baseline: Path,
        manifest: TransactionManifest,
        journal: TransactionJournal,
        error: str,
    ) -> dict[str, Any]:
        try:
            if manifest.state in {TransactionState.PREPARED, TransactionState.APPLIED, TransactionState.READBACK_PASS}:
                if manifest.state != TransactionState.PREPARED:
                    manifest.transition(TransactionState.ROLLBACK_REQUIRED)
                    journal.append(manifest.transaction_id, manifest.state.value, {"error": error})
                else:
                    manifest.transition(TransactionState.ROLLBACK_REQUIRED)
                    journal.append(manifest.transaction_id, manifest.state.value, {"error": error})
            if replaced_baseline.is_dir():
                failed = replaced_baseline.parent / "failed-applied-state"
                if target.exists():
                    if failed.exists():
                        shutil.rmtree(failed)
                    os.replace(target, failed)
                os.replace(replaced_baseline, target)
            if staging.exists():
                shutil.rmtree(staging)
            if manifest.state == TransactionState.ROLLBACK_REQUIRED:
                manifest.transition(TransactionState.ROLLED_BACK)
                journal.append(manifest.transaction_id, manifest.state.value, {"restored_target": str(target)})
            return {
                "schema": "codeforge-local-rollback-receipt-v1",
                "transaction_id": manifest.transaction_id,
                "state": manifest.state.value,
                "target_restored": target.is_dir(),
                "error": error,
                "journal": journal.verify(),
                "status": "PASS" if target.is_dir() and manifest.state == TransactionState.ROLLED_BACK else "FAIL",
            }
        except BaseException as rollback_error:
            return {
                "schema": "codeforge-local-rollback-receipt-v1",
                "transaction_id": manifest.transaction_id,
                "state": "FAILED",
                "target_restored": target.is_dir(),
                "error": error,
                "rollback_error": str(rollback_error),
                "status": "FAIL",
            }
