from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


class VerificationLayer:
    """Verifiziert Dateien und Inventare per SHA-256; keine stillen Korrekturen."""

    @staticmethod
    def sha256(path: str | Path) -> str:
        digest = hashlib.sha256()
        with Path(path).open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def verify_file(self, path: str | Path, expected_sha256: str) -> dict[str, Any]:
        actual = self.sha256(path)
        return {
            "path": str(Path(path)),
            "expected_sha256": expected_sha256,
            "actual_sha256": actual,
            "status": "PASS" if actual == expected_sha256 else "FAIL",
        }

    def verify_inventory(self, root: str | Path, inventory: list[dict[str, Any]]) -> dict[str, Any]:
        root_path = Path(root)
        mismatches = []
        for record in inventory:
            path = root_path / record["path"]
            if not path.is_file():
                mismatches.append({"path": record["path"], "reason": "MISSING"})
                continue
            actual = self.sha256(path)
            if actual != record["sha256"]:
                mismatches.append({
                    "path": record["path"],
                    "reason": "HASH_MISMATCH",
                    "expected": record["sha256"],
                    "actual": actual,
                })
        return {
            "status": "PASS" if not mismatches else "FAIL",
            "checked": len(inventory),
            "mismatches": mismatches,
        }
