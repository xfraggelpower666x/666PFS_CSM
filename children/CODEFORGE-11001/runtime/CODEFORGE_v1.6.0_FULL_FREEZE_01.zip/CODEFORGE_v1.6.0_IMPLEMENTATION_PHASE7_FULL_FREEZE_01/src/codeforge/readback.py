from __future__ import annotations

from pathlib import Path
from typing import Any
import json

from .verification import VerificationLayer
from .writer_models import proposal_digest


class ProposalReadbackVerifier:
    def verify(self, proposal: dict[str, Any] | str | Path, post_state: str | Path) -> dict[str, Any]:
        if isinstance(proposal, (str, Path)):
            document = json.loads(Path(proposal).read_text(encoding="utf-8"))
        else:
            document = proposal
        if document.get("schema") != "codeforge-change-proposal-v1":
            raise ValueError("Unsupported proposal schema")
        proposal_id = str(document.get("proposal_id", ""))
        expected_digest = str(document.get("digest", ""))
        actual_digest = proposal_digest(document, proposal_id)
        integrity_pass = bool(proposal_id) and expected_digest == actual_digest

        root = Path(post_state).resolve()
        mismatches: list[dict[str, Any]] = []
        if not integrity_pass:
            mismatches.append({
                "path": None,
                "reason": "PROPOSAL_DIGEST_MISMATCH",
                "expected": expected_digest,
                "actual": actual_digest,
            })
        for operation in document.get("operations", []):
            path = root / operation["path"]
            if operation["operation"] in {"create", "update"}:
                if not path.is_file():
                    mismatches.append({"path": operation["path"], "reason": "MISSING"})
                    continue
                actual = VerificationLayer.sha256(path)
                if actual != operation["new_sha256"]:
                    mismatches.append({
                        "path": operation["path"], "reason": "HASH_MISMATCH",
                        "expected": operation["new_sha256"], "actual": actual,
                    })
            elif operation["operation"] == "delete" and path.exists():
                mismatches.append({"path": operation["path"], "reason": "EXPECTED_ABSENT"})
        return {
            "schema": "codeforge-proposal-readback-v1",
            "proposal_id": proposal_id,
            "proposal_digest": expected_digest,
            "actual_proposal_digest": actual_digest,
            "proposal_integrity": "PASS" if integrity_pass else "FAIL",
            "post_state": str(root),
            "checked": len(document.get("operations", [])),
            "mismatches": mismatches,
            "status": "PASS" if not mismatches else "FAIL",
        }
