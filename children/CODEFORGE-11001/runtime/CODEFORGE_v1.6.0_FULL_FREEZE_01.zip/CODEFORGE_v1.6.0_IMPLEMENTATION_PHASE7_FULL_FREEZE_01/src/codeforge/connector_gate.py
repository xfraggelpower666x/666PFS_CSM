from __future__ import annotations

from typing import Any

from .connector_models import ConnectorHeadReceipt, ConnectorSessionReceipt
from .connector_policy import ConnectorAdapterPolicy
from .hashchain import seal_document, verify_document
from .remote_capability import validate_capability_receipt
from .remote_lock import validate_remote_lock
from .remote_models import RemoteExecutionContract
from .remote_sensitive_guard import scan_remote_operations


class ConnectorCandidateGate:
    def __init__(self, policy: ConnectorAdapterPolicy):
        self.policy = policy

    def evaluate(
        self,
        *,
        contract: dict[str, Any],
        session: dict[str, Any],
        head_receipt: dict[str, Any],
        capability: dict[str, Any],
        lock: dict[str, Any],
        allowlist_receipts: list[dict[str, Any]],
        default_branch: str,
        target_branch_exists: bool,
    ) -> dict[str, Any]:
        parsed = RemoteExecutionContract.from_dict(contract)
        reasons: list[str] = []
        checks: dict[str, Any] = {}

        checks["contract"] = parsed.validate()
        if checks["contract"]["status"] != "PASS":
            reasons.extend(checks["contract"]["reasons"])
        if parsed.execution_mode != "CONTRACT_ONLY":
            reasons.append("CONNECTOR_CANDIDATE_REQUIRES_CONTRACT_ONLY_MODE")

        checks["policy"] = self.policy.evaluate_candidate(
            provider=parsed.provider,
            session=session,
            repository=parsed.repository,
            base_branch=parsed.base_branch,
            target_branch=parsed.target_branch,
            default_branch=default_branch,
            target_branch_exists=target_branch_exists,
        )
        if checks["policy"]["status"] != "PASS":
            reasons.extend(checks["policy"]["reasons"])

        parsed_session = ConnectorSessionReceipt.from_dict(session)
        checks["head"] = ConnectorHeadReceipt.from_dict(head_receipt).validate(
            provider=parsed.provider,
            connector_session_id=parsed_session.session_id,
            repository=parsed.repository,
            branch=parsed.base_branch,
            expected_head_sha=parsed.expected_base_head_sha,
        )
        if checks["head"]["status"] != "PASS":
            reasons.extend(checks["head"]["reasons"])

        checks["capability"] = validate_capability_receipt(
            capability,
            provider=parsed.provider,
            repository=parsed.repository,
            require_mock_write=False,
        )
        if checks["capability"]["status"] != "PASS":
            reasons.extend(checks["capability"]["reasons"])
        if capability.get("receipt_id") != parsed.capability_evidence_id:
            reasons.append("CONNECTOR_CAPABILITY_CONTRACT_MISMATCH")
        provider_rule = self.policy.provider_rule(parsed.provider)
        if not set(provider_rule.get("required_permissions", [])).issubset(set(capability.get("permissions", []))):
            reasons.append("CONNECTOR_CAPABILITY_PERMISSIONS_INCOMPLETE")
        if not set(provider_rule.get("required_methods", [])).issubset(set(capability.get("methods", []))):
            reasons.append("CONNECTOR_CAPABILITY_METHODS_INCOMPLETE")
        if capability.get("subject") != parsed_session.principal:
            reasons.append("CONNECTOR_CAPABILITY_PRINCIPAL_MISMATCH")

        checks["lock"] = validate_remote_lock(
            lock,
            target_identity=f"{parsed.repository}@{parsed.target_branch}",
            expected_head_sha=parsed.expected_base_head_sha,
        )
        if checks["lock"]["status"] != "PASS":
            reasons.extend(checks["lock"]["reasons"])
        if lock.get("lock_id") != parsed.lock_id:
            reasons.append("CONNECTOR_LOCK_CONTRACT_MISMATCH")

        if len(allowlist_receipts) != len(parsed.operations):
            reasons.append("CONNECTOR_ALLOWLIST_RECEIPT_COUNT_MISMATCH")
        for index, receipt in enumerate(allowlist_receipts):
            if not receipt.get("allowed") or receipt.get("status") != "PASS":
                reasons.append(f"CONNECTOR_ALLOWLIST_FAILED:{index}")
            if index < len(parsed.operations):
                operation = parsed.operations[index]
                if receipt.get("path") != operation.path or receipt.get("operation") != operation.operation:
                    reasons.append(f"CONNECTOR_ALLOWLIST_BINDING_MISMATCH:{index}")

        checks["sensitive_guard"] = scan_remote_operations(parsed.operations)
        if checks["sensitive_guard"]["status"] != "PASS":
            reasons.append("CONNECTOR_SENSITIVE_CONTENT_BLOCKED")

        if not verify_document(capability):
            reasons.append("CONNECTOR_CAPABILITY_DIGEST_MISMATCH")
        if not verify_document(lock):
            reasons.append("CONNECTOR_LOCK_DIGEST_MISMATCH")

        return seal_document({
            "schema": "codeforge-connector-candidate-gate-v1",
            "contract_id": parsed.contract_id,
            "checks": checks,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": sorted(set(reasons)),
            "real_execution_enabled": False,
        })
