from __future__ import annotations

from pathlib import Path
from typing import Any

from .hashchain import digest_document
from .models import utc_now
from .storage import JsonlLedger


class RemoteExecutionJournal:
    def __init__(self,path:str|Path):self.ledger=JsonlLedger(path)
    def append(self,state:str,payload:dict[str,Any])->dict[str,Any]:
        records=self.ledger.read_all(); previous=records[-1]["record_digest"] if records else "0"*64
        record={"schema":"codeforge-remote-journal-record-v1","sequence":len(records)+1,"state":state,"payload":payload,"previous_digest":previous,"created_at":utc_now()}; record["record_digest"]=digest_document(record); self.ledger.append(record); return record
    def verify(self)->dict[str,Any]:
        reasons=[]; previous="0"*64; records=self.ledger.read_all()
        for index,record in enumerate(records,1):
            expected=record.get("record_digest"); material=dict(record); material.pop("record_digest",None)
            if record.get("sequence")!=index: reasons.append(f"SEQUENCE_MISMATCH:{index}")
            if record.get("previous_digest")!=previous: reasons.append(f"PREVIOUS_DIGEST_MISMATCH:{index}")
            if digest_document(material)!=expected: reasons.append(f"RECORD_DIGEST_MISMATCH:{index}")
            previous=str(expected)
        return {"schema":"codeforge-remote-journal-verification-v1","records":len(records),"tail_digest":previous,"status":"PASS" if not reasons else "FAIL","reasons":reasons}
