from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .models import Checkpoint, stable_id, utc_now
from .storage import AtomicJsonStore, JsonlLedger


def _canonical_digest(payload: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def _checkpoint_digest(data: dict[str, Any]) -> str:
    material = {
        "checkpoint_id": data["checkpoint_id"],
        "phase": data["phase"],
        "state": data["state"],
        "block_from": data["block_from"],
        "block_to": data["block_to"],
        "payload": data["payload"],
        "previous_checkpoint": data.get("previous_checkpoint"),
        "created_at": data["created_at"],
    }
    # Checkpoint.seal() historically uses JSON's default separators. Preserve it.
    return hashlib.sha256(
        json.dumps(material, sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()


class ContinuationKernel:
    """Crash-safe interruption, integration, re-audit and resume lifecycle.

    The v2 state is backward compatible with v1. A resume is rejected when the
    checkpoint, interruption chain, active task or latest re-audit is missing or
    has been changed after sealing.
    """

    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        root = self.workspace / "continuation"
        self.state_store = AtomicJsonStore(root / "state.json")
        self.checkpoint_ledger = JsonlLedger(root / "checkpoints.jsonl")
        self.interruption_ledger = JsonlLedger(root / "interruptions.jsonl")
        self.integration_ledger = JsonlLedger(root / "integrations.jsonl")
        self.knowledge_ledger = JsonlLedger(root / "knowledge_updates.jsonl")
        self.architecture_ledger = JsonlLedger(root / "architecture_audits.jsonl")
        self.reaudit_ledger = JsonlLedger(root / "reaudits.jsonl")

    def _new_state(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-continuation-v2",
            "active_task": None,
            "active_task_digest": None,
            "last_checkpoint": None,
            "pending_interruptions": [],
            "last_integration_receipt": None,
            "last_reaudit_receipt": None,
            "resume_state": "IDLE",
            "updated_at": utc_now(),
        }

    def initialize(self) -> None:
        if not self.state_store.path.exists():
            self.state_store.write(self._new_state())
            return
        state = self.state_store.read()
        if state.get("schema") == "codeforge-continuation-v1":
            migrated = self._new_state()
            migrated.update({
                "active_task": state.get("active_task"),
                "last_checkpoint": state.get("last_checkpoint"),
                "pending_interruptions": state.get("pending_interruptions", []),
                "resume_state": state.get("resume_state", "IDLE"),
            })
            if migrated["active_task"] is not None:
                migrated["active_task_digest"] = _canonical_digest(migrated["active_task"])
            migrated["migration"] = {"from": "codeforge-continuation-v1", "at": utc_now()}
            self.state_store.write(migrated)

    def _read_state(self) -> dict[str, Any]:
        self.initialize()
        state = self.state_store.read()
        if state.get("schema") != "codeforge-continuation-v2":
            raise RuntimeError("Unsupported continuation state schema")
        return state

    def set_active_task(self, task: dict[str, Any]) -> None:
        state = self._read_state()
        state["active_task"] = task
        state["active_task_digest"] = _canonical_digest(task)
        state["resume_state"] = "ACTIVE"
        state["updated_at"] = utc_now()
        self.state_store.write(state)

    def checkpoint(self, checkpoint: Checkpoint) -> Checkpoint:
        state = self._read_state()
        checkpoint.seal()
        record = checkpoint.to_dict()
        if record["digest"] != _checkpoint_digest(record):
            raise RuntimeError("Checkpoint seal mismatch")
        self.checkpoint_ledger.append(record)
        state["last_checkpoint"] = record
        state["resume_state"] = "CHECKPOINTED"
        state["updated_at"] = utc_now()
        self.state_store.write(state)
        return checkpoint

    def interrupt(self, message: str, classification: str = "USER_INFORMATION") -> dict[str, Any]:
        state = self._read_state()
        checkpoint = state.get("last_checkpoint") or {}
        material = {
            "at": utc_now(),
            "classification": classification,
            "message": message,
            "checkpoint_id": checkpoint.get("checkpoint_id"),
            "checkpoint_digest": checkpoint.get("digest"),
            "active_task_digest": state.get("active_task_digest"),
            "integration_state": "PENDING",
        }
        record = dict(material)
        record["interruption_id"] = stable_id("INT", material)
        record["digest"] = _canonical_digest(material)
        self.interruption_ledger.append(record)
        state["pending_interruptions"].append(record)
        state["last_integration_receipt"] = None
        state["last_reaudit_receipt"] = None
        state["resume_state"] = "INTERRUPTED"
        state["updated_at"] = utc_now()
        self.state_store.write(state)
        return record

    def _verify_interruption(self, record: dict[str, Any], state: dict[str, Any]) -> None:
        material = {k: record[k] for k in (
            "at", "classification", "message", "checkpoint_id", "checkpoint_digest",
            "active_task_digest", "integration_state"
        )}
        if record.get("digest") != _canonical_digest(material):
            raise RuntimeError("Interruption digest mismatch")
        checkpoint = state.get("last_checkpoint") or {}
        if record.get("checkpoint_id") != checkpoint.get("checkpoint_id"):
            raise RuntimeError("Interruption checkpoint identity mismatch")
        if record.get("checkpoint_digest") != checkpoint.get("digest"):
            raise RuntimeError("Interruption checkpoint digest mismatch")
        if record.get("active_task_digest") != state.get("active_task_digest"):
            raise RuntimeError("Interruption active task mismatch")

    def integrate_pending(self) -> list[dict[str, Any]]:
        state = self._read_state()
        checkpoint = state.get("last_checkpoint")
        if not checkpoint:
            raise RuntimeError("No verified checkpoint available for interruption integration")
        if checkpoint.get("digest") != _checkpoint_digest(checkpoint):
            raise RuntimeError("Stored checkpoint digest mismatch")

        integrated: list[dict[str, Any]] = []
        for record in state["pending_interruptions"]:
            self._verify_interruption(record, state)
            integrated_record = dict(record)
            integrated_record["integration_state"] = "INTEGRATED"
            integrated_record["integrated_at"] = utc_now()
            integrated_record["source_digest"] = record["digest"]
            integrated_record["integration_digest"] = _canonical_digest({
                "interruption_id": record["interruption_id"],
                "source_digest": record["digest"],
                "checkpoint_digest": record["checkpoint_digest"],
                "active_task_digest": record["active_task_digest"],
                "integration_state": "INTEGRATED",
            })
            integrated.append(integrated_record)
            self.integration_ledger.append(integrated_record)
            self.knowledge_ledger.append({
                "schema": "codeforge-continuation-knowledge-v1",
                "interruption_id": record["interruption_id"],
                "classification": record["classification"],
                "message_digest": hashlib.sha256(record["message"].encode("utf-8")).hexdigest(),
                "checkpoint_digest": record["checkpoint_digest"],
                "status": "INTEGRATED",
                "at": utc_now(),
            })

        architecture_receipt = {
            "schema": "codeforge-continuation-architecture-audit-v1",
            "checkpoint_id": checkpoint["checkpoint_id"],
            "checkpoint_digest": checkpoint["digest"],
            "integrated_interruption_ids": [r["interruption_id"] for r in integrated],
            "architecture_drift": False,
            "status": "PASS",
            "at": utc_now(),
        }
        architecture_receipt["digest"] = _canonical_digest(architecture_receipt)
        self.architecture_ledger.append(architecture_receipt)

        integration_receipt = {
            "schema": "codeforge-continuation-integration-receipt-v2",
            "checkpoint_id": checkpoint["checkpoint_id"],
            "checkpoint_digest": checkpoint["digest"],
            "active_task_digest": state.get("active_task_digest"),
            "interruption_digests": [r["source_digest"] for r in integrated],
            "architecture_audit_digest": architecture_receipt["digest"],
            "status": "PASS",
            "at": utc_now(),
        }
        integration_receipt["digest"] = _canonical_digest(integration_receipt)

        reaudit = {
            "schema": "codeforge-continuation-reaudit-v2",
            "checkpoint_digest": checkpoint["digest"],
            "active_task_digest": state.get("active_task_digest"),
            "integration_receipt_digest": integration_receipt["digest"],
            "pending_interruptions": 0,
            "status": "PASS",
            "at": utc_now(),
        }
        reaudit["digest"] = _canonical_digest(reaudit)
        self.reaudit_ledger.append(reaudit)

        state["pending_interruptions"] = []
        state["last_integration_receipt"] = integration_receipt
        state["last_reaudit_receipt"] = reaudit
        state["resume_state"] = "READY_TO_RESUME"
        state["updated_at"] = utc_now()
        self.state_store.write(state)
        return integrated

    def resume(self) -> dict[str, Any]:
        state = self._read_state()
        if state["pending_interruptions"]:
            raise RuntimeError("Pending interruption information must be integrated before resume")
        checkpoint = state.get("last_checkpoint")
        if not checkpoint:
            raise RuntimeError("No verified checkpoint available")
        if checkpoint.get("digest") != _checkpoint_digest(checkpoint):
            raise RuntimeError("Stored checkpoint digest mismatch")
        task = state.get("active_task")
        if task is not None and state.get("active_task_digest") != _canonical_digest(task):
            raise RuntimeError("Active task digest mismatch")
        if state.get("resume_state") == "READY_TO_RESUME":
            integration = state.get("last_integration_receipt") or {}
            reaudit = state.get("last_reaudit_receipt") or {}
            if integration.get("status") != "PASS" or reaudit.get("status") != "PASS":
                raise RuntimeError("Verified integration and re-audit receipts are required")
            integration_material = {k: v for k, v in integration.items() if k != "digest"}
            reaudit_material = {k: v for k, v in reaudit.items() if k != "digest"}
            if integration.get("digest") != _canonical_digest(integration_material):
                raise RuntimeError("Integration receipt digest mismatch")
            if reaudit.get("digest") != _canonical_digest(reaudit_material):
                raise RuntimeError("Re-audit receipt digest mismatch")
            if reaudit.get("integration_receipt_digest") != integration.get("digest"):
                raise RuntimeError("Re-audit is not bound to latest integration")
        state["resume_state"] = "ACTIVE"
        state["updated_at"] = utc_now()
        self.state_store.write(state)
        return {
            "resume_from": checkpoint,
            "active_task": task,
            "continuation_schema": state["schema"],
            "reaudit": state.get("last_reaudit_receipt"),
        }

    def repository_state(self) -> dict[str, Any]:
        state = self._read_state()
        snapshot = {
            "schema": "codeforge-repository-continuation-state-v1",
            "active_task": state.get("active_task"),
            "active_task_digest": state.get("active_task_digest"),
            "last_checkpoint": state.get("last_checkpoint"),
            "resume_state": state.get("resume_state"),
            "pending_interruption_count": len(state.get("pending_interruptions", [])),
            "last_integration_receipt": state.get("last_integration_receipt"),
            "last_reaudit_receipt": state.get("last_reaudit_receipt"),
            "generated_at": utc_now(),
        }
        snapshot["digest"] = _canonical_digest(snapshot)
        return snapshot

    def status(self) -> dict[str, Any]:
        return self._read_state()
