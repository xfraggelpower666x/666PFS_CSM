from __future__ import annotations

from typing import Any

from .connector_models import ConnectorActionPlan
from .connector_transport import RecordingGitHubConnectorTransport, content_sha256
from .hashchain import seal_document, verify_document


class RecordingConnectorReadbackVerifier:
    def verify(
        self,
        *,
        transport: RecordingGitHubConnectorTransport,
        plan: dict[str, Any],
        execution_receipt: dict[str, Any],
    ) -> dict[str, Any]:
        parsed = ConnectorActionPlan.from_dict(plan)
        reasons: list[str] = []
        if not verify_document(execution_receipt):
            reasons.append("CONNECTOR_EXECUTION_RECEIPT_DIGEST_MISMATCH")
        if execution_receipt.get("status") != "PASS":
            reasons.append("CONNECTOR_EXECUTION_NOT_COMMITTED")
        if execution_receipt.get("plan_id") != parsed.plan_id or execution_receipt.get("plan_digest") != parsed.digest:
            reasons.append("CONNECTOR_EXECUTION_PLAN_MISMATCH")
        commit = execution_receipt.get("commit_sha")
        if transport.head(parsed.target_branch) != commit:
            reasons.append("CONNECTOR_BRANCH_HEAD_READBACK_MISMATCH")
        try:
            tree = transport.tree(parsed.target_branch)
        except KeyError:
            tree = {}
            reasons.append("CONNECTOR_READBACK_TREE_MISSING")
        for action in parsed.actions:
            if action.path is None:
                continue
            current = tree.get(action.path)
            if action.action == "delete_file":
                if current is not None:
                    reasons.append(f"CONNECTOR_DELETE_READBACK_FAILED:{action.path}")
            elif action.action in {"create_file", "update_file"}:
                if current is None:
                    reasons.append(f"CONNECTOR_CONTENT_READBACK_MISSING:{action.path}")
                elif content_sha256(current) != action.content_sha256:
                    reasons.append(f"CONNECTOR_CONTENT_READBACK_SHA_MISMATCH:{action.path}")
        if tree and transport._tree_digest(tree) != execution_receipt.get("tree_digest"):
            reasons.append("CONNECTOR_TREE_DIGEST_READBACK_MISMATCH")
        return seal_document({
            "schema": "codeforge-recording-connector-readback-v1",
            "plan_id": parsed.plan_id,
            "target_branch": parsed.target_branch,
            "commit_sha": commit,
            "network_used": False,
            "status": "PASS" if not reasons else "FAIL",
            "reasons": reasons,
        })
