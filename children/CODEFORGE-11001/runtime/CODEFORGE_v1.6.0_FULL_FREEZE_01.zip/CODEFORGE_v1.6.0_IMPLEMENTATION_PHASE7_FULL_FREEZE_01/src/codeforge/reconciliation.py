from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from .governance import AUTHORITY_RANK
from .status import Status


@dataclass(slots=True)
class ReconciliationResult:
    classification: str
    status: Status
    authoritative_source: str | None
    reasons: list[str]
    conflicts: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        return data


class ReconciliationEngine:
    def reconcile(self, sources: list[dict[str, Any]]) -> ReconciliationResult:
        if not sources:
            return ReconciliationResult(
                classification="INCOMPLETE_EVIDENCE",
                status=Status.HOLD,
                authoritative_source=None,
                reasons=["No evidence sources supplied"],
                conflicts=[],
            )
        ranked = sorted(
            sources,
            key=lambda src: (AUTHORITY_RANK.get(src.get("source_type", "unknown"), 0), src.get("observed_at", "")),
            reverse=True,
        )
        authority = ranked[0]
        top_rank = AUTHORITY_RANK.get(authority.get("source_type", "unknown"), 0)
        top = [src for src in ranked if AUTHORITY_RANK.get(src.get("source_type", "unknown"), 0) == top_rank]
        conflicts = []
        hashes = {src.get("sha256") for src in top if src.get("sha256")}
        versions = {src.get("version") for src in top if src.get("version")}
        if len(hashes) > 1 or len(versions) > 1:
            for src in top:
                conflicts.append({
                    "source": src.get("source"),
                    "sha256": src.get("sha256"),
                    "version": src.get("version"),
                })
            return ReconciliationResult(
                classification="SAME_AUTHORITY_CONFLICT",
                status=Status.CONFLICT_QUARANTINE,
                authoritative_source=None,
                reasons=["Equal-authority sources disagree"],
                conflicts=conflicts,
            )
        lower_disagreements = []
        for src in ranked[1:]:
            if src.get("sha256") and authority.get("sha256") and src["sha256"] != authority["sha256"]:
                lower_disagreements.append(src.get("source", "unknown"))
        reasons = [f"Selected highest authority: {authority.get('source_type')}"]
        if lower_disagreements:
            reasons.append("Lower-authority evidence differs and remains historical: " + ", ".join(lower_disagreements))
        return ReconciliationResult(
            classification="AUTHORITATIVE_SOURCE_SELECTED",
            status=Status.VERIFIED,
            authoritative_source=authority.get("source"),
            reasons=reasons,
            conflicts=[],
        )
