from __future__ import annotations

from pathlib import Path
from typing import Any

from .models import utc_now
from .storage import JsonlLedger


class AuditLedger:
    def __init__(self, path: str | Path):
        self.ledger = JsonlLedger(path)

    def record(self, stage: str, result: str, payload: dict[str, Any]) -> None:
        self.ledger.append({
            "at": utc_now(),
            "stage": stage,
            "result": result,
            "payload": payload,
        })

    def all(self) -> list[dict[str, Any]]:
        return self.ledger.read_all()


class RepairLedger:
    def __init__(self, path: str | Path):
        self.ledger = JsonlLedger(path)

    def propose(self, finding_id: str, action: str, scope: list[str], evidence_ids: list[str]) -> None:
        self.ledger.append({
            "at": utc_now(),
            "finding_id": finding_id,
            "action": action,
            "scope": scope,
            "evidence_ids": evidence_ids,
            "state": "PROPOSED",
            "mutation_performed": False,
        })

    def record_execution(self, finding_id: str, result: str, readback: dict[str, Any]) -> None:
        self.ledger.append({
            "at": utc_now(),
            "finding_id": finding_id,
            "state": "EXECUTED",
            "result": result,
            "readback": readback,
        })

    def all(self) -> list[dict[str, Any]]:
        return self.ledger.read_all()
