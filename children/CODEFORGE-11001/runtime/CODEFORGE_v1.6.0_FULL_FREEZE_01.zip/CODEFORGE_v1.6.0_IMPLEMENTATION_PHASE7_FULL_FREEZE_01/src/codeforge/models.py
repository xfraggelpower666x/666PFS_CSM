from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
import hashlib
import json
import uuid

from .status import Status


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def stable_id(prefix: str, payload: Any) -> str:
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    return f"{prefix}-{hashlib.sha256(raw).hexdigest()[:16]}"


@dataclass(slots=True)
class EvidenceRecord:
    source: str
    source_type: str
    authority_rank: int
    locator: str
    status: Status = Status.VERIFIED
    collected_at: str = field(default_factory=utc_now)
    sha256: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    evidence_id: str = ""

    def __post_init__(self) -> None:
        if not self.evidence_id:
            self.evidence_id = stable_id("EVD", {
                "source": self.source,
                "locator": self.locator,
                "sha256": self.sha256,
                "metadata": self.metadata,
            })

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["status"] = self.status.value
        return result


@dataclass(slots=True)
class Finding:
    code: str
    message: str
    severity: str
    status: Status
    path: str | None = None
    evidence_ids: list[str] = field(default_factory=list)
    repair_hint: str | None = None
    finding_id: str = ""

    def __post_init__(self) -> None:
        if not self.finding_id:
            self.finding_id = stable_id("FND", {
                "code": self.code,
                "message": self.message,
                "path": self.path,
                "evidence_ids": self.evidence_ids,
            })

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["status"] = self.status.value
        return result


@dataclass(slots=True)
class Decision:
    subject: str
    outcome: str
    rationale: str
    evidence_ids: list[str]
    status: Status = Status.VERIFIED
    created_at: str = field(default_factory=utc_now)
    decision_id: str = ""

    def __post_init__(self) -> None:
        if not self.decision_id:
            self.decision_id = stable_id("DEC", {
                "subject": self.subject,
                "outcome": self.outcome,
                "evidence_ids": self.evidence_ids,
            })

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["status"] = self.status.value
        return result


@dataclass(slots=True)
class Checkpoint:
    phase: str
    state: str
    block_from: int
    block_to: int
    payload: dict[str, Any]
    previous_checkpoint: str | None = None
    created_at: str = field(default_factory=utc_now)
    checkpoint_id: str = field(default_factory=lambda: f"CP-{uuid.uuid4().hex[:16]}")
    digest: str = ""

    def seal(self) -> "Checkpoint":
        material = {
            "checkpoint_id": self.checkpoint_id,
            "phase": self.phase,
            "state": self.state,
            "block_from": self.block_from,
            "block_to": self.block_to,
            "payload": self.payload,
            "previous_checkpoint": self.previous_checkpoint,
            "created_at": self.created_at,
        }
        self.digest = hashlib.sha256(
            json.dumps(material, sort_keys=True, ensure_ascii=False).encode("utf-8")
        ).hexdigest()
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        return asdict(self)
