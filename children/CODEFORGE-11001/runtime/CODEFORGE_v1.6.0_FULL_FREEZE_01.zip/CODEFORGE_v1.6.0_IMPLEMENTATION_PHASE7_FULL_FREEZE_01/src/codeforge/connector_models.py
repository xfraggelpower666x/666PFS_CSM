from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
import re

from .hashchain import digest_document
from .models import stable_id, utc_now
from .targets import normalize_relative_path

_SHA_RE = re.compile(r"^[0-9a-fA-F]{7,64}$")
_ALLOWED_ACTIONS = {
    "create_branch", "create_file", "update_file", "delete_file",
    "read_file", "read_branch_head", "deployment_readback",
}
_FORBIDDEN_FIELD_FRAGMENTS = (
    "token", "secret", "password", "credential", "private_key", "api_key",
)


def _forbidden_fields(value: Any, prefix: str = "") -> list[str]:
    findings: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            lowered = str(key).lower()
            if any(fragment in lowered for fragment in _FORBIDDEN_FIELD_FRAGMENTS):
                findings.append(path)
            findings.extend(_forbidden_fields(item, path))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            findings.extend(_forbidden_fields(item, f"{prefix}[{index}]"))
    return findings


def _is_fresh(timestamp: str, *, max_age_seconds: int, now: datetime | None = None) -> bool:
    try:
        observed = datetime.fromisoformat(timestamp)
        current = now or datetime.now(timezone.utc)
        if observed.tzinfo is None:
            observed = observed.replace(tzinfo=timezone.utc)
        return 0 <= (current - observed).total_seconds() <= max_age_seconds
    except (TypeError, ValueError):
        return False


@dataclass(slots=True)
class ConnectorSessionReceipt:
    provider: str
    connector_instance_id: str
    principal: str
    repositories: list[str]
    permissions: list[str]
    methods: list[str]
    evidence_id: str
    issued_at: str
    expires_at: str
    session_id: str = ""
    digest: str = ""

    def _material(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-connector-session-receipt-v1",
            "provider": self.provider,
            "connector_instance_id": self.connector_instance_id,
            "principal": self.principal,
            "repositories": sorted(set(self.repositories)),
            "permissions": sorted(set(self.permissions)),
            "methods": sorted(set(self.methods)),
            "evidence_id": self.evidence_id,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
        }

    def seal(self) -> "ConnectorSessionReceipt":
        material = self._material()
        if not self.session_id:
            self.session_id = stable_id("CSE", material)
        integrity = dict(material)
        integrity["session_id"] = self.session_id
        self.digest = digest_document(integrity)
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        data = self._material()
        data["session_id"] = self.session_id
        data["digest"] = self.digest
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ConnectorSessionReceipt":
        return cls(
            provider=str(data.get("provider", "")),
            connector_instance_id=str(data.get("connector_instance_id", "")),
            principal=str(data.get("principal", "")),
            repositories=list(data.get("repositories", [])),
            permissions=list(data.get("permissions", [])),
            methods=list(data.get("methods", [])),
            evidence_id=str(data.get("evidence_id", "")),
            issued_at=str(data.get("issued_at", "")),
            expires_at=str(data.get("expires_at", "")),
            session_id=str(data.get("session_id", "")),
            digest=str(data.get("digest", "")),
        )

    def validate(
        self,
        *,
        provider: str,
        repository: str,
        required_permissions: set[str],
        required_methods: set[str],
        now: datetime | None = None,
    ) -> dict[str, Any]:
        document = self.to_dict()
        reasons: list[str] = []
        expected = document.pop("digest", "")
        if digest_document(document) != expected:
            reasons.append("CONNECTOR_SESSION_DIGEST_MISMATCH")
        if self.provider != provider:
            reasons.append("CONNECTOR_SESSION_PROVIDER_MISMATCH")
        if repository not in set(self.repositories):
            reasons.append("CONNECTOR_REPOSITORY_SCOPE_MISSING")
        if not required_permissions.issubset(set(self.permissions)):
            reasons.append("CONNECTOR_PERMISSIONS_INCOMPLETE")
        if not required_methods.issubset(set(self.methods)):
            reasons.append("CONNECTOR_METHODS_INCOMPLETE")
        if not self.connector_instance_id or not self.principal or not self.evidence_id:
            reasons.append("CONNECTOR_SESSION_IDENTITY_INCOMPLETE")
        try:
            current = now or datetime.now(timezone.utc)
            expiry = datetime.fromisoformat(self.expires_at)
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if expiry <= current:
                reasons.append("CONNECTOR_SESSION_EXPIRED")
        except (TypeError, ValueError):
            reasons.append("CONNECTOR_SESSION_EXPIRY_INVALID")
        if _forbidden_fields(self.to_dict()):
            reasons.append("CONNECTOR_SESSION_SECRET_FIELD_FORBIDDEN")
        return {
            "schema": "codeforge-connector-session-validation-v1",
            "session_id": self.session_id,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
        }


@dataclass(slots=True)
class ConnectorHeadReceipt:
    provider: str
    connector_session_id: str
    repository: str
    branch: str
    head_sha: str
    evidence_id: str
    observed_at: str = field(default_factory=utc_now)
    receipt_id: str = ""
    digest: str = ""

    def _material(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-connector-head-receipt-v1",
            "provider": self.provider,
            "connector_session_id": self.connector_session_id,
            "repository": self.repository,
            "branch": self.branch,
            "head_sha": self.head_sha,
            "evidence_id": self.evidence_id,
            "observed_at": self.observed_at,
        }

    def seal(self) -> "ConnectorHeadReceipt":
        material = self._material()
        if not self.receipt_id:
            self.receipt_id = stable_id("CHR", material)
        integrity = dict(material)
        integrity["receipt_id"] = self.receipt_id
        self.digest = digest_document(integrity)
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        data = self._material()
        data["receipt_id"] = self.receipt_id
        data["digest"] = self.digest
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ConnectorHeadReceipt":
        return cls(
            provider=str(data.get("provider", "")),
            connector_session_id=str(data.get("connector_session_id", "")),
            repository=str(data.get("repository", "")),
            branch=str(data.get("branch", "")),
            head_sha=str(data.get("head_sha", "")),
            evidence_id=str(data.get("evidence_id", "")),
            observed_at=str(data.get("observed_at", "")),
            receipt_id=str(data.get("receipt_id", "")),
            digest=str(data.get("digest", "")),
        )

    def validate(
        self,
        *,
        provider: str,
        connector_session_id: str,
        repository: str,
        branch: str,
        expected_head_sha: str,
        max_age_seconds: int = 300,
        now: datetime | None = None,
    ) -> dict[str, Any]:
        document = self.to_dict()
        reasons: list[str] = []
        expected = document.pop("digest", "")
        if digest_document(document) != expected:
            reasons.append("CONNECTOR_HEAD_RECEIPT_DIGEST_MISMATCH")
        if self.provider != provider:
            reasons.append("CONNECTOR_HEAD_PROVIDER_MISMATCH")
        if self.connector_session_id != connector_session_id:
            reasons.append("CONNECTOR_HEAD_SESSION_MISMATCH")
        if self.repository != repository or self.branch != branch:
            reasons.append("CONNECTOR_HEAD_TARGET_MISMATCH")
        if not _SHA_RE.fullmatch(self.head_sha):
            reasons.append("CONNECTOR_HEAD_SHA_INVALID")
        if self.head_sha.lower() != expected_head_sha.lower():
            reasons.append("CONNECTOR_HEAD_RECHECK_FAILED")
        if not self.evidence_id:
            reasons.append("CONNECTOR_HEAD_EVIDENCE_MISSING")
        if not _is_fresh(self.observed_at, max_age_seconds=max_age_seconds, now=now):
            reasons.append("CONNECTOR_HEAD_RECEIPT_STALE")
        return {
            "schema": "codeforge-connector-head-validation-v1",
            "receipt_id": self.receipt_id,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
        }


@dataclass(slots=True)
class ConnectorAction:
    sequence: int
    action: str
    repository: str
    branch: str
    path: str | None = None
    expected_sha256: str | None = None
    content_sha256: str | None = None
    content_size: int | None = None
    source_branch: str | None = None
    source_head_sha: str | None = None

    def validate(self) -> list[str]:
        reasons: list[str] = []
        if self.sequence < 1:
            reasons.append("ACTION_SEQUENCE_INVALID")
        if self.action not in _ALLOWED_ACTIONS:
            reasons.append("CONNECTOR_ACTION_UNSUPPORTED")
        if self.path is not None:
            try:
                if normalize_relative_path(self.path) != self.path:
                    reasons.append("ACTION_PATH_NOT_NORMALIZED")
            except ValueError:
                reasons.append("ACTION_PATH_UNSAFE")
        if self.action in {"create_file", "update_file"}:
            if not self.content_sha256 or self.content_size is None:
                reasons.append("ACTION_CONTENT_BINDING_MISSING")
        if self.action in {"update_file", "delete_file"} and not self.expected_sha256:
            reasons.append("ACTION_EXPECTED_SHA_MISSING")
        if self.action == "create_branch" and (not self.source_branch or not self.source_head_sha):
            reasons.append("ACTION_BRANCH_SOURCE_MISSING")
        return reasons

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ConnectorAction":
        fields = cls.__dataclass_fields__
        return cls(**{key: data.get(key) for key in fields})


@dataclass(slots=True)
class ConnectorActionPlan:
    provider: str
    contract_id: str
    contract_digest: str
    session_id: str
    session_digest: str
    head_receipt_id: str
    head_receipt_digest: str
    capability_receipt_id: str
    capability_receipt_digest: str
    lock_id: str
    lock_digest: str
    allowlist_digest: str
    gate_digest: str
    repository: str
    base_branch: str
    target_branch: str
    expected_base_head_sha: str
    actions: list[ConnectorAction]
    test_only: bool = False
    created_at: str = field(default_factory=utc_now)
    plan_id: str = ""
    digest: str = ""

    def _material(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-connector-action-plan-v1",
            "provider": self.provider,
            "contract_id": self.contract_id,
            "contract_digest": self.contract_digest,
            "session_id": self.session_id,
            "session_digest": self.session_digest,
            "head_receipt_id": self.head_receipt_id,
            "head_receipt_digest": self.head_receipt_digest,
            "capability_receipt_id": self.capability_receipt_id,
            "capability_receipt_digest": self.capability_receipt_digest,
            "lock_id": self.lock_id,
            "lock_digest": self.lock_digest,
            "allowlist_digest": self.allowlist_digest,
            "gate_digest": self.gate_digest,
            "repository": self.repository,
            "base_branch": self.base_branch,
            "target_branch": self.target_branch,
            "expected_base_head_sha": self.expected_base_head_sha,
            "actions": [item.to_dict() for item in self.actions],
            "test_only": self.test_only,
            "created_at": self.created_at,
        }

    def seal(self) -> "ConnectorActionPlan":
        material = self._material()
        if not self.plan_id:
            self.plan_id = stable_id("CAPL", material)
        integrity = dict(material)
        integrity["plan_id"] = self.plan_id
        self.digest = digest_document(integrity)
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        data = self._material()
        data["plan_id"] = self.plan_id
        data["digest"] = self.digest
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ConnectorActionPlan":
        return cls(
            provider=str(data.get("provider", "")),
            contract_id=str(data.get("contract_id", "")),
            contract_digest=str(data.get("contract_digest", "")),
            session_id=str(data.get("session_id", "")),
            session_digest=str(data.get("session_digest", "")),
            head_receipt_id=str(data.get("head_receipt_id", "")),
            head_receipt_digest=str(data.get("head_receipt_digest", "")),
            capability_receipt_id=str(data.get("capability_receipt_id", "")),
            capability_receipt_digest=str(data.get("capability_receipt_digest", "")),
            lock_id=str(data.get("lock_id", "")),
            lock_digest=str(data.get("lock_digest", "")),
            allowlist_digest=str(data.get("allowlist_digest", "")),
            gate_digest=str(data.get("gate_digest", "")),
            repository=str(data.get("repository", "")),
            base_branch=str(data.get("base_branch", "")),
            target_branch=str(data.get("target_branch", "")),
            expected_base_head_sha=str(data.get("expected_base_head_sha", "")),
            actions=[ConnectorAction.from_dict(item) for item in data.get("actions", [])],
            test_only=bool(data.get("test_only", False)),
            created_at=str(data.get("created_at", utc_now())),
            plan_id=str(data.get("plan_id", "")),
            digest=str(data.get("digest", "")),
        )

    def validate(self) -> dict[str, Any]:
        document = self.to_dict()
        reasons: list[str] = []
        expected = document.pop("digest", "")
        if digest_document(document) != expected:
            reasons.append("CONNECTOR_PLAN_DIGEST_MISMATCH")
        if not self.contract_id or not self.contract_digest:
            reasons.append("CONNECTOR_PLAN_CONTRACT_BINDING_MISSING")
        if not self.session_id or not self.session_digest:
            reasons.append("CONNECTOR_PLAN_SESSION_BINDING_MISSING")
        if not self.head_receipt_id or not self.head_receipt_digest:
            reasons.append("CONNECTOR_PLAN_HEAD_BINDING_MISSING")
        if self.contract_id != "READBACK_ONLY":
            if not self.capability_receipt_id or not self.capability_receipt_digest:
                reasons.append("CONNECTOR_PLAN_CAPABILITY_BINDING_MISSING")
            if not self.lock_id or not self.lock_digest:
                reasons.append("CONNECTOR_PLAN_LOCK_BINDING_MISSING")
            if not self.allowlist_digest:
                reasons.append("CONNECTOR_PLAN_ALLOWLIST_BINDING_MISSING")
            if not self.gate_digest:
                reasons.append("CONNECTOR_PLAN_GATE_BINDING_MISSING")
        if not self.actions:
            reasons.append("CONNECTOR_PLAN_ACTIONS_EMPTY")
        for expected_sequence, action in enumerate(self.actions, 1):
            if action.sequence != expected_sequence:
                reasons.append(f"CONNECTOR_ACTION_SEQUENCE_MISMATCH:{expected_sequence}")
            reasons.extend(f"ACTION_{expected_sequence}:{reason}" for reason in action.validate())
        forbidden = _forbidden_fields(self.to_dict())
        if forbidden:
            reasons.append("CONNECTOR_PLAN_SECRET_FIELD_FORBIDDEN")
        return {
            "schema": "codeforge-connector-plan-validation-v1",
            "plan_id": self.plan_id,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
        }
