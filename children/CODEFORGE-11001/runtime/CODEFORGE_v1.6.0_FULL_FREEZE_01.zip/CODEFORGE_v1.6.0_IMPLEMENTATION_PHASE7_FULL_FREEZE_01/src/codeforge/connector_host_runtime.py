from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
import hashlib
import json

from .connector_execution_permit import RADIO_REPOSITORY, RealConnectorExecutionPermit, RealConnectorPermitRegistry
from .connector_journal import ConnectorCandidateJournal
from .connector_models import ConnectorActionPlan
from .hashchain import digest_document, seal_document


class HostConnectorInvoker(Protocol):
    mode: str
    network_used: bool
    supported_actions: set[str]

    def invoke(self, action: str, arguments: dict[str, Any]) -> dict[str, Any]: ...


def content_sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()


def _safe_arguments(arguments: dict[str, Any]) -> dict[str, Any]:
    safe: dict[str, Any] = {}
    for key, value in arguments.items():
        if key == "content":
            encoded = str(value).encode("utf-8")
            safe["content_sha256"] = content_sha256(encoded)
            safe["content_size"] = len(encoded)
        else:
            safe[key] = value
    return safe


class RecordingHostGitHubInvoker:
    """GitHub-ähnlicher Host-Invoker ohne Netzwerk für deterministische Adaptertests."""

    mode = "TEST_HOST_ADAPTER"
    network_used = False
    supported_actions = {
        "GitHub.read_branch_head", "GitHub.create_branch", "GitHub.fetch_file",
        "GitHub.create_file", "GitHub.update_file", "GitHub.delete_file",
        "GitHub.fetch_commit", "GitHub.update_ref",
    }

    def __init__(self, repository: str):
        self.supported_actions = set(type(self).supported_actions)
        self.repository = repository
        self.refs: dict[str, str] = {}
        self.trees: dict[str, dict[str, bytes]] = {}
        self.parents: dict[str, str | None] = {}
        self.invocations: list[dict[str, Any]] = []

    @staticmethod
    def _tree_digest(tree: dict[str, bytes]) -> str:
        return digest_document([
            {"path": path, "sha256": content_sha256(data), "size": len(data)}
            for path, data in sorted(tree.items())
        ])

    def _commit(self, parent: str | None, tree: dict[str, bytes], message: str) -> str:
        return hashlib.sha1(json.dumps({
            "parent": parent,
            "tree": self._tree_digest(tree),
            "message": message,
        }, sort_keys=True).encode("utf-8")).hexdigest()

    def seed(self, branch: str, tree: dict[str, bytes], *, commit_sha: str | None = None) -> str:
        commit = commit_sha or self._commit(None, tree, f"seed:{branch}")
        self.refs[branch] = commit
        self.trees[commit] = deepcopy(tree)
        self.parents[commit] = None
        return commit

    def _result(self, **payload: Any) -> dict[str, Any]:
        return {"ok": True, "result": payload}

    def _fail(self, code: str) -> dict[str, Any]:
        return {"ok": False, "error": code}

    def invoke(self, action: str, arguments: dict[str, Any]) -> dict[str, Any]:
        self.invocations.append({"action": action, "arguments": _safe_arguments(arguments)})
        if action not in self.supported_actions:
            return self._fail("HOST_ACTION_UNSUPPORTED")
        repo = arguments.get("repository_full_name") or arguments.get("repo_full_name")
        if repo != self.repository:
            return self._fail("HOST_REPOSITORY_MISMATCH")
        if action == "GitHub.read_branch_head":
            branch = str(arguments["branch"])
            if branch not in self.refs:
                return self._fail("BRANCH_NOT_FOUND")
            return self._result(head_sha=self.refs[branch], branch=branch)
        if action == "GitHub.create_branch":
            branch = str(arguments["branch_name"])
            sha = str(arguments["sha"])
            if branch in self.refs:
                return self._fail("BRANCH_ALREADY_EXISTS")
            if sha not in self.trees:
                return self._fail("SOURCE_COMMIT_NOT_FOUND")
            self.refs[branch] = sha
            return self._result(branch=branch, head_sha=sha)
        if action == "GitHub.fetch_file":
            branch = str(arguments["ref"])
            path = str(arguments["path"])
            if branch not in self.refs:
                return self._fail("BRANCH_NOT_FOUND")
            data = self.trees[self.refs[branch]].get(path)
            if data is None:
                return self._fail("FILE_NOT_FOUND")
            return self._result(
                content=data.decode("utf-8"), sha=git_blob_sha(data),
                content_sha256=content_sha256(data), size=len(data),
            )
        if action in {"GitHub.create_file", "GitHub.update_file", "GitHub.delete_file"}:
            branch = str(arguments["branch"])
            path = str(arguments["path"])
            if branch not in self.refs:
                return self._fail("BRANCH_NOT_FOUND")
            parent = self.refs[branch]
            tree = deepcopy(self.trees[parent])
            current = tree.get(path)
            if action == "GitHub.create_file":
                if current is not None:
                    return self._fail("CREATE_PATH_EXISTS")
                tree[path] = str(arguments["content"]).encode("utf-8")
            elif action == "GitHub.update_file":
                if current is None:
                    return self._fail("UPDATE_PATH_MISSING")
                if str(arguments.get("sha")) != git_blob_sha(current):
                    return self._fail("UPDATE_BLOB_SHA_MISMATCH")
                tree[path] = str(arguments["content"]).encode("utf-8")
            else:
                if current is None:
                    return self._fail("DELETE_PATH_MISSING")
                if str(arguments.get("sha")) != git_blob_sha(current):
                    return self._fail("DELETE_BLOB_SHA_MISMATCH")
                del tree[path]
            commit = self._commit(parent, tree, str(arguments.get("message", "CodeForge host adapter")))
            self.trees[commit] = tree
            self.parents[commit] = parent
            self.refs[branch] = commit
            return self._result(commit_sha=commit, branch=branch)
        if action == "GitHub.fetch_commit":
            sha = str(arguments["commit_sha"])
            if sha not in self.trees:
                return self._fail("COMMIT_NOT_FOUND")
            return self._result(commit_sha=sha, tree_digest=self._tree_digest(self.trees[sha]), parent=self.parents[sha])
        if action == "GitHub.update_ref":
            branch = str(arguments["branch_name"])
            sha = str(arguments["sha"])
            if sha not in self.trees:
                return self._fail("ROLLBACK_COMMIT_NOT_FOUND")
            self.refs[branch] = sha
            return self._result(branch=branch, head_sha=sha)
        return self._fail("HOST_ACTION_UNHANDLED")


@dataclass(slots=True)
class HostConnectorExecutionAdapter:
    workspace: Path

    REQUIRED_ACTIONS = {
        "GitHub.read_branch_head", "GitHub.create_branch", "GitHub.fetch_file",
        "GitHub.create_file", "GitHub.update_file", "GitHub.delete_file",
        "GitHub.fetch_commit", "GitHub.update_ref",
    }

    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)

    @staticmethod
    def _runtime_gate(runtime: dict[str, Any], *, test_mode: bool, repository: str, base_branch: str, target_branch: str) -> list[str]:
        execution = runtime.get("execution", {})
        reasons: list[str] = []
        if test_mode:
            if execution.get("host_adapter_test_execution_enabled") is not True:
                reasons.append("HOST_ADAPTER_TEST_EXECUTION_DISABLED")
            if execution.get("connector_network_write_enabled") is not False:
                reasons.append("TEST_HOST_ADAPTER_NETWORK_MUST_BE_DISABLED")
        else:
            allowlist = set(execution.get("real_target_allowlist", []))
            if repository not in allowlist:
                reasons.append("REAL_CONNECTOR_TARGET_NOT_ALLOWLISTED")
            required_true = (
                "real_connector_execution_enabled", "connector_network_write_enabled",
                "github_write_enabled", "exact_authorization_required",
                "single_use_authorization_required", "remote_head_recheck_required",
                "readback_required", "automatic_rollback_required",
            )
            for key in required_true:
                if execution.get(key) is not True:
                    reasons.append(f"RUNTIME_FLAG_REQUIRED:{key}")
        if target_branch == base_branch or not target_branch.startswith("codeforge/"):
            reasons.append("HOST_CONNECTOR_ISOLATED_BRANCH_REQUIRED")
        return reasons

    def _execute(
        self,
        *,
        plan: dict[str, Any], permit: dict[str, Any], content_by_path: dict[str, bytes],
        runtime: dict[str, Any], invoker: HostConnectorInvoker, test_mode: bool,
        inject_failure: str | None = None,
    ) -> dict[str, Any]:
        reasons = self._runtime_gate(runtime, test_mode=test_mode, repository=str(plan.get("repository", "")), base_branch=str(plan.get("base_branch", "")), target_branch=str(plan.get("target_branch", "")))
        parsed = ConnectorActionPlan.from_dict(plan)
        validation = parsed.validate()
        if validation["status"] != "PASS":
            reasons.extend(validation["reasons"])
        permit_obj = RealConnectorExecutionPermit.from_dict(permit)
        permit_validation = permit_obj.validate(plan=plan)
        if permit_validation["status"] != "PASS":
            reasons.extend(permit_validation["reasons"])
        if parsed.repository == RADIO_REPOSITORY:
            reasons.append("RADIO_FORBIDDEN_AS_FIRST_REAL_CONNECTOR_TARGET")
        if not self.REQUIRED_ACTIONS.issubset(set(invoker.supported_actions)):
            reasons.append("HOST_CONNECTOR_REQUIRED_ACTIONS_UNAVAILABLE")
        if test_mode:
            if invoker.mode != "TEST_HOST_ADAPTER" or invoker.network_used:
                reasons.append("TEST_HOST_INVOKER_MODE_INVALID")
            if permit_obj.environment != "TEST_HOST_ADAPTER":
                reasons.append("TEST_HOST_PERMIT_REQUIRED")
        else:
            if invoker.mode != "REAL_CONNECTOR" or not invoker.network_used:
                reasons.append("REAL_HOST_CONNECTOR_MODE_REQUIRED")
            if permit_obj.environment != "REAL_CONNECTOR_CANDIDATE":
                reasons.append("REAL_CONNECTOR_PERMIT_REQUIRED")
        if reasons:
            return seal_document({
                "schema": "codeforge-host-connector-execution-receipt-v1",
                "status": "WRITE_BLOCKED", "reasons": sorted(set(reasons)),
                "mutation_performed": False, "network_used": bool(invoker.network_used),
            })

        registry = RealConnectorPermitRegistry(self.workspace / "authorization" / "real-connector-permits.json")
        consumed = registry.consume(permit, plan=plan)
        if consumed["status"] != "PASS":
            return seal_document({
                "schema": "codeforge-host-connector-execution-receipt-v1",
                "status": "WRITE_BLOCKED", "reasons": consumed["reasons"],
                "mutation_performed": False, "network_used": bool(invoker.network_used),
            })

        journal = ConnectorCandidateJournal(self.workspace / "journal" / "host-connector.jsonl")
        invocations: list[dict[str, Any]] = []
        branch_created = False
        latest_commit = parsed.expected_base_head_sha

        def call(action: str, arguments: dict[str, Any]) -> dict[str, Any]:
            result = invoker.invoke(action, arguments)
            invocations.append({"action": action, "arguments": _safe_arguments(arguments), "ok": bool(result.get("ok"))})
            journal.append("HOST_INVOCATION", invocations[-1])
            if not result.get("ok"):
                raise RuntimeError(f"HOST_INVOCATION_FAILED:{action}:{result.get('error', 'UNKNOWN')}")
            return result["result"]

        try:
            head = call("GitHub.read_branch_head", {
                "repository_full_name": parsed.repository, "branch": parsed.base_branch,
            })
            if head.get("head_sha") != parsed.expected_base_head_sha:
                raise RuntimeError("HOST_CONNECTOR_HEAD_RECHECK_FAILED")
            call("GitHub.create_branch", {
                "repository_full_name": parsed.repository, "branch_name": parsed.target_branch,
                "sha": parsed.expected_base_head_sha,
            })
            branch_created = True
            if inject_failure == "after_branch":
                raise RuntimeError("INJECTED_HOST_ADAPTER_AFTER_BRANCH_FAILURE")

            for action in parsed.actions:
                if action.action == "create_branch":
                    continue
                assert action.path is not None
                if action.action in {"update_file", "delete_file"}:
                    pre = call("GitHub.fetch_file", {
                        "repository_full_name": parsed.repository, "path": action.path,
                        "ref": parsed.target_branch, "encoding": "utf-8",
                    })
                    if pre.get("content_sha256") != action.expected_sha256:
                        raise RuntimeError(f"HOST_PREIMAGE_SHA256_MISMATCH:{action.path}")
                    blob_sha = pre["sha"]
                else:
                    missing = invoker.invoke("GitHub.fetch_file", {
                        "repository_full_name": parsed.repository, "path": action.path,
                        "ref": parsed.target_branch, "encoding": "utf-8",
                    })
                    invocations.append({"action": "GitHub.fetch_file", "arguments": {
                        "repository_full_name": parsed.repository, "path": action.path,
                        "ref": parsed.target_branch, "encoding": "utf-8",
                    }, "ok": bool(missing.get("ok"))})
                    journal.append("HOST_INVOCATION", invocations[-1])
                    if missing.get("ok"):
                        raise RuntimeError(f"HOST_CREATE_PATH_ALREADY_EXISTS:{action.path}")
                    blob_sha = None

                common = {
                    "repository_full_name": parsed.repository, "path": action.path,
                    "branch": parsed.target_branch,
                    "message": f"CodeForge {parsed.plan_id} {action.action} {action.path}",
                }
                if action.action in {"create_file", "update_file"}:
                    data = content_by_path.get(action.path)
                    if data is None or content_sha256(data) != action.content_sha256 or len(data) != action.content_size:
                        raise RuntimeError(f"HOST_CONTENT_BINDING_MISMATCH:{action.path}")
                    common["content"] = data.decode("utf-8")
                if blob_sha is not None:
                    common["sha"] = blob_sha
                tool_action = {
                    "create_file": "GitHub.create_file",
                    "update_file": "GitHub.update_file",
                    "delete_file": "GitHub.delete_file",
                }[action.action]
                result = call(tool_action, common)
                latest_commit = result["commit_sha"]
                if inject_failure == f"after:{action.path}":
                    raise RuntimeError(f"INJECTED_HOST_ADAPTER_FAILURE:{action.path}")

            commit = call("GitHub.fetch_commit", {
                "repo_full_name": parsed.repository, "commit_sha": latest_commit,
            })
            target_head = call("GitHub.read_branch_head", {
                "repository_full_name": parsed.repository, "branch": parsed.target_branch,
            })
            if target_head.get("head_sha") != latest_commit or commit.get("commit_sha") != latest_commit:
                raise RuntimeError("HOST_FINAL_COMMIT_READBACK_MISMATCH")

            for action in parsed.actions:
                if action.action == "create_branch":
                    continue
                assert action.path is not None
                result = invoker.invoke("GitHub.fetch_file", {
                    "repository_full_name": parsed.repository, "path": action.path,
                    "ref": parsed.target_branch, "encoding": "utf-8",
                })
                invocations.append({"action": "GitHub.fetch_file", "arguments": {
                    "repository_full_name": parsed.repository, "path": action.path,
                    "ref": parsed.target_branch, "encoding": "utf-8",
                }, "ok": bool(result.get("ok"))})
                journal.append("READBACK", invocations[-1])
                if action.action == "delete_file":
                    if result.get("ok"):
                        raise RuntimeError(f"HOST_DELETE_READBACK_PRESENT:{action.path}")
                else:
                    if not result.get("ok") or result["result"].get("content_sha256") != action.content_sha256:
                        raise RuntimeError(f"HOST_CONTENT_READBACK_MISMATCH:{action.path}")

            return seal_document({
                "schema": "codeforge-host-connector-execution-receipt-v1",
                "provider": parsed.provider, "repository": parsed.repository,
                "plan_id": parsed.plan_id, "plan_digest": parsed.digest,
                "permit_id": permit_obj.permit_id, "target_branch": parsed.target_branch,
                "base_head": parsed.expected_base_head_sha, "commit_sha": latest_commit,
                "invocation_count": len(invocations), "invocation_digest": digest_document(invocations),
                "journal": journal.verify(), "mutation_performed": True,
                "network_used": bool(invoker.network_used), "test_mode": test_mode,
                "status": "PASS",
            })
        except Exception as exc:
            rollback_status = "NOT_REQUIRED"
            if branch_created:
                rollback = invoker.invoke("GitHub.update_ref", {
                    "repository_full_name": parsed.repository, "branch_name": parsed.target_branch,
                    "sha": parsed.expected_base_head_sha, "force": True,
                })
                invocations.append({"action": "GitHub.update_ref", "arguments": {
                    "repository_full_name": parsed.repository, "branch_name": parsed.target_branch,
                    "sha": parsed.expected_base_head_sha, "force": True,
                }, "ok": bool(rollback.get("ok"))})
                journal.append("ROLLBACK", invocations[-1])
                rollback_status = "PASS" if rollback.get("ok") else "FAIL"
            return seal_document({
                "schema": "codeforge-host-connector-execution-receipt-v1",
                "provider": parsed.provider, "repository": parsed.repository,
                "plan_id": parsed.plan_id, "permit_id": permit_obj.permit_id,
                "target_branch": parsed.target_branch, "status": "ROLLED_BACK" if rollback_status == "PASS" else "FAIL",
                "reason": str(exc), "rollback_ref_reset": rollback_status,
                "branch_cleanup": "READBACK_PENDING" if branch_created else "NOT_REQUIRED",
                "invocation_count": len(invocations), "invocation_digest": digest_document(invocations),
                "journal": journal.verify(), "mutation_performed": False,
                "network_used": bool(invoker.network_used), "test_mode": test_mode,
            })

    def execute_test(self, **kwargs: Any) -> dict[str, Any]:
        return self._execute(test_mode=True, **kwargs)

    def execute_real(self, **kwargs: Any) -> dict[str, Any]:
        return self._execute(test_mode=False, **kwargs)
