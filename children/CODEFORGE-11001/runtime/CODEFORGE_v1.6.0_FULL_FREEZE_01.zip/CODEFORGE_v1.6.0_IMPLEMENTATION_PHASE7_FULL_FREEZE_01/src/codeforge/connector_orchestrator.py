from __future__ import annotations

from pathlib import Path
from typing import Any

from .connector_gate import ConnectorCandidateGate
from .connector_journal import ConnectorCandidateJournal
from .connector_plan import GitHubConnectorPlanBuilder
from .connector_readback import RecordingConnectorReadbackVerifier
from .connector_transport import NullConnectorTransport, RecordingGitHubConnectorTransport


class ConnectorCandidateOrchestrator:
    def __init__(self, workspace: str | Path, gate: ConnectorCandidateGate):
        self.workspace = Path(workspace)
        self.gate = gate

    def prepare(
        self,
        *,
        contract: dict[str, Any],
        session: dict[str, Any],
        head_receipt: dict[str, Any],
        capability: dict[str, Any],
        lock: dict[str, Any],
        allowlist_receipts: list[dict[str, Any]],
        default_branch: str,
        target_branch_exists: bool,
        test_only: bool = False,
    ) -> dict[str, Any]:
        gate_receipt = self.gate.evaluate(
            contract=contract,
            session=session,
            head_receipt=head_receipt,
            capability=capability,
            lock=lock,
            allowlist_receipts=allowlist_receipts,
            default_branch=default_branch,
            target_branch_exists=target_branch_exists,
        )
        if gate_receipt["status"] != "PASS":
            return {
                "schema": "codeforge-connector-candidate-prepare-v1",
                "status": "WRITE_BLOCKED",
                "reasons": gate_receipt["reasons"],
                "mutation_performed": False,
            }
        built = GitHubConnectorPlanBuilder().build(
            contract=contract,
            session=session,
            head_receipt=head_receipt,
            capability=capability,
            lock=lock,
            allowlist_receipts=allowlist_receipts,
            gate_receipt=gate_receipt,
            test_only=test_only,
        )
        return {
            "schema": "codeforge-connector-candidate-prepare-v1",
            "status": built["status"],
            "reasons": built["reasons"],
            "gate": gate_receipt,
            "plan": built["plan"],
            "mutation_performed": False,
            "real_execution_enabled": False,
        }

    def execute_real(self, plan: dict[str, Any]) -> dict[str, Any]:
        return NullConnectorTransport().execute(plan)

    def execute_recording_test(
        self,
        *,
        transport: RecordingGitHubConnectorTransport,
        plan: dict[str, Any],
        content_by_path: dict[str, bytes],
        runtime_config: dict[str, Any],
        inject_failure: str | None = None,
    ) -> dict[str, Any]:
        enabled = bool(runtime_config.get("execution", {}).get("connector_candidate_test_execution_enabled", False))
        if not enabled:
            return {
                "schema": "codeforge-connector-candidate-test-execution-v1",
                "status": "WRITE_BLOCKED",
                "reasons": ["CONNECTOR_CANDIDATE_TEST_EXECUTION_DISABLED"],
                "mutation_performed": False,
            }
        journal = ConnectorCandidateJournal(self.workspace / "journal" / "connector-candidate.jsonl")
        journal.append("PREPARED", {"plan_id": plan.get("plan_id"), "plan_digest": plan.get("digest")})
        execution = transport.execute(plan, content_by_path=content_by_path, inject_failure=inject_failure)
        journal.append(execution.get("status", "UNKNOWN"), {"receipt": execution})
        if execution.get("status") != "PASS":
            return {
                "schema": "codeforge-connector-candidate-test-execution-v1",
                "status": execution.get("status", "FAIL"),
                "execution": execution,
                "journal": journal.verify(),
                "mutation_performed": False,
            }
        readback = RecordingConnectorReadbackVerifier().verify(
            transport=transport,
            plan=plan,
            execution_receipt=execution,
        )
        journal.append("READBACK", {"receipt": readback})
        return {
            "schema": "codeforge-connector-candidate-test-execution-v1",
            "status": "PASS" if readback.get("status") == "PASS" else "FAIL",
            "execution": execution,
            "readback": readback,
            "journal": journal.verify(),
            "mutation_performed": execution.get("mutation_performed", False),
            "network_used": False,
        }
