from __future__ import annotations

from pathlib import Path
from typing import Any
import json

from .branch_policy import BranchIsolationPolicy
from .connector_models import ConnectorSessionReceipt


class ConnectorAdapterPolicy:
    """Fail-closed provider policy. Candidate preparation is not execution permission."""

    def __init__(self, document: dict[str, Any]):
        if document.get("schema") != "codeforge-connector-adapter-policy-v1":
            raise ValueError("Unsupported connector policy schema")
        self.document = document

    @classmethod
    def from_file(cls, path: str | Path) -> "ConnectorAdapterPolicy":
        return cls(json.loads(Path(path).read_text(encoding="utf-8")))

    def provider_rule(self, provider: str) -> dict[str, Any]:
        rule = self.document.get("providers", {}).get(provider)
        return dict(rule) if isinstance(rule, dict) else {}

    def evaluate_candidate(
        self,
        *,
        provider: str,
        session: dict[str, Any],
        repository: str,
        base_branch: str,
        target_branch: str,
        default_branch: str,
        target_branch_exists: bool,
    ) -> dict[str, Any]:
        reasons: list[str] = []
        rule = self.provider_rule(provider)
        if not rule:
            reasons.append("CONNECTOR_PROVIDER_NOT_CONFIGURED")
        if not rule.get("candidate_enabled", False):
            reasons.append("CONNECTOR_CANDIDATE_DISABLED")
        if rule.get("real_execution_enabled", False):
            reasons.append("REAL_CONNECTOR_EXECUTION_POLICY_MUST_REMAIN_FALSE")
        if rule.get("network_write_enabled", False):
            reasons.append("NETWORK_WRITE_POLICY_MUST_REMAIN_FALSE")
        required_permissions = set(rule.get("required_permissions", []))
        required_methods = set(rule.get("required_methods", []))
        session_result = ConnectorSessionReceipt.from_dict(session).validate(
            provider=provider,
            repository=repository,
            required_permissions=required_permissions,
            required_methods=required_methods,
        )
        if session_result["status"] != "PASS":
            reasons.extend(session_result["reasons"])
        branch = BranchIsolationPolicy(
            allowed_prefixes=tuple(self.document.get("isolated_branch_prefixes", ["codeforge/"])),
            protected_branches=tuple(self.document.get("protected_branches", [])),
        ).evaluate(
            base_branch=base_branch,
            target_branch=target_branch,
            default_branch=default_branch,
            target_branch_exists=target_branch_exists,
        )
        if branch["status"] != "PASS":
            reasons.extend(branch["reasons"])
        return {
            "schema": "codeforge-connector-policy-evaluation-v1",
            "provider": provider,
            "session": session_result,
            "branch": branch,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
            "real_execution_enabled": False,
        }
