from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import zipfile

from .models import stable_id, utc_now
from .verification import VerificationLayer


class DirectorySnapshot:
    def create(self, root: str | Path, archive_path: str | Path) -> dict[str, Any]:
        source = Path(root).resolve()
        target = Path(archive_path).resolve()
        if not source.is_dir():
            raise NotADirectoryError(source)
        files = []
        for path in sorted(p for p in source.rglob("*") if p.is_file()):
            rel = path.relative_to(source).as_posix()
            files.append({"path": rel, "size": path.stat().st_size, "sha256": VerificationLayer.sha256(path)})
        manifest = {
            "schema": "codeforge-directory-snapshot-v1",
            "snapshot_id": stable_id("SNP", {"root": str(source), "files": files}),
            "created_at": utc_now(),
            "root": str(source),
            "files": files,
        }
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr("SNAPSHOT_MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
            for item in files:
                archive.write(source / item["path"], f"files/{item['path']}")
        with zipfile.ZipFile(target) as archive:
            corrupt = archive.testzip()
            loaded = json.loads(archive.read("SNAPSHOT_MANIFEST.json").decode("utf-8"))
        return {
            "schema": "codeforge-directory-snapshot-receipt-v1",
            "snapshot_id": manifest["snapshot_id"],
            "path": str(target),
            "files": len(files),
            "sha256": VerificationLayer.sha256(target),
            "crc": "PASS" if corrupt is None else f"FAIL:{corrupt}",
            "manifest_readback": "PASS" if loaded == manifest else "FAIL",
            "status": "PASS" if corrupt is None and loaded == manifest else "FAIL",
        }
