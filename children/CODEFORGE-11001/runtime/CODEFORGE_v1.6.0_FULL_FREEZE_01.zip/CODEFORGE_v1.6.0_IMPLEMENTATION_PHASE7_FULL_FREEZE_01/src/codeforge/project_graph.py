from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

from .scanner import ScanResult


JS_IMPORT = re.compile(r"(?:import\s+(?:[^;]+?\s+from\s+)?|require\s*\()?[\"']([^\"']+)[\"']")
HTML_LINK = re.compile(r"(?:src|href)=[\"']([^\"'#?]+)", re.IGNORECASE)


class ProjectGraphBuilder:
    def build(self, scan: ScanResult) -> dict[str, Any]:
        root = Path(scan.root)
        file_paths = {record.path for record in scan.files}
        nodes = [{"id": path, "type": "file"} for path in sorted(file_paths)]
        edges: list[dict[str, str]] = []
        unresolved: list[dict[str, str]] = []

        for record in scan.files:
            if record.kind != "text":
                continue
            path = root / record.path
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            refs: set[str] = set()
            if path.suffix.lower() in {".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx"}:
                refs.update(JS_IMPORT.findall(text))
            if path.suffix.lower() in {".html", ".htm"}:
                refs.update(HTML_LINK.findall(text))
            for ref in sorted(refs):
                if ref.startswith(("http://", "https://", "data:", "#")):
                    continue
                candidate = (Path(record.path).parent / ref).as_posix()
                candidate = str(Path(candidate)).replace("\\", "/")
                while candidate.startswith("../"):
                    candidate = candidate[3:]
                if candidate.startswith("/"):
                    candidate = candidate[1:]
                variants = [candidate]
                if Path(candidate).suffix == "":
                    variants.extend([candidate + ext for ext in (".js", ".mjs", ".json", ".py")])
                    variants.append(candidate.rstrip("/") + "/index.js")
                target = next((item for item in variants if item in file_paths), None)
                if target:
                    edges.append({"from": record.path, "to": target, "type": "references"})
                else:
                    unresolved.append({"from": record.path, "reference": ref})

        adjacency: dict[str, list[str]] = defaultdict(list)
        for edge in edges:
            adjacency[edge["from"]].append(edge["to"])
        return {
            "schema": "codeforge-project-graph-v1",
            "root": scan.root,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "nodes": nodes,
            "edges": edges,
            "unresolved_references": unresolved,
            "adjacency": {key: sorted(set(value)) for key, value in sorted(adjacency.items())},
        }

    @staticmethod
    def write(path: str | Path, graph: dict[str, Any]) -> None:
        Path(path).write_text(json.dumps(graph, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
