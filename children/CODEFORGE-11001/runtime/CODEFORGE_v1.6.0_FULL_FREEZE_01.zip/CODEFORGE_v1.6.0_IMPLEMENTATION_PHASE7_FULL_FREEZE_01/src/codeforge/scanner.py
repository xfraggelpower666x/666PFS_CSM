from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


DEFAULT_IGNORE = {".git", "node_modules", ".venv", "__pycache__", ".codeforge-workspace"}
TEXT_SUFFIXES = {
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".html", ".css",
    ".json", ".jsonc", ".md", ".txt", ".toml", ".yaml", ".yml", ".xml",
    ".sh", ".bat", ".ps1", ".ini", ".cfg", ".env.example",
}
SECRET_PATTERNS = {
    "github_token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    "generic_bearer": re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{20,}"),
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "cloudflare_token_assignment": re.compile(r"(?i)CLOUDFLARE(?:_API)?_TOKEN\s*[:=]\s*[^\s$<{]{12,}"),
}


@dataclass(slots=True)
class FileRecord:
    path: str
    size: int
    sha256: str
    kind: str
    mime: str | None
    line_count: int | None


@dataclass(slots=True)
class ScanResult:
    root: str
    file_count: int
    total_bytes: int
    files: list[FileRecord]
    duplicate_groups: list[list[str]]
    secret_signal_paths: list[dict[str, str]]
    architecture_signals: dict[str, list[str]]

    def to_dict(self) -> dict:
        return {
            "root": self.root,
            "file_count": self.file_count,
            "total_bytes": self.total_bytes,
            "files": [asdict(record) for record in self.files],
            "duplicate_groups": self.duplicate_groups,
            "secret_signal_paths": self.secret_signal_paths,
            "architecture_signals": self.architecture_signals,
        }


class RepositoryScanner:
    def __init__(self, ignore: Iterable[str] = DEFAULT_IGNORE):
        self.ignore = set(ignore)

    @staticmethod
    def _hash(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _is_text(path: Path) -> bool:
        if path.suffix.lower() in TEXT_SUFFIXES or path.name.endswith(".env.example"):
            return True
        try:
            sample = path.read_bytes()[:4096]
        except OSError:
            return False
        return b"\x00" not in sample

    def scan(self, root: str | Path) -> ScanResult:
        root_path = Path(root).resolve()
        if not root_path.is_dir():
            raise NotADirectoryError(root_path)
        files: list[FileRecord] = []
        hash_paths: dict[str, list[str]] = defaultdict(list)
        secret_signals: list[dict[str, str]] = []
        signals: dict[str, list[str]] = defaultdict(list)
        total_bytes = 0

        for current, dirs, names in os.walk(root_path):
            dirs[:] = sorted(d for d in dirs if d not in self.ignore)
            for name in sorted(names):
                path = Path(current) / name
                rel = path.relative_to(root_path).as_posix()
                try:
                    size = path.stat().st_size
                    digest = self._hash(path)
                except OSError:
                    continue
                is_text = self._is_text(path)
                line_count = None
                if is_text:
                    try:
                        text = path.read_text(encoding="utf-8", errors="replace")
                        line_count = text.count("\n") + (1 if text else 0)
                        for pattern_name, pattern in SECRET_PATTERNS.items():
                            if pattern.search(text):
                                secret_signals.append({"path": rel, "pattern": pattern_name, "value": "REDACTED"})
                    except OSError:
                        pass
                record = FileRecord(
                    path=rel,
                    size=size,
                    sha256=digest,
                    kind="text" if is_text else "binary",
                    mime=mimetypes.guess_type(path.name)[0],
                    line_count=line_count,
                )
                files.append(record)
                total_bytes += size
                hash_paths[digest].append(rel)

                lower = rel.lower()
                if lower.endswith("package.json"):
                    signals["package_manifests"].append(rel)
                if "/workflows/" in f"/{lower}" or lower.startswith(".github/workflows/"):
                    signals["workflows"].append(rel)
                if "wrangler" in Path(lower).name:
                    signals["cloudflare_configs"].append(rel)
                if Path(lower).name in {"worker.js", "worker.mjs", "worker.ts"}:
                    signals["workers"].append(rel)
                if lower.endswith((".html", ".htm")):
                    signals["html_entries"].append(rel)
                if lower.startswith("tests/") or "/tests/" in f"/{lower}":
                    signals["tests"].append(rel)

        duplicates = [sorted(paths) for paths in hash_paths.values() if len(paths) > 1]
        files.sort(key=lambda item: item.path)
        return ScanResult(
            root=str(root_path),
            file_count=len(files),
            total_bytes=total_bytes,
            files=files,
            duplicate_groups=sorted(duplicates, key=lambda group: group[0]),
            secret_signal_paths=secret_signals,
            architecture_signals={key: sorted(value) for key, value in sorted(signals.items())},
        )
