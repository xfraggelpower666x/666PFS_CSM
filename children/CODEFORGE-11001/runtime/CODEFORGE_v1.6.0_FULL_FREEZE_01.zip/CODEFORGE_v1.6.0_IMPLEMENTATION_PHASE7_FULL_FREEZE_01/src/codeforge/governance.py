from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from .status import Status
AUTHORITY_RANK={"github_repository":400,"live_readback":300,"verified_release":200,"handoff_report":100,"unknown":0}
@dataclass(slots=True)
class GateResult: allowed:bool; status:Status; reasons:list[str]
class MutationGate:
    REQUIRED={"evidence_complete","reconciliation_complete","repair_plan_complete","pre_change_backup_complete","target_allowlisted","branch_allowlisted","scope_allowlisted","lock_clear","remote_head_match"}
    LOCAL_EXECUTION_REQUIRED=REQUIRED|{"proposal_digest_verified","authorization_digest_verified","authorization_single_use","candidate_readback_pass","sandbox_marker_verified","transaction_journal_ready"}
    REMOTE_MOCK_EXECUTION_REQUIRED=REQUIRED|{"proposal_digest_verified","remote_contract_digest_verified","authorization_digest_verified","authorization_single_use","capability_receipt_fresh","isolated_branch_verified","remote_lock_verified","idempotency_reserved","remote_readback_ready","transaction_journal_ready"}
    CONNECTOR_CANDIDATE_REQUIRED=REQUIRED|{"proposal_digest_verified","remote_contract_digest_verified","connector_session_fresh","connector_head_receipt_fresh","capability_receipt_fresh","isolated_branch_verified","remote_lock_verified","connector_plan_digest_verified"}
    def evaluate(self,claims:Iterable[str],*,phase:int=1,operation:str="execute",provider:str="remote")->GateResult:
        claim_set=set(claims); reasons=[]
        if operation=="proposal":required=self.REQUIRED
        elif operation=="connector_candidate":required=self.CONNECTOR_CANDIDATE_REQUIRED
        elif provider=="mock_github":required=self.REMOTE_MOCK_EXECUTION_REQUIRED
        else:required=self.LOCAL_EXECUTION_REQUIRED
        missing=sorted(required-claim_set)
        if missing:reasons.append("Missing required claims: "+", ".join(missing))
        if phase<=1:reasons.append("Phase 1 is read-only; mutation capabilities are disabled")
        if operation not in {"proposal","execute","connector_candidate"}:reasons.append("Unsupported gate operation")
        if operation=="execute" and phase<=2:reasons.append("Phase 2 permits verified dry-run proposals only; execution is disabled")
        if operation=="execute" and provider=="local_sandbox" and phase<3:reasons.append("Local sandbox execution requires Phase 3")
        if operation=="execute" and provider=="mock_github" and phase<4:reasons.append("Mock remote execution requires Phase 4")
        if operation=="execute" and provider not in {"local_sandbox","mock_github"}:reasons.append("Real remote execution providers remain disabled")
        if operation=="connector_candidate" and phase<5:reasons.append("Connector candidate preparation requires Phase 5")
        allowed=not reasons and ((operation=="proposal" and phase>=2) or (operation=="connector_candidate" and phase>=5) or (operation=="execute" and provider=="local_sandbox" and phase>=3) or (operation=="execute" and provider=="mock_github" and phase>=4))
        return GateResult(allowed,Status.PASS if allowed else Status.WRITE_BLOCKED,reasons)
def choose_authority(source_types:Iterable[str])->str:
    ranked=sorted(source_types,key=lambda item:AUTHORITY_RANK.get(item,0),reverse=True); return ranked[0] if ranked else "unknown"
