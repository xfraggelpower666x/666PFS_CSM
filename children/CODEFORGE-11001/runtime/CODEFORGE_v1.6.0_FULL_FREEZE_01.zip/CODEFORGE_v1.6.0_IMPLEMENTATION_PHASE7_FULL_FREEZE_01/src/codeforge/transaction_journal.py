from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import os

from .hashchain import digest_document
from .models import utc_now


class TransactionJournal:
    """Append-only, fsync-backed and hash-chained transaction journal."""

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def records(self) -> list[dict[str, Any]]:
        if not self.path.is_file():
            return []
        result = []
        for line_number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                result.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"INVALID_JOURNAL_JSON:{line_number}") from exc
        return result

    def verify(self) -> dict[str, Any]:
        records = self.records()
        previous = "GENESIS"
        errors: list[dict[str, Any]] = []
        for expected_sequence, record in enumerate(records, 1):
            if record.get("sequence") != expected_sequence:
                errors.append({"sequence": expected_sequence, "reason": "SEQUENCE_MISMATCH"})
            if record.get("previous_hash") != previous:
                errors.append({"sequence": expected_sequence, "reason": "PREVIOUS_HASH_MISMATCH"})
            material = dict(record)
            actual = material.pop("record_hash", None)
            expected = digest_document(material)
            if actual != expected:
                errors.append({"sequence": expected_sequence, "reason": "RECORD_HASH_MISMATCH"})
            previous = str(actual)
        return {
            "schema": "codeforge-transaction-journal-verification-v1",
            "path": str(self.path),
            "records": len(records),
            "head_hash": previous,
            "errors": errors,
            "status": "PASS" if not errors else "FAIL",
        }

    def append(self, transaction_id: str, state: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        current = self.verify()
        if current["status"] != "PASS":
            raise RuntimeError("JOURNAL_INTEGRITY_FAIL")
        record = {
            "schema": "codeforge-transaction-journal-record-v1",
            "sequence": current["records"] + 1,
            "transaction_id": transaction_id,
            "state": state,
            "timestamp": utc_now(),
            "payload": payload or {},
            "previous_hash": current["head_hash"],
        }
        record["record_hash"] = digest_document(record)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, sort_keys=True, ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        return record
