from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
import json

from .connector_models import ConnectorActionPlan
from .hashchain import digest_document, verify_document
from .models import stable_id, utc_now
from .storage import AtomicJsonStore

RADIO_REPOSITORY = "xfraggelpower666x/WebRadio-666SOUNDsDESIGn"


def required_execution_phrase(contract_id: str, plan_id: str) -> str:
    return f"AUTHORIZE CODEFORGE REAL CONNECTOR EXECUTION {contract_id} {plan_id}"


@dataclass(slots=True)
class RealConnectorExecutionPermit:
    provider: str
    repository: str
    base_branch: str
    target_branch: str
    contract_id: str
    contract_digest: str
    plan_id: str
    plan_digest: str
    session_id: str
    session_digest: str
    head_receipt_id: str
    head_receipt_digest: str
    capability_receipt_id: str
    capability_receipt_digest: str
    lock_id: str
    lock_digest: str
    gate_digest: str
    authorization_phrase_digest: str
    issued_by: str
    environment: str
    issued_at: str
    expires_at: str
    permit_id: str = ""
    digest: str = ""

    def _material(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-real-connector-execution-permit-v1",
            "provider": self.provider,
            "repository": self.repository,
            "base_branch": self.base_branch,
            "target_branch": self.target_branch,
            "contract_id": self.contract_id,
            "contract_digest": self.contract_digest,
            "plan_id": self.plan_id,
            "plan_digest": self.plan_digest,
            "session_id": self.session_id,
            "session_digest": self.session_digest,
            "head_receipt_id": self.head_receipt_id,
            "head_receipt_digest": self.head_receipt_digest,
            "capability_receipt_id": self.capability_receipt_id,
            "capability_receipt_digest": self.capability_receipt_digest,
            "lock_id": self.lock_id,
            "lock_digest": self.lock_digest,
            "gate_digest": self.gate_digest,
            "authorization_phrase_digest": self.authorization_phrase_digest,
            "issued_by": self.issued_by,
            "environment": self.environment,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
        }

    def seal(self) -> "RealConnectorExecutionPermit":
        material = self._material()
        if not self.permit_id:
            self.permit_id = stable_id("RCEP", material)
        integrity = dict(material)
        integrity["permit_id"] = self.permit_id
        self.digest = digest_document(integrity)
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        data = self._material()
        data["permit_id"] = self.permit_id
        data["digest"] = self.digest
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RealConnectorExecutionPermit":
        return cls(**{key: data.get(key, "") for key in cls.__dataclass_fields__})

    def validate(self, *, plan: dict[str, Any], now: datetime | None = None) -> dict[str, Any]:
        reasons: list[str] = []
        document = self.to_dict()
        expected = document.pop("digest", "")
        if digest_document(document) != expected:
            reasons.append("REAL_CONNECTOR_PERMIT_DIGEST_MISMATCH")
        parsed = ConnectorActionPlan.from_dict(plan)
        plan_validation = parsed.validate()
        if plan_validation["status"] != "PASS":
            reasons.extend(plan_validation["reasons"])
        bindings = {
            "provider": parsed.provider,
            "repository": parsed.repository,
            "base_branch": parsed.base_branch,
            "target_branch": parsed.target_branch,
            "contract_id": parsed.contract_id,
            "contract_digest": parsed.contract_digest,
            "plan_id": parsed.plan_id,
            "plan_digest": parsed.digest,
            "session_id": parsed.session_id,
            "session_digest": parsed.session_digest,
            "head_receipt_id": parsed.head_receipt_id,
            "head_receipt_digest": parsed.head_receipt_digest,
            "capability_receipt_id": parsed.capability_receipt_id,
            "capability_receipt_digest": parsed.capability_receipt_digest,
            "lock_id": parsed.lock_id,
            "lock_digest": parsed.lock_digest,
            "gate_digest": parsed.gate_digest,
        }
        for key, value in bindings.items():
            if getattr(self, key) != value:
                reasons.append(f"REAL_CONNECTOR_PERMIT_BINDING_MISMATCH:{key}")
        if self.repository == RADIO_REPOSITORY:
            reasons.append("RADIO_FORBIDDEN_AS_FIRST_REAL_CONNECTOR_TARGET")
        if self.provider != "github":
            reasons.append("REAL_CONNECTOR_PROVIDER_UNSUPPORTED")
        if self.environment not in {"TEST_HOST_ADAPTER", "REAL_CONNECTOR_CANDIDATE"}:
            reasons.append("REAL_CONNECTOR_PERMIT_ENVIRONMENT_INVALID")
        if not self.issued_by:
            reasons.append("REAL_CONNECTOR_PERMIT_ISSUER_MISSING")
        try:
            current = now or datetime.now(timezone.utc)
            expiry = datetime.fromisoformat(self.expires_at)
            issued = datetime.fromisoformat(self.issued_at)
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if issued.tzinfo is None:
                issued = issued.replace(tzinfo=timezone.utc)
            if expiry <= current:
                reasons.append("REAL_CONNECTOR_PERMIT_EXPIRED")
            if expiry - issued > timedelta(minutes=5):
                reasons.append("REAL_CONNECTOR_PERMIT_TTL_TOO_LONG")
        except (TypeError, ValueError):
            reasons.append("REAL_CONNECTOR_PERMIT_TIME_INVALID")
        return {
            "schema": "codeforge-real-connector-permit-validation-v1",
            "permit_id": self.permit_id,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": sorted(set(reasons)),
        }


def issue_real_connector_execution_permit(
    *,
    plan: dict[str, Any],
    phrase: str,
    issued_by: str,
    environment: str = "REAL_CONNECTOR_CANDIDATE",
    ttl_seconds: int = 120,
) -> dict[str, Any]:
    parsed = ConnectorActionPlan.from_dict(plan)
    validation = parsed.validate()
    if validation["status"] != "PASS":
        raise ValueError("CONNECTOR_PLAN_INVALID")
    if parsed.repository == RADIO_REPOSITORY:
        raise ValueError("RADIO_FORBIDDEN_AS_FIRST_REAL_CONNECTOR_TARGET")
    if ttl_seconds < 30 or ttl_seconds > 300:
        raise ValueError("ttl_seconds must be between 30 and 300")
    required = required_execution_phrase(parsed.contract_id, parsed.plan_id)
    if phrase != required:
        raise ValueError("EXACT_REAL_CONNECTOR_AUTHORIZATION_PHRASE_REQUIRED")
    now = datetime.now(timezone.utc).replace(microsecond=0)
    return RealConnectorExecutionPermit(
        provider=parsed.provider,
        repository=parsed.repository,
        base_branch=parsed.base_branch,
        target_branch=parsed.target_branch,
        contract_id=parsed.contract_id,
        contract_digest=parsed.contract_digest,
        plan_id=parsed.plan_id,
        plan_digest=parsed.digest,
        session_id=parsed.session_id,
        session_digest=parsed.session_digest,
        head_receipt_id=parsed.head_receipt_id,
        head_receipt_digest=parsed.head_receipt_digest,
        capability_receipt_id=parsed.capability_receipt_id,
        capability_receipt_digest=parsed.capability_receipt_digest,
        lock_id=parsed.lock_id,
        lock_digest=parsed.lock_digest,
        gate_digest=parsed.gate_digest,
        authorization_phrase_digest=digest_document({"phrase": phrase}),
        issued_by=issued_by,
        environment=environment,
        issued_at=now.isoformat(),
        expires_at=(now + timedelta(seconds=ttl_seconds)).isoformat(),
    ).seal().to_dict()


class RealConnectorPermitRegistry:
    """Verbraucht versiegelte Freigaben exakt einmal und speichert niemals die Freigabephrase."""

    def __init__(self, path: str | Path):
        self.store = AtomicJsonStore(path)

    def consume(self, permit: dict[str, Any], *, plan: dict[str, Any]) -> dict[str, Any]:
        parsed = RealConnectorExecutionPermit.from_dict(permit)
        validation = parsed.validate(plan=plan)
        if validation["status"] != "PASS":
            return {"status": "WRITE_BLOCKED", "reasons": validation["reasons"], "consumed": False}
        document = self.store.read({"schema": "codeforge-real-connector-permit-registry-v1", "consumed": {}})
        consumed = document.setdefault("consumed", {})
        if parsed.permit_id in consumed:
            return {"status": "WRITE_BLOCKED", "reasons": ["REAL_CONNECTOR_PERMIT_ALREADY_CONSUMED"], "consumed": False}
        consumed[parsed.permit_id] = {
            "permit_digest": parsed.digest,
            "plan_id": parsed.plan_id,
            "consumed_at": utc_now(),
        }
        self.store.write(document)
        return {"status": "PASS", "reasons": [], "consumed": True, "permit_id": parsed.permit_id}
