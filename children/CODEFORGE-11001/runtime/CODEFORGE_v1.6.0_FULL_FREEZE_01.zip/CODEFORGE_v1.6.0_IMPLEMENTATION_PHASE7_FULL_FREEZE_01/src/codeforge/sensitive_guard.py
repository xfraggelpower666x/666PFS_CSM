from __future__ import annotations

from pathlib import Path
from typing import Any

from .scanner import SECRET_PATTERNS
from .writer_models import ProposalOperation


class ChangedFileSecretGuard:
    """Scans only candidate create/update files and never returns matched values."""

    def inspect(self, candidate: str | Path, operations: list[ProposalOperation]) -> dict[str, Any]:
        root = Path(candidate).resolve()
        signals: list[dict[str, str]] = []
        for operation in operations:
            if operation.operation not in {"create", "update"}:
                continue
            path = root / operation.path
            if not path.is_file() or path.stat().st_size > 5_000_000:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for name, pattern in SECRET_PATTERNS.items():
                if pattern.search(text):
                    signals.append({"path": operation.path, "pattern": name, "value": "REDACTED"})
        return {
            "schema": "codeforge-changed-file-secret-guard-v1",
            "signals": signals,
            "status": "PASS" if not signals else "BLOCKED",
        }
