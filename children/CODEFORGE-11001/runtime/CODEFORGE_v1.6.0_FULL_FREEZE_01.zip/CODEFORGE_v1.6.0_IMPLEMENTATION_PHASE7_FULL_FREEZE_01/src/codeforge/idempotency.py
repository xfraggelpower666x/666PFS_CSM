from __future__ import annotations

from pathlib import Path
from typing import Any

from .hashchain import seal_document, verify_document
from .models import stable_id, utc_now
from .storage import AtomicJsonStore


class IdempotencyRegistry:
    def __init__(self, root: str | Path): self.root=Path(root)
    @staticmethod
    def key_for(contract: dict[str, Any]) -> str:
        return stable_id("IDM", {"contract_id":contract.get("contract_id"),"digest":contract.get("digest"),"provider":contract.get("provider"),"repository":contract.get("repository"),"target_branch":contract.get("target_branch")})
    def _path(self,key:str)->Path:return self.root/f"{key}.json"
    def reserve(self, contract: dict[str, Any]) -> dict[str, Any]:
        key=self.key_for(contract); path=self._path(key)
        if path.exists():
            current=AtomicJsonStore(path).read({})
            return {"schema":"codeforge-idempotency-reservation-v1","key":key,"status":"WRITE_BLOCKED","reason":"IDEMPOTENCY_KEY_ALREADY_USED","current_state":current.get("state")}
        receipt=seal_document({"schema":"codeforge-idempotency-record-v1","key":key,"contract_id":contract.get("contract_id"),"contract_digest":contract.get("digest"),"state":"RESERVED","reserved_at":utc_now(),"committed_at":None,"execution_receipt_digest":None})
        AtomicJsonStore(path).write(receipt)
        return {"schema":"codeforge-idempotency-reservation-v1","key":key,"status":"PASS","record":receipt}
    def commit(self,key:str,execution_receipt:dict[str,Any])->dict[str,Any]:
        path=self._path(key); current=AtomicJsonStore(path).read(None)
        if not isinstance(current,dict) or not verify_document(current): return {"status":"WRITE_BLOCKED","reason":"IDEMPOTENCY_RECORD_INVALID"}
        if current.get("state")!="RESERVED": return {"status":"WRITE_BLOCKED","reason":"IDEMPOTENCY_NOT_RESERVED"}
        updated=dict(current); updated["state"]="COMMITTED"; updated["committed_at"]=utc_now(); updated["execution_receipt_digest"]=execution_receipt.get("digest"); updated=seal_document(updated); AtomicJsonStore(path).write(updated)
        return {"schema":"codeforge-idempotency-commit-v1","key":key,"status":"PASS","record":updated}
    def release(self,key:str,reason:str)->dict[str,Any]:
        path=self._path(key); current=AtomicJsonStore(path).read(None)
        if not isinstance(current,dict) or current.get("state")!="RESERVED": return {"status":"WRITE_BLOCKED","reason":"IDEMPOTENCY_NOT_RESERVED"}
        updated=dict(current); updated["state"]="RELEASED"; updated["released_at"]=utc_now(); updated["release_reason"]=reason; updated=seal_document(updated); AtomicJsonStore(path).write(updated)
        return {"schema":"codeforge-idempotency-release-v1","key":key,"status":"PASS","record":updated}
    def inspect(self,key:str)->dict[str,Any]:
        current=AtomicJsonStore(self._path(key)).read(None)
        if not isinstance(current,dict): return {"status":"OPEN","key":key}
        return {"status":"PASS" if verify_document(current) else "FAIL","key":key,"record":current}
