from __future__ import annotations

from typing import Any

from .connector_models import ConnectorAction, ConnectorActionPlan, ConnectorHeadReceipt, ConnectorSessionReceipt
from .hashchain import digest_document, verify_document
from .remote_models import RemoteExecutionContract
from .targets import normalize_relative_path


class GitHubConnectorPlanBuilder:
    """Maps a fully gated contract to connector actions without executing them."""

    provider = "github"

    def build(
        self,
        *,
        contract: dict[str, Any],
        session: dict[str, Any],
        head_receipt: dict[str, Any],
        capability: dict[str, Any],
        lock: dict[str, Any],
        allowlist_receipts: list[dict[str, Any]],
        gate_receipt: dict[str, Any],
        test_only: bool = False,
    ) -> dict[str, Any]:
        parsed = RemoteExecutionContract.from_dict(contract)
        connector_session = ConnectorSessionReceipt.from_dict(session)
        head = ConnectorHeadReceipt.from_dict(head_receipt)
        reasons: list[str] = []
        validation = parsed.validate()
        if validation["status"] != "PASS":
            reasons.extend(validation["reasons"])
        if parsed.provider != self.provider or parsed.execution_mode != "CONTRACT_ONLY":
            reasons.append("GITHUB_CONNECTOR_CONTRACT_REQUIRED")

        session_validation = connector_session.validate(
            provider=self.provider,
            repository=parsed.repository,
            required_permissions={"read", "contents_write", "branch_write"},
            required_methods={"GET", "POST", "PUT", "DELETE"},
        )
        if session_validation["status"] != "PASS":
            reasons.extend(session_validation["reasons"])
        head_validation = head.validate(
            provider=self.provider,
            connector_session_id=connector_session.session_id,
            repository=parsed.repository,
            branch=parsed.base_branch,
            expected_head_sha=parsed.expected_base_head_sha,
        )
        if head_validation["status"] != "PASS":
            reasons.extend(head_validation["reasons"])
        if not verify_document(capability) or capability.get("receipt_id") != parsed.capability_evidence_id:
            reasons.append("CONNECTOR_PLAN_CAPABILITY_BINDING_INVALID")
        if not verify_document(lock) or lock.get("lock_id") != parsed.lock_id:
            reasons.append("CONNECTOR_PLAN_LOCK_BINDING_INVALID")
        if not verify_document(gate_receipt) or gate_receipt.get("status") != "PASS" or gate_receipt.get("contract_id") != parsed.contract_id:
            reasons.append("CONNECTOR_PLAN_GATE_BINDING_INVALID")
        if len(allowlist_receipts) != len(parsed.operations) or any(not item.get("allowed") for item in allowlist_receipts):
            reasons.append("CONNECTOR_PLAN_ALLOWLIST_BINDING_INVALID")

        actions = [
            ConnectorAction(
                sequence=1,
                action="create_branch",
                repository=parsed.repository,
                branch=parsed.target_branch,
                source_branch=parsed.base_branch,
                source_head_sha=parsed.expected_base_head_sha,
            )
        ]
        for index, operation in enumerate(parsed.operations, 2):
            action_name = {
                "create": "create_file",
                "update": "update_file",
                "delete": "delete_file",
            }[operation.operation]
            actions.append(
                ConnectorAction(
                    sequence=index,
                    action=action_name,
                    repository=parsed.repository,
                    branch=parsed.target_branch,
                    path=operation.path,
                    expected_sha256=operation.expected_blob_sha256,
                    content_sha256=operation.content_sha256,
                    content_size=operation.content_size,
                )
            )
        plan = ConnectorActionPlan(
            provider=self.provider,
            contract_id=parsed.contract_id,
            contract_digest=parsed.digest,
            session_id=connector_session.session_id,
            session_digest=connector_session.digest,
            head_receipt_id=head.receipt_id,
            head_receipt_digest=head.digest,
            capability_receipt_id=str(capability.get("receipt_id", "")),
            capability_receipt_digest=str(capability.get("digest", "")),
            lock_id=str(lock.get("lock_id", "")),
            lock_digest=str(lock.get("digest", "")),
            allowlist_digest=digest_document(allowlist_receipts),
            gate_digest=str(gate_receipt.get("digest", "")),
            repository=parsed.repository,
            base_branch=parsed.base_branch,
            target_branch=parsed.target_branch,
            expected_base_head_sha=parsed.expected_base_head_sha,
            actions=actions,
            test_only=test_only,
        ).seal()
        plan_validation = plan.validate()
        if plan_validation["status"] != "PASS":
            reasons.extend(plan_validation["reasons"])
        return {
            "schema": "codeforge-github-connector-plan-build-v1",
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": sorted(set(reasons)),
            "plan": plan.to_dict(),
        }


class CloudflareConnectorPlanBuilder:
    """Produces validated readback-only plans; deployment writes remain unavailable."""

    provider = "cloudflare"

    def build_readback_plan(
        self,
        *,
        repository: str,
        branch: str,
        deployment_identity_path: str,
        session: dict[str, Any],
        head_receipt: dict[str, Any],
    ) -> dict[str, Any]:
        connector_session = ConnectorSessionReceipt.from_dict(session)
        head = ConnectorHeadReceipt.from_dict(head_receipt)
        reasons: list[str] = []
        session_validation = connector_session.validate(
            provider=self.provider,
            repository=repository,
            required_permissions={"read"},
            required_methods={"GET"},
        )
        if session_validation["status"] != "PASS":
            reasons.extend(session_validation["reasons"])
        head_validation = head.validate(
            provider=self.provider,
            connector_session_id=connector_session.session_id,
            repository=repository,
            branch=branch,
            expected_head_sha=head.head_sha,
        )
        if head_validation["status"] != "PASS":
            reasons.extend(head_validation["reasons"])
        try:
            normalized_path = normalize_relative_path(deployment_identity_path)
        except ValueError:
            normalized_path = deployment_identity_path
            reasons.append("CLOUDFLARE_READBACK_PATH_INVALID")
        action = ConnectorAction(
            sequence=1,
            action="deployment_readback",
            repository=repository,
            branch=branch,
            path=normalized_path,
        )
        plan = ConnectorActionPlan(
            provider=self.provider,
            contract_id="READBACK_ONLY",
            contract_digest="0" * 64,
            session_id=connector_session.session_id,
            session_digest=connector_session.digest,
            head_receipt_id=head.receipt_id,
            head_receipt_digest=head.digest,
            capability_receipt_id="",
            capability_receipt_digest="",
            lock_id="",
            lock_digest="",
            allowlist_digest="",
            gate_digest="",
            repository=repository,
            base_branch=branch,
            target_branch=branch,
            expected_base_head_sha=head.head_sha,
            actions=[action],
            test_only=False,
        ).seal()
        validation = plan.validate()
        if validation["status"] != "PASS":
            reasons.extend(validation["reasons"])
        return {
            "schema": "codeforge-cloudflare-connector-readback-plan-v1",
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": sorted(set(reasons)),
            "plan": plan.to_dict(),
            "write_execution": "WRITE_BLOCKED",
        }

    def build_write_plan(self, **_: Any) -> dict[str, Any]:
        return {
            "schema": "codeforge-cloudflare-connector-write-plan-v1",
            "status": "WRITE_BLOCKED",
            "reasons": ["CLOUDFLARE_CONNECTOR_WRITE_TRANSPORT_NOT_IMPLEMENTED"],
            "mutation_performed": False,
        }
