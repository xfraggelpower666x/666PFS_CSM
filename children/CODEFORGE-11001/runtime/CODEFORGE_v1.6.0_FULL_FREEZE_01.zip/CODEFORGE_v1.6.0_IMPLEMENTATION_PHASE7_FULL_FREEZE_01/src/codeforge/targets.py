from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import PurePosixPath
from typing import Any
import fnmatch
import re

from .models import stable_id, utc_now
from .status import Status

_SHA_RE = re.compile(r"^[0-9a-fA-F]{7,64}$")


def normalize_relative_path(path: str) -> str:
    normalized = path.replace("\\", "/").strip("/")
    candidate = PurePosixPath(normalized)
    if not normalized or candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError(f"Unsafe repository path: {path!r}")
    return candidate.as_posix()


@dataclass(frozen=True, slots=True)
class RepositoryTarget:
    repository: str
    branch: str

    def __post_init__(self) -> None:
        if self.repository.count("/") != 1:
            raise ValueError("repository must use owner/name form")
        if not self.branch or self.branch.startswith("-") or ".." in self.branch:
            raise ValueError("invalid branch")

    @property
    def identity(self) -> str:
        return f"{self.repository}@{self.branch}"

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(slots=True)
class RemoteHeadClaim:
    target: RepositoryTarget
    expected_sha: str
    observed_sha: str
    evidence_id: str
    observed_at: str = field(default_factory=utc_now)

    def validate(self) -> dict[str, Any]:
        reasons: list[str] = []
        for label, value in (("expected_sha", self.expected_sha), ("observed_sha", self.observed_sha)):
            if not _SHA_RE.fullmatch(value):
                reasons.append(f"{label} is not a valid commit/tree digest")
        if self.expected_sha.lower() != self.observed_sha.lower():
            reasons.append("REMOTE_HEAD_MISMATCH")
        if not self.evidence_id:
            reasons.append("REMOTE_HEAD_EVIDENCE_MISSING")
        return {
            "schema": "codeforge-remote-head-gate-v1",
            "target": self.target.to_dict(),
            "expected_sha": self.expected_sha,
            "observed_sha": self.observed_sha,
            "evidence_id": self.evidence_id,
            "observed_at": self.observed_at,
            "status": Status.PASS.value if not reasons else Status.BLOCKED.value,
            "reasons": reasons,
        }


class AllowlistPolicy:
    """Exact repository/branch/path/operation policy. Missing rules fail closed."""

    def __init__(self, document: dict[str, Any]):
        if document.get("schema") != "codeforge-writer-allowlist-v1":
            raise ValueError("Unsupported allowlist schema")
        self.document = document

    @classmethod
    def from_file(cls, path: str) -> "AllowlistPolicy":
        import json
        from pathlib import Path

        return cls(json.loads(Path(path).read_text(encoding="utf-8")))

    @staticmethod
    def _matches(path: str, pattern: str) -> bool:
        # fnmatch handles root files more predictably than PurePath.match for **.
        return fnmatch.fnmatchcase(path, pattern) or (
            pattern.startswith("**/") and fnmatch.fnmatchcase(path, pattern[3:])
        )

    def evaluate(self, target: RepositoryTarget, path: str, operation: str) -> dict[str, Any]:
        normalized = normalize_relative_path(path)
        rules = self.document.get("repositories", {}).get(target.repository)
        reasons: list[str] = []
        if not isinstance(rules, dict):
            reasons.append("TARGET_NOT_ALLOWLISTED")
        else:
            if target.branch not in set(rules.get("branches", [])):
                reasons.append("BRANCH_NOT_ALLOWLISTED")
            if operation not in set(rules.get("operations", [])):
                reasons.append("OPERATION_NOT_ALLOWLISTED")
            includes = rules.get("include", [])
            excludes = rules.get("exclude", [])
            if not any(self._matches(normalized, pattern) for pattern in includes):
                reasons.append("PATH_NOT_INCLUDED")
            if any(self._matches(normalized, pattern) for pattern in excludes):
                reasons.append("PATH_EXCLUDED")
        return {
            "target": target.to_dict(),
            "path": normalized,
            "operation": operation,
            "allowed": not reasons,
            "status": Status.PASS.value if not reasons else Status.WRITE_BLOCKED.value,
            "reasons": reasons,
        }

    def fingerprint(self) -> str:
        return stable_id("POL", self.document)
