from __future__ import annotations

import base64
import hashlib
from dataclasses import asdict, dataclass, field
from typing import Any

from .hashchain import digest_document, verify_document
from .models import stable_id, utc_now
from .targets import RepositoryTarget, normalize_relative_path

_ALLOWED_OPERATIONS = {"create", "update", "delete"}
_ALLOWED_MODES = {"CONTRACT_ONLY", "MOCK_ONLY"}


@dataclass(slots=True)
class RemoteOperationIntent:
    operation: str
    path: str
    expected_blob_sha256: str | None = None
    content_b64: str | None = None
    content_sha256: str | None = None
    content_size: int | None = None

    @classmethod
    def from_bytes(cls, operation: str, path: str, content: bytes | None = None, *, expected_blob_sha256: str | None = None) -> "RemoteOperationIntent":
        normalized = normalize_relative_path(path)
        if content is None:
            return cls(operation, normalized, expected_blob_sha256, None, None, None)
        return cls(
            operation=operation,
            path=normalized,
            expected_blob_sha256=expected_blob_sha256,
            content_b64=base64.b64encode(content).decode("ascii"),
            content_sha256=hashlib.sha256(content).hexdigest(),
            content_size=len(content),
        )

    def decoded_content(self) -> bytes | None:
        if self.content_b64 is None:
            return None
        return base64.b64decode(self.content_b64.encode("ascii"), validate=True)

    def validate(self) -> list[str]:
        reasons: list[str] = []
        try:
            normalized = normalize_relative_path(self.path)
            if normalized != self.path:
                reasons.append("PATH_NOT_NORMALIZED")
        except ValueError:
            reasons.append("UNSAFE_PATH")
        if self.operation not in _ALLOWED_OPERATIONS:
            reasons.append("UNSUPPORTED_OPERATION")
        if self.operation == "delete":
            if any(value is not None for value in (self.content_b64, self.content_sha256, self.content_size)):
                reasons.append("DELETE_MUST_NOT_CONTAIN_CONTENT")
        else:
            if self.content_b64 is None or self.content_sha256 is None or self.content_size is None:
                reasons.append("CONTENT_BINDING_MISSING")
            else:
                try:
                    data = self.decoded_content()
                except Exception:
                    data = None
                    reasons.append("CONTENT_BASE64_INVALID")
                if data is not None:
                    if hashlib.sha256(data).hexdigest() != self.content_sha256:
                        reasons.append("CONTENT_SHA256_MISMATCH")
                    if len(data) != self.content_size:
                        reasons.append("CONTENT_SIZE_MISMATCH")
        if self.operation in {"update", "delete"} and not self.expected_blob_sha256:
            reasons.append("EXPECTED_BLOB_SHA256_MISSING")
        if self.operation == "create" and self.expected_blob_sha256 is not None:
            reasons.append("CREATE_MUST_NOT_EXPECT_EXISTING_BLOB")
        return reasons

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RemoteOperationIntent":
        return cls(**{key: data.get(key) for key in cls.__dataclass_fields__})


@dataclass(slots=True)
class RemoteExecutionContract:
    provider: str
    repository: str
    base_branch: str
    target_branch: str
    expected_base_head_sha: str
    operations: list[RemoteOperationIntent]
    proposal_id: str
    proposal_digest: str
    capability_evidence_id: str
    lock_id: str
    execution_mode: str = "CONTRACT_ONLY"
    created_at: str = field(default_factory=utc_now)
    contract_id: str = ""
    digest: str = ""

    @property
    def target(self) -> RepositoryTarget:
        return RepositoryTarget(self.repository, self.target_branch)

    def _material(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-remote-execution-contract-v1",
            "provider": self.provider,
            "repository": self.repository,
            "base_branch": self.base_branch,
            "target_branch": self.target_branch,
            "expected_base_head_sha": self.expected_base_head_sha,
            "operations": [item.to_dict() for item in self.operations],
            "proposal_id": self.proposal_id,
            "proposal_digest": self.proposal_digest,
            "capability_evidence_id": self.capability_evidence_id,
            "lock_id": self.lock_id,
            "execution_mode": self.execution_mode,
            "created_at": self.created_at,
        }

    def seal(self) -> "RemoteExecutionContract":
        material = self._material()
        if not self.contract_id:
            self.contract_id = stable_id("RCT", material)
        integrity = dict(material)
        integrity["contract_id"] = self.contract_id
        self.digest = digest_document(integrity)
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        data = self._material()
        data["contract_id"] = self.contract_id
        data["digest"] = self.digest
        return data

    def validate(self) -> dict[str, Any]:
        document = self.to_dict()
        reasons: list[str] = []
        if self.execution_mode not in _ALLOWED_MODES:
            reasons.append("UNSUPPORTED_EXECUTION_MODE")
        if self.execution_mode == "MOCK_ONLY" and self.provider != "mock_github":
            reasons.append("MOCK_MODE_PROVIDER_MISMATCH")
        if self.execution_mode == "CONTRACT_ONLY" and self.provider == "mock_github":
            reasons.append("MOCK_PROVIDER_REQUIRES_MOCK_ONLY")
        try:
            RepositoryTarget(self.repository, self.target_branch)
            RepositoryTarget(self.repository, self.base_branch)
        except ValueError:
            reasons.append("INVALID_REPOSITORY_TARGET")
        if not self.proposal_id or not self.proposal_digest:
            reasons.append("PROPOSAL_BINDING_MISSING")
        if not self.capability_evidence_id:
            reasons.append("CAPABILITY_EVIDENCE_MISSING")
        if not self.lock_id:
            reasons.append("REMOTE_LOCK_BINDING_MISSING")
        if not self.operations:
            reasons.append("OPERATIONS_EMPTY")
        paths: set[str] = set()
        for index, operation in enumerate(self.operations):
            for reason in operation.validate():
                reasons.append(f"OPERATION_{index}:{reason}")
            if operation.path in paths:
                reasons.append(f"DUPLICATE_PATH:{operation.path}")
            paths.add(operation.path)
        expected = document.pop("digest", "")
        if not expected or digest_document(document) != expected:
            reasons.append("REMOTE_CONTRACT_DIGEST_MISMATCH")
        return {
            "schema": "codeforge-remote-contract-validation-v1",
            "contract_id": self.contract_id,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RemoteExecutionContract":
        return cls(
            provider=str(data.get("provider", "")),
            repository=str(data.get("repository", "")),
            base_branch=str(data.get("base_branch", "")),
            target_branch=str(data.get("target_branch", "")),
            expected_base_head_sha=str(data.get("expected_base_head_sha", "")),
            operations=[RemoteOperationIntent.from_dict(item) for item in data.get("operations", [])],
            proposal_id=str(data.get("proposal_id", "")),
            proposal_digest=str(data.get("proposal_digest", "")),
            capability_evidence_id=str(data.get("capability_evidence_id", "")),
            lock_id=str(data.get("lock_id", "")),
            execution_mode=str(data.get("execution_mode", "CONTRACT_ONLY")),
            created_at=str(data.get("created_at", utc_now())),
            contract_id=str(data.get("contract_id", "")),
            digest=str(data.get("digest", "")),
        )
