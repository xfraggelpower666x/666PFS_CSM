from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .hashchain import seal_document, verify_document
from .models import stable_id, utc_now

_REQUIRED_MOCK_PERMISSIONS = {"read", "contents_write", "branch_write"}


def issue_capability_receipt(*, provider: str, repository: str, subject: str, permissions: list[str], methods: list[str], evidence_id: str, ttl_seconds: int = 300) -> dict[str, Any]:
    if ttl_seconds < 30 or ttl_seconds > 1800:
        raise ValueError("ttl_seconds must be between 30 and 1800")
    now = datetime.now(timezone.utc).replace(microsecond=0)
    receipt = {
        "schema": "codeforge-remote-capability-receipt-v1",
        "receipt_id": stable_id("CAP", {"provider": provider, "repository": repository, "subject": subject, "issued_at": now.isoformat(), "evidence_id": evidence_id}),
        "provider": provider,
        "repository": repository,
        "subject": subject,
        "permissions": sorted(set(permissions)),
        "methods": sorted(set(methods)),
        "evidence_id": evidence_id,
        "issued_at": now.isoformat(),
        "expires_at": (now + timedelta(seconds=ttl_seconds)).isoformat(),
        "status": "PASS",
    }
    return seal_document(receipt)


def validate_capability_receipt(receipt: dict[str, Any], *, provider: str, repository: str, require_mock_write: bool = False, now: datetime | None = None) -> dict[str, Any]:
    reasons: list[str] = []
    if not verify_document(receipt):
        reasons.append("CAPABILITY_DIGEST_MISMATCH")
    if receipt.get("provider") != provider:
        reasons.append("CAPABILITY_PROVIDER_MISMATCH")
    if receipt.get("repository") != repository:
        reasons.append("CAPABILITY_REPOSITORY_MISMATCH")
    if not receipt.get("evidence_id"):
        reasons.append("CAPABILITY_EVIDENCE_MISSING")
    try:
        current = now or datetime.now(timezone.utc)
        if datetime.fromisoformat(str(receipt.get("expires_at"))) <= current:
            reasons.append("CAPABILITY_RECEIPT_EXPIRED")
    except (TypeError, ValueError):
        reasons.append("CAPABILITY_EXPIRY_INVALID")
    permissions = set(receipt.get("permissions", []))
    if "read" not in permissions:
        reasons.append("READ_PERMISSION_MISSING")
    if require_mock_write and not _REQUIRED_MOCK_PERMISSIONS.issubset(permissions):
        reasons.append("MOCK_WRITE_PERMISSIONS_INCOMPLETE")
    methods = set(receipt.get("methods", []))
    if "GET" not in methods:
        reasons.append("GET_CAPABILITY_MISSING")
    return {
        "schema": "codeforge-remote-capability-validation-v1",
        "receipt_id": receipt.get("receipt_id"),
        "status": "PASS" if not reasons else "WRITE_BLOCKED",
        "reasons": reasons,
    }
