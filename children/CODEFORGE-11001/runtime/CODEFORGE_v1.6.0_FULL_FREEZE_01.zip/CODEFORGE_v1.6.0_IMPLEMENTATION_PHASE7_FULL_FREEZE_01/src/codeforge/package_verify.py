from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import zipfile


class PortablePackageVerifier:
    """Verifies a ZIP against a receipt or checksum independent of cwd."""

    @staticmethod
    def sha256(path: str | Path) -> str:
        digest = hashlib.sha256()
        with Path(path).open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def verify(
        self,
        archive: str | Path,
        *,
        checksum_file: str | Path | None = None,
        readback_file: str | Path | None = None,
    ) -> dict[str, Any]:
        path = Path(archive).resolve()
        expected: str | None = None
        sources: list[str] = []
        if checksum_file:
            checksum_path = Path(checksum_file).resolve()
            first = checksum_path.read_text(encoding="utf-8").strip().split()[0]
            expected = first.lower()
            sources.append(str(checksum_path))
        readback = None
        if readback_file:
            readback_path = Path(readback_file).resolve()
            readback = json.loads(readback_path.read_text(encoding="utf-8"))
            readback_expected = str(readback.get("sha256", "")).lower()
            if expected and readback_expected != expected:
                return {"status": "FAIL", "reason": "EVIDENCE_HASH_CONFLICT", "sources": sources + [str(readback_path)]}
            expected = readback_expected or expected
            sources.append(str(readback_path))
        actual = self.sha256(path)
        with zipfile.ZipFile(path) as handle:
            corrupt = handle.testzip()
            entries = len(handle.infolist())
        checks = {
            "hash": expected is None or expected == actual,
            "crc": corrupt is None,
            "entries": readback is None or int(readback.get("entries", entries)) == entries,
            "size": readback is None or int(readback.get("size", path.stat().st_size)) == path.stat().st_size,
        }
        return {
            "schema": "codeforge-portable-package-verification-v1",
            "archive": str(path),
            "sources": sources,
            "expected_sha256": expected,
            "actual_sha256": actual,
            "entries": entries,
            "size": path.stat().st_size,
            "crc": "PASS" if corrupt is None else f"FAIL:{corrupt}",
            "checks": checks,
            "status": "PASS" if all(checks.values()) else "FAIL",
        }
