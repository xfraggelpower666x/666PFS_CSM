from __future__ import annotations

from pathlib import Path
from typing import Any

from .storage import AtomicJsonStore


class Registry:
    def __init__(self, path: str | Path, schema: str):
        self.store = AtomicJsonStore(path)
        self.schema = schema

    def initialize(self) -> None:
        if not self.store.path.exists():
            self.store.write({"schema": self.schema, "entries": {}})

    def register(self, key: str, value: dict[str, Any], *, replace: bool = False) -> None:
        self.initialize()
        data = self.store.read()
        if key in data["entries"] and not replace:
            raise KeyError(f"Registry entry already exists: {key}")
        data["entries"][key] = value
        self.store.write(data)

    def get(self, key: str) -> dict[str, Any] | None:
        self.initialize()
        return self.store.read()["entries"].get(key)

    def all(self) -> dict[str, dict[str, Any]]:
        self.initialize()
        return self.store.read()["entries"]


class StageRegistry(Registry):
    DEFAULT_STAGES = {
        "analysis": {"order": 10, "mutating": False},
        "evidence": {"order": 20, "mutating": False},
        "reconciliation": {"order": 30, "mutating": False},
        "repair_plan": {"order": 40, "mutating": False},
        "pre_change_backup": {"order": 45, "mutating": False},
        "proposal": {"order": 47, "mutating": False},
        "authorization": {"order": 48, "mutating": False},
        "transaction_prepare": {"order": 49, "mutating": False},
        "local_sandbox_execute": {"order": 50, "mutating": True, "enabled_by_default": False},
        "remote_execute": {"order": 51, "mutating": True, "enabled": False},
        "readback": {"order": 55, "mutating": False},
        "rollback_or_commit": {"order": 57, "mutating": True, "local_sandbox_only": True},
        "re_audit": {"order": 60, "mutating": False},
        "checkpoint": {"order": 70, "mutating": False},
        "resume": {"order": 80, "mutating": False},
    }

    def seed(self) -> None:
        self.initialize()
        data = self.store.read()
        changed = False
        for key, value in self.DEFAULT_STAGES.items():
            if data["entries"].get(key) != value:
                data["entries"][key] = value
                changed = True
        if changed:
            self.store.write(data)


class CapabilityRegistry(Registry):
    DEFAULT_CAPABILITIES = {
        "local_repository_scan": {"mode": "read_only", "phase": 1},
        "sha256_inventory": {"mode": "read_only", "phase": 1},
        "project_graph": {"mode": "read_only", "phase": 1},
        "github_readonly": {"mode": "GET_only", "phase": 1},
        "cloudflare_readback": {"mode": "GET_only_allowlisted", "phase": 1},
        "radio_intelligence": {"mode": "read_only_plugin", "phase": 1},
        "remote_head_gate": {"mode": "verification_only", "phase": 2},
        "repository_lock": {"mode": "local_planning_lock", "phase": 2},
        "writer_allowlist": {"mode": "fail_closed", "phase": 2},
        "exact_scope_diff": {"mode": "read_only", "phase": 2},
        "pre_change_backup": {"mode": "local_backup_only", "phase": 2},
        "change_proposal": {"mode": "dry_run", "phase": 2},
        "proposal_readback": {"mode": "verification_only", "phase": 2},
        "exact_authorization": {"mode": "single_use_local", "phase": 3},
        "transaction_journal": {"mode": "hash_chained", "phase": 3},
        "local_sandbox_execute": {"mode": "explicit_enable_and_authorization", "phase": 3},
        "atomic_directory_swap": {"mode": "local_sandbox_only", "phase": 3},
        "transaction_rollback": {"mode": "automatic_local", "phase": 3},
        "transaction_recovery": {"mode": "fail_safe_local", "phase": 3},
        "deterministic_release_freeze": {"mode": "local_artifact", "phase": 3},
        "incremental_inventory": {"mode": "read_only_cache", "phase": 3},
        "github_write": {"mode": "DISABLED", "phase": 3},
        "cloudflare_write": {"mode": "DISABLED", "phase": 3},
    }

    def seed(self) -> None:
        self.initialize()
        data = self.store.read()
        changed = False
        for key, value in self.DEFAULT_CAPABILITIES.items():
            if data["entries"].get(key) != value:
                data["entries"][key] = value
                changed = True
        if changed:
            self.store.write(data)
