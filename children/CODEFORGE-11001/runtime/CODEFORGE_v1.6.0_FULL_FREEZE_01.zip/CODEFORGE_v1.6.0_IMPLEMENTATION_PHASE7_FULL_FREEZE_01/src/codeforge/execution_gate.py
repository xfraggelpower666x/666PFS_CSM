from __future__ import annotations

from pathlib import Path
from typing import Any
import json

from .authorization import ExecutionAuthorizationRegistry
from .hashchain import verify_document
from .readback import ProposalReadbackVerifier
from .targets import RemoteHeadClaim, RepositoryTarget
from .writer_models import proposal_digest


class ExecutionGate:
    """Re-verifies every mutable dependency immediately before local execution."""

    def evaluate(
        self,
        *,
        proposal: dict[str, Any],
        authorization: dict[str, Any],
        candidate: str | Path,
        target: str | Path,
        remote_head: RemoteHeadClaim,
        runtime_config: dict[str, Any],
    ) -> dict[str, Any]:
        reasons: list[str] = []
        checks: dict[str, Any] = {}

        proposal_id = str(proposal.get("proposal_id", ""))
        actual_digest = proposal_digest(proposal, proposal_id)
        checks["proposal_integrity"] = proposal.get("digest") == actual_digest and bool(proposal_id)
        if not checks["proposal_integrity"]:
            reasons.append("PROPOSAL_DIGEST_MISMATCH")

        checks["authorization_integrity"] = verify_document(authorization)
        if not checks["authorization_integrity"]:
            reasons.append("AUTHORIZATION_DIGEST_MISMATCH")
        if authorization.get("proposal_id") != proposal_id or authorization.get("proposal_digest") != proposal.get("digest"):
            reasons.append("AUTHORIZATION_PROPOSAL_MISMATCH")
        if authorization.get("consumed"):
            reasons.append("AUTHORIZATION_ALREADY_CONSUMED")

        head_receipt = remote_head.validate()
        checks["remote_head"] = head_receipt
        if head_receipt["status"] != "PASS":
            reasons.append("REMOTE_HEAD_RECHECK_FAILED")

        execution = runtime_config.get("execution", {})
        if execution.get("mode") != "CONTROLLED_LOCAL_SANDBOX":
            reasons.append("LOCAL_SANDBOX_MODE_REQUIRED")
        if execution.get("local_sandbox_enabled") is not True:
            reasons.append("LOCAL_SANDBOX_EXECUTION_DISABLED")
        if execution.get("github_write_enabled") is not False:
            reasons.append("GITHUB_WRITE_MUST_REMAIN_DISABLED")
        if execution.get("cloudflare_write_enabled") is not False:
            reasons.append("CLOUDFLARE_WRITE_MUST_REMAIN_DISABLED")

        target_root = Path(target).resolve()
        sandbox_root = Path(execution.get("sandbox_root", "")).resolve()
        try:
            target_root.relative_to(sandbox_root)
            checks["target_within_sandbox"] = True
        except ValueError:
            checks["target_within_sandbox"] = False
            reasons.append("TARGET_OUTSIDE_SANDBOX_ROOT")

        marker_path = target_root / ".codeforge-sandbox-target.json"
        if not marker_path.is_file():
            reasons.append("SANDBOX_TARGET_MARKER_MISSING")
        else:
            try:
                marker = json.loads(marker_path.read_text(encoding="utf-8"))
                expected_target = RepositoryTarget(
                    proposal["target"]["repository"], proposal["target"]["branch"]
                ).identity
                if marker.get("schema") != "codeforge-sandbox-target-v1" or marker.get("target_identity") != expected_target:
                    reasons.append("SANDBOX_TARGET_MARKER_MISMATCH")
            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                reasons.append("SANDBOX_TARGET_MARKER_INVALID")

        candidate_receipt = ProposalReadbackVerifier().verify(proposal, candidate)
        checks["candidate_readback"] = candidate_receipt
        if candidate_receipt["status"] != "PASS":
            reasons.append("CANDIDATE_READBACK_FAILED")

        return {
            "schema": "codeforge-execution-gate-v1",
            "proposal_id": proposal_id,
            "authorization_id": authorization.get("authorization_id"),
            "checks": checks,
            "reasons": reasons,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "execution_allowed": not reasons,
        }
