from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ..models import Finding
from ..scanner import ScanResult
from ..status import Status


ROUTE_TOKENS = ("/stream", "/fallback-stream", "/api/nowplaying")
PROTECTED_RADIO_PATHS = ("worker.js", "public/", "workers/", "js/", "css/", ".github/workflows/")
AUDIO_OWNER_PATTERNS = (
    re.compile(r"<audio\b", re.IGNORECASE),
    re.compile(r"\bnew\s+Audio\s*\("),
    re.compile(r"\bcreateMediaElementSource\s*\("),
)


class RadioIntelligencePlugin:
    plugin_id = "radio_intelligence"
    version = "1.1.0"

    def analyse(self, scan: ScanResult) -> dict[str, Any]:
        root = Path(scan.root)
        findings: list[Finding] = []
        package_path = root / "package.json"
        package = None
        if package_path.exists():
            try:
                package = json.loads(package_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                findings.append(Finding(
                    code="RADIO_PACKAGE_INVALID",
                    message=f"package.json is not valid JSON: {type(exc).__name__}",
                    severity="HIGH",
                    status=Status.FAIL,
                    path="package.json",
                ))
        else:
            findings.append(Finding(
                code="RADIO_PACKAGE_MISSING",
                message="No package.json found; repository verification contract cannot be confirmed locally",
                severity="MEDIUM",
                status=Status.OPEN,
            ))

        if package:
            scripts = package.get("scripts", {})
            missing = [name for name in ("check", "test", "verify") if name not in scripts]
            if missing:
                findings.append(Finding(
                    code="RADIO_VERIFY_SCRIPTS_INCOMPLETE",
                    message="Missing package scripts: " + ", ".join(missing),
                    severity="HIGH",
                    status=Status.FAIL,
                    path="package.json",
                ))

        workers = scan.architecture_signals.get("workers", [])
        if not workers:
            findings.append(Finding(
                code="RADIO_WORKER_MISSING",
                message="No worker entry file detected",
                severity="HIGH",
                status=Status.FAIL,
            ))

        worker_hashes = {record.path: record.sha256 for record in scan.files if record.path in workers}
        root_worker = worker_hashes.get("worker.js")
        legacy_candidates = [path for path in workers if path != "worker.js"]
        if root_worker and legacy_candidates:
            mismatched = [path for path in legacy_candidates if worker_hashes[path] != root_worker]
            if mismatched:
                findings.append(Finding(
                    code="RADIO_WORKER_MIRROR_DRIFT",
                    message="Worker mirrors differ from root worker",
                    severity="HIGH",
                    status=Status.OPEN,
                    path=", ".join(mismatched),
                    repair_hint="Reconcile routes and runtime ownership before any replacement; do not blindly copy.",
                ))

        route_presence = {token: [] for token in ROUTE_TOKENS}
        audio_owners: list[dict[str, Any]] = []
        for record in scan.files:
            if record.kind != "text" or not record.path.endswith((".js", ".mjs", ".html")):
                continue
            path = root / record.path
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for token in ROUTE_TOKENS:
                if token in text:
                    route_presence[token].append(record.path)
            count = sum(len(pattern.findall(text)) for pattern in AUDIO_OWNER_PATTERNS)
            if count:
                audio_owners.append({"path": record.path, "signals": count})

        for token, paths in route_presence.items():
            if not paths:
                findings.append(Finding(
                    code="RADIO_ROUTE_NOT_OBSERVED",
                    message=f"Route token not observed in local evidence: {token}",
                    severity="MEDIUM",
                    status=Status.OPEN,
                ))

        secret_signals = scan.secret_signal_paths
        if secret_signals:
            findings.append(Finding(
                code="RADIO_SECRET_SIGNAL",
                message=f"Potential secret material detected in {len(secret_signals)} path(s); values remain redacted",
                severity="CRITICAL",
                status=Status.BLOCKED,
                repair_hint="Rotate exposed credentials if confirmed and move secrets to protected environment storage.",
            ))

        topology = {
            "workers": workers,
            "html_entries": scan.architecture_signals.get("html_entries", []),
            "route_presence": route_presence,
            "audio_owner_signals": audio_owners,
            "package_version": package.get("version") if package else None,
            "reference_project": "666SOUNDsDESIGn WebRadio",
            "specialization": "RADIO_REPOSITORY_CODING_AGENT",
            "protected_paths": list(PROTECTED_RADIO_PATHS),
            "codeforge_repository_root": "engineering/codeforge",
            "verify_script": (package or {}).get("scripts", {}).get("verify") if package else None,
        }
        return {
            "schema": "codeforge-radio-intelligence-v1",
            "plugin": {"id": self.plugin_id, "version": self.version},
            "topology": topology,
            "findings": [finding.to_dict() for finding in findings],
            "summary": {
                "finding_count": len(findings),
                "blocking_count": sum(1 for finding in findings if finding.status in {Status.BLOCKED, Status.FAIL}),
                "mutation_performed": False,
            },
        }
