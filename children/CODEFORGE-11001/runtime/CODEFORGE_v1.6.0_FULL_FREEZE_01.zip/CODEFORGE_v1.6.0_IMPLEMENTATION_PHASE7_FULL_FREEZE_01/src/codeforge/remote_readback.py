from __future__ import annotations

from typing import Any

from .hashchain import seal_document, verify_document
from .mock_remote import MockRemoteRepository, blob_sha256
from .remote_models import RemoteExecutionContract


class MockRemoteReadbackVerifier:
    def verify(self, *, repository: MockRemoteRepository, contract: dict[str,Any], execution_receipt: dict[str,Any])->dict[str,Any]:
        parsed=RemoteExecutionContract.from_dict(contract); reasons=[]
        if not verify_document(execution_receipt): reasons.append("EXECUTION_RECEIPT_DIGEST_MISMATCH")
        if execution_receipt.get("status")!="PASS": reasons.append("EXECUTION_NOT_COMMITTED")
        commit=execution_receipt.get("commit_sha")
        if repository.head(parsed.target_branch)!=commit: reasons.append("REMOTE_BRANCH_HEAD_MISMATCH")
        try: tree=repository.tree(parsed.target_branch)
        except KeyError: tree={}; reasons.append("REMOTE_TREE_NOT_FOUND")
        for op in parsed.operations:
            current=tree.get(op.path)
            if op.operation=="delete":
                if current is not None: reasons.append(f"DELETE_READBACK_FAILED:{op.path}")
            else:
                if current is None: reasons.append(f"CONTENT_READBACK_MISSING:{op.path}")
                elif blob_sha256(current)!=op.content_sha256: reasons.append(f"CONTENT_READBACK_SHA_MISMATCH:{op.path}")
        if tree and repository.tree_digest(parsed.target_branch)!=execution_receipt.get("tree_digest"): reasons.append("TREE_DIGEST_READBACK_MISMATCH")
        return seal_document({"schema":"codeforge-mock-remote-readback-receipt-v1","contract_id":parsed.contract_id,"target_branch":parsed.target_branch,"commit_sha":commit,"operation_count":len(parsed.operations),"status":"PASS" if not reasons else "FAIL","reasons":reasons})
