from __future__ import annotations

from pathlib import Path
from typing import Any

from ..import_gate import ImportGate
from ..models import EvidenceRecord


class EvidenceCollector:
    """Erzeugt normalisierte Evidence-Records aus geprüften lokalen Importquellen."""

    def collect_local(self, source: str | Path, *, authority_rank: int = 200) -> EvidenceRecord:
        result = ImportGate().inspect(source)
        if not result.accepted:
            raise ValueError("Import Gate rejected source: " + "; ".join(result.reasons))
        return EvidenceRecord(
            source=Path(source).name,
            source_type="verified_release",
            authority_rank=authority_rank,
            locator=result.source,
            sha256=result.sha256,
            metadata={
                "size": result.size,
                "crc": result.crc,
                "classification": result.classification,
            },
        )
