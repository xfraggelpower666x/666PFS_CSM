from __future__ import annotations
import re
from typing import Any
from .remote_models import RemoteOperationIntent
_PATTERNS={
 "GITHUB_TOKEN":re.compile(rb"(?:ghp_|github_pat_)[A-Za-z0-9_]{12,}"),
 "OPENAI_KEY":re.compile(rb"sk-[A-Za-z0-9_-]{16,}"),
 "PRIVATE_KEY":re.compile(rb"-----BEGIN " + rb"(?:RSA |EC |OPENSSH )?" + rb"PRIVATE KEY-----"),
 "CLOUDFLARE_TOKEN_ASSIGNMENT":re.compile(rb"CLOUDFLARE_(?:API_)?TOKEN\s*[:=]\s*[^\s]+",re.I),
 "DISCORD_WEBHOOK":re.compile(rb"https://(?:canary\.|ptb\.)?discord(?:app)?\.com/api/webhooks/",re.I),
}
def scan_remote_operations(operations:list[RemoteOperationIntent])->dict[str,Any]:
 findings=[]
 for op in operations:
  data=op.decoded_content()
  if data is None:continue
  for code,pattern in _PATTERNS.items():
   if pattern.search(data):findings.append({"path":op.path,"signal":code})
 return {"schema":"codeforge-remote-sensitive-guard-v1","findings":findings,"status":"PASS" if not findings else "WRITE_BLOCKED"}
