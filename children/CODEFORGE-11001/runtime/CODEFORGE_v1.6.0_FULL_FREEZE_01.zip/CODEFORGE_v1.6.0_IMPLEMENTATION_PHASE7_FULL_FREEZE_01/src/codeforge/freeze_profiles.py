from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .release_manager import DeterministicReleaseManager


@dataclass(frozen=True, slots=True)
class FreezeProfile:
    name: str
    description: str
    excludes: tuple[str, ...]
    cumulative_history: bool


RUNTIME_FREEZE = FreezeProfile(
    name="RUNTIME_FREEZE",
    description="Aktueller Code, Tests, Konfiguration und aktuelle Evidence ohne eingebettete Vorversionen.",
    excludes=(
        "__pycache__/**", "**/__pycache__/**", "*.pyc", "**/*.pyc",
        ".codeforge-workspace/**", "**/.codeforge-workspace/**",
        "HISTORY/**",
    ),
    cumulative_history=False,
)

FULL_FREEZE = FreezeProfile(
    name="FULL_FREEZE",
    description="Kumulativer Freeze einschließlich eingebetteter, verifizierter Vorversion und Receipts.",
    excludes=(
        "__pycache__/**", "**/__pycache__/**", "*.pyc", "**/*.pyc",
        ".codeforge-workspace/**", "**/.codeforge-workspace/**",
    ),
    cumulative_history=True,
)


class ClassifiedReleaseManager:
    def __init__(self):
        self.manager = DeterministicReleaseManager()

    def freeze(self, source: str | Path, archive_path: str | Path, *, root_name: str, profile: FreezeProfile) -> dict[str, Any]:
        receipt = self.manager.freeze(
            source, archive_path, root_name=root_name, excludes=profile.excludes,
            manifest_metadata={
                "classification": profile.name,
                "classification_description": profile.description,
                "cumulative_history": profile.cumulative_history,
            },
        )
        receipt.update({
            "classification": profile.name,
            "classification_description": profile.description,
            "cumulative_history": profile.cumulative_history,
        })
        return receipt
