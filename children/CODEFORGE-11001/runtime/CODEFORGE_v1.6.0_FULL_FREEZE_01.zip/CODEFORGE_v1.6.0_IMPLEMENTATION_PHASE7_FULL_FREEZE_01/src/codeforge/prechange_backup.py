from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import zipfile

from .models import stable_id, utc_now
from .verification import VerificationLayer
from .writer_models import ProposalOperation


class PreChangeBackup:
    """Backs up only the exact pre-change scope required for rollback."""

    def create(
        self,
        baseline: str | Path,
        operations: list[ProposalOperation],
        target_zip: str | Path,
        *,
        target_identity: str,
        remote_head_sha: str,
    ) -> dict[str, Any]:
        root = Path(baseline).resolve()
        target = Path(target_zip).resolve()
        if not root.is_dir():
            raise NotADirectoryError(root)
        target.parent.mkdir(parents=True, exist_ok=True)
        originals: list[dict[str, Any]] = []
        for operation in operations:
            if operation.operation not in {"update", "delete"}:
                continue
            source = root / operation.path
            if not source.is_file():
                raise FileNotFoundError(f"Pre-change source missing: {operation.path}")
            actual = VerificationLayer.sha256(source)
            if actual != operation.old_sha256:
                raise RuntimeError(f"PRE_CHANGE_HASH_MISMATCH:{operation.path}")
            originals.append({
                "path": operation.path,
                "sha256": actual,
                "size": source.stat().st_size,
                "archive_path": f"files/{operation.path}",
            })
        manifest = {
            "schema": "codeforge-pre-change-backup-v1",
            "backup_id": stable_id("BKP", {
                "target": target_identity,
                "remote_head_sha": remote_head_sha,
                "originals": originals,
            }),
            "created_at": utc_now(),
            "target": target_identity,
            "remote_head_sha": remote_head_sha,
            "originals": originals,
            "create_paths_without_original": [op.path for op in operations if op.operation == "create"],
        }
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
            for original in originals:
                archive.write(root / original["path"], original["archive_path"])
        with zipfile.ZipFile(target) as archive:
            corrupt = archive.testzip()
            names = archive.namelist()
            loaded = json.loads(archive.read("MANIFEST.json").decode("utf-8"))
        status = "PASS" if corrupt is None and loaded == manifest else "FAIL"
        return {
            "schema": "codeforge-pre-change-backup-receipt-v1",
            "backup_id": manifest["backup_id"],
            "path": str(target),
            "entries": len(names),
            "originals": len(originals),
            "crc": "PASS" if corrupt is None else f"FAIL:{corrupt}",
            "manifest_readback": "PASS" if loaded == manifest else "FAIL",
            "sha256": VerificationLayer.sha256(target),
            "status": status,
        }
