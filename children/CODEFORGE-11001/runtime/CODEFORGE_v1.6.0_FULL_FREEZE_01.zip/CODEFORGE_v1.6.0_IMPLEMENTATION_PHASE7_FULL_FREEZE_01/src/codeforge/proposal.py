from __future__ import annotations

from pathlib import Path
from typing import Any

from .governance import MutationGate
from .locks import RepositoryLockManager
from .prechange_backup import PreChangeBackup
from .rollback import RollbackPlanBuilder
from .scope_diff import ScopeDiffEngine
from .sensitive_guard import ChangedFileSecretGuard
from .storage import AtomicJsonStore
from .targets import AllowlistPolicy, RemoteHeadClaim, RepositoryTarget
from .writer_models import ChangeProposal, ProposalPrerequisites


class ProposalBlocked(RuntimeError):
    def __init__(self, code: str, receipt: dict[str, Any]):
        super().__init__(code)
        self.code = code
        self.receipt = receipt


class DryRunProposalEngine:
    """Phase-2 writer design: verified proposal output, zero repository mutation."""

    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self.locks = RepositoryLockManager(self.workspace / "locks")

    def prepare(
        self,
        baseline: str | Path,
        candidate: str | Path,
        *,
        target: RepositoryTarget,
        remote_head: RemoteHeadClaim,
        policy: AllowlistPolicy,
        owner: str,
        prerequisites: ProposalPrerequisites,
        ignore: tuple[str, ...] | None = None,
    ) -> dict[str, Any]:
        prerequisite_receipt = prerequisites.validate()
        if prerequisite_receipt["status"] != "PASS":
            raise ProposalBlocked("PREREQUISITES_BLOCKED", prerequisite_receipt)

        head_receipt = remote_head.validate()
        if head_receipt["status"] != "PASS":
            raise ProposalBlocked("REMOTE_HEAD_GATE_BLOCKED", head_receipt)

        lock = self.locks.acquire(target, owner)
        lock_receipt = lock.to_dict()
        if not lock.acquired or not lock.token:
            raise ProposalBlocked("REPOSITORY_LOCK_BLOCKED", lock_receipt)

        release_receipt: dict[str, Any] | None = None
        try:
            engine = ScopeDiffEngine(ignore=ignore or ScopeDiffEngine.DEFAULT_IGNORES)
            operations = engine.compare(baseline, candidate)
            if not operations:
                raise ProposalBlocked("NO_CHANGES", {"status": "OPEN", "operations": 0})

            policy_receipts = [policy.evaluate(target, item.path, item.operation) for item in operations]
            blocked_policy = [item for item in policy_receipts if not item["allowed"]]
            if blocked_policy:
                raise ProposalBlocked("ALLOWLIST_BLOCKED", {
                    "status": "WRITE_BLOCKED", "blocked": blocked_policy, "checked": len(policy_receipts)
                })

            secret_receipt = ChangedFileSecretGuard().inspect(candidate, operations)
            if secret_receipt["status"] != "PASS":
                raise ProposalBlocked("SECRET_GUARD_BLOCKED", secret_receipt)

            scope_id = "-".join([target.repository.replace("/", "_"), remote_head.observed_sha[:12]])
            backup_path = self.workspace / "backups" / f"PRE_CHANGE_{scope_id}.zip"
            backup_receipt = PreChangeBackup().create(
                baseline,
                operations,
                backup_path,
                target_identity=target.identity,
                remote_head_sha=remote_head.observed_sha,
            )
            if backup_receipt["status"] != "PASS":
                raise ProposalBlocked("PRE_CHANGE_BACKUP_FAILED", backup_receipt)

            claims = {
                "evidence_complete", "reconciliation_complete", "repair_plan_complete",
                "pre_change_backup_complete", "target_allowlisted", "branch_allowlisted",
                "scope_allowlisted", "lock_clear", "remote_head_match",
            }
            gate = MutationGate().evaluate(claims, phase=2, operation="proposal")
            gate_receipt = {
                "allowed": gate.allowed,
                "status": gate.status.value,
                "reasons": gate.reasons,
                "operation": "proposal",
            }
            if not gate.allowed:
                raise ProposalBlocked("PROPOSAL_GATE_BLOCKED", gate_receipt)

            rollback = RollbackPlanBuilder().build(operations, backup_receipt)
            proposal = ChangeProposal(
                target=target,
                remote_head_sha=remote_head.observed_sha,
                operations=operations,
                policy_fingerprint=policy.fingerprint(),
                backup_receipt=backup_receipt,
                lock_receipt=lock_receipt,
                gate_receipt=gate_receipt,
                rollback_plan=rollback,
                prerequisites=prerequisite_receipt,
                remote_head_gate=head_receipt,
                allowlist_receipts=policy_receipts,
                sensitive_guard=secret_receipt,
            ).seal()
            document = proposal.to_dict()
            output = self.workspace / "proposals" / f"{proposal.proposal_id}.json"
            AtomicJsonStore(output).write(document)
            document["proposal_path"] = str(output)
            return document
        finally:
            release_receipt = self.locks.release(target, lock.token)
            # Release is recorded separately so the sealed proposal remains immutable.
            if release_receipt.get("released"):
                AtomicJsonStore(self.workspace / "locks" / "last-release.json").write(release_receipt)
