from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any
import hashlib
import json

from .models import stable_id, utc_now
from .targets import RepositoryTarget


@dataclass(slots=True)
class ProposalOperation:
    operation: str
    path: str
    old_sha256: str | None
    new_sha256: str | None
    old_size: int | None
    new_size: int | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ProposalPrerequisites:
    evidence: dict[str, Any]
    reconciliation: dict[str, Any]
    repair_plan: dict[str, Any]

    def validate(self) -> dict[str, Any]:
        sections = {
            "evidence": self.evidence,
            "reconciliation": self.reconciliation,
            "repair_plan": self.repair_plan,
        }
        invalid: list[dict[str, Any]] = []
        accepted = {"PASS", "VERIFIED"}
        for name, receipt in sections.items():
            status = str(receipt.get("status", "")) if isinstance(receipt, dict) else ""
            evidence_ids = receipt.get("evidence_ids", []) if isinstance(receipt, dict) else []
            if status not in accepted:
                invalid.append({"section": name, "reason": "STATUS_NOT_VERIFIED", "status": status})
            if not evidence_ids:
                invalid.append({"section": name, "reason": "EVIDENCE_IDS_MISSING"})
        return {
            "schema": "codeforge-proposal-prerequisites-v1",
            "sections": sections,
            "status": "PASS" if not invalid else "BLOCKED",
            "invalid": invalid,
        }


def _lock_summary(receipt: dict[str, Any]) -> dict[str, Any]:
    return {
        key: receipt.get(key)
        for key in ("acquired", "status", "target", "owner", "reasons", "acquired_at", "expires_at")
    }


def _backup_summary(receipt: dict[str, Any]) -> dict[str, Any]:
    return {
        key: receipt.get(key)
        for key in ("backup_id", "entries", "originals", "crc", "manifest_readback", "sha256", "status")
    }


def proposal_core_material(document: dict[str, Any]) -> dict[str, Any]:
    return {
        "target": document.get("target"),
        "remote_head_sha": document.get("remote_head_sha"),
        "operations": document.get("operations", []),
        "policy_fingerprint": document.get("policy_fingerprint"),
        "backup_receipt": _backup_summary(document.get("backup_receipt", {})),
        "lock_receipt": _lock_summary(document.get("lock_receipt", {})),
        "gate_receipt": document.get("gate_receipt", {}),
        "rollback_plan": document.get("rollback_plan", {}),
        "prerequisites": document.get("prerequisites", {}),
        "remote_head_gate": document.get("remote_head_gate", {}),
        "allowlist_receipts": document.get("allowlist_receipts", []),
        "sensitive_guard": document.get("sensitive_guard", {}),
        "created_at": document.get("created_at"),
        "state": document.get("state"),
        "execution_allowed": document.get("execution_allowed"),
        "mutation_performed": document.get("mutation_performed"),
    }


def proposal_digest(document: dict[str, Any], proposal_id: str) -> str:
    material = proposal_core_material(document)
    material["proposal_id"] = proposal_id
    return hashlib.sha256(
        json.dumps(material, sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()


@dataclass(slots=True)
class ChangeProposal:
    target: RepositoryTarget
    remote_head_sha: str
    operations: list[ProposalOperation]
    policy_fingerprint: str
    backup_receipt: dict[str, Any]
    lock_receipt: dict[str, Any]
    gate_receipt: dict[str, Any]
    rollback_plan: dict[str, Any]
    prerequisites: dict[str, Any]
    remote_head_gate: dict[str, Any]
    allowlist_receipts: list[dict[str, Any]]
    sensitive_guard: dict[str, Any]
    created_at: str = field(default_factory=utc_now)
    proposal_id: str = ""
    digest: str = ""
    state: str = "DRY_RUN_VERIFIED"
    execution_allowed: bool = False
    mutation_performed: bool = False

    def _document_without_integrity(self) -> dict[str, Any]:
        return {
            "schema": "codeforge-change-proposal-v1",
            "target": self.target.to_dict(),
            "remote_head_sha": self.remote_head_sha,
            "operations": [item.to_dict() for item in self.operations],
            "policy_fingerprint": self.policy_fingerprint,
            "backup_receipt": self.backup_receipt,
            "lock_receipt": self.lock_receipt,
            "gate_receipt": self.gate_receipt,
            "rollback_plan": self.rollback_plan,
            "prerequisites": self.prerequisites,
            "remote_head_gate": self.remote_head_gate,
            "allowlist_receipts": self.allowlist_receipts,
            "sensitive_guard": self.sensitive_guard,
            "created_at": self.created_at,
            "state": self.state,
            "execution_allowed": self.execution_allowed,
            "mutation_performed": self.mutation_performed,
        }

    def seal(self) -> "ChangeProposal":
        document = self._document_without_integrity()
        if not self.proposal_id:
            self.proposal_id = stable_id("PRP", proposal_core_material(document))
        self.digest = proposal_digest(document, self.proposal_id)
        return self

    def to_dict(self) -> dict[str, Any]:
        if not self.digest:
            self.seal()
        document = self._document_without_integrity()
        document["proposal_id"] = self.proposal_id
        document["digest"] = self.digest
        return document
