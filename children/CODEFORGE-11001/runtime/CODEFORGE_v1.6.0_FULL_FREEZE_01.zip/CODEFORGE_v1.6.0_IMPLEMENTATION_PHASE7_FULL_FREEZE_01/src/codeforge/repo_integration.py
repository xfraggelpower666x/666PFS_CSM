from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from .models import utc_now
from .storage import AtomicJsonStore


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_digest(payload: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


@dataclass(frozen=True, slots=True)
class RepositoryIntegrationPolicy:
    repository: str
    branch: str
    root: str = "engineering/codeforge"
    production_branch: str = "WebRadio-666SOUNDsDESIGn"

    def validate(self) -> None:
        root = PurePosixPath(self.root)
        if root.is_absolute() or ".." in root.parts or str(root) != "engineering/codeforge":
            raise ValueError("CodeForge repository root must be exactly engineering/codeforge")
        if self.branch == self.production_branch:
            raise ValueError("CodeForge integration must use an isolated branch")


class RepositorySnapshotBuilder:
    def __init__(self, policy: RepositoryIntegrationPolicy):
        policy.validate()
        self.policy = policy

    def _validate_rel(self, rel: str) -> str:
        path = PurePosixPath(rel)
        if path.is_absolute() or ".." in path.parts or not path.parts:
            raise ValueError(f"Unsafe repository path: {rel}")
        full = PurePosixPath(self.policy.root) / path
        if not str(full).startswith("engineering/codeforge/"):
            raise ValueError(f"Path escapes CodeForge root: {rel}")
        return full.as_posix()

    def build_manifest(self, files: dict[str, Path], *, version: str, checkpoint: str, continuation_state: dict[str, Any]) -> dict[str, Any]:
        entries = []
        for rel, source in sorted(files.items()):
            repo_path = self._validate_rel(rel)
            if not source.is_file():
                raise FileNotFoundError(source)
            entries.append({
                "repository_path": repo_path,
                "source_name": source.name,
                "size": source.stat().st_size,
                "sha256": sha256_file(source),
            })
        manifest = {
            "schema": "codeforge-radio-repository-integration-v1",
            "framework_identity": "CODEFORGE-UNIVERSAL-CODING-AGENT",
            "radio_specialization": "plugins/radio_intelligence",
            "repository": self.policy.repository,
            "branch": self.policy.branch,
            "production_branch": self.policy.production_branch,
            "root": self.policy.root,
            "version": version,
            "checkpoint": checkpoint,
            "continuation_state_digest": continuation_state["digest"],
            "files": entries,
            "guards": {
                "production_branch_write": False,
                "cloudflare_deploy_trigger": False,
                "radio_runtime_mutation": False,
                "allowed_repository_prefix": "engineering/codeforge/",
            },
            "created_at": utc_now(),
        }
        manifest["digest"] = canonical_digest(manifest)
        return manifest

    @staticmethod
    def verify_manifest(manifest: dict[str, Any], materialized_root: Path) -> dict[str, Any]:
        material = {k: v for k, v in manifest.items() if k != "digest"}
        if manifest.get("digest") != canonical_digest(material):
            raise RuntimeError("Repository integration manifest digest mismatch")
        failures = []
        for entry in manifest["files"]:
            path = materialized_root / entry["repository_path"]
            if not path.is_file():
                failures.append({"path": entry["repository_path"], "reason": "MISSING"})
                continue
            if path.stat().st_size != entry["size"] or sha256_file(path) != entry["sha256"]:
                failures.append({"path": entry["repository_path"], "reason": "DIGEST_MISMATCH"})
        return {"status": "PASS" if not failures else "FAIL", "failures": failures, "checked": len(manifest["files"])}

    def materialize(self, destination: Path, files: dict[str, Path], manifest: dict[str, Any], continuation_state: dict[str, Any]) -> Path:
        root = destination / self.policy.root
        root.mkdir(parents=True, exist_ok=True)
        for rel, source in files.items():
            target = destination / self._validate_rel(rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        AtomicJsonStore(root / "CONTINUATION_STATE.json").write(continuation_state)
        AtomicJsonStore(root / "INTEGRATION_MANIFEST.json").write(manifest)
        pointer = {
            "schema": "codeforge-radio-repository-pointer-v1",
            "version": manifest["version"],
            "checkpoint": manifest["checkpoint"],
            "runtime_release": next(e["repository_path"] for e in manifest["files"] if e["repository_path"].endswith(".zip")),
            "manifest_digest": manifest["digest"],
            "continuation_state_digest": continuation_state["digest"],
            "status": "CANDIDATE_BRANCH_ONLY",
        }
        pointer["digest"] = canonical_digest(pointer)
        AtomicJsonStore(root / "CURRENT.json").write(pointer)
        return root
