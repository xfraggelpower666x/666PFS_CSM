from __future__ import annotations

from pathlib import Path
from typing import Any

from .models import Decision, EvidenceRecord, Finding, utc_now
from .storage import AtomicJsonStore, JsonlLedger


class ProjectIntelligenceDatabase:
    AREAS = (
        "knowledge", "evidence", "decisions", "timeline", "bugs", "patches",
        "reports", "roadmap", "architecture", "project_graph",
    )

    def __init__(self, root: str | Path):
        self.root = Path(root)

    def initialize(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        for area in self.AREAS:
            (self.root / area).mkdir(exist_ok=True)
        manifest = AtomicJsonStore(self.root / "manifest.json")
        if not manifest.path.exists():
            manifest.write({
                "schema": "codeforge-pidb-v1",
                "created_at": utc_now(),
                "areas": list(self.AREAS),
                "authority_order": [
                    "github_repository", "live_readback", "verified_release", "handoff_report"
                ],
            })

    def append_evidence(self, record: EvidenceRecord) -> None:
        self.initialize()
        JsonlLedger(self.root / "evidence" / "records.jsonl").append(record.to_dict())

    def append_decision(self, decision: Decision) -> None:
        self.initialize()
        JsonlLedger(self.root / "decisions" / "records.jsonl").append(decision.to_dict())

    def append_finding(self, finding: Finding) -> None:
        self.initialize()
        JsonlLedger(self.root / "bugs" / "findings.jsonl").append(finding.to_dict())

    def append_timeline(self, event: str, payload: dict[str, Any]) -> None:
        self.initialize()
        JsonlLedger(self.root / "timeline" / "events.jsonl").append({
            "at": utc_now(), "event": event, "payload": payload,
        })

    def write_report(self, name: str, report: dict[str, Any]) -> Path:
        self.initialize()
        path = self.root / "reports" / f"{name}.json"
        AtomicJsonStore(path).write(report)
        return path
