from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

_BRANCH_RE = re.compile(r"^(?!/)(?!.*//)(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._/-]{1,160}$")


@dataclass(frozen=True, slots=True)
class BranchIsolationPolicy:
    allowed_prefixes: tuple[str, ...] = ("codeforge/",)
    protected_branches: tuple[str, ...] = ("main", "master", "production", "WebRadio-666SOUNDsDESIGn")

    def evaluate(self, *, base_branch: str, target_branch: str, default_branch: str, target_branch_exists: bool) -> dict[str, Any]:
        reasons: list[str] = []
        if not _BRANCH_RE.fullmatch(target_branch):
            reasons.append("INVALID_TARGET_BRANCH")
        if target_branch == base_branch:
            reasons.append("TARGET_BRANCH_EQUALS_BASE")
        if target_branch == default_branch:
            reasons.append("DIRECT_DEFAULT_BRANCH_WRITE_FORBIDDEN")
        if target_branch in self.protected_branches:
            reasons.append("PROTECTED_BRANCH_WRITE_FORBIDDEN")
        if not any(target_branch.startswith(prefix) for prefix in self.allowed_prefixes):
            reasons.append("ISOLATED_BRANCH_PREFIX_REQUIRED")
        if target_branch_exists:
            reasons.append("TARGET_BRANCH_MUST_BE_NEW")
        return {
            "schema": "codeforge-branch-isolation-receipt-v1",
            "base_branch": base_branch,
            "target_branch": target_branch,
            "default_branch": default_branch,
            "target_branch_exists": target_branch_exists,
            "status": "PASS" if not reasons else "WRITE_BLOCKED",
            "reasons": reasons,
        }
