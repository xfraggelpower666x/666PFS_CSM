from __future__ import annotations

from typing import Any

from .writer_models import ProposalOperation


class RollbackPlanBuilder:
    """Builds an inverse plan only; Phase 2 never executes it."""

    def build(self, operations: list[ProposalOperation], backup_receipt: dict[str, Any]) -> dict[str, Any]:
        inverse: list[dict[str, Any]] = []
        for operation in reversed(operations):
            if operation.operation == "create":
                inverse.append({
                    "operation": "delete",
                    "path": operation.path,
                    "expected_current_sha256": operation.new_sha256,
                })
            elif operation.operation == "update":
                inverse.append({
                    "operation": "restore",
                    "path": operation.path,
                    "expected_current_sha256": operation.new_sha256,
                    "restore_sha256": operation.old_sha256,
                    "archive_path": f"files/{operation.path}",
                })
            elif operation.operation == "delete":
                inverse.append({
                    "operation": "restore",
                    "path": operation.path,
                    "expected_current_sha256": None,
                    "restore_sha256": operation.old_sha256,
                    "archive_path": f"files/{operation.path}",
                })
        return {
            "schema": "codeforge-rollback-plan-v1",
            "backup_id": backup_receipt.get("backup_id"),
            "backup_sha256": backup_receipt.get("sha256"),
            "operations": inverse,
            "execution_allowed": False,
            "state": "PROPOSED_ONLY",
        }
