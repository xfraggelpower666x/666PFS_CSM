from __future__ import annotations

from pathlib import Path
from typing import Any
import json

from .scanner import RepositoryScanner
from .storage import AtomicJsonStore


class IncrementalInventory:
    def __init__(self, cache_file: str | Path):
        self.store = AtomicJsonStore(cache_file)

    def scan(self, root: str | Path) -> dict[str, Any]:
        current = RepositoryScanner().scan(root).to_dict()
        previous = self.store.read({"files": []})
        old = {item["path"]: item for item in previous.get("files", [])}
        new = {item["path"]: item for item in current.get("files", [])}
        created = sorted(set(new) - set(old))
        deleted = sorted(set(old) - set(new))
        updated = sorted(path for path in set(old) & set(new) if old[path]["sha256"] != new[path]["sha256"])
        receipt = {
            "schema": "codeforge-incremental-inventory-v1",
            "root": current["root"],
            "created": created,
            "updated": updated,
            "deleted": deleted,
            "unchanged": len(set(old) & set(new)) - len(updated),
            "current_file_count": current["file_count"],
            "status": "PASS",
        }
        self.store.write(current)
        return receipt
