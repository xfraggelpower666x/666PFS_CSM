from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
import json
import uuid

from .hashchain import seal_document, verify_document
from .models import stable_id, utc_now
from .remote_models import RemoteExecutionContract
from .storage import AtomicJsonStore


class RemoteAuthorizationBlocked(RuntimeError):
    def __init__(self, code: str, receipt: dict[str, Any]):
        super().__init__(code); self.code = code; self.receipt = receipt


def expected_remote_authorization_phrase(contract: dict[str, Any] | RemoteExecutionContract) -> str:
    document = contract.to_dict() if isinstance(contract, RemoteExecutionContract) else contract
    return f"AUTHORIZE MOCK REMOTE {document.get('contract_id')} {str(document.get('digest', ''))[:16]}"


class RemoteExecutionAuthorizationRegistry:
    def __init__(self, root: str | Path): self.root = Path(root)
    def _path(self, authorization_id: str) -> Path: return self.root / f"{authorization_id}.json"

    def issue(self, contract: dict[str, Any] | RemoteExecutionContract, *, phrase: str, issued_by: str, ttl_seconds: int = 600) -> dict[str, Any]:
        document = contract.to_dict() if isinstance(contract, RemoteExecutionContract) else dict(contract)
        parsed = RemoteExecutionContract.from_dict(document)
        validation = parsed.validate()
        if validation["status"] != "PASS": raise RemoteAuthorizationBlocked("REMOTE_CONTRACT_INVALID", validation)
        if parsed.provider != "mock_github" or parsed.execution_mode != "MOCK_ONLY":
            raise RemoteAuthorizationBlocked("REAL_REMOTE_AUTHORIZATION_FORBIDDEN", {"status": "WRITE_BLOCKED", "provider": parsed.provider})
        if phrase != expected_remote_authorization_phrase(document):
            raise RemoteAuthorizationBlocked("REMOTE_AUTHORIZATION_PHRASE_MISMATCH", {"status": "WRITE_BLOCKED", "contract_id": parsed.contract_id})
        if ttl_seconds < 30 or ttl_seconds > 1800: raise ValueError("ttl_seconds must be between 30 and 1800")
        self.root.mkdir(parents=True, exist_ok=True)
        now = datetime.now(timezone.utc).replace(microsecond=0)
        authorization_id = stable_id("RAU", {"contract_id": parsed.contract_id, "digest": parsed.digest, "issued_by": issued_by, "nonce": uuid.uuid4().hex})
        receipt = seal_document({
            "schema": "codeforge-remote-execution-authorization-v1",
            "authorization_id": authorization_id,
            "contract_id": parsed.contract_id,
            "contract_digest": parsed.digest,
            "provider": parsed.provider,
            "repository": parsed.repository,
            "target_branch": parsed.target_branch,
            "issued_by": issued_by,
            "issued_at": now.isoformat(),
            "expires_at": (now + timedelta(seconds=ttl_seconds)).isoformat(),
            "single_use": True,
            "consumed": False,
            "consumed_at": None,
            "status": "PASS",
        })
        AtomicJsonStore(self._path(authorization_id)).write(receipt)
        return receipt

    def inspect(self, authorization_id: str) -> dict[str, Any]:
        path = self._path(authorization_id)
        if not path.is_file(): return {"status": "WRITE_BLOCKED", "reasons": ["REMOTE_AUTHORIZATION_NOT_FOUND"]}
        receipt = json.loads(path.read_text(encoding="utf-8")); reasons=[]
        if not verify_document(receipt): reasons.append("REMOTE_AUTHORIZATION_DIGEST_MISMATCH")
        try:
            if datetime.fromisoformat(str(receipt.get("expires_at"))) <= datetime.now(timezone.utc): reasons.append("REMOTE_AUTHORIZATION_EXPIRED")
        except (TypeError, ValueError): reasons.append("REMOTE_AUTHORIZATION_EXPIRY_INVALID")
        if receipt.get("consumed"): reasons.append("REMOTE_AUTHORIZATION_ALREADY_CONSUMED")
        return {"schema": "codeforge-remote-authorization-inspection-v1", "authorization": receipt, "status": "PASS" if not reasons else "WRITE_BLOCKED", "reasons": reasons}

    def consume(self, authorization_id: str, contract: dict[str, Any]) -> dict[str, Any]:
        inspection = self.inspect(authorization_id)
        if inspection["status"] != "PASS": raise RemoteAuthorizationBlocked("REMOTE_AUTHORIZATION_NOT_USABLE", inspection)
        receipt=inspection["authorization"]
        if receipt.get("contract_id") != contract.get("contract_id") or receipt.get("contract_digest") != contract.get("digest"):
            raise RemoteAuthorizationBlocked("REMOTE_AUTHORIZATION_CONTRACT_MISMATCH", {"status":"WRITE_BLOCKED"})
        updated=dict(receipt); updated["consumed"]=True; updated["consumed_at"]=utc_now(); updated["status"]="CONSUMED"; updated=seal_document(updated)
        AtomicJsonStore(self._path(authorization_id)).write(updated)
        return {"schema":"codeforge-remote-authorization-consumption-v1","authorization_id":authorization_id,"contract_id":contract.get("contract_id"),"status":"PASS","consumed_at":updated["consumed_at"]}
