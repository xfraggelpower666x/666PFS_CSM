from __future__ import annotations

from pathlib import Path
from typing import Any

from .hashchain import seal_document
from .idempotency import IdempotencyRegistry
from .mock_remote import MockRemoteRepository
from .remote_authorization import RemoteExecutionAuthorizationRegistry, RemoteAuthorizationBlocked
from .remote_gate import RemoteExecutionGate
from .remote_journal import RemoteExecutionJournal
from .remote_readback import MockRemoteReadbackVerifier


class RemoteMockOrchestrator:
    def __init__(self,workspace:str|Path):
        self.workspace=Path(workspace); self.auth=RemoteExecutionAuthorizationRegistry(self.workspace/"remote-authorizations"); self.idempotency=IdempotencyRegistry(self.workspace/"idempotency")
    def execute(self, *, repository:MockRemoteRepository, contract:dict[str,Any], authorization_id:str, capability:dict[str,Any], lock:dict[str,Any], allowlist_receipts:list[dict[str,Any]], runtime_config:dict[str,Any], inject_failure:str|None=None)->dict[str,Any]:
        journal=RemoteExecutionJournal(self.workspace/"remote-transactions"/str(contract.get("contract_id"))/"journal.jsonl")
        journal.append("PREPARED",{"contract_id":contract.get("contract_id")})
        inspection=self.auth.inspect(authorization_id)
        if inspection.get("status")!="PASS": return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","status":"WRITE_BLOCKED","mutation_performed":False,"reasons":inspection.get("reasons",[]),"journal":journal.verify()})
        reservation=self.idempotency.reserve(contract); journal.append("IDEMPOTENCY",reservation)
        gate=RemoteExecutionGate().evaluate(contract=contract,authorization=inspection["authorization"],capability=capability,lock=lock,default_branch=repository.default_branch,observed_base_head_sha=str(repository.head(str(contract.get("base_branch"))) or ""),target_branch_exists=repository.branch_exists(str(contract.get("target_branch"))),allowlist_receipts=allowlist_receipts,idempotency_reservation=reservation,runtime_config=runtime_config)
        journal.append("GATE",gate)
        if gate["status"]!="PASS":
            if reservation.get("status")=="PASS":self.idempotency.release(reservation["key"],"GATE_BLOCKED")
            return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","contract_id":contract.get("contract_id"),"status":"WRITE_BLOCKED","mutation_performed":False,"reasons":gate["reasons"],"gate":gate,"journal":journal.verify()})
        try: consumption=self.auth.consume(authorization_id,contract)
        except RemoteAuthorizationBlocked as exc:
            self.idempotency.release(reservation["key"],exc.code); return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","status":"WRITE_BLOCKED","mutation_performed":False,"reasons":[exc.code],"journal":journal.verify()})
        journal.append("AUTHORIZED",consumption)
        ref_snapshot=repository.snapshot_ref(str(contract.get("target_branch")))
        execution=repository.execute_contract(contract,inject_failure=inject_failure); journal.append("EXECUTED",execution)
        if execution.get("status")!="PASS":
            self.idempotency.release(reservation["key"],str(execution.get("reason","EXECUTION_FAILED"))); journal.append("ROLLED_BACK",execution)
            return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","contract_id":contract.get("contract_id"),"status":"ROLLED_BACK","mutation_performed":False,"execution":execution,"journal":journal.verify()})
        readback=MockRemoteReadbackVerifier().verify(repository=repository,contract=contract,execution_receipt=execution); journal.append("READBACK",readback)
        if readback["status"]!="PASS":
            repository.restore_ref(ref_snapshot)
            self.idempotency.release(reservation["key"],"READBACK_FAILED")
            return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","contract_id":contract.get("contract_id"),"status":"FAIL","mutation_performed":True,"execution":execution,"readback":readback,"journal":journal.verify()})
        commit=self.idempotency.commit(reservation["key"],execution)
        if commit.get("status") != "PASS":
            repository.restore_ref(ref_snapshot)
            journal.append("ROLLED_BACK", {"reason": "IDEMPOTENCY_COMMIT_FAILED"})
            return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","contract_id":contract.get("contract_id"),"status":"ROLLED_BACK","mutation_performed":False,"execution":execution,"readback":readback,"idempotency":commit,"journal":journal.verify()})
        journal.append("COMMITTED",commit)
        verification=journal.verify()
        return seal_document({"schema":"codeforge-remote-orchestration-receipt-v1","contract_id":contract.get("contract_id"),"status":"PASS","mutation_performed":True,"execution":execution,"readback":readback,"idempotency":commit,"journal":verification})
