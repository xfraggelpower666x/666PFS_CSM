from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .connector_models import ConnectorHeadReceipt, ConnectorSessionReceipt


def issue_connector_session_receipt(
    *,
    provider: str,
    connector_instance_id: str,
    principal: str,
    repositories: list[str],
    permissions: list[str],
    methods: list[str],
    evidence_id: str,
    ttl_seconds: int = 300,
) -> dict[str, Any]:
    if ttl_seconds < 30 or ttl_seconds > 1800:
        raise ValueError("ttl_seconds must be between 30 and 1800")
    now = datetime.now(timezone.utc).replace(microsecond=0)
    return ConnectorSessionReceipt(
        provider=provider,
        connector_instance_id=connector_instance_id,
        principal=principal,
        repositories=repositories,
        permissions=permissions,
        methods=methods,
        evidence_id=evidence_id,
        issued_at=now.isoformat(),
        expires_at=(now + timedelta(seconds=ttl_seconds)).isoformat(),
    ).seal().to_dict()


def issue_connector_head_receipt(
    *,
    provider: str,
    connector_session_id: str,
    repository: str,
    branch: str,
    head_sha: str,
    evidence_id: str,
    observed_at: str | None = None,
) -> dict[str, Any]:
    return ConnectorHeadReceipt(
        provider=provider,
        connector_session_id=connector_session_id,
        repository=repository,
        branch=branch,
        head_sha=head_sha,
        evidence_id=evidence_id,
        observed_at=observed_at or datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    ).seal().to_dict()
