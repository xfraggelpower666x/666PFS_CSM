from __future__ import annotations

from pathlib import Path
from typing import Any

from .models import Checkpoint, EvidenceRecord
from .pidb import ProjectIntelligenceDatabase
from .project_graph import ProjectGraphBuilder
from .reconciliation import ReconciliationEngine
from .scanner import RepositoryScanner
from .plugins.radio_intelligence import RadioIntelligencePlugin
from .storage import AtomicJsonStore


class EngineeringKernel:
    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self.pidb = ProjectIntelligenceDatabase(self.workspace / "pidb")

    def audit_local_repository(self, repository: str | Path, *, radio: bool = False) -> dict[str, Any]:
        scanner = RepositoryScanner()
        scan = scanner.scan(repository)
        scan_path = self.workspace / "artifacts" / "repository-scan.json"
        AtomicJsonStore(scan_path).write(scan.to_dict())

        evidence = EvidenceRecord(
            source=str(Path(repository).resolve()),
            source_type="verified_release",
            authority_rank=200,
            locator=str(Path(repository).resolve()),
            sha256=None,
            metadata={"file_count": scan.file_count, "total_bytes": scan.total_bytes},
        )
        self.pidb.append_evidence(evidence)

        graph = ProjectGraphBuilder().build(scan)
        graph_path = self.workspace / "pidb" / "project_graph" / "current.json"
        AtomicJsonStore(graph_path).write(graph)

        plugin_report = None
        if radio:
            plugin_report = RadioIntelligencePlugin().analyse(scan)
            self.pidb.write_report("radio-intelligence", plugin_report)

        reconciliation = ReconciliationEngine().reconcile([
            {
                "source": evidence.source,
                "source_type": evidence.source_type,
                "sha256": evidence.sha256,
                "observed_at": evidence.collected_at,
            }
        ])
        report = {
            "pipeline": ["analysis", "evidence", "reconciliation", "repair_plan", "re_audit", "checkpoint"],
            "scan": {"path": str(scan_path), "file_count": scan.file_count, "total_bytes": scan.total_bytes},
            "graph": {"path": str(graph_path), "nodes": graph["node_count"], "edges": graph["edge_count"]},
            "reconciliation": reconciliation.to_dict(),
            "radio": plugin_report,
            "repair_plan": {
                "status": "PROPOSED_ONLY",
                "mutation_performed": False,
                "rule": "No direct change; every finding requires targeted evidence and re-audit",
            },
        }
        self.pidb.write_report("local-audit", report)
        return report
