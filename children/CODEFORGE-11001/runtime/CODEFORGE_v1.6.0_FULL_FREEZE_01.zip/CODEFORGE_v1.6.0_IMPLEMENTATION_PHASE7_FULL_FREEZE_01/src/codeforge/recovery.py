from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from .models import utc_now
from .verification import VerificationLayer


class RecoveryPipeline:
    """Erzeugt verifizierte Workspace-Sicherungen; Projekt-Repositories bleiben unberührt."""

    def create_workspace_backup(self, workspace: str | Path, target_zip: str | Path) -> dict[str, Any]:
        workspace_path = Path(workspace).resolve()
        target = Path(target_zip).resolve()
        if not workspace_path.is_dir():
            raise NotADirectoryError(workspace_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(workspace_path.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(workspace_path).as_posix())
        with zipfile.ZipFile(target) as archive:
            corrupt = archive.testzip()
            entries = len(archive.infolist())
        sha256 = VerificationLayer.sha256(target)
        return {
            "created_at": utc_now(),
            "workspace": str(workspace_path),
            "target": str(target),
            "entries": entries,
            "crc": "PASS" if corrupt is None else f"FAIL:{corrupt}",
            "sha256": sha256,
            "status": "PASS" if corrupt is None else "FAIL",
        }

    def inspect_backup(self, source_zip: str | Path) -> dict[str, Any]:
        source = Path(source_zip).resolve()
        with zipfile.ZipFile(source) as archive:
            corrupt = archive.testzip()
            names = archive.namelist()
        return {
            "source": str(source),
            "entries": len(names),
            "crc": "PASS" if corrupt is None else f"FAIL:{corrupt}",
            "sha256": VerificationLayer.sha256(source),
            "status": "PASS" if corrupt is None else "FAIL",
        }
