from __future__ import annotations

import hashlib
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from .hashchain import digest_document, seal_document
from .remote_models import RemoteExecutionContract
from .targets import normalize_relative_path


def blob_sha256(data: bytes) -> str: return hashlib.sha256(data).hexdigest()

def _commit_sha(parent: str, tree_digest: str, message: str) -> str:
    return hashlib.sha1(f"{parent}\n{tree_digest}\n{message}".encode("utf-8")).hexdigest()


@dataclass(slots=True)
class RefSnapshot:
    branch: str
    existed: bool
    head: str | None


class MockRemoteRepository:
    """Deterministic in-memory remote used only to verify adapter contracts."""
    provider_name = "mock_github"

    def __init__(self, repository: str, default_branch: str = "main"):
        self.repository=repository; self.default_branch=default_branch; self.refs:dict[str,str]={}; self.trees:dict[str,dict[str,bytes]]={}; self.parents:dict[str,str|None]={}

    def seed(self, files: dict[str, bytes], *, branch: str | None = None) -> str:
        branch=branch or self.default_branch; tree={normalize_relative_path(k):bytes(v) for k,v in files.items()}; tree_digest=self.tree_digest_from(tree); commit=_commit_sha("0"*40,tree_digest,"seed"); self.trees[commit]=tree; self.parents[commit]=None; self.refs[branch]=commit; return commit
    def head(self,branch:str)->str|None:return self.refs.get(branch)
    def branch_exists(self,branch:str)->bool:return branch in self.refs
    def tree(self,branch_or_commit:str)->dict[str,bytes]:
        commit=self.refs.get(branch_or_commit,branch_or_commit)
        if commit not in self.trees: raise KeyError(f"TREE_NOT_FOUND:{branch_or_commit}")
        return deepcopy(self.trees[commit])
    @staticmethod
    def tree_digest_from(tree:dict[str,bytes])->str:
        return digest_document({path:blob_sha256(data) for path,data in sorted(tree.items())})
    def tree_digest(self,branch_or_commit:str)->str:return self.tree_digest_from(self.tree(branch_or_commit))
    def snapshot_ref(self,branch:str)->RefSnapshot:return RefSnapshot(branch,branch in self.refs,self.refs.get(branch))
    def restore_ref(self,snapshot:RefSnapshot)->None:
        if snapshot.existed and snapshot.head is not None:self.refs[snapshot.branch]=snapshot.head
        else:self.refs.pop(snapshot.branch,None)

    def execute_contract(self, contract: dict[str,Any]|RemoteExecutionContract, *, inject_failure: str|None=None)->dict[str,Any]:
        parsed=contract if isinstance(contract,RemoteExecutionContract) else RemoteExecutionContract.from_dict(contract); validation=parsed.validate()
        if validation["status"]!="PASS": return {"status":"WRITE_BLOCKED","mutation_performed":False,"reasons":validation["reasons"]}
        if parsed.provider!="mock_github" or parsed.execution_mode!="MOCK_ONLY": return {"status":"WRITE_BLOCKED","mutation_performed":False,"reasons":["MOCK_PROVIDER_REQUIRED"]}
        base_head=self.head(parsed.base_branch)
        if base_head!=parsed.expected_base_head_sha:return {"status":"WRITE_BLOCKED","mutation_performed":False,"reasons":["REMOTE_HEAD_RECHECK_FAILED"]}
        if self.branch_exists(parsed.target_branch):return {"status":"WRITE_BLOCKED","mutation_performed":False,"reasons":["TARGET_BRANCH_ALREADY_EXISTS"]}
        snapshot=self.snapshot_ref(parsed.target_branch); tree=self.tree(base_head)
        try:
            for op in parsed.operations:
                current=tree.get(op.path); current_sha=blob_sha256(current) if current is not None else None
                if op.operation=="create":
                    if current is not None: raise RuntimeError(f"CREATE_PATH_EXISTS:{op.path}")
                    tree[op.path]=op.decoded_content() or b""
                elif op.operation=="update":
                    if current is None: raise RuntimeError(f"UPDATE_PATH_MISSING:{op.path}")
                    if current_sha!=op.expected_blob_sha256: raise RuntimeError(f"UPDATE_BLOB_MISMATCH:{op.path}")
                    tree[op.path]=op.decoded_content() or b""
                elif op.operation=="delete":
                    if current is None: raise RuntimeError(f"DELETE_PATH_MISSING:{op.path}")
                    if current_sha!=op.expected_blob_sha256: raise RuntimeError(f"DELETE_BLOB_MISMATCH:{op.path}")
                    del tree[op.path]
            tree_digest=self.tree_digest_from(tree); commit=_commit_sha(base_head,tree_digest,f"CodeForge mock contract {parsed.contract_id}")
            self.trees[commit]=deepcopy(tree); self.parents[commit]=base_head; self.refs[parsed.target_branch]=commit
            if inject_failure=="after_commit": raise RuntimeError("INJECTED_AFTER_COMMIT_FAILURE")
            return seal_document({"schema":"codeforge-mock-remote-execution-receipt-v1","provider":self.provider_name,"repository":self.repository,"base_branch":parsed.base_branch,"target_branch":parsed.target_branch,"contract_id":parsed.contract_id,"base_head":base_head,"commit_sha":commit,"tree_digest":tree_digest,"operation_count":len(parsed.operations),"mutation_performed":True,"status":"PASS","rollback_performed":False})
        except Exception as exc:
            self.restore_ref(snapshot)
            return seal_document({"schema":"codeforge-mock-remote-execution-receipt-v1","provider":self.provider_name,"repository":self.repository,"target_branch":parsed.target_branch,"contract_id":parsed.contract_id,"mutation_performed":False,"status":"ROLLED_BACK","rollback_performed":True,"reason":str(exc)})
