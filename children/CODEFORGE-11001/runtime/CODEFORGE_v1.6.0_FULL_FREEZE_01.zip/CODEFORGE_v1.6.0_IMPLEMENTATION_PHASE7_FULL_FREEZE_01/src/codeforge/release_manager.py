from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable
import fnmatch
import hashlib
import json
import zipfile

from .hashchain import digest_document
from .models import utc_now
from .verification import VerificationLayer


class DeterministicReleaseManager:
    """Creates deterministic ZIP freezes and performs CRC/hash/readback validation."""

    FIXED_ZIP_TIME = (2026, 1, 1, 0, 0, 0)

    @staticmethod
    def _files(root: Path, excludes: Iterable[str]) -> list[Path]:
        patterns = tuple(excludes)
        result = []
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(root).as_posix()
            if rel == "FREEZE/RELEASE_MANIFEST.json":
                continue
            if any(fnmatch.fnmatchcase(rel, pattern) for pattern in patterns):
                continue
            result.append(path)
        return sorted(result, key=lambda item: item.relative_to(root).as_posix())

    def freeze(
        self,
        source: str | Path,
        archive_path: str | Path,
        *,
        root_name: str,
        manifest_metadata: dict[str, Any] | None = None,
        excludes: Iterable[str] = (
            "__pycache__/**", "**/__pycache__/**",
            ".codeforge-workspace/**", "**/.codeforge-workspace/**",
            "*.pyc", "**/*.pyc",
        ),
    ) -> dict[str, Any]:
        root = Path(source).resolve()
        target = Path(archive_path).resolve()
        files = self._files(root, excludes)
        inventory = []
        for path in files:
            rel = path.relative_to(root).as_posix()
            inventory.append({"path": rel, "size": path.stat().st_size, "sha256": VerificationLayer.sha256(path)})
        manifest = {
            "schema": "codeforge-release-freeze-v1",
            "root_name": root_name,
            "normalized_timestamp": "2026-01-01T00:00:00+00:00",
            "files": inventory,
            "tree_hash": digest_document(inventory),
        }
        if manifest_metadata:
            manifest.update(manifest_metadata)
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for item in inventory:
                data = (root / item["path"]).read_bytes()
                info = zipfile.ZipInfo(f"{root_name}/{item['path']}", self.FIXED_ZIP_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
            info = zipfile.ZipInfo(f"{root_name}/FREEZE/RELEASE_MANIFEST.json", self.FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        verification = self.verify(target, expected_root=root_name)
        receipt = {
            "schema": "codeforge-release-freeze-receipt-v1",
            "archive": str(target),
            "archive_sha256": VerificationLayer.sha256(target),
            "source_files": len(inventory),
            "tree_hash": manifest["tree_hash"],
            "verification": verification,
            "status": verification["status"],
        }
        return receipt

    def verify(self, archive_path: str | Path, *, expected_root: str | None = None) -> dict[str, Any]:
        archive_path = Path(archive_path).resolve()
        errors = []
        with zipfile.ZipFile(archive_path) as archive:
            corrupt = archive.testzip()
            names = archive.namelist()
            manifests = [name for name in names if name.endswith("/FREEZE/RELEASE_MANIFEST.json")]
            if corrupt:
                errors.append(f"CRC_FAIL:{corrupt}")
            if len(manifests) != 1:
                errors.append("RELEASE_MANIFEST_COUNT_INVALID")
                manifest = None
            else:
                manifest = json.loads(archive.read(manifests[0]).decode("utf-8"))
                root_name = manifest.get("root_name")
                if expected_root and root_name != expected_root:
                    errors.append("ROOT_NAME_MISMATCH")
                for item in manifest.get("files", []):
                    name = f"{root_name}/{item['path']}"
                    if name not in names:
                        errors.append(f"MISSING_ENTRY:{item['path']}")
                        continue
                    data = archive.read(name)
                    if hashlib.sha256(data).hexdigest() != item["sha256"]:
                        errors.append(f"ENTRY_HASH_MISMATCH:{item['path']}")
                if digest_document(manifest.get("files", [])) != manifest.get("tree_hash"):
                    errors.append("TREE_HASH_MISMATCH")
        return {
            "schema": "codeforge-release-verification-v1",
            "archive": str(archive_path),
            "entries": len(names),
            "crc": "PASS" if corrupt is None else "FAIL",
            "errors": errors,
            "status": "PASS" if not errors else "FAIL",
        }
