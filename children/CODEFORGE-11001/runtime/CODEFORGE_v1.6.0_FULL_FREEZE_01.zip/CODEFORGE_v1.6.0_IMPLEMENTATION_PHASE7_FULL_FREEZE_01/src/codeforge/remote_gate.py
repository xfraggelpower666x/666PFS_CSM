from __future__ import annotations
from datetime import datetime,timezone
from typing import Any
from .branch_policy import BranchIsolationPolicy
from .hashchain import seal_document,verify_document
from .idempotency import IdempotencyRegistry
from .remote_capability import validate_capability_receipt
from .remote_lock import validate_remote_lock
from .remote_models import RemoteExecutionContract
from .remote_sensitive_guard import scan_remote_operations
class RemoteExecutionGate:
 def evaluate(self,*,contract:dict[str,Any],authorization:dict[str,Any],capability:dict[str,Any],lock:dict[str,Any],default_branch:str,observed_base_head_sha:str,target_branch_exists:bool,allowlist_receipts:list[dict[str,Any]],idempotency_reservation:dict[str,Any],runtime_config:dict[str,Any])->dict[str,Any]:
  parsed=RemoteExecutionContract.from_dict(contract);reasons=[];checks={}
  validation=parsed.validate();checks["contract"]=validation
  if validation["status"]!="PASS":reasons.extend(validation["reasons"])
  checks["authorization_integrity"]=verify_document(authorization)
  if not checks["authorization_integrity"]:reasons.append("REMOTE_AUTHORIZATION_DIGEST_MISMATCH")
  if authorization.get("contract_id")!=parsed.contract_id or authorization.get("contract_digest")!=parsed.digest:reasons.append("REMOTE_AUTHORIZATION_CONTRACT_MISMATCH")
  if authorization.get("provider")!=parsed.provider or authorization.get("repository")!=parsed.repository or authorization.get("target_branch")!=parsed.target_branch:reasons.append("REMOTE_AUTHORIZATION_TARGET_MISMATCH")
  if authorization.get("consumed"):reasons.append("REMOTE_AUTHORIZATION_ALREADY_CONSUMED")
  try:
   if datetime.fromisoformat(str(authorization.get("expires_at")))<=datetime.now(timezone.utc):reasons.append("REMOTE_AUTHORIZATION_EXPIRED")
  except (TypeError,ValueError):reasons.append("REMOTE_AUTHORIZATION_EXPIRY_INVALID")
  cap=validate_capability_receipt(capability,provider=parsed.provider,repository=parsed.repository,require_mock_write=True);checks["capability"]=cap
  if cap["status"]!="PASS":reasons.extend(cap["reasons"])
  if capability.get("evidence_id")!=parsed.capability_evidence_id:reasons.append("CAPABILITY_EVIDENCE_BINDING_MISMATCH")
  lock_check=validate_remote_lock(lock,target_identity=f"{parsed.repository}@{parsed.target_branch}",expected_head_sha=parsed.expected_base_head_sha);checks["lock"]=lock_check
  if lock_check["status"]!="PASS":reasons.extend(lock_check["reasons"])
  if lock.get("lock_id")!=parsed.lock_id:reasons.append("REMOTE_LOCK_ID_BINDING_MISMATCH")
  branch=BranchIsolationPolicy().evaluate(base_branch=parsed.base_branch,target_branch=parsed.target_branch,default_branch=default_branch,target_branch_exists=target_branch_exists);checks["branch_isolation"]=branch
  if branch["status"]!="PASS":reasons.extend(branch["reasons"])
  if observed_base_head_sha!=parsed.expected_base_head_sha:reasons.append("REMOTE_HEAD_RECHECK_FAILED")
  expected_allow={(op.path,op.operation,parsed.repository,parsed.target_branch) for op in parsed.operations};actual_allow=set()
  for item in allowlist_receipts:
   target=item.get("target",{}) if isinstance(item,dict) else {}
   actual_allow.add((item.get("path"),item.get("operation"),target.get("repository"),target.get("branch")))
   if item.get("allowed") is not True or item.get("status")!="PASS":reasons.append("REMOTE_SCOPE_ALLOWLIST_FAILED")
  if actual_allow!=expected_allow:reasons.append("REMOTE_SCOPE_ALLOWLIST_BINDING_MISMATCH")
  if idempotency_reservation.get("status")!="PASS":reasons.append("IDEMPOTENCY_RESERVATION_FAILED")
  if idempotency_reservation.get("key")!=IdempotencyRegistry.key_for(contract):reasons.append("IDEMPOTENCY_KEY_BINDING_MISMATCH")
  sensitive=scan_remote_operations(parsed.operations);checks["sensitive_guard"]=sensitive
  if sensitive["status"]!="PASS":reasons.append("REMOTE_CONTENT_SECRET_SIGNAL")
  execution=runtime_config.get("execution",{}) if isinstance(runtime_config,dict) else {}
  if execution.get("mock_remote_execution_enabled") is not True:reasons.append("MOCK_REMOTE_EXECUTION_DISABLED")
  if execution.get("real_remote_execution_enabled") is not False:reasons.append("REAL_REMOTE_EXECUTION_FLAG_MUST_REMAIN_FALSE")
  if parsed.provider!="mock_github" or parsed.execution_mode!="MOCK_ONLY":reasons.append("REAL_REMOTE_EXECUTION_FORBIDDEN")
  return seal_document({"schema":"codeforge-remote-execution-gate-v1","contract_id":parsed.contract_id,"provider":parsed.provider,"repository":parsed.repository,"target_branch":parsed.target_branch,"checks":checks,"status":"PASS" if not reasons else "WRITE_BLOCKED","reasons":sorted(set(reasons))})
