from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .hashchain import seal_document, verify_document
from .models import stable_id


def issue_remote_lock(*, target_identity: str, owner: str, observed_head_sha: str, evidence_id: str, ttl_seconds: int = 300) -> dict[str, Any]:
    if ttl_seconds < 30 or ttl_seconds > 1800:
        raise ValueError("ttl_seconds must be between 30 and 1800")
    now = datetime.now(timezone.utc).replace(microsecond=0)
    receipt = {
        "schema": "codeforge-remote-lock-receipt-v1",
        "lock_id": stable_id("RLK", {"target": target_identity, "owner": owner, "head": observed_head_sha, "issued_at": now.isoformat()}),
        "target_identity": target_identity,
        "owner": owner,
        "observed_head_sha": observed_head_sha,
        "evidence_id": evidence_id,
        "acquired_at": now.isoformat(),
        "expires_at": (now + timedelta(seconds=ttl_seconds)).isoformat(),
        "status": "PASS",
    }
    return seal_document(receipt)


def validate_remote_lock(receipt: dict[str, Any], *, target_identity: str, expected_head_sha: str, now: datetime | None = None) -> dict[str, Any]:
    reasons: list[str] = []
    if not verify_document(receipt):
        reasons.append("REMOTE_LOCK_DIGEST_MISMATCH")
    if receipt.get("target_identity") != target_identity:
        reasons.append("REMOTE_LOCK_TARGET_MISMATCH")
    if receipt.get("observed_head_sha") != expected_head_sha:
        reasons.append("REMOTE_LOCK_HEAD_MISMATCH")
    if not receipt.get("evidence_id"):
        reasons.append("REMOTE_LOCK_EVIDENCE_MISSING")
    try:
        current = now or datetime.now(timezone.utc)
        if datetime.fromisoformat(str(receipt.get("expires_at"))) <= current:
            reasons.append("REMOTE_LOCK_EXPIRED")
    except (TypeError, ValueError):
        reasons.append("REMOTE_LOCK_EXPIRY_INVALID")
    return {
        "schema": "codeforge-remote-lock-validation-v1",
        "lock_id": receipt.get("lock_id"),
        "status": "PASS" if not reasons else "WRITE_BLOCKED",
        "reasons": reasons,
    }
