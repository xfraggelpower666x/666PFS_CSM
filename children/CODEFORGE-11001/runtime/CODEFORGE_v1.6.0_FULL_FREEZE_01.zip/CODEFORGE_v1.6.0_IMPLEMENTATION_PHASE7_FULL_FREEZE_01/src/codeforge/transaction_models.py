from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from .hashchain import seal_document, verify_document
from .models import stable_id, utc_now


class TransactionState(StrEnum):
    PLANNED = "PLANNED"
    AUTHORIZED = "AUTHORIZED"
    PREPARED = "PREPARED"
    APPLIED = "APPLIED"
    READBACK_PASS = "READBACK_PASS"
    COMMITTED = "COMMITTED"
    ROLLBACK_REQUIRED = "ROLLBACK_REQUIRED"
    ROLLED_BACK = "ROLLED_BACK"
    FAILED = "FAILED"


ALLOWED_TRANSITIONS = {
    TransactionState.PLANNED: {TransactionState.AUTHORIZED, TransactionState.FAILED},
    TransactionState.AUTHORIZED: {TransactionState.PREPARED, TransactionState.FAILED},
    TransactionState.PREPARED: {TransactionState.APPLIED, TransactionState.ROLLBACK_REQUIRED, TransactionState.FAILED},
    TransactionState.APPLIED: {TransactionState.READBACK_PASS, TransactionState.ROLLBACK_REQUIRED},
    TransactionState.READBACK_PASS: {TransactionState.COMMITTED, TransactionState.ROLLBACK_REQUIRED},
    TransactionState.ROLLBACK_REQUIRED: {TransactionState.ROLLED_BACK, TransactionState.FAILED},
    TransactionState.COMMITTED: set(),
    TransactionState.ROLLED_BACK: set(),
    TransactionState.FAILED: set(),
}


def validate_transition(current: TransactionState, target: TransactionState) -> None:
    if target not in ALLOWED_TRANSITIONS[current]:
        raise ValueError(f"INVALID_TRANSACTION_TRANSITION:{current.value}->{target.value}")


@dataclass(slots=True)
class TransactionManifest:
    proposal_id: str
    proposal_digest: str
    authorization_id: str
    target_identity: str
    target_path: str
    candidate_path: str
    operation_count: int
    transaction_id: str = ""
    state: TransactionState = TransactionState.PLANNED
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    digest: str = ""

    def seal(self) -> "TransactionManifest":
        if not self.transaction_id:
            self.transaction_id = stable_id("TXN", {
                "proposal_id": self.proposal_id,
                "proposal_digest": self.proposal_digest,
                "authorization_id": self.authorization_id,
                "target_path": self.target_path,
                "created_at": self.created_at,
            })
        document = self.to_dict(include_digest=False)
        self.digest = seal_document(document)["digest"]
        return self

    def transition(self, target: TransactionState) -> "TransactionManifest":
        validate_transition(self.state, target)
        self.state = target
        self.updated_at = utc_now()
        self.digest = ""
        return self.seal()

    def to_dict(self, *, include_digest: bool = True) -> dict[str, Any]:
        document = {
            "schema": "codeforge-transaction-manifest-v1",
            "transaction_id": self.transaction_id,
            "proposal_id": self.proposal_id,
            "proposal_digest": self.proposal_digest,
            "authorization_id": self.authorization_id,
            "target_identity": self.target_identity,
            "target_path": self.target_path,
            "candidate_path": self.candidate_path,
            "operation_count": self.operation_count,
            "state": self.state.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
        if include_digest:
            if not self.digest:
                self.seal()
            document["digest"] = self.digest
        return document

    @classmethod
    def from_dict(cls, document: dict[str, Any]) -> "TransactionManifest":
        if document.get("schema") != "codeforge-transaction-manifest-v1" or not verify_document(document):
            raise ValueError("INVALID_TRANSACTION_MANIFEST")
        return cls(
            proposal_id=document["proposal_id"],
            proposal_digest=document["proposal_digest"],
            authorization_id=document["authorization_id"],
            target_identity=document["target_identity"],
            target_path=document["target_path"],
            candidate_path=document["candidate_path"],
            operation_count=int(document["operation_count"]),
            transaction_id=document["transaction_id"],
            state=TransactionState(document["state"]),
            created_at=document["created_at"],
            updated_at=document["updated_at"],
            digest=document["digest"],
        )
