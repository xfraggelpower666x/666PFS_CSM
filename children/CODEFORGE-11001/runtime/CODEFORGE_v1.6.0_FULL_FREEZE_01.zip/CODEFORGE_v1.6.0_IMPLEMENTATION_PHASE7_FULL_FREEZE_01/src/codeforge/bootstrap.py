from __future__ import annotations

from pathlib import Path
from typing import Any

from .core import CoreKernel


class BootstrapPipeline:
    """Initialisiert CodeForge deterministisch und erzeugt einen prüfbaren Bootstrap-Checkpoint."""

    def __init__(self, workspace: str | Path):
        self.core = CoreKernel(workspace)

    def run(self) -> dict[str, Any]:
        status = self.core.initialize()
        checkpoint = self.core.create_checkpoint(
            phase="BOOTSTRAP",
            state="PASS",
            block_from=1,
            block_to=7,
            payload={
                "workspace_initialized": True,
                "stage_registry_seeded": True,
                "capability_registry_seeded": True,
                "pidb_initialized": True,
                "mutation_mode": "CONTROLLED_LOCAL_SANDBOX_PHASE_3",
                "local_sandbox_execution_enabled_by_default": False,
                "github_write_enabled": False,
                "cloudflare_write_enabled": False,
            },
        )
        return {"status": status, "checkpoint": checkpoint.to_dict()}
