from __future__ import annotations

import hashlib
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .status import Status


@dataclass(slots=True)
class ImportGateResult:
    accepted: bool
    status: Status
    source: str
    source_kind: str
    size: int
    sha256: str
    crc: str | None
    classification: str
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        return data


class ImportGate:
    """Prüft Importquellen, ohne sie als technische Wahrheit zu aktivieren."""

    ALLOWED_SUFFIXES = {".zip", ".md", ".txt", ".json", ".jsonc", ".yml", ".yaml", ".toml"}

    @staticmethod
    def _sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def inspect(self, source: str | Path, *, max_bytes: int = 2_000_000_000) -> ImportGateResult:
        path = Path(source).resolve()
        reasons: list[str] = []
        if not path.is_file():
            raise FileNotFoundError(path)
        size = path.stat().st_size
        suffix = path.suffix.lower()
        if suffix not in self.ALLOWED_SUFFIXES:
            reasons.append(f"Dateityp nicht freigegeben: {suffix or '<ohne Endung>'}")
        if size > max_bytes:
            reasons.append(f"Datei überschreitet Importlimit: {size} > {max_bytes}")
        crc = None
        if suffix == ".zip":
            try:
                with zipfile.ZipFile(path) as archive:
                    corrupt = archive.testzip()
                crc = "PASS" if corrupt is None else f"FAIL:{corrupt}"
                if corrupt is not None:
                    reasons.append(f"ZIP-CRC fehlerhaft: {corrupt}")
            except zipfile.BadZipFile:
                crc = "FAIL:BAD_ZIP"
                reasons.append("Ungültiges ZIP-Archiv")
        accepted = not reasons
        return ImportGateResult(
            accepted=accepted,
            status=Status.VERIFIED if accepted else Status.BLOCKED,
            source=str(path),
            source_kind="archive_evidence" if suffix == ".zip" else "document_evidence",
            size=size,
            sha256=self._sha256(path),
            crc=crc,
            classification="EVIDENCE_ONLY_NOT_AUTHORITY",
            reasons=reasons or ["Import technisch gültig; Autorität wird separat reconciliert"],
        )
