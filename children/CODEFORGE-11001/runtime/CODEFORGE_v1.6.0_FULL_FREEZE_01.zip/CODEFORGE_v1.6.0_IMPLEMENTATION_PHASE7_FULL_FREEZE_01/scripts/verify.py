from __future__ import annotations

import compileall
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
os.environ["PYTHONPATH"] = str(SRC) + os.pathsep + str(ROOT / "tests") + os.pathsep + os.environ.get("PYTHONPATH", "")
sys.path.insert(0, str(SRC))
sys.path.insert(0, str(ROOT / "tests"))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_phase7_ledger(path: Path) -> dict:
    entries = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    previous = "0" * 64
    ok = len(entries) == 1000 and entries[0]["block"] == 8101 and entries[-1]["block"] == 9100
    for entry in entries:
        digest = entry.get("digest")
        material = {k: v for k, v in entry.items() if k != "digest"}
        expected = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        ok = ok and entry.get("previous_digest") == previous and digest == expected
        previous = digest
    return {"entries": len(entries), "status": "PASS" if ok else "FAIL", "final_digest": previous, "sha256": sha256(path)}


def main() -> int:
    results: dict[str, object] = {}
    results["compile"] = compileall.compile_dir(SRC, quiet=1)
    test = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-v"],
        cwd=ROOT, text=True, capture_output=True,
    )
    output = (test.stdout + test.stderr).strip().splitlines()
    results["tests"] = test.returncode == 0
    results["test_output"] = output[-80:]
    results["test_count"] = sum(1 for line in output if line.rstrip().endswith("... ok"))

    import codeforge
    from codeforge.child_candidate import build_universal_child_candidate, verify_universal_child_candidate
    from codeforge.continuation import ContinuationKernel
    from codeforge.core import CoreKernel
    from codeforge.models import Checkpoint
    from codeforge.repo_integration import RepositoryIntegrationPolicy, RepositorySnapshotBuilder
    from codeforge.scanner import RepositoryScanner

    results["package_version"] = codeforge.__version__
    results["package_version_ok"] = codeforge.__version__ == "1.6.0"

    with tempfile.TemporaryDirectory() as tmp:
        temp = Path(tmp)
        core = CoreKernel(temp / "workspace")
        status = core.initialize()
        results["core_mode"] = status["mode"]
        results["core_mode_ok"] = status["mode"] == "REPOSITORY_INTEGRATED_RADIO_CODING_AGENT_PHASE_7"
        execution = status["execution"]
        results["writes_default_off"] = all(execution.get(key) is False for key in (
            "connector_network_write_enabled", "real_remote_execution_enabled", "github_write_enabled",
            "cloudflare_write_enabled", "real_connector_execution_enabled"
        ))

        cont = ContinuationKernel(temp / "continuation-workspace")
        cont.set_active_task({"id": "phase7-radio-repo-integration", "checkpoint": 9100})
        cont.checkpoint(Checkpoint("IMPLEMENTATION_PHASE7", "PASS", 8101, 9100, {"repository_root": "engineering/codeforge"}))
        cont.interrupt("fortsetzungslogik und universal/radio separation")
        blocked = False
        try:
            cont.resume()
        except RuntimeError:
            blocked = True
        integrated = cont.integrate_pending()
        resumed = cont.resume()
        repository_state = cont.repository_state()
        results["continuation_pending_blocks_resume"] = blocked
        results["continuation_integrated"] = len(integrated) == 1 and integrated[0]["integration_state"] == "INTEGRATED"
        results["continuation_reaudit"] = resumed.get("reaudit", {}).get("status") == "PASS"
        results["continuation_repository_state"] = len(repository_state.get("digest", "")) == 64

        artifact = temp / "runtime.zip"
        artifact.write_bytes(b"phase7-runtime")
        policy = RepositoryIntegrationPolicy(
            repository="xfraggelpower666x/WebRadio-666SOUNDsDESIGn",
            branch="codeforge/framework-v1.6.0-phase7",
        )
        builder = RepositorySnapshotBuilder(policy)
        manifest = builder.build_manifest(
            {"releases/runtime.zip": artifact}, version="1.6.0",
            checkpoint="IMPLEMENTATION_PHASE7_9100", continuation_state=repository_state,
        )
        repo_root = temp / "repo"
        builder.materialize(repo_root, {"releases/runtime.zip": artifact}, manifest, repository_state)
        results["repo_manifest_readback"] = builder.verify_manifest(manifest, repo_root)["status"] == "PASS"
        results["repo_root_isolated"] = manifest["root"] == "engineering/codeforge" and manifest["guards"]["production_branch_write"] is False

        child = build_universal_child_candidate(
            version="1.6.0", freeze_sha256="a" * 64, checkpoint="IMPLEMENTATION_PHASE7_9100"
        )
        results["child_candidate_valid"] = verify_universal_child_candidate(child)
        results["child_prepare_only"] = child["status"] == "PREPARE_ONLY" and child["registry_write_allowed"] is False
        results["child_universal_radio_external"] = child["identity_scope"] == "UNIVERSAL_CODING_AGENT" and child["specializations"]["radio"]["part_of_child_identity"] is False

    ledger = verify_phase7_ledger(ROOT / "data" / "phase7" / "IMPLEMENTATION_BLOCKS_8101_9100.jsonl")
    results["phase7_ledger"] = ledger

    config = json.loads((ROOT / "config" / "codeforge.json").read_text(encoding="utf-8"))
    allowlist = json.loads((ROOT / "config" / "writer-allowlist.json").read_text(encoding="utf-8"))
    radio_config = json.loads((ROOT / "config" / "radio-integration.json").read_text(encoding="utf-8"))
    child_policy = json.loads((ROOT / "config" / "666pfs-child-candidate-policy.json").read_text(encoding="utf-8"))
    results["config_version_consistency"] = config.get("framework_version") == allowlist.get("version") == "1.6.0"
    results["repo_config_isolated"] = config.get("repository_integration", {}).get("root") == "engineering/codeforge" and config["repository_integration"]["production_branch_write"] is False
    results["radio_plugin_bound"] = radio_config.get("plugin_version") == "1.1.0" and radio_config.get("radio_runtime_write_enabled") is False
    results["child_policy_fail_closed"] = child_policy.get("status") == "PREPARE_ONLY" and child_policy.get("registry_write_allowed") is False

    radio = allowlist.get("repositories", {}).get("xfraggelpower666x/WebRadio-666SOUNDsDESIGn", {})
    results["radio_write_blocked"] = radio.get("operations") == [] and radio.get("include") == [] and radio.get("exclude") == ["**"]

    scan = RepositoryScanner().scan(ROOT)
    results["self_scan_files"] = scan.file_count
    results["self_scan_bytes"] = scan.total_bytes
    results["secret_signals"] = len(scan.secret_signal_paths)

    required = [
        results["compile"], results["tests"], results["test_count"] >= 216,
        results["package_version_ok"], results["core_mode_ok"], results["writes_default_off"],
        results["continuation_pending_blocks_resume"], results["continuation_integrated"],
        results["continuation_reaudit"], results["continuation_repository_state"],
        results["repo_manifest_readback"], results["repo_root_isolated"],
        results["child_candidate_valid"], results["child_prepare_only"], results["child_universal_radio_external"],
        ledger["status"] == "PASS", results["config_version_consistency"], results["repo_config_isolated"],
        results["radio_plugin_bound"], results["child_policy_fail_closed"], results["radio_write_blocked"],
        results["secret_signals"] == 0,
    ]
    results["status"] = "PASS" if all(required) else "FAIL"
    print(json.dumps(results, indent=2, ensure_ascii=False, sort_keys=True))
    return 0 if results["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
