from __future__ import annotations
from pathlib import Path
import tempfile,unittest
from codeforge.idempotency import IdempotencyRegistry
from codeforge.remote_authorization import expected_remote_authorization_phrase
from codeforge.remote_gate import RemoteExecutionGate
from codeforge.remote_orchestrator import RemoteMockOrchestrator
from codeforge.remote_sensitive_guard import scan_remote_operations
from codeforge.remote_models import RemoteOperationIntent
from phase4_helpers import build_case
class BindingSensitiveGuardTests(unittest.TestCase):
 def gate(self,t,mutate):
  r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=orch.auth.issue(c,phrase=expected_remote_authorization_phrase(c),issued_by="x");res=orch.idempotency.reserve(c);mutate(c,cap,lock,allow,a,res,run);return RemoteExecutionGate().evaluate(contract=c,authorization=a,capability=cap,lock=lock,default_branch=r.default_branch,observed_base_head_sha=r.head("main"),target_branch_exists=False,allowlist_receipts=allow,idempotency_reservation=res,runtime_config=run)
 def test_capability_evidence_binding(self):
  with tempfile.TemporaryDirectory() as t:self.assertIn("CAPABILITY_EVIDENCE_BINDING_MISMATCH",self.gate(t,lambda c,cap,*x:cap.__setitem__("evidence_id","other"))["reasons"])
 def test_lock_id_binding(self):
  with tempfile.TemporaryDirectory() as t:self.assertIn("REMOTE_LOCK_ID_BINDING_MISMATCH",self.gate(t,lambda c,cap,lock,*x:lock.__setitem__("lock_id","other"))["reasons"])
 def test_authorization_target_binding(self):
  with tempfile.TemporaryDirectory() as t:self.assertIn("REMOTE_AUTHORIZATION_TARGET_MISMATCH",self.gate(t,lambda c,cap,lock,allow,a,*x:a.__setitem__("target_branch","codeforge/other"))["reasons"])
 def test_allowlist_exact_binding(self):
  with tempfile.TemporaryDirectory() as t:self.assertIn("REMOTE_SCOPE_ALLOWLIST_BINDING_MISMATCH",self.gate(t,lambda c,cap,lock,allow,*x:allow.pop())["reasons"])
 def test_idempotency_key_binding(self):
  with tempfile.TemporaryDirectory() as t:self.assertIn("IDEMPOTENCY_KEY_BINDING_MISMATCH",self.gate(t,lambda c,cap,lock,allow,a,res,*x:res.__setitem__("key","other"))["reasons"])
 def test_secret_signal_blocks(self):
  op=RemoteOperationIntent.from_bytes("create","x.txt",b"token=ghp_abcdefghijklmnop");self.assertEqual("WRITE_BLOCKED",scan_remote_operations([op])["status"])
 def test_private_key_signal_blocks(self):
  op=RemoteOperationIntent.from_bytes("create","x.pem",b"-----BEGIN " + b"PRIVATE KEY-----");self.assertEqual("WRITE_BLOCKED",scan_remote_operations([op])["status"])
 def test_normal_content_passes(self):self.assertEqual("PASS",scan_remote_operations([RemoteOperationIntent.from_bytes("create","x.txt",b"hello")])["status"])
if __name__=="__main__":unittest.main()
