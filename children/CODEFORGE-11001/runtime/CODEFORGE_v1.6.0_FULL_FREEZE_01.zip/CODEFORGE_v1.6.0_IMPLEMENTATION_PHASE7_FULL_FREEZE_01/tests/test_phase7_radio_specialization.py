import tempfile
import unittest
from pathlib import Path
from codeforge.scanner import RepositoryScanner
from codeforge.plugins.radio_intelligence import RadioIntelligencePlugin

class RadioSpecializationTests(unittest.TestCase):
    def test_radio_profile_is_specialized_but_non_mutating(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/"worker.js").write_text("export default {fetch(){return new Response('/stream')}}")
            (root/"index.html").write_text("<audio></audio><script>fetch('/fallback-stream');fetch('/api/nowplaying')</script>")
            (root/"package.json").write_text('{"version":"1","scripts":{"check":"x","test":"x","verify":"x"}}')
            scan=RepositoryScanner().scan(root)
            result=RadioIntelligencePlugin().analyse(scan)
            self.assertEqual(result["topology"]["specialization"],"RADIO_REPOSITORY_CODING_AGENT")
            self.assertEqual(result["topology"]["codeforge_repository_root"],"engineering/codeforge")
            self.assertFalse(result["summary"]["mutation_performed"])
