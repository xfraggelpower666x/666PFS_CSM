import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from codeforge.package_verify import PortablePackageVerifier


class PortablePackageTests(unittest.TestCase):
    def test_verification_is_independent_of_current_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            archive = root / "package.zip"
            with zipfile.ZipFile(archive, "w") as handle:
                handle.writestr("file.txt", "hello")
            verifier = PortablePackageVerifier()
            digest = verifier.sha256(archive)
            checksum = root / "package.zip.sha256"
            checksum.write_text(f"{digest}  package.zip\n", encoding="utf-8")
            readback = root / "package.zip.readback.json"
            with zipfile.ZipFile(archive) as handle:
                entries = len(handle.infolist())
            readback.write_text(json.dumps({
                "sha256": digest, "entries": entries, "size": archive.stat().st_size
            }), encoding="utf-8")
            result = verifier.verify(archive, checksum_file=checksum, readback_file=readback)
            self.assertEqual(result["status"], "PASS")
