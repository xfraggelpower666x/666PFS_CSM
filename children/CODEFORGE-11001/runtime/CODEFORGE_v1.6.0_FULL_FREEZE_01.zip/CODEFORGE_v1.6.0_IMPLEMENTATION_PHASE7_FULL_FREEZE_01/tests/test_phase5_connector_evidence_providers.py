from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

from codeforge.connector_evidence import ConnectorEvidenceStore, create_connector_evidence
from codeforge.providers.cloudflare_connector_candidate import CloudflareConnectorCandidateProvider
from codeforge.providers.github_connector_candidate import GitHubConnectorCandidateProvider
from codeforge.providers.registry import ProviderRegistry
from phase5_helpers import build_connector_case, build_gate_receipt


class ConnectorEvidenceProviderTests(unittest.TestCase):
    def test_evidence_creation_and_store(self):
        with tempfile.TemporaryDirectory() as tmp:
            receipt = create_connector_evidence(
                provider="github", operation="search_commits", subject="candidate/codeforge",
                locator="connector://github/search_commits", payload={"head": "a" * 40},
            )
            result = ConnectorEvidenceStore(Path(tmp)).write(receipt)
            self.assertEqual("PASS", result["status"]); self.assertEqual("PASS", result["readback"])

    def test_evidence_secret_field_rejected(self):
        with self.assertRaises(ValueError):
            create_connector_evidence(
                provider="github", operation="read", subject="a/b", locator="x", payload={"api_token": "redacted"},
            )

    def test_evidence_tamper_store_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            receipt = create_connector_evidence(provider="github", operation="read", subject="a/b", locator="x", payload={"head": "a" * 40})
            receipt["payload"]["head"] = "b" * 40
            result = ConnectorEvidenceStore(Path(tmp)).write(receipt)
            self.assertEqual("WRITE_BLOCKED", result["status"])

    def test_github_candidate_provider_status(self):
        status = GitHubConnectorCandidateProvider().status()
        self.assertFalse(status["network_write"]); self.assertFalse(status["real_execution"])

    def test_github_candidate_provider_execute_blocks(self):
        result = GitHubConnectorCandidateProvider().execute(plan={"plan_id": "x"})
        self.assertEqual("WRITE_BLOCKED", result["status"])

    def test_cloudflare_candidate_provider_status(self):
        status = CloudflareConnectorCandidateProvider().status()
        self.assertEqual("READBACK_PLAN_ONLY", status["status"]); self.assertFalse(status["network_write"])

    def test_cloudflare_candidate_execute_blocks(self):
        result = CloudflareConnectorCandidateProvider().execute(plan={"plan_id": "x"})
        self.assertEqual("WRITE_BLOCKED", result["status"])

    def test_provider_registry_inventory(self):
        registry = ProviderRegistry(); registry.register(GitHubConnectorCandidateProvider()); registry.register(CloudflareConnectorCandidateProvider())
        inventory = registry.inventory()
        self.assertIn("github_connector_candidate", inventory); self.assertIn("cloudflare_connector_candidate", inventory)

    def test_provider_duplicate_rejected(self):
        registry = ProviderRegistry(); registry.register(GitHubConnectorCandidateProvider())
        with self.assertRaises(KeyError): registry.register(GitHubConnectorCandidateProvider())

    def test_provider_plan_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = GitHubConnectorCandidateProvider().plan(
                contract=case["contract"], session=case["session"], head_receipt=case["head"],
                capability=case["capability"], lock=case["lock"], allowlist_receipts=case["allow"],
                gate_receipt=build_gate_receipt(case), test_only=True,
            )
            self.assertEqual("PASS", result["status"])


if __name__ == "__main__":
    unittest.main()
