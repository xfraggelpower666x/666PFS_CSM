from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from codeforge.controlled_writer import ControlledWriter
from codeforge.core import CoreKernel
from codeforge.governance import MutationGate
from codeforge.providers.disabled_remote import DisabledRemoteProvider
from codeforge.providers.registry import ProviderRegistry


class Phase3ProvidersCoreTests(unittest.TestCase):
    def test_core_defaults_local_execution_off(self):
        with tempfile.TemporaryDirectory() as tmp:
            status=CoreKernel(Path(tmp)/"workspace").initialize()
            self.assertFalse(status["execution"]["local_sandbox_enabled"])
            self.assertEqual("WRITE_BLOCKED",status["providers"]["github"]["status"])

    def test_remote_providers_block_execution(self):
        for name in ("github","cloudflare"):
            receipt=DisabledRemoteProvider(name).execute()
            self.assertFalse(receipt["mutation_performed"]); self.assertEqual("WRITE_BLOCKED",receipt["status"])

    def test_provider_duplicate_blocks(self):
        registry=ProviderRegistry(); provider=DisabledRemoteProvider("github"); registry.register(provider)
        with self.assertRaises(KeyError): registry.register(provider)

    def test_phase3_gate_allows_local_only(self):
        claims=MutationGate.LOCAL_EXECUTION_REQUIRED
        self.assertTrue(MutationGate().evaluate(claims,phase=3,operation="execute",provider="local_sandbox").allowed)
        self.assertFalse(MutationGate().evaluate(claims,phase=3,operation="execute",provider="github").allowed)

    def test_writer_facade_blocks_remote(self):
        receipt=ControlledWriter().execute({"proposal_id":"P"},provider="github")
        self.assertFalse(receipt["mutation_performed"])


if __name__ == "__main__": unittest.main()
