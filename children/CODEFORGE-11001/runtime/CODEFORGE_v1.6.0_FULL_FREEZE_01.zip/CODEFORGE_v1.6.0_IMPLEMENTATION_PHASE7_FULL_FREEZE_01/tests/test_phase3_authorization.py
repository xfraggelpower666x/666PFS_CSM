from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import tempfile
import unittest

from codeforge.authorization import AuthorizationBlocked, ExecutionAuthorizationRegistry, expected_authorization_phrase
from codeforge.hashchain import seal_document
from phase3_helpers import build_proposal, make_tree


class Phase3AuthorizationTests(unittest.TestCase):
    def test_exact_phrase_and_single_use(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); baseline, candidate = make_tree(root); proposal = build_proposal(baseline, candidate)
            registry = ExecutionAuthorizationRegistry(root / "auth")
            receipt = registry.issue(proposal, phrase=expected_authorization_phrase(proposal), issued_by="tester")
            self.assertEqual("PASS", registry.inspect(receipt["authorization_id"])["status"])
            consumed = registry.consume(receipt["authorization_id"], proposal)
            self.assertEqual("PASS", consumed["status"])
            self.assertEqual("WRITE_BLOCKED", registry.inspect(receipt["authorization_id"])["status"])

    def test_wrong_phrase_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); baseline, candidate = make_tree(root); proposal = build_proposal(baseline, candidate)
            with self.assertRaises(AuthorizationBlocked):
                ExecutionAuthorizationRegistry(root / "auth").issue(proposal, phrase="wrong", issued_by="tester")

    def test_tampered_proposal_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); baseline, candidate = make_tree(root); proposal = build_proposal(baseline, candidate)
            proposal["operations"][0]["path"] = "tampered.py"
            with self.assertRaises(AuthorizationBlocked):
                ExecutionAuthorizationRegistry(root / "auth").issue(proposal, phrase=expected_authorization_phrase(proposal), issued_by="tester")

    def test_tampered_authorization_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); baseline, candidate = make_tree(root); proposal = build_proposal(baseline, candidate)
            registry = ExecutionAuthorizationRegistry(root / "auth")
            receipt = registry.issue(proposal, phrase=expected_authorization_phrase(proposal), issued_by="tester")
            path = root / "auth" / f"{receipt['authorization_id']}.json"
            data = json.loads(path.read_text()); data["issued_by"] = "attacker"; path.write_text(json.dumps(data))
            self.assertIn("AUTHORIZATION_DIGEST_MISMATCH", registry.inspect(receipt["authorization_id"])["reasons"])

    def test_expired_authorization_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); baseline, candidate = make_tree(root); proposal = build_proposal(baseline, candidate)
            registry = ExecutionAuthorizationRegistry(root / "auth")
            receipt = registry.issue(proposal, phrase=expected_authorization_phrase(proposal), issued_by="tester")
            path = root / "auth" / f"{receipt['authorization_id']}.json"
            data = json.loads(path.read_text()); data["expires_at"] = (datetime.now(timezone.utc)-timedelta(seconds=1)).replace(microsecond=0).isoformat(); data = seal_document(data); path.write_text(json.dumps(data))
            self.assertIn("AUTHORIZATION_EXPIRED", registry.inspect(receipt["authorization_id"])["reasons"])


if __name__ == "__main__": unittest.main()
