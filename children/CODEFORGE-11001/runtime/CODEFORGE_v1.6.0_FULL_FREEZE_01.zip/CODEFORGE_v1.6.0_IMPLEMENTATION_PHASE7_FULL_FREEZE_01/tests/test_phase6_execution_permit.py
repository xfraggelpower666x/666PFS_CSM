from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import tempfile
import unittest

from codeforge.connector_execution_permit import (
    RADIO_REPOSITORY, RealConnectorExecutionPermit, RealConnectorPermitRegistry,
    issue_real_connector_execution_permit, required_execution_phrase,
)
from phase6_helpers import build_phase6_case


class Phase6ExecutionPermitTests(unittest.TestCase):
    def test_exact_phrase_issues_permit(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            result = RealConnectorExecutionPermit.from_dict(case["permit"]).validate(plan=case["plan"])
            self.assertEqual(result["status"], "PASS")

    def test_wrong_phrase_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            with self.assertRaisesRegex(ValueError, "EXACT_REAL_CONNECTOR"):
                issue_real_connector_execution_permit(plan=case["plan"], phrase="go", issued_by="x")

    def test_permit_tamper_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            tampered = dict(case["permit"])
            tampered["target_branch"] = "codeforge/tampered"
            result = RealConnectorExecutionPermit.from_dict(tampered).validate(plan=case["plan"])
            self.assertEqual(result["status"], "WRITE_BLOCKED")

    def test_expired_permit_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            permit = RealConnectorExecutionPermit.from_dict(case["permit"])
            later = datetime.now(timezone.utc) + timedelta(minutes=10)
            self.assertEqual(permit.validate(plan=case["plan"], now=later)["status"], "WRITE_BLOCKED")

    def test_registry_single_use(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            registry = RealConnectorPermitRegistry(Path(tmp) / "permits.json")
            self.assertEqual(registry.consume(case["permit"], plan=case["plan"])["status"], "PASS")
            self.assertEqual(registry.consume(case["permit"], plan=case["plan"])["status"], "WRITE_BLOCKED")

    def test_radio_target_cannot_receive_permit(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            plan = dict(case["plan"])
            plan["repository"] = RADIO_REPOSITORY
            with self.assertRaises(ValueError):
                issue_real_connector_execution_permit(
                    plan=plan,
                    phrase=required_execution_phrase(plan["contract_id"], plan["plan_id"]),
                    issued_by="x",
                )

    def test_ttl_over_five_minutes_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            with self.assertRaises(ValueError):
                issue_real_connector_execution_permit(
                    plan=case["plan"], phrase=case["phrase"], issued_by="x", ttl_seconds=301,
                )


if __name__ == "__main__":
    unittest.main()
