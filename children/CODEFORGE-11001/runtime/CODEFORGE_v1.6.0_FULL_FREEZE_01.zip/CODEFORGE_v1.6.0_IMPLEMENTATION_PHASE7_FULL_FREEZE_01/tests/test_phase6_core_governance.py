from __future__ import annotations

from pathlib import Path
import json
import tempfile
import unittest

import codeforge
from codeforge.core import CoreKernel


class Phase6CoreGovernanceTests(unittest.TestCase):
    def test_package_version(self):
        self.assertGreaterEqual(tuple(map(int, codeforge.__version__.split("."))), (1, 5, 0))

    def test_core_phase6_status_and_provider(self):
        with tempfile.TemporaryDirectory() as tmp:
            status = CoreKernel(Path(tmp)).initialize()
            self.assertGreaterEqual(tuple(map(int, status["framework_version"].split("."))), (1, 5, 0))
            self.assertIn(status["mode"], {"REAL_CONNECTOR_EXECUTION_ADAPTER_DESIGN_PHASE_6", "REPOSITORY_INTEGRATED_RADIO_CODING_AGENT_PHASE_7"})
            self.assertIn("github_host_execution_candidate", status["providers"])
            self.assertFalse(status["execution"]["host_adapter_test_execution_enabled"])
            self.assertFalse(status["execution"]["real_connector_execution_enabled"])

    def test_policy_all_real_writes_default_off(self):
        root = Path(__file__).resolve().parents[1]
        policy = json.loads((root / "config" / "connector-execution-policy.json").read_text(encoding="utf-8"))
        self.assertFalse(policy["real_connector_execution"])
        self.assertFalse(policy["connector_network_write"])
        self.assertFalse(policy["github_write"])
        self.assertTrue(policy["radio_first_target_forbidden"])
        self.assertEqual(policy["real_target_allowlist"], [])


if __name__ == "__main__":
    unittest.main()
