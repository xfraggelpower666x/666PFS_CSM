import unittest

from codeforge.targets import AllowlistPolicy, RemoteHeadClaim, RepositoryTarget, normalize_relative_path


class Phase2TargetTests(unittest.TestCase):
    def policy(self):
        return AllowlistPolicy({
            "schema": "codeforge-writer-allowlist-v1",
            "repositories": {"owner/repo": {
                "branches": ["main"], "operations": ["create", "update", "delete"],
                "include": ["src/**", "README.md"], "exclude": ["src/secrets/**"],
            }},
        })

    def test_path_traversal_is_rejected(self):
        with self.assertRaises(ValueError):
            normalize_relative_path("../outside.txt")

    def test_allowlist_accepts_exact_scope(self):
        result = self.policy().evaluate(RepositoryTarget("owner/repo", "main"), "src/app.py", "update")
        self.assertTrue(result["allowed"])

    def test_allowlist_rejects_excluded_scope(self):
        result = self.policy().evaluate(RepositoryTarget("owner/repo", "main"), "src/secrets/key.txt", "create")
        self.assertFalse(result["allowed"])

    def test_remote_head_mismatch_fails_closed(self):
        target = RepositoryTarget("owner/repo", "main")
        result = RemoteHeadClaim(target, "a" * 40, "b" * 40, "EVD-1").validate()
        self.assertEqual(result["status"], "BLOCKED")
