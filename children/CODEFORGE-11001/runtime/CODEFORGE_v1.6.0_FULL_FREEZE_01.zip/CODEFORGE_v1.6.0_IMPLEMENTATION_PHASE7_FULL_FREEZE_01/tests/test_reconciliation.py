import unittest

from codeforge.reconciliation import ReconciliationEngine
from codeforge.status import Status


class ReconciliationTests(unittest.TestCase):
    def test_github_outranks_handoff(self):
        result = ReconciliationEngine().reconcile([
            {"source": "handoff", "source_type": "handoff_report", "sha256": "a"},
            {"source": "repo", "source_type": "github_repository", "sha256": "b"},
        ])
        self.assertEqual(result.authoritative_source, "repo")
        self.assertEqual(result.status, Status.VERIFIED)

    def test_equal_authority_conflict_quarantines(self):
        result = ReconciliationEngine().reconcile([
            {"source": "repo-a", "source_type": "github_repository", "sha256": "a"},
            {"source": "repo-b", "source_type": "github_repository", "sha256": "b"},
        ])
        self.assertEqual(result.status, Status.CONFLICT_QUARANTINE)
