from __future__ import annotations

from pathlib import Path

from codeforge.connector_policy import ConnectorAdapterPolicy
from codeforge.connector_receipts import issue_connector_head_receipt, issue_connector_session_receipt
from codeforge.connector_transport import RecordingGitHubConnectorTransport, content_sha256
from codeforge.remote_capability import issue_capability_receipt
from codeforge.remote_lock import issue_remote_lock
from codeforge.remote_models import RemoteExecutionContract, RemoteOperationIntent
from codeforge.targets import AllowlistPolicy, RepositoryTarget


def build_connector_case(tmp: Path):
    repository = "candidate/codeforge"
    base_branch = "main"
    target_branch = "codeforge/phase5-connector-selftest"
    transport = RecordingGitHubConnectorTransport(repository)
    base_head = transport.seed(
        {
            "README.md": b"old\n",
            "src/old.py": b"print('old')\n",
            "docs/delete.md": b"delete\n",
        }
    )
    capability = issue_capability_receipt(
        provider="github",
        repository=repository,
        subject="connector-test",
        permissions=["read", "contents_write", "branch_write"],
        methods=["GET", "POST", "PUT", "DELETE"],
        evidence_id="EVD-phase5-capability",
    )
    lock = issue_remote_lock(
        target_identity=f"{repository}@{target_branch}",
        owner="connector-test",
        observed_head_sha=base_head,
        evidence_id="EVD-phase5-lock",
    )
    operations = [
        RemoteOperationIntent.from_bytes(
            "update", "README.md", b"new\n", expected_blob_sha256=content_sha256(b"old\n")
        ),
        RemoteOperationIntent.from_bytes("create", "src/new.py", b"print('new')\n"),
        RemoteOperationIntent.from_bytes(
            "delete", "docs/delete.md", None, expected_blob_sha256=content_sha256(b"delete\n")
        ),
    ]
    contract = RemoteExecutionContract(
        provider="github",
        repository=repository,
        base_branch=base_branch,
        target_branch=target_branch,
        expected_base_head_sha=base_head,
        operations=operations,
        proposal_id="PRP-phase5-test",
        proposal_digest="a" * 64,
        capability_evidence_id=capability["receipt_id"],
        lock_id=lock["lock_id"],
        execution_mode="CONTRACT_ONLY",
    ).seal().to_dict()
    session = issue_connector_session_receipt(
        provider="github",
        connector_instance_id="connector-fixture-001",
        principal="connector-test",
        repositories=[repository],
        permissions=["read", "contents_write", "branch_write"],
        methods=["GET", "POST", "PUT", "DELETE"],
        evidence_id="EVD-phase5-session",
    )
    head = issue_connector_head_receipt(
        provider="github",
        connector_session_id=session["session_id"],
        repository=repository,
        branch=base_branch,
        head_sha=base_head,
        evidence_id="EVD-phase5-head",
    )
    root = Path(__file__).resolve().parents[1]
    allowlist = AllowlistPolicy.from_file(root / "config" / "writer-allowlist.json")
    target = RepositoryTarget(repository, target_branch)
    allow_receipts = [allowlist.evaluate(target, op.path, op.operation) for op in operations]
    policy = ConnectorAdapterPolicy.from_file(root / "config" / "connector-adapter-policy.json")
    content = {"README.md": b"new\n", "src/new.py": b"print('new')\n"}
    runtime = {
        "execution": {
            "connector_candidate_test_execution_enabled": True,
            "connector_network_write_enabled": False,
            "real_remote_execution_enabled": False,
        }
    }
    return {
        "transport": transport,
        "contract": contract,
        "session": session,
        "head": head,
        "capability": capability,
        "lock": lock,
        "allow": allow_receipts,
        "policy": policy,
        "content": content,
        "runtime": runtime,
        "base_head": base_head,
    }


def build_gate_receipt(case):
    from codeforge.connector_gate import ConnectorCandidateGate
    return ConnectorCandidateGate(case["policy"]).evaluate(
        contract=case["contract"],
        session=case["session"],
        head_receipt=case["head"],
        capability=case["capability"],
        lock=case["lock"],
        allowlist_receipts=case["allow"],
        default_branch="main",
        target_branch_exists=False,
    )


def build_connector_plan(case, *, head_receipt=None, test_only=True):
    from codeforge.connector_plan import GitHubConnectorPlanBuilder
    gate = build_gate_receipt(case)
    return GitHubConnectorPlanBuilder().build(
        contract=case["contract"],
        session=case["session"],
        head_receipt=head_receipt or case["head"],
        capability=case["capability"],
        lock=case["lock"],
        allowlist_receipts=case["allow"],
        gate_receipt=gate,
        test_only=test_only,
    )
