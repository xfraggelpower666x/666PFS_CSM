from __future__ import annotations

from pathlib import Path
import shutil
import tempfile
import unittest

from codeforge.authorization import ExecutionAuthorizationRegistry, expected_authorization_phrase
from codeforge.local_executor import AtomicLocalSandboxExecutor, TransactionBlocked
from codeforge.targets import RemoteHeadClaim, RepositoryTarget
from phase3_helpers import build_proposal, make_tree, mark_target, runtime_config


class Phase3LocalExecutorTests(unittest.TestCase):
    def setup_case(self, root: Path):
        workspace = root / "workspace"; sandbox = workspace / "sandboxes"; sandbox.mkdir(parents=True)
        baseline, candidate = make_tree(root); target = sandbox / "target"; shutil.copytree(baseline, target); mark_target(target)
        proposal = build_proposal(baseline, candidate)
        executor = AtomicLocalSandboxExecutor(workspace)
        auth = executor.authorizations.issue(proposal, phrase=expected_authorization_phrase(proposal), issued_by="tester")
        head = RemoteHeadClaim(RepositoryTarget("local/codeforge", "implementation-phase3"), "a"*40, "a"*40, "EVD-head")
        return executor, candidate, target, proposal, auth, head, sandbox

    def test_atomic_create_update_delete_commit(self):
        with tempfile.TemporaryDirectory() as tmp:
            executor, candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp))
            receipt = executor.execute(proposal=proposal, authorization_id=auth["authorization_id"], candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox))
            self.assertEqual("PASS", receipt["status"])
            self.assertEqual("new\n", (target / "src/app.py").read_text())
            self.assertTrue((target / "docs/new.md").is_file())
            self.assertFalse((target / "old.txt").exists())
            self.assertEqual("keep\n", (target / "keep.txt").read_text())
            self.assertFalse(receipt["remote_mutation_performed"])

    def test_failure_after_swap_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            executor, candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp))
            def fail(stage, manifest):
                if stage == "APPLIED": raise RuntimeError("INJECTED")
            with self.assertRaises(TransactionBlocked) as caught:
                executor.execute(proposal=proposal, authorization_id=auth["authorization_id"], candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox), failure_hook=fail)
            self.assertEqual("PASS", caught.exception.receipt["status"])
            self.assertEqual("old\n", (target / "src/app.py").read_text())
            self.assertTrue((target / "old.txt").is_file())
            tx_root = next((Path(tmp) / "workspace" / "transactions").iterdir())
            import json
            manifest = json.loads((tx_root / "manifest.json").read_text())
            self.assertEqual("ROLLED_BACK", manifest["state"])

    def test_authorization_cannot_be_reused(self):
        with tempfile.TemporaryDirectory() as tmp:
            executor, candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp))
            executor.execute(proposal=proposal, authorization_id=auth["authorization_id"], candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox))
            with self.assertRaises(TransactionBlocked):
                executor.execute(proposal=proposal, authorization_id=auth["authorization_id"], candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox))

    def test_disabled_runtime_never_consumes_authorization(self):
        with tempfile.TemporaryDirectory() as tmp:
            executor, candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp))
            with self.assertRaises(TransactionBlocked):
                executor.execute(proposal=proposal, authorization_id=auth["authorization_id"], candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox, enabled=False))
            self.assertEqual("PASS", executor.authorizations.inspect(auth["authorization_id"])["status"])


if __name__ == "__main__": unittest.main()
