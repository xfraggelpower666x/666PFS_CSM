from __future__ import annotations

from pathlib import Path
import tempfile
import unittest
import zipfile

from codeforge.freeze_profiles import ClassifiedReleaseManager, FULL_FREEZE, RUNTIME_FREEZE


class Phase6FreezeProfileTests(unittest.TestCase):
    def test_runtime_excludes_history_full_includes_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "src"
            (root / "HISTORY" / "PHASE5").mkdir(parents=True)
            (root / "src").mkdir()
            (root / "src" / "code.py").write_text("x=1\n", encoding="utf-8")
            (root / "HISTORY" / "PHASE5" / "parent.zip").write_bytes(b"PK" + b"x" * 100)
            manager = ClassifiedReleaseManager()
            runtime = Path(tmp) / "runtime.zip"
            full = Path(tmp) / "full.zip"
            rr = manager.freeze(root, runtime, root_name="PACKAGE", profile=RUNTIME_FREEZE)
            fr = manager.freeze(root, full, root_name="PACKAGE", profile=FULL_FREEZE)
            with zipfile.ZipFile(runtime) as archive:
                self.assertFalse(any("/HISTORY/" in name for name in archive.namelist()))
                import json
                manifest_name = next(name for name in archive.namelist() if name.endswith("/FREEZE/RELEASE_MANIFEST.json"))
                self.assertEqual(json.loads(archive.read(manifest_name))["classification"], "RUNTIME_FREEZE")
            with zipfile.ZipFile(full) as archive:
                self.assertTrue(any("/HISTORY/" in name for name in archive.namelist()))
                import json
                manifest_name = next(name for name in archive.namelist() if name.endswith("/FREEZE/RELEASE_MANIFEST.json"))
                self.assertEqual(json.loads(archive.read(manifest_name))["classification"], "FULL_FREEZE")
            self.assertEqual(rr["classification"], "RUNTIME_FREEZE")
            self.assertEqual(fr["classification"], "FULL_FREEZE")
            self.assertGreater(full.stat().st_size, runtime.stat().st_size)

    def test_profile_freezes_are_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "src"
            root.mkdir()
            (root / "a.txt").write_text("hello\n", encoding="utf-8")
            manager = ClassifiedReleaseManager()
            a = Path(tmp) / "a.zip"
            b = Path(tmp) / "b.zip"
            ra = manager.freeze(root, a, root_name="PACKAGE", profile=FULL_FREEZE)
            rb = manager.freeze(root, b, root_name="PACKAGE", profile=FULL_FREEZE)
            self.assertEqual(ra["archive_sha256"], rb["archive_sha256"])


if __name__ == "__main__":
    unittest.main()
