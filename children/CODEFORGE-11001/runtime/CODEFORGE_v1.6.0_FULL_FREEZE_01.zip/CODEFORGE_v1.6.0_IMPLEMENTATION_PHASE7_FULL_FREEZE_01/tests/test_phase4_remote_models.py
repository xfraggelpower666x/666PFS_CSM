from __future__ import annotations
import unittest
from codeforge.remote_models import RemoteOperationIntent,RemoteExecutionContract
class RemoteModelsTests(unittest.TestCase):
    def contract(self):
        return RemoteExecutionContract("mock_github","mock/codeforge","main","codeforge/test","a"*40,[RemoteOperationIntent.from_bytes("create","README.md",b"x")],"P","b"*64,"E","L","MOCK_ONLY").seal()
    def test_operation_content_binding(self):self.assertEqual([],RemoteOperationIntent.from_bytes("create","a.txt",b"abc").validate())
    def test_tampered_content_detected(self):
        op=RemoteOperationIntent.from_bytes("create","a.txt",b"abc");op.content_sha256="0"*64;self.assertIn("CONTENT_SHA256_MISMATCH",op.validate())
    def test_delete_content_rejected(self):
        op=RemoteOperationIntent.from_bytes("delete","a.txt",b"x",expected_blob_sha256="a"*64);self.assertIn("DELETE_MUST_NOT_CONTAIN_CONTENT",op.validate())
    def test_update_requires_old_hash(self):self.assertIn("EXPECTED_BLOB_SHA256_MISSING",RemoteOperationIntent.from_bytes("update","a.txt",b"x").validate())
    def test_contract_passes(self):self.assertEqual("PASS",self.contract().validate()["status"])
    def test_contract_digest_tamper_blocks(self):
        c=self.contract();c.proposal_id="tamper";self.assertIn("REMOTE_CONTRACT_DIGEST_MISMATCH",c.validate()["reasons"])
    def test_duplicate_path_blocks(self):
        c=self.contract();c.operations.append(RemoteOperationIntent.from_bytes("create","README.md",b"y"));c.seal();self.assertTrue(any(r.startswith("DUPLICATE_PATH") for r in c.validate()["reasons"]))
    def test_mock_mode_wrong_provider_blocks(self):
        c=self.contract();c.provider="github";c.seal();self.assertIn("MOCK_MODE_PROVIDER_MISMATCH",c.validate()["reasons"])
if __name__=="__main__":unittest.main()
