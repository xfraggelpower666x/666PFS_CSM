import tempfile
import unittest
from pathlib import Path

from codeforge.controlled_writer import ControlledWriter
from codeforge.proposal import DryRunProposalEngine, ProposalBlocked
from codeforge.readback import ProposalReadbackVerifier
from codeforge.targets import AllowlistPolicy, RemoteHeadClaim, RepositoryTarget
from codeforge.writer_models import ProposalPrerequisites


class Phase2ProposalTests(unittest.TestCase):
    def prerequisites(self):
        return ProposalPrerequisites(
            evidence={"status": "VERIFIED", "evidence_ids": ["EVD-1"]},
            reconciliation={"status": "PASS", "evidence_ids": ["EVD-1"]},
            repair_plan={"status": "VERIFIED", "evidence_ids": ["DEC-1"]},
        )

    def make_policy(self):
        return AllowlistPolicy({
            "schema": "codeforge-writer-allowlist-v1",
            "repositories": {"owner/repo": {
                "branches": ["main"], "operations": ["create", "update", "delete"],
                "include": ["**"], "exclude": ["secrets/**"],
            }},
        })

    def test_verified_proposal_does_not_mutate_baseline(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); before = root / "before"; after = root / "after"; workspace = root / "workspace"
            before.mkdir(); after.mkdir()
            (before / "app.txt").write_text("old", encoding="utf-8")
            (after / "app.txt").write_text("new", encoding="utf-8")
            target = RepositoryTarget("owner/repo", "main")
            head = RemoteHeadClaim(target, "a" * 40, "a" * 40, "EVD-HEAD")
            proposal = DryRunProposalEngine(workspace).prepare(
                before, after, target=target, remote_head=head, policy=self.make_policy(), owner="test", prerequisites=self.prerequisites()
            )
            self.assertEqual((before / "app.txt").read_text(encoding="utf-8"), "old")
            self.assertFalse(proposal["execution_allowed"])
            self.assertFalse(proposal["mutation_performed"])
            self.assertEqual(proposal["lock_receipt"]["token"], "REDACTED")
            self.assertEqual(proposal["prerequisites"]["status"], "PASS")
            self.assertEqual(proposal["backup_receipt"]["status"], "PASS")
            readback = ProposalReadbackVerifier().verify(proposal, after)
            self.assertEqual(readback["status"], "PASS")
            execution = ControlledWriter().execute(proposal)
            self.assertEqual(execution["status"], "WRITE_BLOCKED")

    def test_unverified_prerequisites_block_proposal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); before = root / "before"; after = root / "after"
            before.mkdir(); after.mkdir()
            (after / "app.txt").write_text("new", encoding="utf-8")
            target = RepositoryTarget("owner/repo", "main")
            head = RemoteHeadClaim(target, "a" * 40, "a" * 40, "EVD-HEAD")
            invalid = ProposalPrerequisites(
                evidence={"status": "OPEN", "evidence_ids": []},
                reconciliation={"status": "PASS", "evidence_ids": ["EVD-1"]},
                repair_plan={"status": "VERIFIED", "evidence_ids": ["DEC-1"]},
            )
            with self.assertRaises(ProposalBlocked) as caught:
                DryRunProposalEngine(root / "workspace").prepare(
                    before, after, target=target, remote_head=head,
                    policy=self.make_policy(), owner="test", prerequisites=invalid
                )
            self.assertEqual(caught.exception.code, "PREREQUISITES_BLOCKED")

    def test_tampered_proposal_fails_integrity_readback(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); before = root / "before"; after = root / "after"
            before.mkdir(); after.mkdir()
            (before / "app.txt").write_text("old", encoding="utf-8")
            (after / "app.txt").write_text("new", encoding="utf-8")
            target = RepositoryTarget("owner/repo", "main")
            head = RemoteHeadClaim(target, "a" * 40, "a" * 40, "EVD-HEAD")
            proposal = DryRunProposalEngine(root / "workspace").prepare(
                before, after, target=target, remote_head=head,
                policy=self.make_policy(), owner="test", prerequisites=self.prerequisites()
            )
            proposal["operations"][0]["new_sha256"] = "0" * 64
            result = ProposalReadbackVerifier().verify(proposal, after)
            self.assertEqual(result["proposal_integrity"], "FAIL")
            self.assertEqual(result["status"], "FAIL")

    def test_secret_signal_blocks_proposal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); before = root / "before"; after = root / "after"
            before.mkdir(); after.mkdir()
            (after / "app.txt").write_text("Authorization: " + "Be" + "arer " + ("abc123" * 6), encoding="utf-8")
            target = RepositoryTarget("owner/repo", "main")
            head = RemoteHeadClaim(target, "a" * 40, "a" * 40, "EVD-HEAD")
            with self.assertRaises(ProposalBlocked) as caught:
                DryRunProposalEngine(root / "workspace").prepare(
                    before, after, target=target, remote_head=head, policy=self.make_policy(), owner="test", prerequisites=self.prerequisites()
                )
            self.assertEqual(caught.exception.code, "SECRET_GUARD_BLOCKED")
