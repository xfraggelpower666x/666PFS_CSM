import unittest

from codeforge.governance import MutationGate
from codeforge.status import Status


class GovernanceTests(unittest.TestCase):
    def test_phase_one_fails_closed(self):
        claims = MutationGate.REQUIRED
        result = MutationGate().evaluate(claims, phase=1, operation="proposal")
        self.assertFalse(result.allowed)
        self.assertEqual(result.status, Status.WRITE_BLOCKED)

    def test_phase_two_requires_all_claims(self):
        result = MutationGate().evaluate({"evidence_complete"}, phase=2, operation="proposal")
        self.assertFalse(result.allowed)
        self.assertIn("Missing required claims", result.reasons[0])

    def test_phase_two_allows_proposal_only(self):
        proposal = MutationGate().evaluate(MutationGate.REQUIRED, phase=2, operation="proposal")
        execution = MutationGate().evaluate(MutationGate.REQUIRED, phase=2, operation="execute")
        self.assertTrue(proposal.allowed)
        self.assertFalse(execution.allowed)
        self.assertEqual(execution.status, Status.WRITE_BLOCKED)
