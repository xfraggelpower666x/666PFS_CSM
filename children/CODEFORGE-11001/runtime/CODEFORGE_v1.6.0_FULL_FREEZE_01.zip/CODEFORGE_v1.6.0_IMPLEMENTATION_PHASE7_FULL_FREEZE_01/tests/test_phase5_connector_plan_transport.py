from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

from codeforge.connector_plan import CloudflareConnectorPlanBuilder, GitHubConnectorPlanBuilder
from codeforge.connector_transport import NullConnectorTransport, RecordingGitHubConnectorTransport
from codeforge.connector_receipts import issue_connector_head_receipt, issue_connector_session_receipt
from phase5_helpers import build_connector_case, build_connector_plan


class ConnectorPlanTransportTests(unittest.TestCase):
    def build(self, case, test_only=True):
        return build_connector_plan(case, test_only=test_only)

    def test_github_plan_has_branch_first(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case)["plan"]
            self.assertEqual("create_branch", plan["actions"][0]["action"])

    def test_github_plan_maps_operations(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); actions = [a["action"] for a in self.build(case)["plan"]["actions"]]
            self.assertEqual(["create_branch", "update_file", "create_file", "delete_file"], actions)

    def test_plan_head_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); head = deepcopy(case["head"]); head["head_sha"] = "f" * 40
            result = build_connector_plan(case, head_receipt=head)
            self.assertIn("CONNECTOR_HEAD_RECHECK_FAILED", result["reasons"])

    def test_null_transport_blocks(self):
        result = NullConnectorTransport().execute({"plan_id": "x"})
        self.assertEqual("WRITE_BLOCKED", result["status"]); self.assertFalse(result["mutation_performed"])

    def test_recording_transport_executes_test_plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case)["plan"]
            result = case["transport"].execute(plan, content_by_path=case["content"])
            self.assertEqual("PASS", result["status"]); self.assertTrue(result["mutation_performed"])

    def test_recording_transport_requires_test_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case, test_only=False)["plan"]
            result = case["transport"].execute(plan, content_by_path=case["content"])
            self.assertIn("RECORDING_CONNECTOR_REQUIRES_TEST_ONLY_PLAN", result["reasons"])

    def test_recording_transport_head_recheck(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case)["plan"]
            case["transport"].refs["main"] = "f" * 40
            result = case["transport"].execute(plan, content_by_path=case["content"])
            self.assertIn("CONNECTOR_HEAD_RECHECK_FAILED", result["reasons"])

    def test_recording_transport_existing_branch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case)["plan"]
            case["transport"].refs[plan["target_branch"]] = case["base_head"]
            result = case["transport"].execute(plan, content_by_path=case["content"])
            self.assertIn("CONNECTOR_TARGET_BRANCH_ALREADY_EXISTS", result["reasons"])

    def test_recording_transport_content_mismatch_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case)["plan"]; content = dict(case["content"]); content["README.md"] = b"wrong\n"
            result = case["transport"].execute(plan, content_by_path=content)
            self.assertEqual("ROLLED_BACK", result["status"]); self.assertFalse(case["transport"].branch_exists(plan["target_branch"]))

    def test_recording_transport_after_commit_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); plan = self.build(case)["plan"]
            result = case["transport"].execute(plan, content_by_path=case["content"], inject_failure="after_commit")
            self.assertEqual("ROLLED_BACK", result["status"]); self.assertFalse(case["transport"].branch_exists(plan["target_branch"]))

    def test_cloudflare_readback_plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            session = issue_connector_session_receipt(
                provider="cloudflare", connector_instance_id="cloudflare-fixture-001", principal="connector-test",
                repositories=["candidate/codeforge"], permissions=["read"], methods=["GET"], evidence_id="EVD-cf-session",
            )
            head = issue_connector_head_receipt(
                provider="cloudflare", connector_session_id=session["session_id"], repository="candidate/codeforge",
                branch="main", head_sha=case["base_head"], evidence_id="EVD-cf-head",
            )
            result = CloudflareConnectorPlanBuilder().build_readback_plan(
                repository="candidate/codeforge", branch="main", deployment_identity_path="666pfs-deployed-commit.json",
                session=session, head_receipt=head,
            )
            self.assertEqual("PASS", result["status"]); self.assertEqual("WRITE_BLOCKED", result["write_execution"])

    def test_cloudflare_write_plan_blocks(self):
        result = CloudflareConnectorPlanBuilder().build_write_plan()
        self.assertEqual("WRITE_BLOCKED", result["status"])


if __name__ == "__main__":
    unittest.main()
