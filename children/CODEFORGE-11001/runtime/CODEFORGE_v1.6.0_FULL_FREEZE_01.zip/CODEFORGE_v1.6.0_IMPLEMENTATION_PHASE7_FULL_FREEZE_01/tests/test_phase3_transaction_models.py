from __future__ import annotations

from pathlib import Path
import json
import tempfile
import unittest

from codeforge.transaction_journal import TransactionJournal
from codeforge.transaction_models import TransactionManifest, TransactionState, validate_transition


class Phase3TransactionModelTests(unittest.TestCase):
    def test_valid_state_chain(self):
        manifest = TransactionManifest("P", "d"*64, "A", "local/codeforge@implementation-phase3", "/tmp/t", "/tmp/c", 1).seal()
        for state in [TransactionState.AUTHORIZED, TransactionState.PREPARED, TransactionState.APPLIED, TransactionState.READBACK_PASS, TransactionState.COMMITTED]:
            manifest.transition(state)
        self.assertEqual(TransactionState.COMMITTED, manifest.state)

    def test_invalid_transition_blocks(self):
        with self.assertRaises(ValueError):
            validate_transition(TransactionState.PLANNED, TransactionState.COMMITTED)

    def test_manifest_digest_roundtrip(self):
        manifest = TransactionManifest("P", "d"*64, "A", "local/codeforge@implementation-phase3", "/tmp/t", "/tmp/c", 1).seal()
        loaded = TransactionManifest.from_dict(manifest.to_dict())
        self.assertEqual(manifest.transaction_id, loaded.transaction_id)

    def test_journal_hash_chain(self):
        with tempfile.TemporaryDirectory() as tmp:
            journal = TransactionJournal(Path(tmp) / "journal.jsonl")
            journal.append("TX", "PLANNED", {})
            journal.append("TX", "AUTHORIZED", {})
            self.assertEqual("PASS", journal.verify()["status"])

    def test_journal_tamper_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "journal.jsonl"; journal = TransactionJournal(path)
            journal.append("TX", "PLANNED", {})
            data = json.loads(path.read_text().strip()); data["state"] = "COMMITTED"; path.write_text(json.dumps(data)+"\n")
            self.assertEqual("FAIL", journal.verify()["status"])


if __name__ == "__main__": unittest.main()
