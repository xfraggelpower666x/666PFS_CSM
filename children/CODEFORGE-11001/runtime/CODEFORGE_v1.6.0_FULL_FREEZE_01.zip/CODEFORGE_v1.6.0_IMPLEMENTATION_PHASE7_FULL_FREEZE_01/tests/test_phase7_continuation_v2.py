import json
import tempfile
import unittest
from pathlib import Path
from codeforge.continuation import ContinuationKernel
from codeforge.models import Checkpoint

class ContinuationV2Tests(unittest.TestCase):
    def test_full_interruption_integration_reaudit_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            k=ContinuationKernel(tmp); k.initialize(); k.set_active_task({"id":"radio-agent","step":8101})
            k.checkpoint(Checkpoint("PHASE7","PASS",8101,8300,{"gate":1}))
            k.interrupt("coding agent also on radio repository")
            self.assertRaises(RuntimeError,k.resume)
            integrated=k.integrate_pending(); self.assertEqual(integrated[0]["integration_state"],"INTEGRATED")
            resumed=k.resume(); self.assertEqual(resumed["continuation_schema"],"codeforge-continuation-v2")
            self.assertEqual(resumed["reaudit"]["status"],"PASS")

    def test_tampered_checkpoint_blocks_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            k=ContinuationKernel(tmp); k.checkpoint(Checkpoint("P","PASS",1,2,{"x":1}))
            state=k.status(); state["last_checkpoint"]["payload"]["x"]=2; k.state_store.write(state)
            with self.assertRaisesRegex(RuntimeError,"checkpoint digest"):
                k.resume()

    def test_v1_state_migrates(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"continuation/state.json"; p.parent.mkdir(parents=True)
            p.write_text(json.dumps({"schema":"codeforge-continuation-v1","active_task":{"a":1},"last_checkpoint":None,"pending_interruptions":[],"resume_state":"IDLE"}))
            k=ContinuationKernel(tmp); k.initialize(); self.assertEqual(k.status()["schema"],"codeforge-continuation-v2")
