import unittest
from codeforge.child_candidate import build_universal_child_candidate, verify_universal_child_candidate

class ChildCandidateTests(unittest.TestCase):
    def test_universal_child_is_prepare_only(self):
        c=build_universal_child_candidate(version="1.6.0",freeze_sha256="b"*64,checkpoint="IMPLEMENTATION_PHASE7_9100")
        self.assertTrue(verify_universal_child_candidate(c))
        self.assertEqual(c["identity_scope"],"UNIVERSAL_CODING_AGENT")
        self.assertFalse(c["specializations"]["radio"]["part_of_child_identity"])
        self.assertFalse(c["registry_write_allowed"])

    def test_tamper_fails(self):
        c=build_universal_child_candidate(version="1.6.0",freeze_sha256="b"*64,checkpoint="IMPLEMENTATION_PHASE7_9100")
        c["status"]="REGISTERED"
        self.assertFalse(verify_universal_child_candidate(c))
