from __future__ import annotations

from pathlib import Path
from typing import Any
import copy
import json

from codeforge.hashchain import seal_document
from codeforge.models import stable_id, utc_now
from codeforge.targets import RepositoryTarget
from codeforge.verification import VerificationLayer
from codeforge.writer_models import proposal_digest


def write_file(root: Path, rel: str, text: str) -> None:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def operation(kind: str, rel: str, baseline: Path, candidate: Path) -> dict[str, Any]:
    old = baseline / rel
    new = candidate / rel
    return {
        "operation": kind,
        "path": rel,
        "old_sha256": VerificationLayer.sha256(old) if old.is_file() else None,
        "new_sha256": VerificationLayer.sha256(new) if new.is_file() else None,
        "old_size": old.stat().st_size if old.is_file() else None,
        "new_size": new.stat().st_size if new.is_file() else None,
    }


def build_proposal(baseline: Path, candidate: Path) -> dict[str, Any]:
    target = RepositoryTarget("local/codeforge", "implementation-phase3")
    operations = [
        operation("update", "src/app.py", baseline, candidate),
        operation("create", "docs/new.md", baseline, candidate),
        operation("delete", "old.txt", baseline, candidate),
    ]
    document = {
        "schema": "codeforge-change-proposal-v1",
        "target": target.to_dict(),
        "remote_head_sha": "a" * 40,
        "operations": operations,
        "policy_fingerprint": "POL-test",
        "backup_receipt": {"backup_id": "BKP-test", "entries": 2, "originals": 2, "crc": "PASS", "manifest_readback": "PASS", "sha256": "b" * 64, "status": "PASS"},
        "lock_receipt": {"acquired": True, "status": "PASS", "target": target.identity, "owner": "tester", "reasons": [], "acquired_at": utc_now(), "expires_at": utc_now()},
        "gate_receipt": {"allowed": True, "status": "PASS", "reasons": [], "operation": "proposal"},
        "rollback_plan": {"schema": "codeforge-rollback-plan-v1", "status": "PROPOSED"},
        "prerequisites": {"status": "PASS"},
        "remote_head_gate": {"status": "PASS"},
        "allowlist_receipts": [{"allowed": True, "path": item["path"]} for item in operations],
        "sensitive_guard": {"status": "PASS", "signals": []},
        "created_at": utc_now(),
        "state": "DRY_RUN_VERIFIED",
        "execution_allowed": False,
        "mutation_performed": False,
    }
    proposal_id = stable_id("PRP", {"operations": operations, "target": target.to_dict()})
    document["proposal_id"] = proposal_id
    document["digest"] = proposal_digest(document, proposal_id)
    return document


def make_tree(root: Path) -> tuple[Path, Path]:
    baseline = root / "baseline"
    candidate = root / "candidate"
    baseline.mkdir(); candidate.mkdir()
    write_file(baseline, "src/app.py", "old\n")
    write_file(baseline, "old.txt", "remove\n")
    write_file(baseline, "keep.txt", "keep\n")
    write_file(candidate, "src/app.py", "new\n")
    write_file(candidate, "docs/new.md", "created\n")
    write_file(candidate, "keep.txt", "keep\n")
    return baseline, candidate


def mark_target(target: Path) -> None:
    (target / ".codeforge-sandbox-target.json").write_text(json.dumps({
        "schema": "codeforge-sandbox-target-v1",
        "target_identity": "local/codeforge@implementation-phase3",
    }), encoding="utf-8")


def runtime_config(sandbox_root: Path, *, enabled: bool = True) -> dict[str, Any]:
    return {"execution": {
        "mode": "CONTROLLED_LOCAL_SANDBOX",
        "local_sandbox_enabled": enabled,
        "sandbox_root": str(sandbox_root.resolve()),
        "github_write_enabled": False,
        "cloudflare_write_enabled": False,
    }}
