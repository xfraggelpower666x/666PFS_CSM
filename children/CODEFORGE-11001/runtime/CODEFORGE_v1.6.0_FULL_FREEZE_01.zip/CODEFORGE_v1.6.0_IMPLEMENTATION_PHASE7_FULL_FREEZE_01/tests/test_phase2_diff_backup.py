import tempfile
import unittest
import zipfile
from pathlib import Path

from codeforge.prechange_backup import PreChangeBackup
from codeforge.scope_diff import ScopeDiffEngine


class Phase2DiffBackupTests(unittest.TestCase):
    def test_exact_diff_and_scope_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            before = root / "before"
            after = root / "after"
            before.mkdir(); after.mkdir()
            (before / "keep.txt").write_text("same", encoding="utf-8")
            (after / "keep.txt").write_text("same", encoding="utf-8")
            (before / "update.txt").write_text("old", encoding="utf-8")
            (after / "update.txt").write_text("new", encoding="utf-8")
            (before / "delete.txt").write_text("gone", encoding="utf-8")
            (after / "create.txt").write_text("born", encoding="utf-8")
            operations = ScopeDiffEngine().compare(before, after)
            self.assertEqual([(o.operation, o.path) for o in operations], [
                ("create", "create.txt"), ("delete", "delete.txt"), ("update", "update.txt")
            ])
            receipt = PreChangeBackup().create(
                before, operations, root / "backup.zip", target_identity="owner/repo@main", remote_head_sha="a" * 40
            )
            self.assertEqual(receipt["status"], "PASS")
            with zipfile.ZipFile(root / "backup.zip") as archive:
                self.assertIn("files/delete.txt", archive.namelist())
                self.assertIn("files/update.txt", archive.namelist())
                self.assertNotIn("files/create.txt", archive.namelist())
