from __future__ import annotations
from pathlib import Path
import tempfile,unittest
from codeforge.idempotency import IdempotencyRegistry
from codeforge.remote_authorization import RemoteExecutionAuthorizationRegistry,RemoteAuthorizationBlocked,expected_remote_authorization_phrase
from phase4_helpers import build_case
class RemoteAuthorizationIdempotencyTests(unittest.TestCase):
    def test_exact_phrase_issues(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));r=RemoteExecutionAuthorizationRegistry(Path(t)/"a").issue(c,phrase=expected_remote_authorization_phrase(c),issued_by="x");self.assertEqual("PASS",r["status"])
    def test_wrong_phrase_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));
            with self.assertRaises(RemoteAuthorizationBlocked):RemoteExecutionAuthorizationRegistry(Path(t)/"a").issue(c,phrase="wrong",issued_by="x")
    def test_real_provider_authorization_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));c=dict(c);c["provider"]="github";c["execution_mode"]="CONTRACT_ONLY"
            from codeforge.remote_models import RemoteExecutionContract
            obj=RemoteExecutionContract.from_dict(c);obj.seal();c=obj.to_dict()
            with self.assertRaises(RemoteAuthorizationBlocked):RemoteExecutionAuthorizationRegistry(Path(t)/"a").issue(c,phrase=expected_remote_authorization_phrase(c),issued_by="x")
    def test_authorization_single_use(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));reg=RemoteExecutionAuthorizationRegistry(Path(t)/"a");r=reg.issue(c,phrase=expected_remote_authorization_phrase(c),issued_by="x");reg.consume(r["authorization_id"],c);self.assertEqual("WRITE_BLOCKED",reg.inspect(r["authorization_id"])["status"])
    def test_idempotency_reserve(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));reg=IdempotencyRegistry(Path(t)/"i");self.assertEqual("PASS",reg.reserve(c)["status"])
    def test_idempotency_replay_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));reg=IdempotencyRegistry(Path(t)/"i");reg.reserve(c);self.assertEqual("WRITE_BLOCKED",reg.reserve(c)["status"])
    def test_idempotency_commit(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));reg=IdempotencyRegistry(Path(t)/"i");r=reg.reserve(c);self.assertEqual("PASS",reg.commit(r["key"],{"digest":"d"})["status"])
    def test_idempotency_release(self):
        with tempfile.TemporaryDirectory() as t:
            _,c,*_=build_case(Path(t));reg=IdempotencyRegistry(Path(t)/"i");r=reg.reserve(c);self.assertEqual("PASS",reg.release(r["key"],"test")["status"])
if __name__=="__main__":unittest.main()
