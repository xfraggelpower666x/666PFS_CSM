import tempfile
import unittest
from pathlib import Path

from codeforge.project_graph import ProjectGraphBuilder
from codeforge.scanner import RepositoryScanner


class ScannerGraphTests(unittest.TestCase):
    def test_scan_and_graph(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "index.html").write_text('<script src="js/app.js"></script>', encoding="utf-8")
            (root / "js").mkdir()
            (root / "js" / "app.js").write_text('console.log("ok")', encoding="utf-8")
            scan = RepositoryScanner().scan(root)
            self.assertEqual(scan.file_count, 2)
            graph = ProjectGraphBuilder().build(scan)
            self.assertEqual(graph["edge_count"], 1)
