from __future__ import annotations

from pathlib import Path

from codeforge.connector_execution_permit import issue_real_connector_execution_permit, required_execution_phrase
from codeforge.connector_host_runtime import RecordingHostGitHubInvoker, content_sha256
from phase5_helpers import build_connector_case, build_connector_plan


def build_phase6_case(tmp: Path):
    case = build_connector_case(tmp)
    plan_result = build_connector_plan(case, test_only=False)
    assert plan_result["status"] == "PASS"
    plan = plan_result["plan"]
    phrase = required_execution_phrase(plan["contract_id"], plan["plan_id"])
    permit = issue_real_connector_execution_permit(
        plan=plan,
        phrase=phrase,
        issued_by="phase6-test",
        environment="TEST_HOST_ADAPTER",
    )
    invoker = RecordingHostGitHubInvoker(case["contract"]["repository"])
    invoker.seed(case["contract"]["base_branch"], {
        "README.md": b"old\n",
        "src/old.py": b"print('old')\n",
        "docs/delete.md": b"delete\n",
    }, commit_sha=case["base_head"])
    runtime = {
        "execution": {
            "host_adapter_test_execution_enabled": True,
            "connector_network_write_enabled": False,
            "real_connector_execution_enabled": False,
            "github_write_enabled": False,
            "exact_authorization_required": True,
            "single_use_authorization_required": True,
            "remote_head_recheck_required": True,
            "readback_required": True,
            "automatic_rollback_required": True,
        }
    }
    return {**case, "plan": plan, "permit": permit, "phrase": phrase, "host_invoker": invoker, "host_runtime": runtime}
