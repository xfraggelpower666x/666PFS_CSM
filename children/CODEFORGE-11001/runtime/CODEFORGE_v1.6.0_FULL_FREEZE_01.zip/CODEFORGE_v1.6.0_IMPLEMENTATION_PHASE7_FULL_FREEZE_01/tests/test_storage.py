import tempfile
import unittest
from pathlib import Path

from codeforge.storage import AtomicJsonStore, JsonlLedger


class StorageTests(unittest.TestCase):
    def test_atomic_json_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = AtomicJsonStore(Path(tmp) / "state.json")
            store.write({"b": 2, "a": 1})
            self.assertEqual(store.read(), {"a": 1, "b": 2})

    def test_jsonl_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            ledger = JsonlLedger(Path(tmp) / "ledger.jsonl")
            ledger.append({"n": 1})
            ledger.append({"n": 2})
            self.assertEqual(ledger.read_all(), [{"n": 1}, {"n": 2}])
