from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

from codeforge.connector_gate import ConnectorCandidateGate
from phase5_helpers import build_connector_case


class ConnectorPolicyGateTests(unittest.TestCase):
    def gate(self, case, **overrides):
        values = {
            "contract": case["contract"], "session": case["session"], "head_receipt": case["head"],
            "capability": case["capability"], "lock": case["lock"], "allowlist_receipts": case["allow"],
            "default_branch": "main", "target_branch_exists": False,
        }
        values.update(overrides)
        return ConnectorCandidateGate(case["policy"]).evaluate(**values)

    def test_gate_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); self.assertEqual("PASS", self.gate(case)["status"])

    def test_existing_target_branch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); result = self.gate(case, target_branch_exists=True)
            self.assertIn("TARGET_BRANCH_MUST_BE_NEW", result["reasons"])

    def test_direct_default_branch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); contract = deepcopy(case["contract"])
            contract["target_branch"] = "main"
            result = self.gate(case, contract=contract)
            self.assertTrue(any("DEFAULT_BRANCH" in reason or "DIGEST" in reason for reason in result["reasons"]))

    def test_stale_head_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); head = deepcopy(case["head"])
            head["observed_at"] = "2020-01-01T00:00:00+00:00"
            result = self.gate(case, head_receipt=head)
            self.assertIn("CONNECTOR_HEAD_RECEIPT_STALE", result["reasons"])

    def test_head_digest_tamper_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); head = deepcopy(case["head"]); head["head_sha"] = "f" * 40
            result = self.gate(case, head_receipt=head)
            self.assertIn("CONNECTOR_HEAD_RECEIPT_DIGEST_MISMATCH", result["reasons"])

    def test_capability_binding_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); contract = deepcopy(case["contract"])
            contract["capability_evidence_id"] = "CAP-other"
            result = self.gate(case, contract=contract)
            self.assertIn("CONNECTOR_CAPABILITY_CONTRACT_MISMATCH", result["reasons"])

    def test_lock_binding_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); contract = deepcopy(case["contract"]); contract["lock_id"] = "RLK-other"
            result = self.gate(case, contract=contract)
            self.assertIn("CONNECTOR_LOCK_CONTRACT_MISMATCH", result["reasons"])

    def test_lock_target_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); lock = deepcopy(case["lock"]); lock["target_identity"] = "other/repo@codeforge/x"
            result = self.gate(case, lock=lock)
            self.assertIn("REMOTE_LOCK_TARGET_MISMATCH", result["reasons"])

    def test_allowlist_count_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); result = self.gate(case, allowlist_receipts=case["allow"][:-1])
            self.assertIn("CONNECTOR_ALLOWLIST_RECEIPT_COUNT_MISMATCH", result["reasons"])

    def test_allowlist_binding_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); allow = deepcopy(case["allow"]); allow[0]["path"] = "wrong.txt"
            result = self.gate(case, allowlist_receipts=allow)
            self.assertIn("CONNECTOR_ALLOWLIST_BINDING_MISMATCH:0", result["reasons"])

    def test_allowlist_denial_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); allow = deepcopy(case["allow"]); allow[1]["allowed"] = False
            result = self.gate(case, allowlist_receipts=allow)
            self.assertIn("CONNECTOR_ALLOWLIST_FAILED:1", result["reasons"])

    def test_policy_network_write_true_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); case["policy"].document["providers"]["github"]["network_write_enabled"] = True
            result = self.gate(case)
            self.assertIn("NETWORK_WRITE_POLICY_MUST_REMAIN_FALSE", result["reasons"])


if __name__ == "__main__":
    unittest.main()
