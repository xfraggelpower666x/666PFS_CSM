from __future__ import annotations
from pathlib import Path
import tempfile,unittest
from codeforge.remote_authorization import expected_remote_authorization_phrase
from codeforge.remote_gate import RemoteExecutionGate
from codeforge.remote_orchestrator import RemoteMockOrchestrator
from codeforge.idempotency import IdempotencyRegistry
from phase4_helpers import build_case
class RemoteGateOrchestratorTests(unittest.TestCase):
    def auth(self,orch,c):return orch.auth.issue(c,phrase=expected_remote_authorization_phrase(c),issued_by="tester")
    def test_gate_passes(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);res=orch.idempotency.reserve(c);g=RemoteExecutionGate().evaluate(contract=c,authorization=a,capability=cap,lock=lock,default_branch=r.default_branch,observed_base_head_sha=r.head("main"),target_branch_exists=False,allowlist_receipts=allow,idempotency_reservation=res,runtime_config=run);self.assertEqual("PASS",g["status"])
    def test_disabled_runtime_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));run["execution"]["mock_remote_execution_enabled"]=False;orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);res=orch.idempotency.reserve(c);g=RemoteExecutionGate().evaluate(contract=c,authorization=a,capability=cap,lock=lock,default_branch=r.default_branch,observed_base_head_sha=r.head("main"),target_branch_exists=False,allowlist_receipts=allow,idempotency_reservation=res,runtime_config=run);self.assertIn("MOCK_REMOTE_EXECUTION_DISABLED",g["reasons"])
    def test_allowlist_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));allow[0]["allowed"]=False;orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);res=orch.idempotency.reserve(c);g=RemoteExecutionGate().evaluate(contract=c,authorization=a,capability=cap,lock=lock,default_branch=r.default_branch,observed_base_head_sha=r.head("main"),target_branch_exists=False,allowlist_receipts=allow,idempotency_reservation=res,runtime_config=run);self.assertIn("REMOTE_SCOPE_ALLOWLIST_FAILED",g["reasons"])
    def test_orchestrator_commits(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);x=orch.execute(repository=r,contract=c,authorization_id=a["authorization_id"],capability=cap,lock=lock,allowlist_receipts=allow,runtime_config=run);self.assertEqual("PASS",x["status"]);self.assertTrue(x["mutation_performed"])
    def test_orchestrator_journal_passes(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);x=orch.execute(repository=r,contract=c,authorization_id=a["authorization_id"],capability=cap,lock=lock,allowlist_receipts=allow,runtime_config=run);self.assertEqual("PASS",x["journal"]["status"])
    def test_orchestrator_replay_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);orch.execute(repository=r,contract=c,authorization_id=a["authorization_id"],capability=cap,lock=lock,allowlist_receipts=allow,runtime_config=run);a2=self.auth(orch,c);x=orch.execute(repository=r,contract=c,authorization_id=a2["authorization_id"],capability=cap,lock=lock,allowlist_receipts=allow,runtime_config=run);self.assertEqual("WRITE_BLOCKED",x["status"])
    def test_orchestrator_failure_rolls_back(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);x=orch.execute(repository=r,contract=c,authorization_id=a["authorization_id"],capability=cap,lock=lock,allowlist_receipts=allow,runtime_config=run,inject_failure="after_commit");self.assertEqual("ROLLED_BACK",x["status"]);self.assertFalse(r.branch_exists(c["target_branch"]))
    def test_consumed_auth_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,cap,lock,allow,run=build_case(Path(t));orch=RemoteMockOrchestrator(Path(t)/"w");a=self.auth(orch,c);orch.auth.consume(a["authorization_id"],c);x=orch.execute(repository=r,contract=c,authorization_id=a["authorization_id"],capability=cap,lock=lock,allowlist_receipts=allow,runtime_config=run);self.assertEqual("WRITE_BLOCKED",x["status"])
if __name__=="__main__":unittest.main()
