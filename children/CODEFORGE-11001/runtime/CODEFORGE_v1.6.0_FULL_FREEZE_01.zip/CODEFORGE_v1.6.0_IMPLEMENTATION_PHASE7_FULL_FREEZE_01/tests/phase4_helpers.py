from __future__ import annotations
import hashlib
from pathlib import Path
from codeforge.mock_remote import MockRemoteRepository, blob_sha256
from codeforge.remote_models import RemoteExecutionContract, RemoteOperationIntent
from codeforge.remote_capability import issue_capability_receipt
from codeforge.remote_lock import issue_remote_lock
from codeforge.targets import AllowlistPolicy, RepositoryTarget

def build_case(tmp:Path):
    repo=MockRemoteRepository("mock/codeforge"); base=repo.seed({"README.md":b"old\n","src/old.py":b"print('old')\n","docs/delete.md":b"delete\n"})
    ops=[RemoteOperationIntent.from_bytes("update","README.md",b"new\n",expected_blob_sha256=blob_sha256(b"old\n")),RemoteOperationIntent.from_bytes("create","src/new.py",b"print('new')\n"),RemoteOperationIntent.from_bytes("delete","docs/delete.md",None,expected_blob_sha256=blob_sha256(b"delete\n"))]
    contract=RemoteExecutionContract(provider="mock_github",repository="mock/codeforge",base_branch="main",target_branch="codeforge/phase4-selftest",expected_base_head_sha=base,operations=ops,proposal_id="PRP-test",proposal_digest="a"*64,capability_evidence_id="EVD-cap",lock_id="RLK-placeholder",execution_mode="MOCK_ONLY")
    # lock id is bound after issue; reseal contract so both agree
    lock=issue_remote_lock(target_identity="mock/codeforge@codeforge/phase4-selftest",owner="tester",observed_head_sha=base,evidence_id="EVD-lock")
    contract.lock_id=lock["lock_id"]; contract.seal(); document=contract.to_dict()
    capability=issue_capability_receipt(provider="mock_github",repository="mock/codeforge",subject="tester",permissions=["read","contents_write","branch_write"],methods=["GET","POST","PUT","PATCH","DELETE"],evidence_id="EVD-cap")
    policy=AllowlistPolicy.from_file(str(Path(__file__).resolve().parents[1]/"config"/"writer-allowlist.json")); target=RepositoryTarget("mock/codeforge","codeforge/phase4-selftest")
    allow=[policy.evaluate(target,op.path,op.operation) for op in ops]
    runtime={"execution":{"mock_remote_execution_enabled":True,"real_remote_execution_enabled":False}}
    return repo,document,capability,lock,allow,runtime
