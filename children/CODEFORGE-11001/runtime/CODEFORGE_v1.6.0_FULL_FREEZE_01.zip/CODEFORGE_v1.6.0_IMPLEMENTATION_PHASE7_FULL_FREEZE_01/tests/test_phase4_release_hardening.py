from __future__ import annotations
from pathlib import Path
import tempfile,unittest,zipfile
from codeforge.release_manager import DeterministicReleaseManager
class ReleaseHardeningTests(unittest.TestCase):
 def test_existing_manifest_not_duplicated(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t)/"src"; (root/"FREEZE").mkdir(parents=True);(root/"a.txt").write_text("a");(root/"FREEZE"/"RELEASE_MANIFEST.json").write_text("{}")
   z=Path(t)/"x.zip";r=DeterministicReleaseManager().freeze(root,z,root_name="root");self.assertEqual("PASS",r["status"])
   with zipfile.ZipFile(z) as h:self.assertEqual(1,sum(n.endswith("/FREEZE/RELEASE_MANIFEST.json") for n in h.namelist()))
 def test_release_deterministic_after_hardening(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t)/"src";root.mkdir();(root/"a").write_text("x");a=Path(t)/"a.zip";b=Path(t)/"b.zip";m=DeterministicReleaseManager();m.freeze(root,a,root_name="root");m.freeze(root,b,root_name="root");self.assertEqual(a.read_bytes(),b.read_bytes())
if __name__=="__main__":unittest.main()
