import tempfile
import unittest
from pathlib import Path

from codeforge.locks import RepositoryLockManager
from codeforge.targets import RepositoryTarget


class Phase2LockTests(unittest.TestCase):
    def test_lock_conflict_and_token_release(self):
        with tempfile.TemporaryDirectory() as tmp:
            manager = RepositoryLockManager(Path(tmp))
            target = RepositoryTarget("owner/repo", "main")
            first = manager.acquire(target, "one")
            self.assertTrue(first.acquired)
            second = manager.acquire(target, "two")
            self.assertFalse(second.acquired)
            wrong = manager.release(target, "wrong")
            self.assertFalse(wrong["released"])
            right = manager.release(target, first.token)
            self.assertTrue(right["released"])
