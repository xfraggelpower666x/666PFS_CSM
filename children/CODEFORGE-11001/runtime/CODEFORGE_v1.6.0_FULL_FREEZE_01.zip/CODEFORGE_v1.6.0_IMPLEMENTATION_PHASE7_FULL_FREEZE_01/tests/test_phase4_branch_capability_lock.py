from __future__ import annotations
from datetime import datetime,timedelta,timezone
import unittest
from codeforge.branch_policy import BranchIsolationPolicy
from codeforge.remote_capability import issue_capability_receipt,validate_capability_receipt
from codeforge.remote_lock import issue_remote_lock,validate_remote_lock
class BranchCapabilityLockTests(unittest.TestCase):
    def test_isolated_branch_passes(self):self.assertEqual("PASS",BranchIsolationPolicy().evaluate(base_branch="main",target_branch="codeforge/x",default_branch="main",target_branch_exists=False)["status"])
    def test_default_branch_blocks(self):self.assertIn("DIRECT_DEFAULT_BRANCH_WRITE_FORBIDDEN",BranchIsolationPolicy().evaluate(base_branch="dev",target_branch="main",default_branch="main",target_branch_exists=False)["reasons"])
    def test_existing_branch_blocks(self):self.assertIn("TARGET_BRANCH_MUST_BE_NEW",BranchIsolationPolicy().evaluate(base_branch="main",target_branch="codeforge/x",default_branch="main",target_branch_exists=True)["reasons"])
    def test_prefix_required(self):self.assertIn("ISOLATED_BRANCH_PREFIX_REQUIRED",BranchIsolationPolicy().evaluate(base_branch="main",target_branch="repair/x",default_branch="main",target_branch_exists=False)["reasons"])
    def test_capability_passes(self):
        r=issue_capability_receipt(provider="mock_github",repository="mock/codeforge",subject="x",permissions=["read","contents_write","branch_write"],methods=["GET"],evidence_id="E");self.assertEqual("PASS",validate_capability_receipt(r,provider="mock_github",repository="mock/codeforge",require_mock_write=True)["status"])
    def test_capability_missing_write_blocks(self):
        r=issue_capability_receipt(provider="mock_github",repository="mock/codeforge",subject="x",permissions=["read"],methods=["GET"],evidence_id="E");self.assertIn("MOCK_WRITE_PERMISSIONS_INCOMPLETE",validate_capability_receipt(r,provider="mock_github",repository="mock/codeforge",require_mock_write=True)["reasons"])
    def test_capability_provider_mismatch(self):
        r=issue_capability_receipt(provider="mock_github",repository="mock/codeforge",subject="x",permissions=["read"],methods=["GET"],evidence_id="E");self.assertIn("CAPABILITY_PROVIDER_MISMATCH",validate_capability_receipt(r,provider="github",repository="mock/codeforge")["reasons"])
    def test_lock_passes(self):
        r=issue_remote_lock(target_identity="mock/codeforge@codeforge/x",owner="x",observed_head_sha="a"*40,evidence_id="E");self.assertEqual("PASS",validate_remote_lock(r,target_identity="mock/codeforge@codeforge/x",expected_head_sha="a"*40)["status"])
    def test_lock_head_mismatch(self):
        r=issue_remote_lock(target_identity="mock/codeforge@codeforge/x",owner="x",observed_head_sha="a"*40,evidence_id="E");self.assertIn("REMOTE_LOCK_HEAD_MISMATCH",validate_remote_lock(r,target_identity="mock/codeforge@codeforge/x",expected_head_sha="b"*40)["reasons"])
    def test_lock_target_mismatch(self):
        r=issue_remote_lock(target_identity="mock/codeforge@codeforge/x",owner="x",observed_head_sha="a"*40,evidence_id="E");self.assertIn("REMOTE_LOCK_TARGET_MISMATCH",validate_remote_lock(r,target_identity="mock/codeforge@codeforge/y",expected_head_sha="a"*40)["reasons"])
if __name__=="__main__":unittest.main()
