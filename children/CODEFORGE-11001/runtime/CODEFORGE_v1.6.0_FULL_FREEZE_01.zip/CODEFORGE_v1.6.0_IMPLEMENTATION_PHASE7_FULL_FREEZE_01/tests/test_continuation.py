import tempfile
import unittest
from pathlib import Path

from codeforge.continuation import ContinuationKernel
from codeforge.models import Checkpoint


class ContinuationTests(unittest.TestCase):
    def test_interruption_must_integrate_before_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            kernel = ContinuationKernel(Path(tmp))
            kernel.initialize()
            kernel.checkpoint(Checkpoint("PHASE1", "PASS", 1, 7, {"ok": True}))
            kernel.interrupt("new information")
            with self.assertRaises(RuntimeError):
                kernel.resume()
            integrated = kernel.integrate_pending()
            self.assertEqual(integrated[0]["integration_state"], "INTEGRATED")
            resumed = kernel.resume()
            self.assertEqual(resumed["resume_from"]["phase"], "PHASE1")
