from __future__ import annotations
import unittest
from codeforge.controlled_writer import ControlledWriter
from codeforge.governance import MutationGate
from codeforge.providers.github_contract import GitHubRemoteAdapterContract
from codeforge.providers.cloudflare_contract import CloudflareRemoteAdapterContract
class RealAdaptersBlockedTests(unittest.TestCase):
    def test_github_execute_blocked(self):self.assertEqual("WRITE_BLOCKED",GitHubRemoteAdapterContract().execute()["status"])
    def test_cloudflare_execute_blocked(self):self.assertEqual("WRITE_BLOCKED",CloudflareRemoteAdapterContract().execute()["status"])
    def test_github_plan_contract_only(self):self.assertFalse(GitHubRemoteAdapterContract().plan({"contract_id":"C"})["transport_available"])
    def test_cloudflare_contract_proposed(self):self.assertEqual("PROPOSED",CloudflareRemoteAdapterContract().deployment_contract(source_repository="x/y",source_commit="a"*40,production_origin="https://example.com")["status"])
    def test_cloudflare_http_blocks(self):self.assertEqual("WRITE_BLOCKED",CloudflareRemoteAdapterContract().deployment_contract(source_repository="x/y",source_commit="a"*40,production_origin="http://example.com")["status"])
    def test_writer_facade_blocks_github(self):self.assertFalse(ControlledWriter().execute({"proposal_id":"P"},provider="github")["mutation_performed"])
    def test_writer_facade_blocks_mock_direct(self):self.assertIn("ORCHESTRATOR",ControlledWriter().execute({"proposal_id":"P"},provider="mock_github")["reason"])
    def test_phase4_mock_gate_model(self):self.assertTrue(MutationGate().evaluate(MutationGate.REMOTE_MOCK_EXECUTION_REQUIRED,phase=4,operation="execute",provider="mock_github").allowed)
    def test_real_remote_gate_model_blocked(self):self.assertFalse(MutationGate().evaluate(MutationGate.REMOTE_MOCK_EXECUTION_REQUIRED,phase=4,operation="execute",provider="github").allowed)
if __name__=="__main__":unittest.main()
