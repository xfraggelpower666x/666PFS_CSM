import json
import tempfile
import unittest
from pathlib import Path

from codeforge.plugins.radio_intelligence import RadioIntelligencePlugin
from codeforge.scanner import RepositoryScanner


class RadioPluginTests(unittest.TestCase):
    def test_minimal_radio_topology(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "package.json").write_text(json.dumps({
                "version": "1.0.0",
                "scripts": {"check": "x", "test": "y", "verify": "z"}
            }), encoding="utf-8")
            (root / "worker.js").write_text('const routes=["/stream","/fallback-stream","/api/nowplaying"]', encoding="utf-8")
            (root / "index.html").write_text('<audio id="radio"></audio>', encoding="utf-8")
            scan = RepositoryScanner().scan(root)
            report = RadioIntelligencePlugin().analyse(scan)
            self.assertEqual(report["topology"]["package_version"], "1.0.0")
            self.assertFalse(any(f["code"] == "RADIO_ROUTE_NOT_OBSERVED" for f in report["findings"]))
