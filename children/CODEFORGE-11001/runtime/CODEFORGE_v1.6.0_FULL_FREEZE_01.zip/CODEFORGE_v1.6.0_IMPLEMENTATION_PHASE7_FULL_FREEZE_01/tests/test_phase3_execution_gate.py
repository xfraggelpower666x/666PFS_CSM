from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from codeforge.authorization import ExecutionAuthorizationRegistry, expected_authorization_phrase
from codeforge.execution_gate import ExecutionGate
from codeforge.targets import RemoteHeadClaim, RepositoryTarget
from phase3_helpers import build_proposal, make_tree, mark_target, runtime_config


class Phase3ExecutionGateTests(unittest.TestCase):
    def setup_case(self, root: Path):
        baseline, candidate = make_tree(root); sandbox = root / "sandboxes"; sandbox.mkdir(); target = sandbox / "target"
        import shutil; shutil.copytree(baseline, target); mark_target(target)
        proposal = build_proposal(baseline, candidate)
        registry = ExecutionAuthorizationRegistry(root / "workspace" / "authorizations")
        auth = registry.issue(proposal, phrase=expected_authorization_phrase(proposal), issued_by="tester")
        head = RemoteHeadClaim(RepositoryTarget("local/codeforge", "implementation-phase3"), "a"*40, "a"*40, "EVD-head")
        return candidate, target, proposal, auth, head, sandbox

    def test_gate_passes_for_marked_enabled_sandbox(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp))
            receipt = ExecutionGate().evaluate(proposal=proposal, authorization=auth, candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox))
            self.assertEqual("PASS", receipt["status"])

    def test_disabled_runtime_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp))
            receipt = ExecutionGate().evaluate(proposal=proposal, authorization=auth, candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox, enabled=False))
            self.assertIn("LOCAL_SANDBOX_EXECUTION_DISABLED", receipt["reasons"])

    def test_target_outside_sandbox_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); candidate, target, proposal, auth, head, sandbox = self.setup_case(root)
            receipt = ExecutionGate().evaluate(proposal=proposal, authorization=auth, candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(root / "other"))
            self.assertIn("TARGET_OUTSIDE_SANDBOX_ROOT", receipt["reasons"])

    def test_marker_missing_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate, target, proposal, auth, head, sandbox = self.setup_case(Path(tmp)); (target / ".codeforge-sandbox-target.json").unlink()
            receipt = ExecutionGate().evaluate(proposal=proposal, authorization=auth, candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox))
            self.assertIn("SANDBOX_TARGET_MARKER_MISSING", receipt["reasons"])

    def test_remote_head_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate, target, proposal, auth, _, sandbox = self.setup_case(Path(tmp))
            head = RemoteHeadClaim(RepositoryTarget("local/codeforge", "implementation-phase3"), "a"*40, "b"*40, "EVD-head")
            receipt = ExecutionGate().evaluate(proposal=proposal, authorization=auth, candidate=candidate, target=target, remote_head=head, runtime_config=runtime_config(sandbox))
            self.assertIn("REMOTE_HEAD_RECHECK_FAILED", receipt["reasons"])


if __name__ == "__main__": unittest.main()
