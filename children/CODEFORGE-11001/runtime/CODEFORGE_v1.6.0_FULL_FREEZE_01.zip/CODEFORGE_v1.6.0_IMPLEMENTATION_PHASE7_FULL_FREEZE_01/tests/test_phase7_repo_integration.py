import tempfile
import unittest
from pathlib import Path
from codeforge.repo_integration import RepositoryIntegrationPolicy, RepositorySnapshotBuilder

class RepoIntegrationTests(unittest.TestCase):
    def test_policy_blocks_production_branch(self):
        with self.assertRaises(ValueError):
            RepositoryIntegrationPolicy("x/y","WebRadio-666SOUNDsDESIGn").validate()

    def test_manifest_materialize_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); artifact=base/"runtime.zip"; artifact.write_bytes(b"runtime")
            cont={"digest":"a"*64}
            policy=RepositoryIntegrationPolicy("x/y","codeforge/framework-v1.6.0-phase7")
            b=RepositorySnapshotBuilder(policy)
            files={"releases/runtime.zip":artifact}
            m=b.build_manifest(files,version="1.6.0",checkpoint="IMPLEMENTATION_PHASE7_9100",continuation_state=cont)
            dest=base/"repo"; b.materialize(dest,files,m,cont)
            self.assertEqual(b.verify_manifest(m,dest)["status"],"PASS")
            (dest/"engineering/codeforge/releases/runtime.zip").write_bytes(b"tampered")
            self.assertEqual(b.verify_manifest(m,dest)["status"],"FAIL")

    def test_path_escape_blocked(self):
        p=RepositoryIntegrationPolicy("x/y","codeforge/framework-v1.6.0-phase7")
        b=RepositorySnapshotBuilder(p)
        with self.assertRaises(ValueError): b._validate_rel("../../worker.js")
