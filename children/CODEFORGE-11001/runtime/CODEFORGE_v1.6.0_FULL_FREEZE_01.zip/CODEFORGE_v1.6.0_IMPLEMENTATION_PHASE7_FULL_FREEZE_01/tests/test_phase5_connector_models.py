from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
import tempfile
import unittest

from codeforge.connector_models import ConnectorAction, ConnectorActionPlan, ConnectorHeadReceipt, ConnectorSessionReceipt
from codeforge.connector_plan import GitHubConnectorPlanBuilder
from phase5_helpers import build_connector_case, build_connector_plan


class ConnectorModelsTests(unittest.TestCase):
    def test_session_receipt_validates(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = ConnectorSessionReceipt.from_dict(case["session"]).validate(
                provider="github",
                repository="candidate/codeforge",
                required_permissions={"read", "contents_write", "branch_write"},
                required_methods={"GET", "POST", "PUT", "DELETE"},
            )
            self.assertEqual("PASS", result["status"])

    def test_session_provider_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = ConnectorSessionReceipt.from_dict(case["session"]).validate(
                provider="cloudflare", repository="candidate/codeforge",
                required_permissions={"read"}, required_methods={"GET"},
            )
            self.assertIn("CONNECTOR_SESSION_PROVIDER_MISMATCH", result["reasons"])

    def test_session_repository_scope_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = ConnectorSessionReceipt.from_dict(case["session"]).validate(
                provider="github", repository="other/repo",
                required_permissions={"read"}, required_methods={"GET"},
            )
            self.assertIn("CONNECTOR_REPOSITORY_SCOPE_MISSING", result["reasons"])

    def test_session_permission_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); document = deepcopy(case["session"])
            document["permissions"] = ["read"]
            result = ConnectorSessionReceipt.from_dict(document).validate(
                provider="github", repository="candidate/codeforge",
                required_permissions={"read", "contents_write"}, required_methods={"GET"},
            )
            self.assertIn("CONNECTOR_PERMISSIONS_INCOMPLETE", result["reasons"])

    def test_session_digest_tamper_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); document = deepcopy(case["session"])
            document["principal"] = "tampered"
            result = ConnectorSessionReceipt.from_dict(document).validate(
                provider="github", repository="candidate/codeforge",
                required_permissions={"read"}, required_methods={"GET"},
            )
            self.assertIn("CONNECTOR_SESSION_DIGEST_MISMATCH", result["reasons"])

    def test_session_expired_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            future = datetime.now(timezone.utc) + timedelta(hours=1)
            result = ConnectorSessionReceipt.from_dict(case["session"]).validate(
                provider="github", repository="candidate/codeforge",
                required_permissions={"read"}, required_methods={"GET"}, now=future,
            )
            self.assertIn("CONNECTOR_SESSION_EXPIRED", result["reasons"])

    def test_head_receipt_validates(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = ConnectorHeadReceipt.from_dict(case["head"]).validate(
                provider="github", connector_session_id=case["session"]["session_id"],
                repository="candidate/codeforge", branch="main", expected_head_sha=case["base_head"],
            )
            self.assertEqual("PASS", result["status"])

    def test_head_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = ConnectorHeadReceipt.from_dict(case["head"]).validate(
                provider="github", connector_session_id=case["session"]["session_id"],
                repository="candidate/codeforge", branch="main", expected_head_sha="f" * 40,
            )
            self.assertIn("CONNECTOR_HEAD_RECHECK_FAILED", result["reasons"])

    def test_head_session_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            result = ConnectorHeadReceipt.from_dict(case["head"]).validate(
                provider="github", connector_session_id="CSE-other",
                repository="candidate/codeforge", branch="main", expected_head_sha=case["base_head"],
            )
            self.assertIn("CONNECTOR_HEAD_SESSION_MISMATCH", result["reasons"])

    def test_action_create_validates(self):
        action = ConnectorAction(1, "create_file", "a/b", "codeforge/x", "x.txt", None, "a" * 64, 1)
        self.assertEqual([], action.validate())

    def test_action_update_requires_expected_sha(self):
        action = ConnectorAction(1, "update_file", "a/b", "codeforge/x", "x.txt", None, "a" * 64, 1)
        self.assertIn("ACTION_EXPECTED_SHA_MISSING", action.validate())

    def test_action_unsafe_path_blocks(self):
        action = ConnectorAction(1, "create_file", "a/b", "codeforge/x", "../x", None, "a" * 64, 1)
        self.assertIn("ACTION_PATH_UNSAFE", action.validate())

    def test_plan_validates(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            built = build_connector_plan(case, test_only=True)
            self.assertEqual("PASS", ConnectorActionPlan.from_dict(built["plan"]).validate()["status"])

    def test_plan_digest_tamper_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            built = build_connector_plan(case, test_only=True)
            document = deepcopy(built["plan"]); document["target_branch"] = "codeforge/tampered"
            result = ConnectorActionPlan.from_dict(document).validate()
            self.assertIn("CONNECTOR_PLAN_DIGEST_MISMATCH", result["reasons"])

    def test_plan_sequence_tamper_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp))
            built = build_connector_plan(case, test_only=True)
            document = deepcopy(built["plan"]); document["actions"][1]["sequence"] = 99
            result = ConnectorActionPlan.from_dict(document).validate()
            self.assertTrue(any("SEQUENCE_MISMATCH" in reason for reason in result["reasons"]))


if __name__ == "__main__":
    unittest.main()
