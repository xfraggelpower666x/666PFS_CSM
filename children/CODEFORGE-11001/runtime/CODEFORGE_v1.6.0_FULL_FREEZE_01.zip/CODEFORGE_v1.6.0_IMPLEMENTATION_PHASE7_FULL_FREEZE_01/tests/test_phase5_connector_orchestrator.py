from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from codeforge.connector_gate import ConnectorCandidateGate
from codeforge.connector_orchestrator import ConnectorCandidateOrchestrator
from phase5_helpers import build_connector_case


class ConnectorOrchestratorTests(unittest.TestCase):
    def prepare(self, tmp, case, test_only=True):
        orchestrator = ConnectorCandidateOrchestrator(Path(tmp) / "workspace", ConnectorCandidateGate(case["policy"]))
        result = orchestrator.prepare(
            contract=case["contract"], session=case["session"], head_receipt=case["head"],
            capability=case["capability"], lock=case["lock"], allowlist_receipts=case["allow"],
            default_branch="main", target_branch_exists=False, test_only=test_only,
        )
        return orchestrator, result

    def test_prepare_passes_without_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); _, result = self.prepare(tmp, case)
            self.assertEqual("PASS", result["status"]); self.assertFalse(result["mutation_performed"])

    def test_real_execution_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            result = orchestrator.execute_real(prepared["plan"])
            self.assertEqual("WRITE_BLOCKED", result["status"])

    def test_recording_execution_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            result = orchestrator.execute_recording_test(
                transport=case["transport"], plan=prepared["plan"], content_by_path=case["content"], runtime_config=case["runtime"],
            )
            self.assertEqual("PASS", result["status"]); self.assertEqual("PASS", result["readback"]["status"])

    def test_test_execution_default_off(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            runtime = {"execution": {"connector_candidate_test_execution_enabled": False}}
            result = orchestrator.execute_recording_test(
                transport=case["transport"], plan=prepared["plan"], content_by_path=case["content"], runtime_config=runtime,
            )
            self.assertEqual("WRITE_BLOCKED", result["status"])

    def test_execution_journal_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            result = orchestrator.execute_recording_test(
                transport=case["transport"], plan=prepared["plan"], content_by_path=case["content"], runtime_config=case["runtime"],
            )
            self.assertEqual("PASS", result["journal"]["status"]); self.assertEqual(3, result["journal"]["records"])

    def test_after_commit_failure_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            result = orchestrator.execute_recording_test(
                transport=case["transport"], plan=prepared["plan"], content_by_path=case["content"], runtime_config=case["runtime"], inject_failure="after_commit",
            )
            self.assertEqual("ROLLED_BACK", result["status"]); self.assertFalse(result["mutation_performed"])

    def test_readback_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            result = orchestrator.execute_recording_test(
                transport=case["transport"], plan=prepared["plan"], content_by_path=case["content"], runtime_config=case["runtime"],
            )
            tree = case["transport"].tree(prepared["plan"]["target_branch"])
            self.assertEqual(b"new\n", tree["README.md"]); self.assertNotIn("docs/delete.md", tree)

    def test_network_never_used(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_connector_case(Path(tmp)); orchestrator, prepared = self.prepare(tmp, case)
            result = orchestrator.execute_recording_test(
                transport=case["transport"], plan=prepared["plan"], content_by_path=case["content"], runtime_config=case["runtime"],
            )
            self.assertFalse(result["network_used"]); self.assertFalse(result["execution"]["network_used"])


if __name__ == "__main__":
    unittest.main()
