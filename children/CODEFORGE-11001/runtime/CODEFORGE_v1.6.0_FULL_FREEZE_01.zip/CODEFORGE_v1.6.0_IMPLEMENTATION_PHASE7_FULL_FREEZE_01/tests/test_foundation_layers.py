import tempfile
import unittest
import zipfile
from pathlib import Path

from codeforge.bootstrap import BootstrapPipeline
from codeforge.import_gate import ImportGate
from codeforge.ledgers import AuditLedger, RepairLedger
from codeforge.recovery import RecoveryPipeline
from codeforge.verification import VerificationLayer
from codeforge.kernels import (
    CoreKernel, ContinuationKernel, KnowledgeKernel, EngineeringKernel,
    MutationGate, ProjectIntelligenceKernel,
)


class FoundationLayerTests(unittest.TestCase):
    def test_kernel_surface_and_bootstrap(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = BootstrapPipeline(Path(tmp) / "workspace").run()
            self.assertEqual(result["checkpoint"]["phase"], "BOOTSTRAP")
            self.assertTrue(all([
                CoreKernel, ContinuationKernel, KnowledgeKernel, EngineeringKernel,
                MutationGate, ProjectIntelligenceKernel,
            ]))

    def test_import_gate_zip_crc_and_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source"
            source.mkdir()
            (source / "file.txt").write_text("hello", encoding="utf-8")
            archive = root / "evidence.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.write(source / "file.txt", "file.txt")
            gate = ImportGate().inspect(archive)
            self.assertTrue(gate.accepted)
            self.assertEqual(gate.crc, "PASS")
            backup = RecoveryPipeline().create_workspace_backup(source, root / "backup.zip")
            self.assertEqual(backup["status"], "PASS")
            check = VerificationLayer().verify_file(root / "backup.zip", backup["sha256"])
            self.assertEqual(check["status"], "PASS")

    def test_audit_and_repair_ledgers(self):
        with tempfile.TemporaryDirectory() as tmp:
            audit = AuditLedger(Path(tmp) / "audit.jsonl")
            repair = RepairLedger(Path(tmp) / "repair.jsonl")
            audit.record("analysis", "PASS", {"x": 1})
            repair.propose("FND-1", "minimal repair", ["a.js"], ["EVD-1"])
            self.assertEqual(len(audit.all()), 1)
            self.assertEqual(repair.all()[0]["state"], "PROPOSED")
