from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from codeforge.connector_execution_permit import issue_real_connector_execution_permit
from codeforge.connector_host_runtime import HostConnectorExecutionAdapter, RecordingHostGitHubInvoker
from phase6_helpers import build_phase6_case


class Phase6HostRuntimeTests(unittest.TestCase):
    def test_default_runtime_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            runtime = {"execution": {"host_adapter_test_execution_enabled": False, "connector_network_write_enabled": False}}
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=runtime, invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "WRITE_BLOCKED")

    def test_recording_host_transaction_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "PASS")
            self.assertTrue(result["mutation_performed"])
            self.assertFalse(result["network_used"])
            self.assertEqual(result["journal"]["status"], "PASS")

    def test_permit_replay_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            adapter = HostConnectorExecutionAdapter(Path(tmp) / "workspace")
            first = adapter.execute_test(plan=case["plan"], permit=case["permit"], content_by_path=case["content"], runtime=case["host_runtime"], invoker=case["host_invoker"])
            second = adapter.execute_test(plan=case["plan"], permit=case["permit"], content_by_path=case["content"], runtime=case["host_runtime"], invoker=case["host_invoker"])
            self.assertEqual(first["status"], "PASS")
            self.assertEqual(second["status"], "WRITE_BLOCKED")

    def test_content_tamper_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            content = dict(case["content"])
            content["README.md"] = b"tampered\n"
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=content,
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "ROLLED_BACK")
            self.assertEqual(result["rollback_ref_reset"], "PASS")
            self.assertEqual(case["host_invoker"].refs[case["contract"]["target_branch"]], case["base_head"])

    def test_injected_failure_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"], inject_failure="after:README.md",
            )
            self.assertEqual(result["status"], "ROLLED_BACK")
            self.assertEqual(result["branch_cleanup"], "READBACK_PENDING")

    def test_head_drift_rolls_back_without_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            case["host_invoker"].seed(case["contract"]["base_branch"], {"README.md": b"advanced\n"})
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "FAIL")
            self.assertIn("HEAD_RECHECK", result["reason"])

    def test_missing_exact_head_action_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            case["host_invoker"].supported_actions.remove("GitHub.read_branch_head")
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "WRITE_BLOCKED")

    def test_real_execution_remains_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_real(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "WRITE_BLOCKED")
            self.assertFalse(result["mutation_performed"])

    def test_invocation_log_never_contains_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=case["plan"], permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "PASS")
            for item in case["host_invoker"].invocations:
                self.assertNotIn("content", item["arguments"])

    def test_real_target_allowlist_empty_blocks_even_with_runtime_flags(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            from codeforge.connector_execution_permit import issue_real_connector_execution_permit
            real_permit = issue_real_connector_execution_permit(
                plan=case["plan"], phrase=case["phrase"], issued_by="phase6-test",
                environment="REAL_CONNECTOR_CANDIDATE",
            )
            case["host_invoker"].mode = "REAL_CONNECTOR"
            case["host_invoker"].network_used = True
            runtime = {"execution": {
                "real_connector_execution_enabled": True, "connector_network_write_enabled": True,
                "github_write_enabled": True, "exact_authorization_required": True,
                "single_use_authorization_required": True, "remote_head_recheck_required": True,
                "readback_required": True, "automatic_rollback_required": True,
                "real_target_allowlist": [],
            }}
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_real(
                plan=case["plan"], permit=real_permit, content_by_path=case["content"],
                runtime=runtime, invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "WRITE_BLOCKED")
            self.assertIn("REAL_CONNECTOR_TARGET_NOT_ALLOWLISTED", result["reasons"])

    def test_non_isolated_target_branch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_phase6_case(Path(tmp))
            plan = dict(case["plan"]); plan["target_branch"] = plan["base_branch"]
            result = HostConnectorExecutionAdapter(Path(tmp) / "workspace").execute_test(
                plan=plan, permit=case["permit"], content_by_path=case["content"],
                runtime=case["host_runtime"], invoker=case["host_invoker"],
            )
            self.assertEqual(result["status"], "WRITE_BLOCKED")
            self.assertIn("HOST_CONNECTOR_ISOLATED_BRANCH_REQUIRED", result["reasons"])


if __name__ == "__main__":
    unittest.main()
