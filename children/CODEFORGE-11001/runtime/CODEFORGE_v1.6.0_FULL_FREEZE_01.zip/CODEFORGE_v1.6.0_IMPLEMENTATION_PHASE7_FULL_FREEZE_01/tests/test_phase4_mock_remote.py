from __future__ import annotations
from pathlib import Path
import tempfile,unittest
from codeforge.mock_remote import MockRemoteRepository,blob_sha256
from codeforge.remote_readback import MockRemoteReadbackVerifier
from phase4_helpers import build_case
class MockRemoteTests(unittest.TestCase):
    def test_seed_head(self):
        r=MockRemoteRepository("mock/x");h=r.seed({"a":b"x"});self.assertEqual(h,r.head("main"))
    def test_execute_contract(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));x=r.execute_contract(c);self.assertEqual("PASS",x["status"]);self.assertTrue(r.branch_exists(c["target_branch"]))
    def test_update_content(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));r.execute_contract(c);self.assertEqual(b"new\n",r.tree(c["target_branch"])["README.md"])
    def test_create_content(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));r.execute_contract(c);self.assertIn("src/new.py",r.tree(c["target_branch"]))
    def test_delete_content(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));r.execute_contract(c);self.assertNotIn("docs/delete.md",r.tree(c["target_branch"]))
    def test_existing_target_branch_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));r.execute_contract(c);self.assertEqual("WRITE_BLOCKED",r.execute_contract(c)["status"])
    def test_head_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));c=dict(c);c["expected_base_head_sha"]="b"*40;self.assertEqual("WRITE_BLOCKED",r.execute_contract(c)["status"])
    def test_after_commit_failure_rolls_back(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));x=r.execute_contract(c,inject_failure="after_commit");self.assertEqual("ROLLED_BACK",x["status"]);self.assertFalse(r.branch_exists(c["target_branch"]))
    def test_readback_passes(self):
        with tempfile.TemporaryDirectory() as t:
            r,c,*_=build_case(Path(t));x=r.execute_contract(c);self.assertEqual("PASS",MockRemoteReadbackVerifier().verify(repository=r,contract=c,execution_receipt=x)["status"])
    def test_tree_digest_changes(self):
        r=MockRemoteRepository("mock/x");r.seed({"a":b"x"});a=r.tree_digest("main");r.seed({"a":b"y"},branch="other");self.assertNotEqual(a,r.tree_digest("other"))
if __name__=="__main__":unittest.main()
