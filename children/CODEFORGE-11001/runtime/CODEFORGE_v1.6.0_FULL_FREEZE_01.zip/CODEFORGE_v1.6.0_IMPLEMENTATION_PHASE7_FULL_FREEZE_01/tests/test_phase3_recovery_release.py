from __future__ import annotations

from pathlib import Path
import json
import os
import tempfile
import unittest

from codeforge.incremental import IncrementalInventory
from codeforge.release_manager import DeterministicReleaseManager
from codeforge.storage import AtomicJsonStore
from codeforge.transaction_journal import TransactionJournal
from codeforge.transaction_models import TransactionManifest, TransactionState
from codeforge.transaction_recovery import TransactionRecovery
from phase3_helpers import write_file


class Phase3RecoveryReleaseTests(unittest.TestCase):
    def test_recovery_restores_retained_baseline(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); target=root/"target"; target.mkdir(); write_file(target,"state.txt","new")
            tx=root/"tx"; tx.mkdir(); baseline=tx/"replaced-baseline"; baseline.mkdir(); write_file(baseline,"state.txt","old")
            manifest=TransactionManifest("P","d"*64,"A","local/codeforge@implementation-phase3",str(target),str(root/"candidate"),1).seal()
            manifest.transition(TransactionState.AUTHORIZED).transition(TransactionState.PREPARED).transition(TransactionState.APPLIED)
            AtomicJsonStore(tx/"manifest.json").write(manifest.to_dict())
            journal=TransactionJournal(tx/"journal.jsonl")
            journal.append(manifest.transaction_id,"PLANNED",{}); journal.append(manifest.transaction_id,"AUTHORIZED",{}); journal.append(manifest.transaction_id,"PREPARED",{}); journal.append(manifest.transaction_id,"APPLIED",{})
            receipt=TransactionRecovery().recover(tx)
            self.assertEqual("PASS",receipt["status"]); self.assertEqual("old",(target/"state.txt").read_text())

    def test_invalid_manifest_quarantines(self):
        with tempfile.TemporaryDirectory() as tmp:
            tx=Path(tmp); (tx/"manifest.json").write_text('{"schema":"bad"}')
            self.assertEqual("CONFLICT_QUARANTINE",TransactionRecovery().inspect(tx)["status"])

    def test_release_freeze_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); source=root/"source"; source.mkdir(); write_file(source,"a.txt","A"); write_file(source,"sub/b.txt","B")
            archive=root/"release.zip"; manager=DeterministicReleaseManager(); receipt=manager.freeze(source,archive,root_name="RELEASE")
            self.assertEqual("PASS",receipt["status"]); self.assertEqual("PASS",manager.verify(archive,expected_root="RELEASE")["status"])


    def test_release_is_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); source=root/"source"; source.mkdir(); write_file(source,"a.txt","A"); write_file(source,"sub/b.txt","B")
            manager=DeterministicReleaseManager(); first=root/"one.zip"; second=root/"two.zip"
            one=manager.freeze(source,first,root_name="RELEASE")
            two=manager.freeze(source,second,root_name="RELEASE")
            self.assertEqual(one["archive_sha256"],two["archive_sha256"])

    def test_release_wrong_root_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); source=root/"source"; source.mkdir(); write_file(source,"a.txt","A")
            archive=root/"release.zip"; manager=DeterministicReleaseManager(); manager.freeze(source,archive,root_name="RELEASE")
            self.assertEqual("FAIL",manager.verify(archive,expected_root="OTHER")["status"])

    def test_incremental_inventory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); repo=root/"repo"; repo.mkdir(); write_file(repo,"a.txt","A")
            inv=IncrementalInventory(root/"cache.json"); first=inv.scan(repo); self.assertEqual(["a.txt"],first["created"])
            write_file(repo,"a.txt","B"); write_file(repo,"b.txt","C"); second=inv.scan(repo)
            self.assertEqual(["b.txt"],second["created"]); self.assertEqual(["a.txt"],second["updated"])


if __name__ == "__main__": unittest.main()
