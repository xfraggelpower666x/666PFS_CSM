from __future__ import annotations

from pathlib import Path
import json
import tempfile
import unittest

import codeforge
from codeforge.core import CoreKernel
from codeforge.governance import MutationGate


class Phase5CoreGovernanceTests(unittest.TestCase):
    def test_package_version(self):
        self.assertGreaterEqual(tuple(map(int, codeforge.__version__.split("."))), (1, 4, 0))

    def test_core_phase5_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            status = CoreKernel(Path(tmp)).initialize()
            self.assertGreaterEqual(tuple(map(int, status["framework_version"].split("."))), (1, 4, 0))
            self.assertIn(status["mode"], {"CONNECTOR_ADAPTER_CANDIDATE_PHASE_5", "REAL_CONNECTOR_EXECUTION_ADAPTER_DESIGN_PHASE_6", "REPOSITORY_INTEGRATED_RADIO_CODING_AGENT_PHASE_7"})

    def test_core_connector_providers_registered(self):
        with tempfile.TemporaryDirectory() as tmp:
            providers = CoreKernel(Path(tmp)).initialize()["providers"]
            self.assertIn("github_connector_candidate", providers); self.assertIn("cloudflare_connector_candidate", providers)

    def test_real_remote_disabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            execution = CoreKernel(Path(tmp)).initialize()["execution"]
            self.assertFalse(execution["real_remote_execution_enabled"])
            self.assertFalse(execution["connector_network_write_enabled"])

    def test_connector_candidate_gate_model_passes(self):
        claims = MutationGate.CONNECTOR_CANDIDATE_REQUIRED
        result = MutationGate().evaluate(claims, phase=5, operation="connector_candidate", provider="github")
        self.assertTrue(result.allowed)

    def test_connector_candidate_phase4_blocks(self):
        result = MutationGate().evaluate(MutationGate.CONNECTOR_CANDIDATE_REQUIRED, phase=4, operation="connector_candidate", provider="github")
        self.assertFalse(result.allowed)

    def test_real_execute_still_blocks(self):
        result = MutationGate().evaluate(MutationGate.LOCAL_EXECUTION_REQUIRED, phase=5, operation="execute", provider="github")
        self.assertFalse(result.allowed)

    def test_config_versions_consistent(self):
        root = Path(__file__).resolve().parents[1]
        config = json.loads((root / "config" / "codeforge.json").read_text())
        allowlist = json.loads((root / "config" / "writer-allowlist.json").read_text())
        self.assertEqual(codeforge.__version__, config["framework_version"]); self.assertEqual(codeforge.__version__, allowlist["version"])

    def test_radio_allowlist_empty(self):
        root = Path(__file__).resolve().parents[1]
        allowlist = json.loads((root / "config" / "writer-allowlist.json").read_text())
        radio = allowlist["repositories"]["xfraggelpower666x/WebRadio-666SOUNDsDESIGn"]
        self.assertEqual([], radio["operations"]); self.assertEqual([], radio["include"])

    def test_connector_policy_real_write_false(self):
        root = Path(__file__).resolve().parents[1]
        policy = json.loads((root / "config" / "connector-adapter-policy.json").read_text())
        self.assertFalse(policy["real_connector_execution"]); self.assertFalse(policy["connector_network_write"])


if __name__ == "__main__":
    unittest.main()
