@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [BLOCKED] Python 3.11 or newer was not found.
    echo Install Python from python.org and run this file again.
    exit /b 1
  )
  set "PY=python"
)

%PY% --version
if errorlevel 1 exit /b 1

set "PYTHONPATH=%CD%\src"
%PY% -m codeforge.cli init --workspace "%CD%\.codeforge-workspace"
if errorlevel 1 exit /b 1
%PY% -m codeforge.cli status --workspace "%CD%\.codeforge-workspace"

endlocal
