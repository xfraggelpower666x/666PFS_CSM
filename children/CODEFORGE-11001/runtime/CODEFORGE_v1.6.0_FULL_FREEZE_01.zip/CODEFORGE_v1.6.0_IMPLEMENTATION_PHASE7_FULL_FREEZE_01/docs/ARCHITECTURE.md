# CodeForge Architecture — Phase 1

## Kernel layer

1. **Core Kernel** wires the workspace and lifecycle.
2. **Continuation Kernel** records interruptions, integrates new information and resumes only from a sealed checkpoint.
3. **Knowledge Kernel / PIDB** stores evidence, decisions, timeline, findings, reports, roadmap, architecture and project graph.
4. **Engineering Kernel** executes the mandatory non-destructive pipeline.
5. **Governance Kernel** ranks source authority and blocks premature mutation.
6. **Project Intelligence Kernel** is represented by PIDB plus scanner and graph artifacts.

## Data flow

```text
Repository / release / live endpoint / handoff
                    │
                    ▼
              Evidence Collector
                    │
                    ▼
              Authority Ranking
                    │
                    ▼
               Reconciliation
                    │
                    ▼
        Findings + proposed repair plan
                    │
                    ▼
             Independent re-audit
                    │
                    ▼
              Sealed checkpoint
```

## Isolation

The radio plugin knows radio-specific signals. Kernels do not. This prevents project names, routes and assumptions from leaking into the universal framework.

## Phase boundary

Phase 1 intentionally stops before repository mutation. The mutation gate exists and is testable, but returns `WRITE_BLOCKED` until a later controlled implementation enables a writer with backup, allowlist, lock, branch and readback enforcement.
