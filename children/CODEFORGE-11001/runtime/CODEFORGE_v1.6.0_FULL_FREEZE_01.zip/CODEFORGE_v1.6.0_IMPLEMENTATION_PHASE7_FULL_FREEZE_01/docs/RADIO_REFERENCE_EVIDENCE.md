# Radio Reference Evidence

## Authority result

The GitHub repository and deployment readback are the technical source of truth. The supplied April archives are retained as historical evidence only.

## Connected repository state observed during freeze

- Repository: `xfraggelpower666x/WebRadio-666SOUNDsDESIGn`
- Default branch: `WebRadio-666SOUNDsDESIGn`
- Connected permission snapshot: admin/maintain/push/pull/triage available
- Observed repository HEAD: `acb102383b79f3a7786bb80d51abc872eb2418e3`
- Current `package.json` version observed through GitHub: `1.2.22`
- Current verification command: `npm run check && npm test`
- Latest observed deployment hardening: commit-bound live identity/readback before backup promotion

## Local uploaded evidence

| Evidence | SHA-256 | CRC |
|---|---|---|
| `GOVEE_FX_SCENE_SYNC_ADDON.zip` | `2692989cf391c17fd2afb53065763289c2b622d272877c4b9cdc722bb3b26834` | PASS |
| `WebRadio-666SOUNDsDESIGn-WebRadio-666SOUNDsDESIGn.zip` | `eabee99acde598015dd00971283b5d21861c6e403de223495314302ef164312c` | PASS |
| `WebRadio-666SOUNDsDESIGn_FULLPACK_v34.3_BOOST_RAMP_ONLY.zip` | `1717a3ba6f305ebbdb13f3f15197bfbc2c338a9c3223f612668049141d465569` | PASS |

## Reconciliation

The local archive README describes an older external-player architecture and contains only 41 files. It cannot override the current repository, whose package and release documentation identify a substantially newer full-version architecture. CodeForge therefore records the archives as historical sources and does not propose copying them over the current branch.
