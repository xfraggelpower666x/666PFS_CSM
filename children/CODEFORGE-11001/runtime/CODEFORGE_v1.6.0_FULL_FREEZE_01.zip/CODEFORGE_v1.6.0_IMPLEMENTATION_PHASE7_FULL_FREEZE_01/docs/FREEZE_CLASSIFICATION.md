# CodeForge Freeze-Klassifizierung

## RUNTIME_FREEZE

Enthält den vollständigen aktuellen Code, Tests, Konfiguration, Schemas, Dokumentation, Ledger und aktuelle Evidence. Eingebettete Vorversions-ZIPs unter `HISTORY/` werden ausgeschlossen.

## FULL_FREEZE

Enthält zusätzlich die verifizierte Vorversions-ZIP und ihre externen SHA-/Readback-/Verify-Receipts unter `HISTORY/`. Dieses Paket ist die kumulative Systemsicherung und wird nicht still durch einen Runtime-Freeze ersetzt.
