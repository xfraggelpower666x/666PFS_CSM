# Implementation Phase 6

## Ziel

Einen hostgebundenen GitHub-Connector-Execution-Adapter als standardmäßig deaktivierten, fail-closed Kandidaten entwerfen.

## Implementiert

- exakt gebundene, kurzlebige und einmalig verbrauchbare Execution Permits
- exakte Autorisierungsphrase mit Contract- und Plan-ID
- Host-Invoker-Protokoll ohne Speicherung von Tokens oder Secrets
- zwingender unmittelbarer Branch-Head-Readback
- Preimage-Prüfung vor Update und Delete
- Create-/Update-/Delete-Ausführung auf neuem isolierten Branch
- Postimage- und Commit-Readback
- Rollback über Ref-Reset auf den verifizierten Ausgangscommit
- Recording Host Invoker für Tests ohne Netzwerk
- getrennte RUNTIME_FREEZE- und FULL_FREEZE-Klassifizierung

## Fail-closed Grenzen

- reale Connector-Ausführung bleibt deaktiviert
- reale Ziel-Allowlist ist leer
- Radio darf nicht erstes reales Schreibziel sein
- der aktuelle GitHub-Connector stellt keine verifizierte `read_branch_head`-Aktion bereit; reale Ausführung bleibt daher blockiert
- Cloudflare-Write bleibt nicht implementiert
