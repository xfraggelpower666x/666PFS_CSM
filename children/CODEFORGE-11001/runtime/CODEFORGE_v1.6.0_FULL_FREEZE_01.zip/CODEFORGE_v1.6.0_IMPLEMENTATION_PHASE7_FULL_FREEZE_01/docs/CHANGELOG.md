# Changelog

## 1.2.0 — Implementation Phase 3

- Chat-only Checkpoints 1100–4100 als `INCOMPLETE_EVIDENCE` quarantänisiert.
- Einmalige, proposal-gebundene lokale Ausführungsautorisierung.
- Hash-Chain Transaction Journal und validierte Zustandsmaschine.
- Atomarer lokaler Sandbox-Swap mit Full-Snapshot, Readback und automatischem Rollback.
- Recovery Pipeline für unterbrochene lokale Transaktionen.
- Deterministischer Release Freeze mit CRC-, Entry- und Tree-Hash-Prüfung.
- Provider Registry; GitHub und Cloudflare bleiben explizit write-blocked.
- Inkrementelles Repository-Inventar.
- Radio-Allowlist bleibt vollständig leer und write-blocked.

## v1.3.0 — Implementation Phase 4

- Remote execution contracts and operation content binding.
- New-branch isolation, capability receipts, remote locks and single-use mock authorization.
- Deterministic mock GitHub transaction with journal, idempotency, readback and rollback.
- Real GitHub, Cloudflare and radio writes remain disabled.


## v1.5.0

- hostgebundener GitHub-Connector-Execution-Adapterentwurf
- einmalige exakte Execution Permits
- Head-/Preimage-/Postimage-Readback und Ref-Reset-Rollback
- Runtime-/Full-Freeze-Klassifizierung
- reale Writes weiterhin deaktiviert
