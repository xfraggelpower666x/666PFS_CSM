# Phase-1-Freeze-Audit

Die Phase-1-ZIP wurde vor der Fortsetzung geprüft.

- erwarteter SHA-256: `543209bbabc7a1927ab7eea848b450c434fbd906e0228b10855be63828269863`
- tatsächlicher SHA-256: identisch
- ZIP-CRC: PASS
- Einträge: 74
- Phase-1-Tests: 12/12 PASS

## Gefundene Portabilitätsabweichung

Die `.sha256`-Datei enthält korrekterweise nur den Dateinamen. `sha256sum -c` funktioniert deshalb nur, wenn das aktuelle Arbeitsverzeichnis die ZIP enthält. Der Hash selbst war korrekt. Phase 2 ergänzt `PortablePackageVerifier`, der Archive und Evidence-Dateien über explizite Pfade prüft.
