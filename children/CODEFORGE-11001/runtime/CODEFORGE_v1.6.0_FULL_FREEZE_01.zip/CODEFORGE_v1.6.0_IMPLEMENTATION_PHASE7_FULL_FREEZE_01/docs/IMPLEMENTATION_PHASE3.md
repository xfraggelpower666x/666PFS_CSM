# CodeForge Implementation Phase 3

## Sicherheitsmodell

Phase 3 aktiviert **keine** GitHub- oder Cloudflare-Schreibfähigkeit. Implementiert wurde ausschließlich eine kontrollierte lokale Sandbox-Transaktion.

Eine lokale Ausführung benötigt gleichzeitig:

1. versiegelten Phase-2-Proposal-Digest,
2. exakte einmalige Autorisierungsphrase,
3. erneuten Remote-Head-Abgleich,
4. aktivierte lokale Sandbox in der Workspace-Konfiguration,
5. Ziel innerhalb des Sandbox-Roots,
6. passende `.codeforge-sandbox-target.json`,
7. Candidate-Readback,
8. Full-Snapshot,
9. Hash-Chain-Journal,
10. Post-Swap-Readback oder automatischen Rollback.

## Transaktionsablauf

```text
PLANNED
→ AUTHORIZED
→ PREPARED
→ APPLIED
→ READBACK_PASS
→ COMMITTED
```

Fehler nach `PREPARED` führen zu:

```text
ROLLBACK_REQUIRED → ROLLED_BACK
```

## Remote-Grenze

```text
GITHUB_WRITE=DISABLED
CLOUDFLARE_WRITE=DISABLED
RADIO_WRITE=DISABLED
LOCAL_SANDBOX_DEFAULT=DISABLED
```
