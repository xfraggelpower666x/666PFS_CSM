# CodeForge Radio Repository Coding Agent

CodeForge ist im WebRadio-Repository zweistufig organisiert:

1. **Universeller Kern** — Analyse, Evidence, Reconciliation, Fortsetzung, Recovery, Tests und kontrollierte Reparaturplanung.
2. **Radio-Plugin** — kennt die geschützten Player-, Audio-, Worker-, Auth-, Discord-, GOVEE- und Deploybereiche des Referenzprojekts.

Der Radio-Agent darf keine produktive Datei still ersetzen. Änderungen werden zuerst als Evidence-gebundener Proposal erzeugt und bleiben ohne explizite Freigabe gesperrt.
