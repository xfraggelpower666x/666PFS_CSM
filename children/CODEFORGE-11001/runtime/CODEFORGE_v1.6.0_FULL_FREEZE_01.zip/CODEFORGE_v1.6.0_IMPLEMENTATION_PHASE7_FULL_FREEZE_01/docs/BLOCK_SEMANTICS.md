# Block semantics

Ein CodeForge-Block ist eine nummerierte, auditierbare Implementierungs- oder Verifikationseinheit. Er ist **nicht automatisch eine eigene Datei oder ein Commit**. Die 1000 Einheiten 4101–5100 sind in fünf interne 200er-Gates zerlegt und jeweils an konkrete Quell-, Test- oder Receipt-Evidence gebunden.

```text
BLOCK_RANGE=4101-5100
BLOCKS=1000
INTERNAL_GATES=5
GATE_SIZE=200
```
