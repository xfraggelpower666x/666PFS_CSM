# Connector Adapter Security Model

1. Connector-Receipts enthalten ausschließlich Identität, Scope, Methoden und Ablaufzeit — niemals Tokens.
2. Jede Candidate-Planung bindet Contract, Session, Head-Receipt, Capability, Lock und Allowlist.
3. Zielbranches müssen neu, isoliert und ungeschützt sein.
4. Reale Netzwerk-Writer sind in Policy, Runtime und Provider gleichzeitig deaktiviert.
5. Der Recording-Connector ist `test_only`, `network=false` und läuft nur mit explizit aktivierter Testkonfiguration.
6. Readback prüft Branch-Head, Dateiinhalte, Löschungen und Tree-Digest.
7. Fehler nach Commit führen im Test-Connector zum Ref-Rollback.
8. Radio-Produktivbranch und Cloudflare-Produktionsdeploy bleiben fail-closed.
