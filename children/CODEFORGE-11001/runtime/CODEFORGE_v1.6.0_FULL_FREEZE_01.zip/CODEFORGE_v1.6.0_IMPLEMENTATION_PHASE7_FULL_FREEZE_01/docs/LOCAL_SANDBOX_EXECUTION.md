# Lokale Sandbox-Ausführung

Die Funktion ist standardmäßig deaktiviert. Sie darf nur für eine markierte Kopie innerhalb des Workspace-Sandbox-Roots aktiviert werden. GitHub, Cloudflare und das Radio werden dadurch nicht schreibfähig.

## Pflichtbedingungen

- `local_sandbox_enabled=true` nur im konkreten Workspace
- Ziel innerhalb `sandbox_root`
- `.codeforge-sandbox-target.json` mit exakter Zielidentität
- versiegelter Proposal-Digest
- exakte Einmal-Autorisierung
- erneuter Head-Abgleich
- Snapshot, Journal, Readback und Rollback

Die Autorisierungsphrase ist kein Connector-Secret und ersetzt keine Remote-Authentifizierung.
