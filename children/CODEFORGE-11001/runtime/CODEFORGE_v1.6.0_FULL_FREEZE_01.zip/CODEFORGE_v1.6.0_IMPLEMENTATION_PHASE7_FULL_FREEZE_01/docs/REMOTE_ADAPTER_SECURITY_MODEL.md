# Remote Adapter Security Model

Ein Remote-Adapter darf erst nach folgender Kette ausführen:

```text
SEALED PROPOSAL
→ SEALED REMOTE CONTRACT
→ FRESH CAPABILITY RECEIPT
→ NEW ISOLATED BRANCH
→ FRESH REMOTE LOCK
→ EXACT SINGLE-USE AUTHORIZATION
→ HEAD RECHECK
→ IDEMPOTENCY RESERVATION
→ EXECUTION JOURNAL
→ REMOTE READBACK
→ COMMIT OR ROLLBACK
```

Phase 4 erlaubt diese Kette ausschließlich im deterministischen `mock_github`-Provider ohne Netzwerkzugriff. Direkte Writes auf `main`, `master`, `production` und `WebRadio-666SOUNDsDESIGn` sind gesperrt. Der Radio-Repo-Eintrag enthält weiterhin keine erlaubten Operationen.
