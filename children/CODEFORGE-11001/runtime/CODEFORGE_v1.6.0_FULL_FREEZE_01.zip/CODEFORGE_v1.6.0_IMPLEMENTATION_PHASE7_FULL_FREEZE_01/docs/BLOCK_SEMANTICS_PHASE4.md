# Phase-4 block semantics

Ein Block ist eine nummerierte, auditierbare Implementierungs- oder Verifikationseinheit und nicht automatisch eine eigene Datei oder ein Commit. Die Einheiten 5101–6100 sind in fünf 200er-Gates zerlegt und an konkrete Quell-, Test- oder Receipt-Evidence gebunden.
