#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
python3 -m codeforge.cli init --workspace "$ROOT/.codeforge-workspace"
python3 -m codeforge.cli status --workspace "$ROOT/.codeforge-workspace"
