# Evidence boundary

The original uploaded ZIP files are not duplicated inside this package. Their names, hashes and CRC results are recorded in `data/pidb/evidence/uploaded_archives.json`. This avoids inflating the framework freeze and prevents an old radio snapshot from being mistaken for current source truth.
