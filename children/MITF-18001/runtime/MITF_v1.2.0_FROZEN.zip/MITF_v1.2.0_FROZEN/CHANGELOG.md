# CHANGELOG

## v1.2.0 FROZEN
Previous candidate: v1.1.0

ADDED:
- Automatic route intelligence
- ROUTE A Direct Master Edit
- ROUTE B Controlled Master Reconstruction
- ROUTE C Hybrid Master Preservation
- SOURCE TEXT MAP and FACT LOCK before rendering
- Automatic escalation after verified route failure
- Failed-output quarantine / no chaining
- Reconstruction provenance state

REPAIRED:
- Overly absolute reconstruction prohibition
- Renderer-as-translator failure path
- Repeated direct-edit corruption loop
- Manual route-selection dependency

PRESERVED:
- MASTER authority
- New upload = new MASTER
- Semantic equivalence
- Factual zero-loss
- HOLD fail-closed
- Target-language variant behavior

REMOVED: NONE
UNCONTROLLED REGENERATION PERMISSION: FORBIDDEN
