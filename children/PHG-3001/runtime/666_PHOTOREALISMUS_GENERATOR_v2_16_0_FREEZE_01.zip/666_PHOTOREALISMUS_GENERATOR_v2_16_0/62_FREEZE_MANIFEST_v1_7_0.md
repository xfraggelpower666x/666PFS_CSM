# FREEZE MANIFEST v1.7.0

Status: FROZEN

Identity source anchoring, per-person separation, protected/mutable traits, creativity budget and drift veto are active.
