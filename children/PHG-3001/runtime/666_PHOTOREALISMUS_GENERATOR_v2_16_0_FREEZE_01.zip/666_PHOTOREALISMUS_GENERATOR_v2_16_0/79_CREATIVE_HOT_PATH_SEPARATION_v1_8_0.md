# CREATIVE HOT PATH SEPARATION v1.9.0

## Creative Image Runtime

SOURCE_BIND → IDENTITY_ANCHOR → EDIT_INTENT_PARSE → MULTI_STEP_EDIT_PLAN → PRIORITY_RESOLUTION → COMPACT_PROMPT → IMAGE_TOOL → VISUAL_READBACK → TARGETED_REPAIR

## System Governance Runtime

AUDIT → FREEZE → VERSIONING → PERSISTENCE → PACKAGE HASHES → BACKUP → REMOTE ROUTING

Governance remains active for package integrity and runtime durability, but it is forbidden from inflating the creative image prompt.
