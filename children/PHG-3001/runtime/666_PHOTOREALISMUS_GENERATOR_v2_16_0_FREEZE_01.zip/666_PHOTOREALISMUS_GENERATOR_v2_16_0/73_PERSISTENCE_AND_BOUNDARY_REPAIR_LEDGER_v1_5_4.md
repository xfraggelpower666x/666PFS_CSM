# 666 PHOTOREALISMUS GENERATOR — PERSISTENCE AND BOUNDARY REPAIR LEDGER

**Version:** v1.5.4  
**Datum:** 2026-07-14  
**Basis:** v1.5.3  
**Modus:** nicht destruktive Deep-Reparatur  
**Status:** REPAIRED / RE-AUDITED / FREEZE CANDIDATE

## Geschlossene Fehler

### PBR-001 — Toolresultat-Fehler wurden nicht durable gespeichert

Abgewiesene, unvollständige, doppelte oder ownership-falsche Toolresultate konnten als `RETRY_READY` zurückgegeben werden, ohne den neuen Zustand, das Journal und den Fehler-Receipt in `RUNTIME_STATE` zu persistieren. Dadurch konnte der gespeicherte Zustand fälschlich auf `DISPATCHING` stehen bleiben.

**Reparatur:** Alle Resultatpfade laufen nun durch eine gemeinsame validierende Persistenzfunktion. Guard-Fails erzeugen einen journalgebundenen OUTPUT-Receipt und werden vor der Rückgabe atomar gespeichert.

### PBR-002 — Cancel wurde nur im Arbeitsspeicher ausgeführt

Der Host-Turn-Executor beendete den Cancel-Pfad vor dem Persistenzblock.

**Reparatur:** `CANCELLED` wird inklusive Journal und Revision dauerhaft gespeichert.

### PBR-003 — Compilerfehler behauptete Terminalstatus ohne Terminaltransition

Ein Prompt-Compilerfehler gab `FAILED_TERMINAL` zurück, obwohl der Runtime-State in `SOURCE_REGISTERED` verblieb.

**Reparatur:** Neues Event `PROMPT_COMPILE_FAILED`, neuer Matrixpfad `MX-048`, echte Transition nach `FAILED_TERMINAL`, Journalisierung und Persistenz.

### PBR-004 — WAL war nicht vollständig crash-recoverbar

Die bisherige WAL dokumentierte den geplanten Commit, enthielt jedoch keine vollständigen Before-Images und keine deterministische Recovery-Routine für Teilwrites über State, Journal und Receipts.

**Reparatur:** Jede Generation wird mit gehashten New-Images und gehashten Before-Images vorbereitet. Beim nächsten Read/Write wird eine vollständig geschriebene Generation finalisiert oder eine partielle Generation vollständig zurückgerollt. Recovery ist idempotent und readback-validiert.

### PBR-005 — Hash-Beweise waren nur auf Vorhandensein geprüft

Beliebige nichtleere Zeichenketten konnten als Source-, Prompt- oder Output-Hash passieren.

**Reparatur:** Kritische Hashfelder verlangen jetzt exakt 64 hexadezimale SHA-256-Zeichen. Source-Hash-Provenienz ist auf `HOST_SUPPLIED_CONTENT_DIGEST` oder `VALIDATED_STAGE1_OUTPUT` begrenzt.

### PBR-006 — Receipt-Fallback war bei fehlendem jsonschema zu schwach

Ohne optionale `jsonschema`-Bibliothek prüfte der Fallback lediglich Pflichtfeldnamen.

**Reparatur:** Kritische Receipt-Prüfungen laufen jetzt immer: nichtleere IDs, Receipt-Typ, Journalfolge und SHA-256-Formate.

### PBR-007 — Prompt-Trigger verwendeten unkontrollierte Teilworttreffer

Trigger konnten innerhalb fremder Wörter anschlagen, beispielsweise `window` in `windowless`.

**Reparatur:** Prompt-Modultrigger verwenden Unicode-Wort- und Phrasengrenzen. Explizite Stämme werden ausschließlich über ein sichtbares `*` definiert.

## Erhaltung

- Sämtliche historischen Release-, Audit-, Freeze- und Legacy-Dateien bleiben erhalten.
- Systemname und System-ID bleiben unverändert.
- ACTIVE bleibt der einzige kanonische Runtime-Root.
- Parent-USBO und Storage-/Concurrency-Unterstruktur wurden nicht verändert.
- Keine Secrets, Tokens, Produktionsbilder oder temporären Runtime-Ergebnisse wurden eingebettet.
