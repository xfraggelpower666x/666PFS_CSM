# RELEASE HANDOFF v1.7.0

Identity Core and Creative Drift Control are active. Previous baseline v1.6.0 remains preserved.
