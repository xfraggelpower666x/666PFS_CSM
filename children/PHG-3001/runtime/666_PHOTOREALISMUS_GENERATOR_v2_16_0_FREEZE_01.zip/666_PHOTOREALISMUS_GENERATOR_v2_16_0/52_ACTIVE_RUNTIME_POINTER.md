# ACTIVE RUNTIME POINTER

Canonical runtime files are under `ACTIVE/`. Active version: **v2.0.0**.

- Host-turn entry: `ACTIVE/19_HOST_TURN_EXECUTOR.py`
- Post-tool result entry: `ACTIVE/28_HOST_RESULT_EXECUTOR.py`
- Prompt compiler: `ACTIVE/26_PROMPT_COMPILER.py`
- Visual QA engine: `ACTIVE/27_VISUAL_QA_ENGINE.py`
- Runtime store: `ACTIVE/22_RUNTIME_STORE.py`
- Canonical resolver: `ACTIVE/25_CANONICAL_RESOLVER.py`

Historical v1.5.4 remains the previous frozen baseline. Legacy runtime content remains isolated under `LEGACY/` and must not auto-activate.

- PHLF-CYBER extension: `ACTIVE/36_PHLF_CYBER_EXTENSION.py`
- Framework source: `EXTENSIONS/PHLF_CYBER_v1_2_0/`
