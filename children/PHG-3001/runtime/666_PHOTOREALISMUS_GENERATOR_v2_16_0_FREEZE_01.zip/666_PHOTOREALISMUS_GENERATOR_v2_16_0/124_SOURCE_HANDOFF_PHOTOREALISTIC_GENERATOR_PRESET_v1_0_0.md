# HANDOFF — PHOTOREALISTIC IMAGE GENERATOR PRESET EXPANSION

VERSION=1.0.0
DATE=2026-08-11
SCOPE=PHOTOREALISTIC_GENERATOR_PRESETS
STATUS=VERIFIZIERT_FROM_CHAT_ITERATIONS

==================================================
1. ZWECK
==================================================

Dieses Handoff fasst die in diesem Chat erkennbaren Anforderungen, Fehlerbilder und wiederverwendbaren Presets für einen Photorealistic Generator zusammen.

Ziele:
- Referenzbild möglichst exakt erhalten
- echten Photorealismus gegenüber 3D/CG/Illustration priorisieren
- Rahmen, Typografie und dekorative Symbole kontrolliert ergänzen
- Text exakt und reproduzierbar setzen
- semantische Platzhalter wie BLUE FISH als definierte visuelle Assets rendern
- Zuschnittfehler vermeiden
- romantische, erotische und Cyberpunk-Varianten als Presets verfügbar machen

==================================================
2. KERNREGELN
==================================================

REFERENCE_IMAGE_LOCK=HIGH
PHOTOREALISM_PRIORITY=MAX
CHARACTER_LOCK=ON
POSE_LOCK=ON
OUTFIT_LOCK=ON

Wenn ein Referenzbild vorhanden ist:
- Personen, Haare, Tattoos, Kleidung, Pose und relative Positionen erhalten
- Umgebung erhalten, sofern kein Austausch verlangt wird
- Kameraperspektive und Bildausschnitt möglichst nah an der Vorlage halten
- nur gewünschte Änderungen an Licht, Atmosphäre, Rahmen, Typografie oder Farbwelt durchführen

PHOTOREALISM POSITIVE:
- photorealistic
- natural skin texture
- realistic hair strands
- physically plausible lighting
- realistic fabric and material response
- photographic dynamic range
- natural shadows and reflections
- cinematic lens behavior

NEGATIVE GUARD:
- no 3D render look
- no game screenshot look
- no CGI plastic skin
- no anime
- no illustration
- no painterly style
- no waxy faces
- no doll-like anatomy

WICHTIG:
Der dekorative Rahmen darf stilisiert, ornamental oder neon sein.
Die Personen und die Hauptszene bleiben photorealistisch.

==================================================
3. ROMANTIC / EROTIC BALANCE
==================================================

ROMANTIC_EROTIC_LEVEL=NON_EXPLICIT_SENSUAL

Geeignet:
- intime Nähe
- Kuss
- Blickkontakt
- Umarmung
- getragene Pose
- liegende oder enge Pose
- sinnliche Körpersprache

Guard:
- keine unnötige Nacktheit
- keine explizite Sexualhandlung
- Erotik primär über Pose, Licht, Nähe und Atmosphäre

==================================================
4. FRAME ENGINE
==================================================

FRAME_FULL_VISIBILITY=REQUIRED
FRAME_SAFE_MARGIN=4_TO_6_PERCENT
FRAME_EDGE_PADDING=REQUIRED

Beobachteter Fehler:
- Rahmen wurde links angeschnitten.

Pflichtregel:
"complete frame fully visible on all four sides, generous safe margin, no cropped border elements, no text touching canvas edges"

LAYER_1=PHOTOREALISTIC_SCENE
LAYER_2=FRAME_STRUCTURE
LAYER_3=ORNAMENTS
LAYER_4=TEXT
LAYER_5=SYMBOL_ASSETS
LAYER_6=GLOW_AND_EFFECTS

Rahmen darf nicht:
- Gesichter verdecken
- Hände verdecken
- zentrale Pose stören
- wichtige Tattoos überlagern

FRAME_DENSITY=MEDIUM_HIGH
SUBJECT_CLEAR_ZONE=REQUIRED

==================================================
5. TYPOGRAPHY ENGINE
==================================================

TEXT_LANGUAGE=ENGLISH
TEXT_CASE=UPPERCASE
TEXT_EXACTNESS=STRICT

Keine:
- automatische Umformulierung
- Grammatikreparatur ohne Auftrag
- Synonyme
- stillen Namensänderungen
- zusätzlichen Wörter

Fixe Namen:
VELUNA
FRAGGEL

TEXT ZONES:
TOP_TEXT_ZONE=UPPER_FRAME
BOTTOM_NAME_ZONE=LOWER_FRAME
BOTTOM_QUOTE_ZONE=LOWER_FRAME_SECONDARY

POST CHECK:
- exakte Wörter
- richtige Reihenfolge
- richtige Großschreibung
- VELUNA korrekt
- FRAGGEL korrekt
- keine doppelten Wörter
- keine abgeschnittenen Buchstaben
- keine erfundenen Zusätze

==================================================
6. SYMBOL / ASSET SEMANTIC MAPPING
==================================================

Wenn der Nutzer BLUE FISH als visuelles Symbol meint:

TOKEN="BLUE FISH"
RENDER_MODE=IMAGE_SYMBOL
TEXT_RENDER=OFF
ASSET_RENDER=ON
ASSET_ID=BLUE_PALETTE_SURGEONFISH

Definition:
- Blue Tang / Paletten-Doktorfisch
- kräftig royalblauer Körper
- schwarzes Paletten-/Painter-Pattern
- gelbe Schwanzflosse
- klar als diese Fischart erkennbar

Damit gilt:
BLUE FISH darf an definierten Stellen als Fischgrafik erscheinen und nicht als ausgeschriebener Text.

==================================================
7. PRESETS
==================================================

PRESET_01=LOVE_FRAME_NEON_PINK
SCENE_STYLE=PHOTOREALISTIC
FRAME_COLOR=NEON_PINK
ACCENT_COLORS=PURPLE,SOFT_RED
ELEMENTS=HEARTS,FILIGREE,SPARKLES,LIGHTNING
TOP_TEXT="LOVE"
BOTTOM_LEFT="VELUNA"
BOTTOM_CENTER=HEART_SYMBOL
BOTTOM_RIGHT="FRAGGEL"
FRAME_SAFE_MARGIN=5_PERCENT

PRESET_02=LOVE_FRAME_ELECTRIC_BLUE
SCENE_STYLE=PHOTOREALISTIC
FRAME_COLOR=ELECTRIC_BLUE
ACCENT_COLORS=ICE_BLUE,WHITE
ELEMENTS=HEARTS,STARS,LIGHTNING,FILIGREE
TOP_TEXT="LOVE"
BOTTOM_LEFT="VELUNA"
BOTTOM_CENTER=HEART_SYMBOL
BOTTOM_RIGHT="FRAGGEL"
BEST_FOR=OCEAN,BEACH,COAST,SUNSET
FRAME_SAFE_MARGIN=5_PERCENT

PRESET_03=OLD_OMEN_ROSE_STARS
SCENE_STYLE=PHOTOREALISTIC
FRAME_COLOR=DEEP_RED,GOLD,WARM_WHITE
ELEMENTS=RED_ROSES,HEARTS,STARS,ORNATE_FILIGREE,LIGHTNING
TOP_TEXT="GODS SCRIBED MY FATE IN STARS"
BOTTOM_LEFT="VELUNA"
BOTTOM_CENTER=HEART_SYMBOL
BOTTOM_RIGHT="FRAGGEL"
BOTTOM_TEXT="LOVE ROSE FROM THE OLD OMEN THEY"
MOOD=ANCIENT_OMEN,DESTINY,ROMANCE

PRESET_04=STARS_BLUE_TANG_FATE
SCENE_STYLE=PHOTOREALISTIC
FRAME_COLOR=ELECTRIC_BLUE
ACCENT_COLORS=ICE_BLUE,GOLD_STARLIGHT
ELEMENTS=HEARTS,STARS,BLUE_TANG_ASSETS,LIGHTNING,FILIGREE
TOP_TEXT="A LOVE OLDER THAN THE STARS STILL CALLS MY NAME"
BOTTOM_LEFT="VELUNA"
BOTTOM_CENTER=HEART_SYMBOL
BOTTOM_RIGHT="FRAGGEL"
BOTTOM_TEXT="LOVE [BLUE_FISH_ASSET] FATE ANSWERS IN YOUR VOICE [BLUE_FISH_ASSET]"
BLUE_FISH_TOKEN_MODE=ASSET_NOT_TEXT

PRESET_05=DEEP_DARK_CRAZY_NEON
SCENE_STYLE=PHOTOREALISTIC_CINEMATIC
COLORS=NEON_PINK,NEON_PURPLE,NEON_BLUE,CYAN
ELEMENTS=LASERS,LIGHTNING,HOLOGRAPHIC_SIGNS,SMOKE,SPARKS
MOOD=DEEP_DARK_CRAZY
REALISM=PHOTOREALISTIC_HUMANS_WITH_STYLIZED_NEON_ENVIRONMENT
TEXT_LANGUAGE=ENGLISH
TEXT_CASE=UPPERCASE

==================================================
8. PROMPT ASSEMBLY ORDER
==================================================

1. SOURCE LOCK
"Use the reference image as the primary composition and identity source."

2. SUBJECT LOCK
"Preserve the same people, faces, hair, tattoos, outfits, pose and relative positioning."

3. REALISM LOCK
"Transform only the rendering quality toward true photorealism, natural skin, realistic hair, physically plausible light, photographic materials and lens response."

4. SCENE PRESERVATION
"Keep the original environment unless explicitly changed."

5. PRESET LOAD
Load selected preset.

6. EXACT TEXT BLOCK
Exact uppercase text only.

7. SYMBOL MAPPING
Resolve semantic asset tokens before rendering.

8. SAFE AREA
"Keep the entire frame and every text element fully visible with 4–6% edge margin."

9. NEGATIVE GUARDS
"No cropped frame, no rewritten text, no spelling changes, no CGI look, no cartoon look, no pose drift, no outfit changes, no extra people, no duplicated limbs, no distorted hands."

==================================================
9. FAILURE MODES AUS DEM CHAT
==================================================

FAIL_01=FRAME_CROPPED
FIX=FRAME_SAFE_MARGIN + FULL_FRAME_VISIBILITY

FAIL_02=STYLE_DRIFT_TO_CGI
FIX=PHOTOREALISM_LOCK + NEGATIVE_CGI_GUARD

FAIL_03=TEXT_REINTERPRETATION
FIX=TEXT_EXACTNESS=STRICT

FAIL_04=SYMBOL_AS_TEXT
FIX=SEMANTIC_ASSET_MAPPING

FAIL_05=GENERIC_FISH
FIX=BLUE_PALETTE_SURGEONFISH_ASSET

FAIL_06=OVERDECORATION
FIX=FRAME_DENSITY=MEDIUM_HIGH + SUBJECT_CLEAR_ZONE

FAIL_07=IDENTITY_OR_POSE_DRIFT
FIX=CHARACTER_LOCK + POSE_LOCK + OUTFIT_LOCK

==================================================
10. VALIDATION CHECKLIST
==================================================

PRE_RENDER:
[ ] reference loaded
[ ] preset selected
[ ] exact text copied
[ ] semantic asset tokens resolved
[ ] photorealism lock active
[ ] pose/outfit/character lock active
[ ] safe margin active

POST_RENDER:
[ ] complete frame visible on all 4 sides
[ ] no cropped typography
[ ] VELUNA correct
[ ] FRAGGEL correct
[ ] English only where requested
[ ] uppercase where requested
[ ] no unintended extra text
[ ] BLUE FISH rendered as Blue Tang if token mode is active
[ ] people photorealistic, not CGI/comic
[ ] pose close to reference
[ ] outfit close to reference
[ ] faces not covered by frame
[ ] no unnecessary scene changes

==================================================
11. EMPFOHLENE GENERATOR-FELDER
==================================================

REFERENCE_IMAGE
PRESET_ID
PHOTOREALISM_LEVEL
CHARACTER_LOCK
POSE_LOCK
OUTFIT_LOCK
BACKGROUND_LOCK
FRAME_ENABLED
FRAME_PRESET
FRAME_SAFE_MARGIN
FRAME_DENSITY
TOP_TEXT
BOTTOM_LEFT_TEXT
BOTTOM_CENTER_SYMBOL
BOTTOM_RIGHT_TEXT
BOTTOM_QUOTE
TEXT_LANGUAGE
TEXT_CASE
TEXT_EXACTNESS
SEMANTIC_ASSET_MAP
COLOR_PALETTE
LIGHTING_PROFILE
ROMANTIC_INTENSITY
EROTIC_INTENSITY
NEGATIVE_GUARDS

==================================================
12. INTEGRATIONSEMPFEHLUNG
==================================================

Empfohlene modulare Pipeline:

REFERENCE LOCK
→ REALISM LOCK
→ SUBJECT LOCK
→ PRESET
→ TEXT LAYOUT
→ ASSET MAPPING
→ SAFE FRAME
→ NEGATIVE GUARDS
→ VALIDATION

Diese Struktur erlaubt neue Presets, ohne bestehende Referenzlogik, Figuren, Pose oder Komposition unnötig zu verändern.

END_OF_HANDOFF
