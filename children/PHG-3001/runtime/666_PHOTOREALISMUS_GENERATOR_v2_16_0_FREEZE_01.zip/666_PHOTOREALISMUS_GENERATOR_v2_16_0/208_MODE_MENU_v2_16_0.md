# PHG MODE MENU v2.16.0

The machine-readable menu remains `ACTIVE/75_MODE_MENU_REGISTRY.json` with seven top-level sections for backward compatibility. ENSC-004 and DSR-005 modes are available under the Special section and resolve by canonical mode code, numeric selection, or semantic intent. Pure mode selection remains guidance-only and never renders immediately.
