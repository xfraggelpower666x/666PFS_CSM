#!/usr/bin/env python3
"""Statische Registry-, Guard- und Matrixprüfung für v1.4.0."""
from pathlib import Path
import json, sys
root = Path(__file__).resolve().parent
orch = json.loads((root/'33_RUNTIME_ORCHESTRA_REGISTER.json').read_text(encoding='utf-8'))
guards = json.loads((root/'34_RUNTIME_GUARD_REGISTER.json').read_text(encoding='utf-8'))
mx = json.loads((root/'35_RUNTIME_EXECUTION_MATRIX.json').read_text(encoding='utf-8'))
errors=[]

def unique(items, key, label):
    vals=[x[key] for x in items]
    if len(vals)!=len(set(vals)): errors.append(f'DUPLICATE {label}')
    return set(vals)

oids=unique(orch['orchestras'],'id','ORCHESTRA_ID')
gids=unique(guards['guards'],'id','GUARD_ID')
mids=unique(mx['rows'],'id','MATRIX_ID')
if orch.get('supervisor') not in oids: errors.append('SUPERVISOR MISSING')
if guards.get('default_policy')!='DENY_UNREGISTERED_PATH': errors.append('DEFAULT DENY MISSING')
for row in mx['rows']:
    if row['orchestra'] not in oids: errors.append(f"{row['id']} UNKNOWN ORCHESTRA {row['orchestra']}")
    for gid in row.get('guards',[]):
        if gid not in gids: errors.append(f"{row['id']} UNKNOWN GUARD {gid}")
required_guards={'GRD-003','GRD-012','GRD-015','GRD-017','GRD-019','GRD-020','GRD-021','GRD-022'}
missing=required_guards-gids
if missing: errors.append('MISSING REQUIRED GUARDS '+','.join(sorted(missing)))
pairs={(r['state'],r['event']) for r in mx['rows']}
for pair in [('IDLE','NEW_IMAGE'),('FAILED_TERMINAL','RESUME_COMMAND'),('DISPATCHING','NO_TOOL_RESULT'),('RETRY_READY','RETRY_EXHAUSTED'),('OUTPUT_VALIDATED','COMMIT_SUCCESS')]:
    if pair not in pairs: errors.append(f'MISSING MATRIX PATH {pair}')
channel=[g for g in guards['guards'] if g['id']=='GRD-012']
if not channel or 'commentary' not in channel[0]['rule'].lower() or 'final' not in channel[0]['rule'].lower():
    errors.append('CHANNEL HARDLOCK INCOMPLETE')
if errors:
    print('RUNTIME REGISTRY VALIDATION = FAIL')
    print('\n'.join(errors)); sys.exit(1)
print(f'RUNTIME REGISTRY VALIDATION = PASS ({len(oids)} Orchestras, {len(gids)} Guards, {len(mids)} Matrix rows)')
