# FREEZE MANIFEST v1.9.0

Status: FROZEN
Previous baseline: v1.8.0
Focus: lean CGI/3D-to-photoreal reconstruction hot path
