#!/usr/bin/env python3
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).resolve().parent/'30_RUN_V154_ACCEPTANCE_TESTS.py'),run_name='__main__')
