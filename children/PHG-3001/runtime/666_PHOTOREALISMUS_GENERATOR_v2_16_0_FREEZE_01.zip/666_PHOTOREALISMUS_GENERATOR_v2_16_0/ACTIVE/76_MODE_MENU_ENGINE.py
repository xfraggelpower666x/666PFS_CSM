#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
MENU=json.loads((ROOT/'75_MODE_MENU_REGISTRY.json').read_text(encoding='utf-8'))

def list_menu(): return MENU

def _flatten():
    out=[]
    numeric={}
    for si,sec in enumerate(MENU['sections'],start=1):
        for mi,mode in enumerate(sec['modes'],start=1):
            out.append(mode)
            numeric[f'{si}.{mi}']=mode
    return out,numeric

def resolve(text:str)->dict:
    raw=(text or '').strip()
    t=re.sub(r"\s+"," ",raw.casefold()).strip()
    all_modes,numeric=_flatten()
    found=[]
    source=[]
    # Explicit canonical codes always win and must work for every registered mode.
    # Longest first prevents a shorter token from shadowing a combination.
    for mode in sorted(all_modes,key=len,reverse=True):
        if mode.casefold() in t and mode not in found:
            found.append(mode); source.append('EXPLICIT_CODE')
    # Numeric shorthand such as 2.2 is normal control and needs no PHG prefix.
    for token,mode in numeric.items():
        if re.search(r'(?<!\d)'+re.escape(token)+r'(?!\d)',t) and mode not in found:
            found.append(mode); source.append('NUMERIC')
    # Semantic aliases only supplement explicit selection; they never replace it.
    aliases={
      'CORE_PHOTOREALISM':('photorealistic','fotorealistisch','photorealism','fotorealismus','real human models','menschliche models'),
      'IDENTITY_PRESERVATION':('identity preservation','identität erhalten','identitaet erhalten','person erhalten','gesicht erhalten'),
      'REFERENCE_PRESERVATION':('reference preservation','referenz erhalten','referenzbild erhalten','komposition erhalten','pose erhalten'),
      'REALISM_CONTROL':('realism control','realismus kontrollieren','kein cgi','keine game-optik','keine game optik'),
      'LYVRA_MINIMAL_FRAME':('lyvra minimal frame','minimal lyvra frame','minimaler lyvra rahmen'),
      'LYVRA_ORNATE_FRAME':('lyvra ornate frame','ornate lyvra frame','ornamentaler lyvra rahmen','aufwendiger lyvra rahmen'),
      'LYVRA_DUAL_WORLD_COMPARE':('dual world','dual-world','deutsche lyvra','american lyvra','amerikanische lyvra'),
      'CCRE_01_DETAIL_TRANSFER':('detail transfer','detail level transfer','detaillierter machen'),
      'CCRE_02_DUO':('creature duo','cyberwesen duo','als duo'),
      'CCRE_03_HYBRID':('hybrid creature','hybridwesen','verschmelzen'),
      'CCRE_04_RIDER':('rider mount','reitend','reitet auf'),
      'CCRE_05_TECH_DNA':('shared tech dna','gemeinsame tech dna'),
      'EVM_CAUSAL_MEANING':('emotional visual meaning','visuelle bedeutung','tiefere visuelle bedeutung','tieferer visueller bedeutung','deeper visual meaning'),
      'EVM_RELATIONSHIP_DEPTH':('relationship depth','beziehungstiefe','beziehungsintensität','beziehungsintensitaet'),
      'EVM_TRANSFORMATION':('evm transformation','emotionale transformation','visueller wandel'),
      'EVM_DISTANCE_CONNECTION':('distance connection','distanz und verbindung','trotz distanz verbunden'),
      'EVM_HEALING_RECONNECTION':('healing reconnection','heilung und wiederannäherung','heilung und wiederannaeherung'),
      'CNSC_RELATIONAL_NEON_HEART':('relational neon heart','interwoven neon heart'),
      'CYBER_LOVE_FRAME':('cyber love frame','cyber love rahmen'),
      'ADAPTIVE_CYBER_GARDEN':('cyber garden','cybergarten'),
      'CYBER_DUALITY':('cyber duality','angel demon hybrid','engel dämon hybrid'),
      'ENVIRONMENTAL_NARRATIVE':('environmental narrative','umwelt narrative','environment story','environmental story'),
      'WEATHER_STORY_MAPPING':('weather story','rain story','storm story','wetter geschichte','regen geschichte'),
      'WET_MATERIAL_REALISM':('wet material realism','nasse materialien','wet skin','wet leather','nasse haut','nasses leder'),
      'SCENE_TEXT_SYMBOL_COHERENCE':('scene text symbol','scene text coherence','szene text symbol','story caption'),
      'NAME_SIDE_BINDING':('name side binding','name-side binding','namen seitenbindung','name folgt person'),
      'DYNAMIC_SIDE_REMAPPING':('dynamic side remapping','side swap remap','seitenwechsel remap','person side remap'),
      'IDENTITY_PROPERTY_REMAP':('identity property remap','identity-bound properties','personengebundene eigenschaften'),
      'COLOR_PERSON_BINDING':('color person binding','farbe folgt person','person color binding'),
      'FRAME_REGION_REMAP':('frame region remap','frame color follows person','rahmenfarbe folgt person'),
    }
    for mode,terms in aliases.items():
        if mode in all_modes and mode not in found and any(x in t for x in terms):
            found.append(mode); source.append('SEMANTIC')
    kind='NONE'
    if found:
        kind='EXPLICIT' if 'EXPLICIT_CODE' in source else ('NUMERIC' if 'NUMERIC' in source else 'SEMANTIC')
    return {'selected_modes':found,'count':len(found),'explicit_or_semantic':kind,'match_sources':source,'conflict':False}
