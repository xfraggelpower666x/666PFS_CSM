#!/usr/bin/env python3
"""Active bridge for 666 Realism Control Suite v1.0.0."""
from __future__ import annotations
from pathlib import Path
import importlib.util
ROOT=Path(__file__).resolve().parent
TARGET=ROOT.parent/'EXTENSIONS'/'REALISM_CONTROL_SUITE_v1_0_0'/'RUNTIME'/'realism_control_suite.py'
spec=importlib.util.spec_from_file_location('rig_suite',TARGET)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
analyze=mod.analyze
compact_directive=mod.compact_directive
