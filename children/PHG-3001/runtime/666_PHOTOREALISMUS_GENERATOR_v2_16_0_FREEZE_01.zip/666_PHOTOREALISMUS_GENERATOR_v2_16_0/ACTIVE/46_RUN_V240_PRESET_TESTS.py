#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys
R=Path(__file__).resolve().parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,R/file); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
E=load("preset_expansion","43_PRESET_EXPANSION_ENGINE.py")
C=load("compiler","26_PROMPT_COMPILER.py")
fails=[]
def check(name, cond, detail=""):
    if not cond: fails.append(f"{name}:{detail}")
r=E.analyze('"You are safe with me" in a long romantic message with a warm sunset scene')
check('V240_01_TEXT_MODE', r['text_mode']=='NARRATIVE_MESSAGE', str(r))
check('V240_02_NARRATIVE_ACTIVE', r['narrative']['active'] and r['narrative']['readability_check'], str(r['narrative']))
check('V240_03_LANGUAGE_PRESERVE', r['typography']['language'] in {'PRESERVE_INPUT_UNLESS_EXPLICIT','PRESERVE_INPUT'}, str(r['typography']))
r=E.analyze('EMOTIONAL_LOVE_MESSAGE with "Follow the glow"')
check('V240_04_PRESET_06', r['preset_id']=='EMOTIONAL_LOVE_MESSAGE', str(r))
r=E.analyze('SUNSET_ACCEPTANCE_MESSAGE with a message about trust and authenticity')
check('V240_05_PRESET_07', r['preset_id']=='SUNSET_ACCEPTANCE_MESSAGE', str(r))
r=E.analyze('DARK_ROMANTIC_MESSAGE with deep red roses')
check('V240_06_PRESET_08', r['preset_id']=='DARK_ROMANTIC_MESSAGE', str(r))
r=E.analyze('Use the reference image, keep composition, cyber birthday purple pink love with HAPPY BIRTHDAY MY ANGEL! and I LOVE YOU')
check('V240_07_CYBER_ACTIVE', r['cyber_love_addon']['active'] and r['composition']['keep_composition'], str(r))
check('V240_08_HERO_HEART', r['cyber_love_addon']['hero_heart_text']=='HAPPY BIRTHDAY MY ANGEL!' and r['cyber_love_addon']['corner_heart_count']==4, str(r['cyber_love_addon']))
check('V240_09_REFERENCE_MODE', r['composition']['reference_mode']=='EDIT_NOT_REBUILD', str(r['composition']))
r=E.analyze('TEXT ONLY ENGLISH cyber birthday electric blue with happy birthday my angel')
check('V240_10_EN_ONLY', r['cyber_love_addon']['english_only_text'] and r['typography']['language']=='ENGLISH', str(r['typography']))
d=E.compact_directive(E.analyze('Use the reference image, cyber birthday purple pink love with exact text "HAPPY BIRTHDAY MY ANGEL!"'))
check('V240_11_DIRECTIVE', 'REFERENCE_MODE=EDIT_NOT_REBUILD' in d and 'holographic 3D heart' in d and 'exactly four secondary corner hearts' in d, d)
f=E.diagnose_failure({'wrong_color_target':True,'hero_heart_not_embraced':True,'long_text_forced_into_frame':True})
check('V240_12_FAILURES', f['failure_codes']==['LONG_TEXT_FORCED_INTO_FRAME','WRONG_COLOR_TARGET','HERO_HEART_NOT_EMBRACED'], str(f))
co=C.compile_prompt('Use the reference image and create a cyber birthday purple pink love frame with exact text "HAPPY BIRTHDAY MY ANGEL!" and lower text I LOVE YOU')
check('V240_13_COMPILER', 'PHOTOREALISTIC_PRESET_EXPANSION' in co['selected_modules'] and '[PRESET_EXPANSION]' in co['compiled_prompt'], str(co['selected_modules']))
check('V240_14_COMPILER_REPORT', co['preset_expansion_report']['cyber_love_addon']['active'], str(co['preset_expansion_report']))
co=C.compile_prompt('Write a long acceptance message and preserve the original wording in a warm sunset scene')
check('V240_15_COMPILER_NARRATIVE', co['preset_expansion_report']['text_mode']=='NARRATIVE_MESSAGE', str(co['preset_expansion_report']))
if fails:
    print('V2.4.0 PRESET TESTS = FAIL'); print('\n'.join(fails)); sys.exit(1)
print('V2.4.0 PRESET TESTS = PASS (15/15)')
