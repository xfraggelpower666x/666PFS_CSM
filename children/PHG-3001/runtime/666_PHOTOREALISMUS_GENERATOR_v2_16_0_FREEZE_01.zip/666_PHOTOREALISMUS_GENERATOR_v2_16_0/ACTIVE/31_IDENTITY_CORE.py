#!/usr/bin/env python3
"""Identity-core and creative-drift policy engine for 666 PRG v2.0.0."""
from __future__ import annotations
import hashlib, json, re

DEFAULT_PROTECTED = [
    "facial_geometry", "eye_shape_and_spacing", "nose_and_mouth_structure",
    "age_range", "ethnicity_cues", "skin_identity_features", "hair_identity_cues",
    "body_proportions", "distinctive_marks"
]
DEFAULT_MUTABLE = ["outfit", "accessories", "pose", "gaze", "camera_distance", "camera_angle", "background", "lighting", "effects"]
HIGH_DRIFT_TERMS = ("different person", "replace face", "new identity", "change ethnicity", "make younger", "make older", "anderes gesicht", "andere person")

def digest(value:str)->str: return hashlib.sha256(value.encode("utf-8")).hexdigest()
def _norm(v:str)->str: return re.sub(r"\s+"," ",(v or "").casefold()).strip()

def build_profile(source_id:str, source_hash:str, person_count:int=1, observed_traits:list[dict]|None=None, creativity_budget:float=0.35)->dict:
    if not source_id or not re.fullmatch(r"[A-Fa-f0-9]{64}", source_hash or ""): raise ValueError("IDENTITY_SOURCE_PROOF_INVALID")
    if person_count < 1: raise ValueError("IDENTITY_PERSON_COUNT_INVALID")
    if not 0.0 <= float(creativity_budget) <= 1.0: raise ValueError("CREATIVITY_BUDGET_INVALID")
    observed_traits=observed_traits or []
    persons=[]
    for i in range(person_count):
        obs=observed_traits[i] if i < len(observed_traits) and isinstance(observed_traits[i],dict) else {}
        persons.append({"person_id":obs.get("person_id") or f"P{i+1}","protected_traits":list(dict.fromkeys(DEFAULT_PROTECTED+list(obs.get("protected_traits",[])))),"mutable_traits":list(dict.fromkeys(DEFAULT_MUTABLE+list(obs.get("mutable_traits",[])))),"identity_weight":float(obs.get("identity_weight",0.92)),"notes":str(obs.get("notes",""))})
    profile={"source_id":source_id,"source_hash":source_hash,"persons":persons,"global_creativity_budget":float(creativity_budget),"cross_person_merge_forbidden":True,"identity_override_requires_explicit_user_intent":True}
    profile["identity_profile_hash"]=digest(json.dumps(profile,ensure_ascii=False,sort_keys=True,separators=(",",":")))
    return profile

def evaluate_intent(profile:dict, intent:str, explicit_identity_override:bool=False)->dict:
    if not isinstance(profile,dict) or not profile.get("persons"): raise ValueError("IDENTITY_PROFILE_MISSING")
    text=_norm(intent)
    high_drift=any(t in text for t in HIGH_DRIFT_TERMS)
    mutable_hits=[m for m in DEFAULT_MUTABLE if m.replace("_"," ") in text]
    requested_pressure=min(1.0, 0.12 + 0.08*len(mutable_hits) + (0.75 if high_drift else 0.0))
    budget=float(profile.get("global_creativity_budget",0.35))
    veto=high_drift and not explicit_identity_override
    over_budget=requested_pressure > max(budget,0.2) and high_drift
    decision="IDENTITY_VETO" if veto or over_budget else "ALLOW_WITH_IDENTITY_LOCK"
    return {"decision":decision,"requested_creativity_pressure":round(requested_pressure,3),"creativity_budget":budget,"high_identity_drift":high_drift,"mutable_dimensions":mutable_hits,"person_ids":[p['person_id'] for p in profile['persons']],"cross_person_merge_forbidden":True}

def prompt_contract(profile:dict)->str:
    people=[]
    for p in profile.get("persons",[]):
        people.append(f"{p['person_id']}: preserve {', '.join(p.get('protected_traits',[]))}; mutable only: {', '.join(p.get('mutable_traits',[]))}; identity weight {p.get('identity_weight',0.92):.2f}")
    return "[IDENTITY_CORE] Source identity is anchored to SHA-256 " + str(profile.get('source_hash')) + ". Keep each person separate; never merge identities. " + " | ".join(people)
