#!/usr/bin/env python3
"""FRAME_MODES acceptance tests for 666 PRG v2.3.0."""
from pathlib import Path
import importlib.util, sys
R=Path(__file__).resolve().parent

def load(name,file):
    spec=importlib.util.spec_from_file_location(name,R/file); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
f=load("frame_modes","38_FRAME_MODES.py")
c=load("compiler","26_PROMPT_COMPILER.py")
fails=[]
def check(name, cond, detail=""):
    if not cond: fails.append(f"{name}:{detail}")

r=f.analyze("Mach bitte einen Rahmen um das Bild")
check("F01_GENERIC_ACTIVE", r['active'], str(r))
check("F02_GENERIC_CLEAN", r['mode']=='FRAME_MODE_CLEAN_BORDER', str(r))
r=f.analyze("Holografischer Cyber Love Rahmen mit Stacheldraht und Herzen")
check("F03_CYBERLOVE", r['mode']=='FRAME_MODE_CYBER_LOVE_HOLO', str(r))
check("F04_BARBED", r['parameters'].get('barbed_wire') is True, str(r))
r=f.analyze("dünner weißer Rahmen ohne Herzen")
check("F05_EXPLICIT_CLEAN", r['mode']=='FRAME_MODE_CLEAN_BORDER', str(r))
check("F06_NO_HEARTS", r['parameters'].get('love_symbols') is False, str(r))
r=f.analyze("Frame Fraggle Herz Veluna in Holo Neon Blau")
check("F07_SIGNATURE", r['signature'].get('enabled') and r['signature'].get('center_symbol_color')=='red_neon', str(r))
r=f.analyze("Bitte ändere nur die Haare")
check("F08_NOT_FORCED", not r['active'], str(r))
co=c.compile_prompt("Holografischer Cyber-Love-Rahmen mit Stacheldraht um das Bild")
check("F09_COMPILER_MODULE", 'FRAME_MODES_FAMILY' in co['selected_modules'], str(co['selected_modules']))
check("F10_FRAME_AUTO", co['frame_modes_report']['active'] and '[FRAME_MODES]' in co['compiled_prompt'], co['compiled_prompt'])
co2=c.compile_prompt("Create an ordinary landscape")
check("F11_COMPILER_NOT_FORCED", 'FRAME_MODES_FAMILY' not in co2['selected_modules'], str(co2['selected_modules']))
if fails:
    print('FRAME MODES TESTS = FAIL'); print('\n'.join(fails)); sys.exit(1)
print('FRAME MODES TESTS = PASS (11/11)')
