#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, sys
R=Path(__file__).resolve().parent

def load(n,p):
    s=importlib.util.spec_from_file_location(n,R/p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load('addon','53_REALISM_CONTROL_ADDON.py')
C=load('compiler','26_PROMPT_COMPILER.py')
checks=[]
def ok(v,msg): checks.append((bool(v),msg))
r=A.analyze('Keep the same reference image and person. Cyberpunk realism, cinematic neon lighting, exact text, image series consistency.')
ok(r['active'],'addon active')
ok('RIG-09-MULTI_IMAGE_CONSISTENCY' in r['selected_modules'],'series module')
ok(r['lighting_preset']=='CINEMATIC_NEON','lighting route')
c=C.compile_prompt('Use the same reference image. Cyberpunk realism with cinematic neon lighting and series consistency.',source_traits=['human','reference image'])
ok('realism_control_report' in c,'compiler report')
ok('[REALISM_CONTROL_ADDON]' in c['compiled_prompt'],'compiler directive')

# v2.7.0 integration-specific regression checks
r0=A.analyze('Create a quiet interior with a wooden chair.')
ok(not r0['active'],'ordinary unrelated prompt remains uninjected')
r2=A.analyze('Keep the same reference photo and same face, preserve crop, exact text, correct hands, natural light.')
ok('RIG-10-REFERENCE_MATCH' in r2['selected_modules'],'reference match route')
ok('RIG-04-HANDS_ANATOMY_REPAIR' in r2['selected_modules'],'hands anatomy route')
ok('RIG-07-TEXT_RENDER_CONTROL' in r2['selected_modules'],'exact text route')
ok(r2['lighting_preset']=='NATURAL_DOCUMENTARY','natural lighting route')
c0=C.compile_prompt('Create a quiet interior with a wooden chair.', source_traits=['environment'])
ok('realism_control_report' in c0,'compiler always returns report object')
ok('[REALISM_CONTROL_ADDON]' not in c0['compiled_prompt'],'no unrelated compiler directive')
fail=[m for v,m in checks if not v]
if fail:
 print('REALISM CONTROL ADDON TESTS = FAIL'); print('\n'.join(fail)); sys.exit(1)
print(f'REALISM CONTROL ADDON INTEGRATION TESTS = PASS ({len(checks)}/{len(checks)})')
