#!/usr/bin/env python3
"""Acceptance-Tests für ASPECT_RATIO_ENGINE und das Broadcast-Preset."""
from pathlib import Path
import importlib.util
import sys

ROOT = Path(__file__).resolve().parent


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


engine = load("aspect_ratio_engine", "40_ASPECT_RATIO_ENGINE.py")
compiler = load("prompt_compiler_v220", "26_PROMPT_COMPILER.py")
fails = []


def check(name, condition, detail=""):
    if not condition:
        fails.append(f"{name}:{detail}")


r = engine.analyze("Erstelle das Bild exakt in 16:9")
check("A01_EXPLICIT_16_9", r["active"] and r["aspect_ratio"] == "16:9" and r["override_default"], str(r))
r = engine.analyze("Vertical poster 9:16")
check("A02_EXPLICIT_9_16", r["aspect_ratio"] == "9:16" and r["orientation"] == "vertical_portrait", str(r))
r = engine.analyze("Square cover 1:1")
check("A03_EXPLICIT_1_1", r["aspect_ratio"] == "1:1", str(r))
r = engine.analyze("Classic 4:3 visual")
check("A04_EXPLICIT_4_3", r["aspect_ratio"] == "4:3", str(r))
r = engine.analyze("Portrait artwork 3:4")
check("A05_EXPLICIT_3_4", r["aspect_ratio"] == "3:4", str(r))
r = engine.analyze("LYVRA cyber holo WebRadio broadcaster poster")
check("A06_PRESET_ACTIVE", r["preset_id"] == "PRESET_LYVRA_CYBER_HOLO_BROADCAST_16_9", str(r))
check("A07_PRESET_DEFAULTS", r["aspect_ratio"] == "16:9" and r["output_variants"] == 5, str(r))
check("A08_PRESET_TEXT", r["visible_text"] == "666SOUNDsDESIGn L.Y.V.R.A. WEBRADIO & BROADCASTER", str(r))
check("A09_PRESET_FRAME", r["frame_mode"] == "FRAME_MODE_CYBER_HOLO" and r["layers"].get("ai_symbol_layer"), str(r))
r = engine.analyze("LYVRA WebRadio broadcaster poster 9:16, 7 variants")
check("A10_USER_OVERRIDE", r["aspect_ratio"] == "9:16" and r["output_variants"] == 7 and r["override_default"], str(r))
r = engine.analyze("Create an ordinary landscape")
check("A11_NO_FALSE_LANDSCAPE", not r["active"], str(r))
r = engine.analyze("Create a Discord banner")
check("A12_DISCORD_BANNER", r["aspect_ratio"] == "16:9" and not r["preset_id"], str(r))
compiled = compiler.compile_prompt("666SOUNDsDESIGn L.Y.V.R.A. WEBRADIO & BROADCASTER, cyber holo AI symbols, 16:9, 5 variants")
check("A13_COMPILER_MODULE", "ASPECT_RATIO_AND_BROADCAST_PRESET" in compiled["selected_modules"], str(compiled["selected_modules"]))
check("A14_COMPILER_DIRECTIVE", "[BROADCAST_PRESET]" in compiled["compiled_prompt"] and compiled["aspect_ratio_report"]["output_variants"] == 5, compiled["compiled_prompt"])
check("A15_EXTERNAL_BOUNDARY", compiled["aspect_ratio_report"]["external_system_mutation"] is False, str(compiled["aspect_ratio_report"]))

if fails:
    print("ASPECT RATIO TESTS = FAIL")
    print("\n".join(fails))
    sys.exit(1)
print("ASPECT RATIO TESTS = PASS (15/15)")
