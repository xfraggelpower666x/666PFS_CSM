#!/usr/bin/env python3
"""PHG-3001 v2.11.0 Causal Visual Intelligence & Continuity Engine (CVICE)."""
from __future__ import annotations
from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parent
REGISTRY=json.loads((ROOT/"68_CVICE_REGISTRY.json").read_text(encoding="utf-8"))
VERSION=REGISTRY["version"]
ENGINE_ID=REGISTRY["engine_id"]

EXPLICIT_TRIGGERS=(
    "prg-cvice-002",
    "causal visual intelligence",
    "visual intelligence continuity engine",
    "causal visual intelligence & continuity engine",
    "reference identity continuity engine",
)
MULTI_REFERENCE_TERMS=("multi-reference","multiple references","mehrere referenzen","mehrere referenzbilder","reference graph","referenzgraph")
CONTINUITY_TERMS=("identity continuity","visual continuity","continuity","identitätskontinuität","identitaetskontinuitaet")
EVOLUTION_TERMS=("evolution sequence","visual evolution","cyberbiology","evolution stages","entwicklungsstufen","self-chosen form")
WORLD_FUSION_TERMS=("world-native fusion","world native fusion","one world","shared environment","anti-collage","welt-native fusion")
KEY_ART_TERMS=("key art","key-art","album cover","cover art","cover artwork","albumcover")
REPAIR_TERMS=("minimal-invasive repair","minimal invasive repair","targeted repair","repair only","nur reparieren","identity drift")
SYMBOLIC_TERMS=("symbolic story scene","symbolic causality","symbolic scene","narrative symbol")
DUALITY_TERMS=("single being duality","one being","angel devil","human machine","organic synthetic")
COUPLE_TERMS=("couple continuity","two identities","separate identities","paar kontinuität","paar kontinuitaet")

ROLE_KEYWORDS={
 "IDENTITY_REFERENCE":("identity","identität","identitaet","same person","character identity"),
 "FACE_REFERENCE":("face","facial","gesicht"),
 "BODY_REFERENCE":("body reference","body shape","körper","koerper"),
 "ANATOMY_REFERENCE":("anatomy","anatomie"),
 "SKIN_REFERENCE":("skin","haut"),
 "HAIR_REFERENCE":("hair","haare","frisur"),
 "AGE_REFERENCE":("age","alter"),
 "POSE_REFERENCE":("pose","stance","haltung"),
 "BODY_LANGUAGE_REFERENCE":("body language","körpersprache","koerpersprache"),
 "CLOTHING_REFERENCE":("clothing","outfit","wardrobe","kleidung"),
 "MATERIAL_REFERENCE":("material","fabric","metal","glass","stoff","metall","glas"),
 "CYBER_INTEGRATION_REFERENCE":("cyber integration","cybernetic","biomechanical","bio-synthetic"),
 "LIGHTING_REFERENCE":("lighting","light reference","beleuchtung","licht"),
 "CAMERA_REFERENCE":("camera","lens","perspective","kamera","objektiv"),
 "ENVIRONMENT_REFERENCE":("environment","background","world reference","umgebung","hintergrund"),
 "EVOLUTION_REFERENCE":("evolution","stage","entwicklung"),
 "SYMBOLIC_REFERENCE":("symbol","symbolic","symbolisch"),
 "COMPOSITION_REFERENCE":("composition","layout","komposition"),
 "BRAND_REFERENCE":("brand","branding","logo identity","marke")
}

PROFILE_ROUTES=(
 (KEY_ART_TERMS,"PRG_PRESET_ALBUM_COVER"),
 (("causal key art","key art",),"PRG_PRESET_CAUSAL_KEY_ART"),
 (("cyberbiology","cyber biology","cyberbiologie"),"PRG_PRESET_CYBERBIOLOGY"),
 (EVOLUTION_TERMS,"PRG_PRESET_EVOLUTION_SEQUENCE"),
 (DUALITY_TERMS,"PRG_PRESET_SINGLE_BEING_DUALITY"),
 (COUPLE_TERMS,"PRG_PRESET_COUPLE_CONTINUITY"),
 (WORLD_FUSION_TERMS,"PRG_PRESET_WORLD_NATIVE_FUSION"),
 (SYMBOLIC_TERMS,"PRG_PRESET_SYMBOLIC_STORY_SCENE"),
)

def _norm(v:str|None)->str:
    return re.sub(r"\s+"," ",(v or "").casefold()).strip()

def _has_any(text:str, terms)->bool:
    return any(term in text for term in terms)

def active_for(text:str, source_traits:list[str]|None=None)->bool:
    t=_norm((text or "")+" "+" ".join(source_traits or []))
    if _has_any(t,EXPLICIT_TRIGGERS): return True
    if _has_any(t,MULTI_REFERENCE_TERMS) and (_has_any(t,CONTINUITY_TERMS) or "identity" in t or "reference" in t): return True
    if _has_any(t,EVOLUTION_TERMS) and ("reference" in t or "identity" in t or "stage" in t): return True
    if _has_any(t,WORLD_FUSION_TERMS) and ("reference" in t or "image" in t or "scene" in t): return True
    if _has_any(t,KEY_ART_TERMS) and ("reference" in t or "identity" in t or "causal" in t): return True
    if _has_any(t,REPAIR_TERMS) and ("image" in t or "identity" in t or "reference" in t): return True
    return False

def detect_profile(text:str)->str:
    t=_norm(text)
    for terms,profile in PROFILE_ROUTES:
        if _has_any(t,terms): return profile
    return "PRG_PRESET_WORLD_NATIVE_FUSION" if _has_any(t,MULTI_REFERENCE_TERMS) else "PRG_PRESET_CAUSAL_KEY_ART"

def classify_reference_roles(text:str)->list[str]:
    t=_norm(text)
    roles=[role for role,terms in ROLE_KEYWORDS.items() if _has_any(t,terms)]
    return roles or ["IDENTITY_REFERENCE"] if "reference" in t else []

def validate_reference_graph(reference_specs:list[dict]|None)->dict:
    specs=list(reference_specs or [])
    if not specs:
        return {"status":"PASS","issues":[],"reference_count":0}
    issues=[]
    seen=set()
    binding_claims={}
    role_use=0
    for i,s in enumerate(specs):
        rid=str(s.get("id") or f"REF_{i+1}")
        if rid in seen: issues.append({"status":"REFERENCE_CONFLICT_HOLD","detail":f"duplicate reference id {rid}"})
        seen.add(rid)
        authority=str(s.get("authority","P2")).upper()
        if authority not in REGISTRY["authority_levels"]:
            issues.append({"status":"REFERENCE_CONFLICT_HOLD","detail":f"invalid authority {authority} for {rid}"})
        roles=[str(x).upper() for x in s.get("roles",[])]
        if not roles:
            issues.append({"status":"REFERENCE_UNDERUSE","detail":f"{rid} has no assigned role"})
        role_use += len(roles)
        binding=str(s.get("binding","GLOBAL"))
        if authority=="P0":
            for role in roles:
                key=(binding,role)
                if key in binding_claims:
                    issues.append({"status":"REFERENCE_CONFLICT_HOLD","detail":f"P0 collision {key}: {binding_claims[key]} vs {rid}"})
                else:
                    binding_claims[key]=rid
    if len(specs)>1 and role_use and any(len(s.get("roles",[])) >= max(4, role_use*0.75) for s in specs):
        issues.append({"status":"REFERENCE_DOMINANCE_ERROR","detail":"one reference controls an excessive share of assigned traits"})
    priority={"REFERENCE_CONFLICT_HOLD":4,"REFERENCE_DOMINANCE_ERROR":3,"REFERENCE_UNDERUSE":2}
    status=max((x["status"] for x in issues), key=lambda s:priority.get(s,0), default="PASS")
    return {"status":status,"issues":issues,"reference_count":len(specs)}

def repair_directive(status:str)->str:
    return {
      "IDENTITY_DRIFT":"Restore original facial geometry, age, skin characteristics, eyes, mouth/nose/jaw and hairline before preserving current transformation details.",
      "FACE_BODY_INTEGRATION_FAILURE":"Keep the recognizable face; repair head scale, neck, shoulders, perspective, lighting, skin continuity, texture and body proportions only.",
      "REFERENCE_UNDERUSE":"Rebind the underused reference to explicit roles/traits and increase authority only for those traits; do not redesign unrelated areas.",
      "REFERENCE_DOMINANCE_ERROR":"Restrict the dominant reference to its intended roles, body regions, stages or scene functions.",
      "REFERENCE_CONFLICT_HOLD":"Hold generation until conflicting authorities/bindings are resolved; do not average canonical conflicts.",
      "COLLAGE_ARTIFACT":"Reconstruct source information natively inside one world with shared perspective, materials, lighting and reflections.",
      "ROBOTIZATION_DRIFT":"Increase integration, biological coherence, natural surface and cultural identity rather than adding more exposed machinery.",
      "ENVIRONMENT_STAGNATION":"Allow the environment to evolve with subject agency when narrative continuity supports it.",
      "STYLE_DRIFT":"Reduce historical/legacy style dominance and rebind only affected current visual traits.",
      "TEXT_DRIFT":"Restore exact requested visible text; remove optional text before compromising critical text.",
      "LIMB_OWNERSHIP_ERROR":"Repair only ambiguous limb/contact ownership while preserving correct identities and composition.",
      "ANATOMY_FAILURE":"Repair the defective anatomy locally before changing successful faces, clothing or environment.",
      "SCHEMA_DRIFT":"Restore approved stage count, order, names and functions without silent merge/reorder.",
      "MIXED_RENDER_REALISM":"Unify surface response, detail scale, optics, lighting and atmospheric scattering into one photographic world.",
    }.get(status,"Repair only the identified defect and preserve all successful components.")

def analyze(text:str, *, source_traits:list[str]|None=None, reference_specs:list[dict]|None=None)->dict:
    if not active_for(text,source_traits):
        return {"active":False,"version":VERSION,"engine_id":ENGINE_ID}
    t=_norm(text)
    graph=validate_reference_graph(reference_specs)
    profile=detect_profile(text)
    return {
      "active":True,
      "version":VERSION,
      "engine_id":ENGINE_ID,
      "mode":"ADD_ONLY",
      "umip_dependency":"NONE",
      "umip_mutation":"FORBIDDEN",
      "profile":profile,
      "layers":list(REGISTRY["layers"]),
      "reference_roles_detected":classify_reference_roles(text),
      "reference_authority":dict(REGISTRY["authority_levels"]),
      "reference_graph_audit":graph,
      "identity_root_chain":list(REGISTRY["identity_root_chain"]),
      "multi_person_identity_isolation":"HARD",
      "limb_ownership":"REQUIRED",
      "contact_anatomy":"REQUIRED",
      "single_being_duality_lock": profile=="PRG_PRESET_SINGLE_BEING_DUALITY",
      "evolution_schema_lock": profile=="PRG_PRESET_EVOLUTION_SEQUENCE",
      "evolution_not_upgrade":True,
      "robotization_drift_guard":"ACTIVE",
      "world_native_fusion":"ACTIVE",
      "collage_detector":"ACTIVE",
      "minimal_invasive_repair":"ACTIVE",
      "cover_not_infographic": profile in {"PRG_PRESET_CAUSAL_KEY_ART","PRG_PRESET_ALBUM_COVER"},
      "quality_targets_percent":dict(REGISTRY["quality_targets_percent"]),
      "failure_statuses":list(REGISTRY["failure_statuses"]),
      "workflow":list(REGISTRY["workflow"]),
      "priority_order":list(REGISTRY["priority_order"]),
      "subprofiles":list(REGISTRY["subprofiles"]),
      "non_destructive":True,
    }

def compact_directive(report:dict)->str:
    if not report.get("active"): return ""
    profile=report["profile"]
    return (
      f"{ENGINE_ID} v{VERSION} ({profile}): preserve canonical identity first and interpret every supplied reference by explicit role and authority before combining anything. "
      "Transfer only bound traits instead of averaging whole images; keep each person on a separate identity root, verify face-body integration, limb ownership and contact anatomy. "
      "Maintain one shared photographic world with coherent materials, perspective, lighting, reflections and atmosphere; source screenshots/diagrams/symbols must become world-native elements rather than collage panels unless explicitly requested. "
      "For evolution, protect approved stage count/order/functions and treat development as integration, individuality, culture and autonomy—not automatic increased mechanization; guard ROBOTIZATION_DRIFT and ENVIRONMENT_STAGNATION. "
      "For cover/key-art modes, compress causal meaning into one cinematic composition rather than an infographic while preserving exact critical typography and semantic separation of title/artist/brand. "
      "If one component fails, repair only that component: preserve successful identity, composition, clothing and environment. Hold instead of averaging unresolved P0/P1 reference conflicts. "
      "UMIP may provide text concepts only; UMIP visual authority/mutation is forbidden. Final gate audits identity fidelity, anatomy, materials, lighting, reference utilization, world integration, narrative causality and style continuity."
    )
