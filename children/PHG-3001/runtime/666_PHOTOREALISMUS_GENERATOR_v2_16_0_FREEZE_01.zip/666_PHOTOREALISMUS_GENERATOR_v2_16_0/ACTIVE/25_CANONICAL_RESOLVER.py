#!/usr/bin/env python3
"""Resolve and verify the canonical ACTIVE runtime without loading LEGACY."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "00_ACTIVE_MANIFEST.json").read_text(encoding="utf-8"))
errors = []
if manifest.get("active_root") != "ACTIVE":
    errors.append("ACTIVE_ROOT_MISMATCH")
if not manifest.get("version"):
    errors.append("VERSION_MISSING")
if manifest.get("child_release_version") != manifest.get("version"):
    errors.append("CHILD_RELEASE_VERSION_MISMATCH")
for key in ("runtime_entry", "validator", "acceptance_runner", "host_turn_executor", "hardlock_test_runner", "prompt_compiler", "visual_qa_engine", "host_result_executor", "guard_handler_registry", "deep_acceptance_runner"):
    rel = manifest.get(key)
    if not rel:
        errors.append(f"MISSING_POINTER:{key}")
        continue
    p = ROOT.parent / rel
    if not p.is_file():
        errors.append(f"BROKEN_POINTER:{key}:{rel}")
if errors:
    print("CANONICAL RESOLVER = FAIL")
    print("\n".join(errors))
    sys.exit(1)
print(f"CANONICAL RESOLVER = PASS (ACTIVE v{manifest.get('version')}, LEGACY isolated)")
