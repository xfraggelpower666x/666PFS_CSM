#!/usr/bin/env python3
"""Deterministischer Aspect-Ratio- und Broadcast-Preset-Router für PHG-3001 v2.2.0."""
from __future__ import annotations

from pathlib import Path
import json
import re

VERSION = "1.0.0"
ROOT = Path(__file__).resolve().parent
PRESETS = json.loads((ROOT / "42_BROADCAST_PRESET_REGISTRY.json").read_text(encoding="utf-8"))

SUPPORTED_RATIOS = {
    "1:1": {"orientation": "square", "use": "profile, cover, square post"},
    "4:3": {"orientation": "landscape", "use": "classic landscape media"},
    "3:4": {"orientation": "portrait", "use": "classic portrait media"},
    "16:9": {"orientation": "widescreen_landscape", "use": "broadcast, desktop, YouTube, Discord banner"},
    "9:16": {"orientation": "vertical_portrait", "use": "story, reel, vertical promotional media"},
}

RATIO_PATTERNS = {
    ratio: re.compile(r"(?<!\d)" + re.escape(ratio).replace(":", r"\s*[:x×]\s*") + r"(?!\d)", re.IGNORECASE)
    for ratio in SUPPORTED_RATIOS
}

BROADCAST_TERMS = (
    "webradio", "web radio", "broadcaster", "broadcast", "radio banner",
    "discord banner", "youtube banner", "lyvra cyber holo broadcast",
)
EXPLICIT_16_9_TERMS = (
    "widescreen", "wide screen", "horizontal banner", "landscape format",
    "landscape orientation", "desktop wallpaper", "broadcast graphic",
)
EXPLICIT_9_16_TERMS = (
    "vertical banner", "portrait format", "portrait orientation", "story format", "reel format",
)


def _norm(value: str | None) -> str:
    return re.sub(r"\s+", " ", (value or "").casefold()).strip()


def _explicit_ratio(text: str) -> str | None:
    """Die zuletzt ausdrücklich genannte Ratio gewinnt bei mehreren Angaben."""
    matches: list[tuple[int, str]] = []
    for ratio, pattern in RATIO_PATTERNS.items():
        matches.extend((m.start(), ratio) for m in pattern.finditer(text))
    return max(matches)[1] if matches else None


def _contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def _variant_count(text: str, default: int) -> int:
    patterns = (
        r"\b(\d{1,2})\s*(?:variants?|varianten?|versions?|versionen?)\b",
        r"\b(?:variants?|varianten?|versions?|versionen?)\s*[:=]?\s*(\d{1,2})\b",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return max(1, min(10, int(match.group(1))))
    return default


def analyze(text: str) -> dict:
    normalized = _norm(text)
    explicit_ratio = _explicit_ratio(normalized)
    has_lyvra = "lyvra" in normalized or "l.y.v.r.a." in normalized
    broadcast_intent = _contains_any(normalized, BROADCAST_TERMS)
    preset_active = has_lyvra and broadcast_intent

    inferred_ratio = None
    if preset_active or _contains_any(normalized, EXPLICIT_16_9_TERMS) or "discord banner" in normalized or "youtube banner" in normalized:
        inferred_ratio = "16:9"
    elif _contains_any(normalized, EXPLICIT_9_16_TERMS):
        inferred_ratio = "9:16"

    ratio = explicit_ratio or inferred_ratio
    active = bool(ratio or preset_active)
    preset = PRESETS["presets"]["PRESET_LYVRA_CYBER_HOLO_BROADCAST_16_9"] if preset_active else None
    if preset_active and ratio is None:
        ratio = preset["default_aspect_ratio"]

    default_variants = int(preset["output_variants_default"]) if preset else 1
    result = {
        "active": active,
        "engine_version": VERSION,
        "aspect_ratio": ratio,
        "explicit_ratio": explicit_ratio,
        "override_default": explicit_ratio is not None,
        "orientation": SUPPORTED_RATIOS.get(ratio, {}).get("orientation") if ratio else None,
        "supported_ratios": list(SUPPORTED_RATIOS),
        "preset_id": preset["preset_id"] if preset else None,
        "preset_display_name": preset["display_name"] if preset else None,
        "output_variants": _variant_count(normalized, default_variants) if active else 1,
        "visible_text": preset["visible_text"] if preset else None,
        "frame_mode": preset["frame_mode"] if preset else None,
        "style": list(preset["style"]) if preset else [],
        "layers": dict(preset["layers"]) if preset else {},
        "external_system_mutation": False,
        "lyvra_role": "VISUAL_BRANDING_CONTEXT_ONLY" if preset else None,
    }
    return result


def compact_directive(report: dict) -> str:
    if not report.get("active"):
        return ""
    ratio = report.get("aspect_ratio")
    bits = [
        f"Render the canvas at exact aspect ratio {ratio}; preserve that ratio through final output.",
        "An explicit user ratio overrides every inferred or preset default.",
    ]
    if report.get("preset_id"):
        bits.extend([
            f"Activate visual preset {report['preset_id']} with {report['frame_mode']}.",
            "Use a premium symmetrical LYVRA cyber-resonance poster composition with holographic AI interface symbols, waveform/resonance architecture and coherent neon purple, neon blue and magenta; gold is optional and subordinate.",
            f"Render this visible title exactly once with exact spelling and punctuation: {report['visible_text']}",
            f"Produce {report['output_variants']} compositionally distinct variants while keeping the visible title and requested aspect ratio fixed.",
            "Treat LYVRA only as visual branding context; do not infer or mutate any external system, identity registry, bootstrap or storage route.",
        ])
    return " ".join(bits)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("intent")
    args = parser.parse_args()
    print(json.dumps(analyze(args.intent), ensure_ascii=False, indent=2))
