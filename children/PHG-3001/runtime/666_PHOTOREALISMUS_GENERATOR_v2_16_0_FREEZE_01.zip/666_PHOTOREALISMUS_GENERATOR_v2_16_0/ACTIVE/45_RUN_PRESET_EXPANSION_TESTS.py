#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys
R=Path(__file__).resolve().parent

def load(name,file):
    spec=importlib.util.spec_from_file_location(name,R/file); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
E=load("preset_expansion","43_PRESET_EXPANSION_ENGINE.py")
C=load("compiler","26_PROMPT_COMPILER.py")
fails=[]
def check(name, cond, detail=""):
    if not cond: fails.append(f"{name}:{detail}")

r=E.analyze("Use the reference image and keep the same pose", source_traits=["reference_image"])
check("P01_REFERENCE_ACTIVE", r["active"] and r["reference_present"], str(r))
check("P02_LOCKS", all(r["locks"][k] for k in ("character","pose","outfit","background","camera","hair","tattoos","relative_positions")), str(r["locks"]))
r=E.analyze("LOVE_FRAME_NEON_PINK")
check("P03_PRESET_PINK", r["preset_id"]=="LOVE_FRAME_NEON_PINK", str(r))
check("P04_SAFE_MARGIN", r["frame"]["safe_margin_percent"]==5, str(r["frame"]))
r=E.analyze("LOVE_FRAME_ELECTRIC_BLUE")
check("P05_PRESET_BLUE", r["preset_id"]=="LOVE_FRAME_ELECTRIC_BLUE", str(r))
r=E.analyze("GODS SCRIBED MY FATE IN STARS")
check("P06_PRESET_OMEN", r["preset_id"]=="OLD_OMEN_ROSE_STARS", str(r))
r=E.analyze("A LOVE OLDER THAN THE STARS STILL CALLS MY NAME with BLUE FISH")
check("P07_PRESET_TANG", r["preset_id"]=="STARS_BLUE_TANG_FATE", str(r))
check("P08_BLUE_FISH_ASSET", bool(r["semantic_assets"]) and r["semantic_assets"][0]["asset_id"]=="BLUE_PALETTE_SURGEONFISH", str(r))
check("P09_BLUE_FISH_TEXT_OFF", r["semantic_assets"][0]["text_render"] is False, str(r))
r=E.analyze("DEEP DARK CRAZY NEON")
check("P10_PRESET_DARK", r["preset_id"]=="DEEP_DARK_CRAZY_NEON", str(r))
r=E.analyze('Frame with exact text "VELUNA" and "FRAGGEL"')
check("P11_TEXT_STRICT", r["typography"]["exactness"]=="STRICT", str(r))
check("P12_LITERAL_CAPTURE", r["typography"]["quoted_literals"]==["VELUNA","FRAGGEL"], str(r))
d=E.compact_directive(E.analyze("frame with BLUE FISH"))
check("P13_DIRECTIVE_SAFE", "fully visible on all four sides" in d and "BLUE_PALETTE_SURGEONFISH" in d, d)
f=E.diagnose_failure({"frame_cropped":True,"generic_fish":True})
check("P14_FAILURE_CODES", f["failure_codes"]==["FRAME_CROPPED","GENERIC_FISH"], str(f))
check("P15_REPAIR", len(f["repair_directives"])==2 and f["repairable"], str(f))
co=C.compile_prompt("LOVE_FRAME_NEON_PINK with exact text VELUNA FRAGGEL")
check("P16_COMPILER_SELECT", "PHOTOREALISTIC_PRESET_EXPANSION" in co["selected_modules"], str(co["selected_modules"]))
check("P17_COMPILER_DIRECTIVE", "[PRESET_EXPANSION]" in co["compiled_prompt"], co["compiled_prompt"])
co=C.compile_prompt("put BLUE FISH in the frame")
check("P18_COMPILER_ASSET", co["preset_expansion_report"]["semantic_assets"][0]["asset_id"]=="BLUE_PALETTE_SURGEONFISH", str(co["preset_expansion_report"]))
co=C.compile_prompt("ordinary photorealistic landscape")
check("P19_NOT_FORCED", not co["preset_expansion_report"]["active"], str(co["preset_expansion_report"]))
r=E.analyze("write BLUE FISH as text")
check("P20_TEXT_OVERRIDE", r["semantic_assets"]==[], str(r))
if fails:
    print("PRESET EXPANSION TESTS = FAIL"); print("\n".join(fails)); sys.exit(1)
print("PRESET EXPANSION TESTS = PASS (20/20)")
