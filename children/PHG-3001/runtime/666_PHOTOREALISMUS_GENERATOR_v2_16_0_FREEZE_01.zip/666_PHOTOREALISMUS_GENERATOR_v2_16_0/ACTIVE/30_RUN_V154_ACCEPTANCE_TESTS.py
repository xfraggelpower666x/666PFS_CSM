#!/usr/bin/env python3
"""Deep negative/positive acceptance suite for 666 PRG v2.0.0."""
from pathlib import Path
import importlib.util
import json
import tempfile
import time
import sys
import copy
import hashlib
import shutil

R=Path(__file__).resolve().parent

def module(name,filename):
    spec=importlib.util.spec_from_file_location(name,R/filename); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

k=module('v154_kernel','11_RUNTIME_KERNEL.py'); h=module('v154_host','19_HOST_TURN_EXECUTOR.py')
res=module('v154_result','28_HOST_RESULT_EXECUTOR.py'); qa=module('v154_qa','27_VISUAL_QA_ENGINE.py'); store=module('v154_store','22_RUNTIME_STORE.py')
fail=[]; passed=[]

def check(test_id,condition,detail=''):
    if condition: passed.append(test_id)
    else: fail.append(f'{test_id}: {detail or "FAILED"}')

def dispatch(text='Generate a photorealistic cyber neon couple portrait',state=None,src='SRC-A',sh='a'*64):
    return h.execute_turn(state or k.initial_state(),text,state is None,src if state is None else None,sh if state is None else None,tool_available=True)

def complete(text='Generate a photorealistic portrait'):
    d=dispatch(text)
    return res.process_result(d['state'],result_kind='SUCCESS',output_id='OUT-'+d['state']['transaction_id'][-4:],output_hash='b'*64,qa_report=qa.perfect_report())

# N01 no output proof cannot pass TOOL_RETURNED.
d=dispatch(); bad,rec,_=k.transition(d['state'],'TOOL_RETURNED',{**k.ownership_context(d['state']),'output_present':True})
check('N01',rec['result']=='GUARD_FAIL' and bad['state']=='RETRY_READY',bad.get('last_error_detail'))

# N02 strict ownership is mandatory.
bad,rec,_=k.transition(d['state'],'TOOL_RETURNED',{'output_present':True,'output_id':'OUT','transaction_id':'WRONG'})
check('N02',rec['result']=='GUARD_FAIL' and 'OWNERSHIP' in bad.get('last_error_detail',''),bad.get('last_error_detail'))

# N03 receipt validates against schema.
receipt=d['host_action']['receipt']; check('N03',not k.validate_receipt(receipt),str(k.validate_receipt(receipt)))

# N04 automatic retry performs a real second dispatch with a new prompt proof.
e=res.process_result(d['state'],result_kind='EMPTY'); r=h.execute_turn(e['state'],'render',False,tool_available=True)
check('N04',r['route']=='CALL_IMAGE_TOOL' and r['state']['attempt']==2 and bool(r['state']['prompt_hash']),r.get('reason',''))

# N05 targeted repair recompiles and dispatches.
d2=dispatch('Generate a portrait with accurate hands')
report=qa.perfect_report(); report['checks']['QA-ANATOMY']={'passed':False,'score':0.4,'observations':'Extra finger detected.'}
rr=res.process_result(d2['state'],result_kind='SUCCESS',output_id='OUT-R',output_hash='c'*64,qa_report=report)
r2=h.execute_turn(rr['state'],'render',False,tool_available=True)
check('N05',rr['route']=='REPAIR_READY' and r2['route']=='CALL_IMAGE_TOOL' and '[TARGETED_REPAIR]' in r2['host_action']['prompt'],r2.get('reason',''))

# N06 QA pass without complete evidence fails.
d3=dispatch(); own={**k.ownership_context(d3['state']),'output_present':True,'output_id':'OUT-Q','output_hash':'d'*64}
s,_,_=k.transition(d3['state'],'TOOL_RETURNED',own); s,_,_=k.transition(s,'OUTPUT_OBJECT_VALID',{**k.ownership_context(s),'output_present':True,'output_id':'OUT-Q','output_hash':'d'*64})
s,rec,_=k.transition(s,'VISUAL_QA_PASS',{**k.ownership_context(s),'output_present':True,'output_id':'OUT-Q','output_hash':'d'*64})
check('N06',rec['result']=='GUARD_FAIL',s.get('last_error_detail'))

# N07 score below threshold does not pass.
low=qa.perfect_report()
for item in low['checks'].values(): item['score']=0.5
check('N07',qa.evaluate(low)['decision']=='REPAIRABLE_FAIL',str(qa.evaluate(low)))

# N08 exact casing survives alias stripping and compilation.
d4=dispatch('Generate: Keep NASA and 666SOUNDsDESIGn exact')
p=d4['host_action']['prompt']; check('N08','NASA' in p and '666SOUNDsDESIGn' in p,p[:120])

# N09 creative system-like nouns remain creative.
cases=['create a neon guard standing at a gate','make a cyberpunk orchestra conductor','create a matrix rain background','make a hardlock door in a bunker']
check('N09',all(h.classify(x)=='CREATIVE_INTENT' for x in cases),str([(x,h.classify(x)) for x in cases]))

# N10 missing tool availability and source digest fail closed.
seed=k.initial_state(); seed,_,_=k.transition(seed,'NEW_IMAGE',{'source_id':'SRC-X','source_hash':'e'*64,'intent':'Portrait'}); seed,_,_=k.transition(seed,'SOURCE_RESOLVED',{})
t=h.execute_turn(seed,'render',False,tool_available=None)
missing=h.execute_turn(k.initial_state(),'Generate portrait',True,'SRC-Z',None,tool_available=True)
check('N10',t['route']=='TOOL_UNAVAILABLE' and missing['route']=='NEED_SOURCE_PROOF',f"{t['route']} / {missing['route']}")

# N11 CAS/revision conflict blocks stale writer.
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    first=store.persist_transaction(root,d4['state'],d4['journal'],[d4['host_action']['receipt']],expected_revision=0)
    conflict=False
    try: store.persist_transaction(root,d4['state'],[],[],expected_revision=0)
    except RuntimeError as exc: conflict='REVISION_CONFLICT' in str(exc)
    check('N11',first['state']['revision']==1 and conflict,'CAS conflict not enforced')

# N12 transaction store creates state/journal/receipt/commit as one generation.
with tempfile.TemporaryDirectory() as td:
    root=Path(td); out=store.persist_transaction(root,d4['state'],d4['journal'],[d4['host_action']['receipt']],expected_revision=0)
    files=['current_state.json','transaction_journal.jsonl','receipts.jsonl','last_commit.json']
    check('N12',all((root/'RUNTIME_STATE'/x).is_file() for x in files) and out['commit']['status']=='COMMITTED','transaction artifacts incomplete')

# N13 circuit breaker survives fresh transactions and blocks the fourth preflight.
s=None
for i in range(3):
    di=dispatch(f'Generate portrait {i}',state=s,src=f'SRC-{i}',sh=(str(i+1)*64)[:64]) if s is None else h.execute_turn(s,'again',False,tool_available=True)
    er=res.process_result(di['state'],result_kind='EMPTY')
    s=er['state']
blocked=h.execute_turn(s,'again',False,tool_available=True)
check('N13',s.get('circuit_open') is True and blocked['route']=='CIRCUIT_OPEN',f"open={s.get('circuit_open')} route={blocked['route']}")

# N14 full host callback reaches COMPLETE only with real output and QA.
co=complete(); check('N14',co['route']=='COMPLETE' and co['state']['state']=='COMPLETE' and not k.validate_runtime_state(co['state']),str(k.validate_runtime_state(co['state'])))

# N15 every hard guard has an executable active component.
handlers=json.loads((R/'29_GUARD_HANDLER_REGISTRY.json').read_text())['handlers']; guards=json.loads((R/'04_GUARD_REGISTER.json').read_text())['guards']
hm={x['guard_id']:x for x in handlers}
check('N15',all(g['id'] in hm and hm[g['id']]['status']=='ACTIVE' and (R/hm[g['id']]['component']).is_file() for g in guards),'handler coverage incomplete')

# N16 Frame Stage 2 starts a child transaction from validated Stage 1 output.
co=complete(); parent=co['state']['transaction_id']; fr=h.execute_turn(co['state'],'Add frame: brushed black metal',False,tool_available=True)
check('N16',fr['route']=='CALL_IMAGE_TOOL' and fr['state'].get('parent_transaction_id')==parent and fr['state'].get('frame_stage')=='ON',fr.get('reason',''))

# N17 duplicate output across fresh transactions is rejected.
co=complete(); same_id=co['state']['output_id']; same_hash=co['state']['output_hash']
fresh=h.execute_turn(co['state'],'again',False,tool_available=True)
dup=res.process_result(fresh['state'],result_kind='SUCCESS',output_id=same_id,output_hash=same_hash,qa_report=qa.perfect_report())
check('N17',dup['route']=='RETRY_READY' and 'DUPLICATE' in dup.get('reason',''),str(dup))

# N18 prompt compiler loads mandatory modules and relevant optional modules.
d5=dispatch('Generate a cyber neon couple embracing beside a glass window')
mods=set(d5['state']['prompt_modules']); mandatory=set(k.PROMPT_COMPILER.REGISTRY['mandatory_modules'])
check('N18',mandatory.issubset(mods) and {'COUPLE_INTERACTION','CYBER_NEON_ENVIRONMENT','REFLECTION_CONTROL'}.issubset(mods),str(sorted(mods)))

# N19 cancel and resume preserve source and produce a new dispatch.
d6=dispatch(); ca=h.execute_turn(d6['state'],'cancel render',False,tool_available=True); re=h.execute_turn(ca['state'],'resume',False,tool_available=True)
check('N19',ca['route']=='CANCELLED' and re['route']=='CALL_IMAGE_TOOL',f"{ca['route']} / {re['route']}")

# N20 explicit system maintenance remains protected.
check('N20',h.classify('Deep Audit and repair system')=='SYSTEM_MAINTENANCE','maintenance not protected')

# N21 prompt triggers use whole words/phrases instead of accidental substrings.
p21=k.PROMPT_COMPILER.compile_prompt('Create an abstract windowless concrete corridor')
check('N21','REFLECTION_CONTROL' not in set(p21['selected_modules']),str(p21['selected_modules']))

# N22 malformed source digests fail before dispatch.
bad_hash=h.execute_turn(k.initial_state(),'Generate portrait',True,'SRC-BAD','not-a-sha256',tool_available=True)
check('N22',bad_hash['route']=='NEED_SOURCE_PROOF',str(bad_hash))

# N23 rejected tool results are persisted instead of leaving DISPATCHING on disk.
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    d23=h.execute_turn(k.initial_state(),'Generate portrait',True,'SRC-P23','a'*64,tool_available=True,runtime_root=root,expected_revision=0)
    r23=res.process_result(d23['state'],result_kind='SUCCESS',runtime_root=root,expected_revision=1)
    disk23=store.load_state(root)
    check('N23',r23['route']=='RETRY_READY' and r23['state']['revision']==2 and disk23['state']=='RETRY_READY' and disk23['revision']==2,str(r23))

# N24 cancellation is durably persisted.
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    d24=h.execute_turn(k.initial_state(),'Generate portrait',True,'SRC-P24','b'*64,tool_available=True,runtime_root=root,expected_revision=0)
    c24=h.execute_turn(d24['state'],'cancel render',False,tool_available=True,runtime_root=root,expected_revision=1)
    disk24=store.load_state(root)
    check('N24',c24['route']=='CANCELLED' and c24['state']['revision']==2 and disk24['state']=='CANCELLED',str(c24))

# N25 a partial multi-file generation is rolled back from WAL before readback.
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    d25=dispatch()
    first=store.persist_transaction(root,d25['state'],d25['journal'],[d25['host_action']['receipt']],expected_revision=0)
    runtime=root/'RUNTIME_STATE'; commit_id='PRG-COMMIT-RECOVERYTEST'; stage=runtime/'.transactions'/commit_id
    (stage/'new').mkdir(parents=True); (stage/'previous').mkdir(parents=True)
    entries=[]
    targets=['current_state.json','transaction_journal.jsonl','receipts.jsonl']
    for name in targets:
        target=runtime/name; prev=stage/'previous'/name; shutil.copy2(target,prev)
        data=target.read_bytes()
        if name=='current_state.json':
            changed=json.loads(data); changed['revision']=2; changed['state']='FAILED_TERMINAL'; data=(json.dumps(changed,indent=2)+'\n').encode()
        elif name=='transaction_journal.jsonl':
            data=data+b'{"sequence":999,"synthetic":true}\n'
        elif name=='receipts.jsonl':
            data=data+b'{"receipt_id":"SYNTHETIC"}\n'
        new=stage/'new'/name; new.write_bytes(data)
        entries.append({'target':name,'new_rel':f'new/{name}','new_sha256':hashlib.sha256(data).hexdigest(),'previous_existed':True,'previous_rel':f'previous/{name}','previous_sha256':hashlib.sha256(prev.read_bytes()).hexdigest()})
    wal={'commit_id':commit_id,'from_revision':1,'to_revision':2,'transaction_id':first['state']['transaction_id'],'lease_owner':None,'status':'PREPARED','stage_dir':stage.relative_to(runtime).as_posix(),'files':entries,'journal_records':len(d25['journal']),'receipt_records':1}
    (runtime/'transaction.wal.json').write_text(json.dumps(wal,indent=2)+'\n')
    shutil.copy2(stage/'new'/'current_state.json',runtime/'current_state.json')
    recovered=store.load_state(root); recovery=json.loads((runtime/'last_recovery.json').read_text())
    check('N25',recovered['revision']==1 and recovered['state']=='DISPATCHING' and recovery['status']=='ROLLED_BACK' and not (runtime/'transaction.wal.json').exists(),str(recovery))

# N26 receipt schema rejects malformed digest evidence.
r26=copy.deepcopy(d['host_action']['receipt']); r26['source_hash']='bad'
check('N26',bool(k.validate_receipt(r26)),str(k.validate_receipt(r26)))

# N27 compiler exceptions transition to FAILED_TERMINAL and are persisted.
with tempfile.TemporaryDirectory() as td:
    root=Path(td); original=h.k.PROMPT_COMPILER.compile_prompt
    def explode(*args,**kwargs): raise RuntimeError('synthetic compiler failure')
    h.k.PROMPT_COMPILER.compile_prompt=explode
    try:
        f27=h.execute_turn(k.initial_state(),'Generate portrait',True,'SRC-P27','c'*64,tool_available=True,runtime_root=root,expected_revision=0)
    finally:
        h.k.PROMPT_COMPILER.compile_prompt=original
    disk27=store.load_state(root)
    check('N27',f27['route']=='FAILED_TERMINAL' and disk27['state']=='FAILED_TERMINAL' and any(x['event']=='PROMPT_COMPILE_FAILED' for x in f27['journal']),str(f27))

# N28 runtime store rejects non-monotonic journal append.
with tempfile.TemporaryDirectory() as td:
    root=Path(td); d28=dispatch(); first=store.persist_transaction(root,d28['state'],d28['journal'],[d28['host_action']['receipt']],expected_revision=0)
    rejected=False
    try:
        store.persist_transaction(root,first['state'],[{'sequence':1}],[],expected_revision=1)
    except RuntimeError as exc:
        rejected='JOURNAL_SEQUENCE_NON_MONOTONIC' in str(exc)
    check('N28',rejected,'non-monotonic append accepted')


# N29 outfit/pose/camera/effect directives activate dedicated prompt modules.
p29=k.PROMPT_COMPILER.compile_prompt('Change outfit to a black leather jacket, use an arms crossed pose, zoom out to a full body shot with cinematic rain and fog')
mods29=set(p29['selected_modules'])
check('N29', {'OUTFIT_TRANSFORMATION','POSE_DIRECTION','CAMERA_REFRAMING','EFFECT_STYLING'}.issubset(mods29), str(sorted(mods29)))

# N30 camera close-up phrasing activates reframing without losing mandatory modules.
p30=k.PROMPT_COMPILER.compile_prompt('Generate a close-up portrait with exact identity preservation')
mods30=set(p30['selected_modules']); mandatory30=set(k.PROMPT_COMPILER.REGISTRY['mandatory_modules'])
check('N30', 'CAMERA_REFRAMING' in mods30 and mandatory30.issubset(mods30), str(sorted(mods30)))

# N31 plain environment wording does not accidentally activate outfit transformation.
p31=k.PROMPT_COMPILER.compile_prompt('Create a realistic concrete room with soft fog and metallic reflections')
mods31=set(p31['selected_modules'])
check('N31', 'OUTFIT_TRANSFORMATION' not in mods31 and 'EFFECT_STYLING' in mods31, str(sorted(mods31)))


# N32 identity lock is no longer duplicated inside every creative prompt.
p32=k.PROMPT_COMPILER.compile_prompt('Create a portrait with a different outfit')
check('N32','IDENTITY_CORE_LOCK' not in set(p32['selected_modules']),str(p32['selected_modules']))

# N33 identity profile separates multiple persons and anchors source hash.
idcore=module('v170_identity','31_IDENTITY_CORE.py')
prof33=idcore.build_profile('SRC-ID','f'*64,person_count=2)
check('N33',len(prof33['persons'])==2 and prof33['persons'][0]['person_id']!=prof33['persons'][1]['person_id'] and prof33['cross_person_merge_forbidden'] is True,str(prof33))

# N34 creative outfit/pose changes remain allowed under identity lock.
ev34=idcore.evaluate_intent(prof33,'Change outfit and pose, zoom out with rain')
check('N34',ev34['decision']=='ALLOW_WITH_IDENTITY_LOCK' and ev34['high_identity_drift'] is False,str(ev34))

# N35 unintended identity replacement is vetoed.
ev35=idcore.evaluate_intent(prof33,'Replace face and make this a different person')
check('N35',ev35['decision']=='IDENTITY_VETO' and ev35['high_identity_drift'] is True,str(ev35))


# N36 director builds an explicit creative hot path without governance injection.
director=module('v180_director','33_CHARACTER_TRANSFORMATION_DIRECTOR.py')
pl36=director.build_plan('Change outfit, use a seated pose, zoom out and add neon rain')
check('N36',pl36['governance_in_prompt'] is False and pl36['steps']==['SOURCE_BIND','MINIMAL_IDENTITY_ANCHOR','EDIT_PLAN','COMPACT_PROMPT','IMAGE_TOOL','VISUAL_READBACK'],str(pl36))

# N37 complex character editing remains one coherent plan.
check('N37',{'OUTFIT','POSE','CAMERA','LIGHTING','EFFECTS'}.issubset(set(pl36['edits'])),str(pl36['edits']))

# N38 compiled prompt contains director contract but no audit/freeze/backup governance blocks.
p38=k.PROMPT_COMPILER.compile_prompt('Give both people new outfits, change pose, zoom out, add fog and neon lighting')
text38=p38['compiled_prompt']
check('N38','[CREATIVE_DIRECTOR]' in text38 and '[SYSTEM_AUDIT]' not in text38 and '[BACKUP]' not in text38 and p38['director_plan']['governance_in_prompt'] is False,text38[:500])

# N39 identity critical mode raises identity weight while still allowing pose and camera edits.
p39=k.PROMPT_COMPILER.compile_prompt('Keep the face exact, change the pose and zoom in')
check('N39',p39['director_plan']['profile']=='IDENTITY_CRITICAL' and p39['director_plan']['identity_weight']>=0.92 and {'POSE','CAMERA'}.issubset(set(p39['director_plan']['edits'])),str(p39['director_plan']))

# N40 world rebuild mode preserves identity but allows environment reconstruction.
p40=k.PROMPT_COMPILER.compile_prompt('Replace background with a futuristic nightclub and add cinematic lighting')
check('N40',p40['director_plan']['profile']=='WORLD_REBUILD' and 'ENVIRONMENT' in p40['director_plan']['edits'],str(p40['director_plan']))

# N41 CGI/3D request selects dedicated reconstruction profile and module.
p41=k.PROMPT_COMPILER.compile_prompt('3D CGI to real photorealism')
check('N41',p41['director_plan']['profile']=='CGI_TO_PHOTOREAL_RECONSTRUCTION' and 'CGI_TO_PHOTOREAL_RECONSTRUCTION' in set(p41['selected_modules']),str(p41))

# N42 reconstruction prompt stays compact and excludes duplicate identity lock.
blocks42=p41['compiled_prompt'].splitlines()
check('N42',len(blocks42)<=4 and '[IDENTITY_CORE_LOCK]' not in p41['compiled_prompt'],p41['compiled_prompt'])

# N43 frame/text guards are conditional rather than mandatory.
p43=k.PROMPT_COMPILER.compile_prompt('Make this image photorealistic')
check('N43','FRAMELESS_STAGE1' not in set(p43['selected_modules']) and 'NO_UNAUTHORIZED_TEXT' not in set(p43['selected_modules']),str(p43['selected_modules']))

# N44 nominal SUCCESS without output proof is normalized to bounded EMPTY retry.
d44=dispatch('Make this image photorealistic')
r44=res.process_result(d44['state'],result_kind='SUCCESS',output_id=None,output_hash=None)
check('N44',r44['route']=='RETRY_READY' and r44['state']['state']=='RETRY_READY',str(r44))

# N45 malformed output hash on nominal SUCCESS cannot enter visual QA or COMPLETE.
d45=dispatch('Make this image photorealistic')
r45=res.process_result(d45['state'],result_kind='SUCCESS',output_id='OUT-BAD',output_hash='bad')
check('N45',r45['route']=='RETRY_READY' and r45['state']['state']=='RETRY_READY',str(r45))

# Channel/status recovery regression tests.
check('N46', h.classify('Ergebnis?')=='STATUS_QUERY', h.classify('Ergebnis?'))
q46=h.execute_turn(k.initial_state(),'Ergebnis?',False,tool_available=True)
check('N47', q46['route']=='STATUS_QUERY' and q46.get('host_action') is None, str(q46))
cv=h.execute_turn(k.initial_state(),'Generate portrait',True,'SRC-CV','a'*64,tool_available=True,host_channel='final')
check('N48', cv['route']=='CHANNEL_VIOLATION' and cv.get('host_action') is None and cv.get('required_channel')=='commentary', str(cv))


# N49 policy engine treats kissing/embrace as affection, not automatic sex.
adult_policy=module('v193_adult_policy','35_ADULT_SWIMWEAR_TATTOO_VISIBILITY_POLICY.py')
ev49=adult_policy.evaluate_intent('Two unmistakably adult people kissing and embracing in a romantic pool scene')
check('N49',ev49['decision']=='ALLOW_NON_EXPLICIT_ADULT_VISIBILITY_WITH_COVERAGE' and ev49['kissing_or_embrace_classification']=='AFFECTION_NOT_AUTOMATIC_SEX' and ev49['explicit_content_blocked'] is False,str(ev49))

# N50 male bare torso for tattoo visibility is allowed as non-explicit adult presentation.
ev50=adult_policy.evaluate_intent('adult male bare torso at a tattoo session, show arm and chest tattoos')
check('N50',ev50['decision']=='ALLOW_NON_EXPLICIT_ADULT_VISIBILITY_WITH_COVERAGE' and ev50['male_bare_torso_allowed_for_tattoos'] is True and ev50['all_intimate_areas_must_remain_covered'] is True,str(ev50))

# N51 upper and lower body skin visibility use the same coverage logic.
ev51=adult_policy.evaluate_intent('adult woman in bikini at the pool with visible leg tattoos and upper body tattoos')
check('N51',ev51['decision']=='ALLOW_NON_EXPLICIT_ADULT_VISIBILITY_WITH_COVERAGE' and ev51['upper_body_and_lower_body_same_logic'] is True and ev51['female_swimwear_or_opaque_bodywear_required'] is True,str(ev51))

# N52 prompt compiler activates adult tattoo/swimwear visibility without treating it as sexual content.
p52=k.PROMPT_COMPILER.compile_prompt('Photorealistic adult pool scene: male bare torso, woman in bikini, show tattoos, kiss and embrace as affection')
mods52=set(p52['selected_modules']); pol52=p52['director_plan']['adult_visibility_policy']
check('N52','ADULT_SWIMWEAR_TATTOO_VISIBILITY' in mods52 and 'ROMANTIC_AFFECTION_NORMALIZATION' in mods52 and pol52['decision']=='ALLOW_NON_EXPLICIT_ADULT_VISIBILITY_WITH_COVERAGE',str(p52))

# N53 photorealism mode keeps reality-normalization directive for skin, swimwear, tattoos and kissing.
p53=k.PROMPT_COMPILER.compile_prompt('3D CGI to true photorealism: adult couple kissing at pool, swimwear, tattoos visible')
check('N53',p53['director_plan']['profile']=='CGI_TO_PHOTOREAL_RECONSTRUCTION' and 'kissing and embrace' in p53['compiled_prompt'] and 'intimate area covered' in p53['compiled_prompt'],p53['compiled_prompt'])

# N54 explicit sexual-content requests remain blocked by policy classification.
ev54=adult_policy.evaluate_intent('explicit sex with visible genitals')
check('N54',ev54['decision']=='BLOCK_EXPLICIT_SEXUAL_CONTENT' and ev54['explicit_content_blocked'] is True,str(ev54))

if fail:
    print('V2.0.0 DEEP ACCEPTANCE TESTS = FAIL')
    print('\n'.join(fail)); sys.exit(1)
print(f'V2.0.0 DEEP ACCEPTANCE TESTS = PASS ({len(passed)}/{len(passed)})')
