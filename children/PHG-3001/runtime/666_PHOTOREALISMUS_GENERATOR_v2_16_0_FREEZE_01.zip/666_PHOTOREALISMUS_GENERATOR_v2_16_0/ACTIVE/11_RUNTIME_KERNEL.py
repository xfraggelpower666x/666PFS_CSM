#!/usr/bin/env python3
"""Executable deterministic runtime kernel for 666 PRG v2.0.0.

Fail-closed state machine with strict source/output evidence, schema-conformant
receipts, deterministic prompt compilation, visual-QA evidence gates, bounded
retry/repair paths and service-scoped circuit-breaker metadata.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import copy
import datetime as dt
import hashlib
import importlib.util
import json
import uuid

try:
    from jsonschema import Draft202012Validator
except Exception:  # pragma: no cover
    Draft202012Validator = None

ROOT = Path(__file__).resolve().parent


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


MODEL = load("01_CANONICAL_STATE_MODEL.json")
MATRIX = load("05_EXECUTION_MATRIX.json")
CONFIG = load("06_RUNTIME_KERNEL_CONFIG.json")
RECEIPT_SCHEMA = load("07_RECEIPT_SCHEMA.json")
FAILURE_POLICY = load("10_FAILURE_POLICY.json")
EVENTS = {e["id"] for e in load("02_EVENT_CATALOG.json")["events"]}
GROUPS = MODEL["state_groups"]
STATES = set(MODEL["states"])
PROMPT_COMPILER = load_module("prg_prompt_compiler", "26_PROMPT_COMPILER.py")
QA_ENGINE = load_module("prg_visual_qa", "27_VISUAL_QA_ENGINE.py")
STATE_VALIDATOR = Draft202012Validator(MODEL["runtime_object_schema"]) if Draft202012Validator else None
RECEIPT_VALIDATOR = Draft202012Validator(RECEIPT_SCHEMA) if Draft202012Validator else None

FAILURE_EVENT_TO_CLASS = {
    "TOOL_EMPTY": "EMPTY_RESULT",
    "TOOL_TEMPORARY_ERROR": "TEMPORARY_SERVICE_ERROR",
    "TOOL_RATE_LIMIT": "RATE_LIMIT",
    "TOOL_CHANNEL_ERROR": "CHANNEL_ERROR",
    "WATCHDOG_TIMEOUT": "WATCHDOG_TIMEOUT",
    "OUTPUT_OBJECT_INVALID": "INVALID_OUTPUT_OBJECT",
    "VISUAL_QA_REPAIRABLE_FAIL": "VISUAL_QA_REPAIRABLE",
    "TOOL_UNAVAILABLE": "TOOL_UNAVAILABLE",
    "TOOL_POLICY_REJECTION": "POLICY_REJECTION",
    "SOURCE_CORRUPT": "SOURCE_CORRUPT",
    "SOURCE_UNSUPPORTED": "SOURCE_UNSUPPORTED",
    "STALE_TOOL_RETURN": "STALE_OUTPUT",
    "DUPLICATE_TOOL_RETURN": "DUPLICATE_OUTPUT",
}


def now_dt() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def now() -> str:
    return now_dt().isoformat()


def parse_time(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)
    except Exception:
        return None


def digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def valid_sha256(value: object) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    return all(ch in "0123456789abcdefABCDEF" for ch in value)


def initial_state() -> dict:
    return {
        "transaction_id": "",
        "parent_transaction_id": None,
        "state": "IDLE",
        "attempt": 0,
        "max_attempts": CONFIG["max_attempts"],
        "repair_attempt": 0,
        "source_status": "MISSING",
        "output_status": "NONE",
        "intent": "",
        "source_id": None,
        "source_hash": None,
        "source_hash_provenance": None,
        "prompt_hash": None,
        "prompt_manifest_hash": None,
        "compiled_prompt": None,
        "prompt_modules": [],
        "repair_directives": [],
        "attempt_id": None,
        "dispatch_channel": None,
        "active_dispatch_key": None,
        "last_error_class": None,
        "last_error_detail": None,
        "journal_sequence": 0,
        "revision": 0,
        "frame_stage": "OFF",
        "pending_source_survives_failure": True,
        "superseded_transactions": [],
        "dispatch_receipts": [],
        "seen_output_keys": [],
        "output_id": None,
        "output_hash": None,
        "qa_report": None,
        "qa_score": None,
        "failure_streak": 0,
        "service_failure_timestamps": [],
        "circuit_open": False,
        "circuit_open_until": None,
        "retry_not_before": None,
        "last_dispatch_at": None,
        "last_commit_at": None,
    }


def _fallback_schema_validation(state: dict) -> list[str]:
    errors: list[str] = []
    required = MODEL["runtime_object_schema"].get("required", [])
    for key in required:
        if key not in state:
            errors.append(f"MISSING_STATE_FIELD:{key}")
    if state.get("state") not in STATES:
        errors.append(f"UNKNOWN_STATE:{state.get('state')}")
    if not isinstance(state.get("attempt"), int) or state.get("attempt", -1) < 0:
        errors.append("INVALID_ATTEMPT")
    return errors


def validate_runtime_state(state: dict) -> list[str]:
    errors: list[str] = []
    if STATE_VALIDATOR:
        for error in sorted(STATE_VALIDATOR.iter_errors(state), key=lambda e: list(e.path)):
            location = ".".join(str(x) for x in error.path) or "$"
            errors.append(f"JSON_SCHEMA:{location}:{error.message}")
    else:
        errors.extend(_fallback_schema_validation(state))
    if state.get("state") != "IDLE" and not state.get("transaction_id"):
        errors.append("MISSING_TRANSACTION_ID")
    if state.get("state") in {"SOURCE_REGISTERED", "PROMPT_READY", "DISPATCH_REQUESTED", "DISPATCHING", "TOOL_RETURNED", "VISUAL_QA_PENDING", "VISUAL_QA_PASSED", "COMPLETE"}:
        if not state.get("source_id") or not state.get("source_hash"):
            errors.append("SOURCE_PROOF_INCOMPLETE")
        elif not valid_sha256(state.get("source_hash")):
            errors.append("SOURCE_HASH_FORMAT_INVALID")
        if state.get("source_hash_provenance") not in {"HOST_SUPPLIED_CONTENT_DIGEST", "VALIDATED_STAGE1_OUTPUT"}:
            errors.append("SOURCE_HASH_PROVENANCE_UNTRUSTED")
    if state.get("state") in {"PROMPT_READY", "DISPATCH_REQUESTED", "DISPATCHING", "TOOL_RETURNED", "VISUAL_QA_PENDING", "VISUAL_QA_PASSED", "COMPLETE"}:
        if not state.get("prompt_hash") or not state.get("compiled_prompt"):
            errors.append("PROMPT_PROOF_INCOMPLETE")
        elif not valid_sha256(state.get("prompt_hash")):
            errors.append("PROMPT_HASH_FORMAT_INVALID")
    if state.get("output_hash") is not None and not valid_sha256(state.get("output_hash")):
        errors.append("OUTPUT_HASH_FORMAT_INVALID")
    if state.get("state") == "DISPATCHING":
        if state.get("dispatch_channel") != "commentary":
            errors.append("INVALID_DISPATCH_CHANNEL")
        if not state.get("attempt_id") or not state.get("active_dispatch_key"):
            errors.append("INCOMPLETE_DISPATCH_BINDING")
    if state.get("state") == "COMPLETE":
        if state.get("output_status") != "QA_PASSED":
            errors.append("COMPLETE_WITHOUT_QA_PASS")
        if not state.get("output_id") and not state.get("output_hash"):
            errors.append("COMPLETE_WITHOUT_OUTPUT_PROOF")
        if not isinstance(state.get("qa_report"), dict) or state.get("qa_score") is None:
            errors.append("COMPLETE_WITHOUT_QA_EVIDENCE")
    return errors


def validate_receipt(receipt: dict) -> list[str]:
    errors: list[str] = []
    if not isinstance(receipt, dict):
        return ["RECEIPT_NOT_OBJECT"]
    if RECEIPT_VALIDATOR:
        errors.extend(f"{'.'.join(str(x) for x in e.path) or '$'}:{e.message}" for e in RECEIPT_VALIDATOR.iter_errors(receipt))
    else:
        errors.extend("MISSING:" + x for x in RECEIPT_SCHEMA.get("required", []) if x not in receipt)
    for field in ("receipt_id", "transaction_id", "attempt_id", "source_id", "timestamp"):
        if not isinstance(receipt.get(field), str) or not receipt.get(field):
            errors.append(f"INVALID_NONEMPTY_FIELD:{field}")
    for field in ("source_hash", "prompt_hash"):
        if not valid_sha256(receipt.get(field)):
            errors.append(f"INVALID_SHA256_FIELD:{field}")
    if receipt.get("output_hash") is not None and not valid_sha256(receipt.get("output_hash")):
        errors.append("INVALID_SHA256_FIELD:output_hash")
    if receipt.get("receipt_type") not in {"DISPATCH", "OUTPUT", "QA", "TERMINAL"}:
        errors.append("INVALID_RECEIPT_TYPE")
    if not isinstance(receipt.get("journal_sequence"), int) or receipt.get("journal_sequence", 0) < 1:
        errors.append("INVALID_JOURNAL_SEQUENCE")
    return sorted(set(errors))


def resolve_row(state: str, event: str) -> dict:
    exact = [r for r in MATRIX["rows"] if r["state"] == state and r["event"] == event]
    if exact:
        return sorted(exact, key=lambda r: r.get("priority", 100), reverse=True)[0]
    grouped = []
    for row in MATRIX["rows"]:
        if not row["state"].startswith("@") or row["event"] != event:
            continue
        if state in GROUPS.get(row["state"][1:], []):
            grouped.append(row)
    if grouped:
        return sorted(grouped, key=lambda r: r.get("priority", 100), reverse=True)[0]
    raise ValueError(f"DEFAULT_DENY: no matrix path for {state} + {event}")


def dispatch_key(state: dict) -> str:
    return digest("|".join([
        state.get("transaction_id") or "",
        state.get("source_hash") or "",
        state.get("prompt_hash") or "",
        str(state.get("attempt", 0) + 1),
    ]))


def output_key(ctx: dict) -> str | None:
    value = ctx.get("output_hash") or ctx.get("output_id")
    return digest(str(value)) if value else None


def ownership_context(state: dict) -> dict:
    return {
        "transaction_id": state.get("transaction_id"),
        "attempt_id": state.get("attempt_id"),
        "source_hash": state.get("source_hash"),
        "prompt_hash": state.get("prompt_hash"),
    }


def make_receipt(state: dict, receipt_type: str, result: str, *, sequence: int | None = None, **extra) -> dict:
    receipt = {
        "receipt_type": receipt_type,
        "receipt_id": extra.pop("receipt_id", f"PRG-RCP-{uuid.uuid4().hex[:12]}"),
        "transaction_id": state.get("transaction_id"),
        "attempt_id": state.get("attempt_id"),
        "source_id": state.get("source_id"),
        "source_hash": state.get("source_hash"),
        "prompt_hash": state.get("prompt_hash"),
        "timestamp": now(),
        "journal_sequence": sequence if sequence is not None else state.get("journal_sequence", 0),
        "dispatch_channel": state.get("dispatch_channel"),
        "tool_result_id": state.get("output_id"),
        "output_hash": state.get("output_hash"),
        "result": result,
        "error_class": state.get("last_error_class"),
    }
    receipt.update(extra)
    return receipt


def _circuit_is_open(state: dict) -> bool:
    until = parse_time(state.get("circuit_open_until"))
    if state.get("circuit_open") and until and now_dt() >= until:
        state["circuit_open"] = False
        state["circuit_open_until"] = None
        state["failure_streak"] = 0
        return False
    return bool(state.get("circuit_open"))


def _retry_backoff_active(state: dict) -> bool:
    threshold = parse_time(state.get("retry_not_before"))
    return bool(threshold and now_dt() < threshold)


def _require_output_proof(state: dict, ctx: dict) -> list[str]:
    errors: list[str] = []
    if ctx.get("output_present") is not True:
        errors.append("OUTPUT_PRESENT_PROOF_REQUIRED")
    if not (ctx.get("output_id") or ctx.get("output_hash") or state.get("output_id") or state.get("output_hash")):
        errors.append("OUTPUT_ID_OR_HASH_REQUIRED")
    return errors


def _require_ownership(state: dict, ctx: dict) -> list[str]:
    errors: list[str] = []
    for field, expected in ownership_context(state).items():
        supplied = ctx.get(field)
        if supplied is None:
            errors.append(f"OWNERSHIP_FIELD_MISSING:{field}")
        elif supplied != expected:
            errors.append(f"OWNERSHIP_FIELD_MISMATCH:{field}")
    return errors


def apply_builtin_guards(state: dict, event: str, ctx: dict, row: dict) -> list[str]:
    errors: list[str] = []
    gids = set(row.get("guards", []))

    if "GRD-062" in gids:
        errors.extend("RUNTIME_STATE_SCHEMA_GUARD:" + e for e in validate_runtime_state(state))
    if "GRD-018" in gids and ctx.get("channel") != "commentary":
        errors.append("TOOL_INVOCATION_CHANNEL_GUARD")
    if "GRD-007" in gids and event != "NEW_IMAGE" and not (ctx.get("source_id") or state.get("source_id")):
        errors.append("ACTIVE_SOURCE_SELECTION_GUARD")
    if "GRD-008" in gids:
        sid = ctx.get("source_id") or state.get("source_id")
        shash = ctx.get("source_hash") or state.get("source_hash")
        provenance = ctx.get("source_hash_provenance") or state.get("source_hash_provenance")
        if not sid or not shash:
            errors.append("SOURCE_HASH_AND_ID_GUARD")
        elif not valid_sha256(shash):
            errors.append("SOURCE_HASH_FORMAT_GUARD")
        if provenance not in {"HOST_SUPPLIED_CONTENT_DIGEST", "VALIDATED_STAGE1_OUTPUT"}:
            errors.append("SOURCE_HASH_PROVENANCE_GUARD")
    if "GRD-010" in gids and not (ctx.get("intent") or state.get("intent")):
        errors.append("USER_INTENT_BINDING_GUARD")
    if "GRD-016" in gids:
        if ctx.get("source_present") is not True or not state.get("source_id") or not state.get("source_hash"):
            errors.append("TOOL_TARGET_PRESENCE_GUARD")
        elif not valid_sha256(state.get("source_hash")):
            errors.append("TOOL_TARGET_HASH_FORMAT_GUARD")
    if "GRD-017" in gids and ctx.get("tool_available") is not True:
        errors.append("TOOL_AVAILABILITY_PREFLIGHT_GUARD")
    if "GRD-020" in gids and event in {"PREFLIGHT_PASSED", "RETRY_ALLOWED"}:
        if state.get("attempt", 0) >= state.get("max_attempts", CONFIG["max_attempts"]):
            errors.append("RETRY_BUDGET_GUARD")
        if event == "RETRY_ALLOWED" and _retry_backoff_active(state):
            errors.append("RETRY_BACKOFF_ACTIVE")
    if "GRD-021" in gids and event in {"PREFLIGHT_PASSED", "RETRY_ALLOWED"} and _circuit_is_open(state):
        errors.append("CIRCUIT_BREAKER_GUARD")
    if "GRD-036" in gids and event == "REPAIR_ALLOWED" and state.get("repair_attempt", 0) >= CONFIG["max_targeted_repairs"]:
        errors.append("REPAIR_BUDGET_GUARD")
    if "GRD-065" in gids and event in {"PREFLIGHT_PASSED", "DISPATCH_ACCEPTED"}:
        if not state.get("compiled_prompt") or not state.get("prompt_hash"):
            errors.append("PROMPT_NONEMPTY_GUARD")
    if any(g in gids for g in {"GRD-011", "GRD-012", "GRD-013", "GRD-014", "GRD-015"}) and event == "PROMPT_COMPILED":
        modules = set(ctx.get("prompt_modules") or [])
        required = set(PROMPT_COMPILER.REGISTRY.get("mandatory_modules", []))
        if not ctx.get("compiled_prompt") or not ctx.get("prompt_hash") or not required.issubset(modules):
            errors.append("PROMPT_COMPILER_EVIDENCE_GUARD")
    if "GRD-019" in gids and event in {"NEW_IMAGE", "PREFLIGHT_PASSED"}:
        if event == "PREFLIGHT_PASSED" and state.get("active_dispatch_key"):
            errors.append("SINGLE_INFLIGHT_TRANSACTION_GUARD")
    if "GRD-024" in gids and event in {"TOOL_RETURNED", "OUTPUT_OBJECT_VALID", "COMMIT_SUCCESS"}:
        errors.extend(_require_output_proof(state, ctx))
        if ctx.get("output_hash") is not None and not valid_sha256(ctx.get("output_hash")):
            errors.append("OUTPUT_HASH_FORMAT_GUARD")
    if "GRD-025" in gids and event in {"TOOL_RETURNED", "OUTPUT_OBJECT_VALID", "STALE_TOOL_RETURN", "COMMIT_SUCCESS"}:
        errors.extend(_require_ownership(state, ctx))
    if "GRD-026" in gids and event in {"TOOL_RETURNED", "OUTPUT_OBJECT_VALID", "COMMIT_SUCCESS"}:
        if ctx.get("transaction_id") in state.get("superseded_transactions", []):
            errors.append("STALE_OUTPUT_REJECTION_GUARD")
    if "GRD-027" in gids and event in {"TOOL_RETURNED", "OUTPUT_OBJECT_VALID"}:
        key = output_key(ctx)
        if not key:
            errors.append("DUPLICATE_OUTPUT_GUARD:NO_OUTPUT_KEY")
        elif event == "TOOL_RETURNED" and key in state.get("seen_output_keys", []):
            errors.append("DUPLICATE_OUTPUT_GUARD")
    if "GRD-059" in gids and event == "DISPATCH_ACCEPTED":
        if state.get("active_dispatch_key") == dispatch_key(state):
            errors.append("DISPATCH_IDEMPOTENCY_GUARD")
    if "GRD-060" in gids and event == "DISPATCH_ACCEPTED":
        for field in ("transaction_id", "source_id", "source_hash", "prompt_hash", "compiled_prompt"):
            if not state.get(field):
                errors.append(f"RECEIPT_FIELD_COMPLETENESS_GUARD:{field}")
    if "GRD-061" in gids and event == "TOOL_RETURNED":
        key = output_key(ctx)
        if key and key in state.get("seen_output_keys", []):
            errors.append("OUTPUT_IDEMPOTENCY_RUNTIME_GUARD")
    if any(g in gids for g in {"GRD-028", "GRD-029", "GRD-030", "GRD-031", "GRD-032", "GRD-033", "GRD-034"}):
        evaluation = QA_ENGINE.evaluate(ctx.get("qa_report"))
        expected = {
            "VISUAL_QA_PASS": "PASS",
            "VISUAL_QA_REPAIRABLE_FAIL": "REPAIRABLE_FAIL",
            "VISUAL_QA_TERMINAL_FAIL": "TERMINAL_FAIL",
            "COMMIT_SUCCESS": "PASS",
        }.get(event)
        if expected and evaluation.get("decision") != expected:
            errors.append("VISUAL_QA_EVIDENCE_GUARD:" + ",".join(evaluation.get("errors") or [evaluation.get("decision", "UNKNOWN")]))
    if "GRD-044" in gids and event == "COMMIT_SUCCESS":
        if state.get("output_status") != "QA_PASSED" or not state.get("qa_report"):
            errors.append("STAGE2_VALIDATED_OUTPUT_GATE")
    if "GRD-045" in gids and (not isinstance(state.get("journal_sequence"), int) or state.get("journal_sequence", -1) < 0):
        errors.append("JOURNAL_SEQUENCE_GUARD")
    return errors


def journal(state: dict, event: str, row: dict, result: str, ctx: dict) -> dict:
    state["journal_sequence"] += 1
    return {
        "sequence": state["journal_sequence"],
        "timestamp": now(),
        "transaction_id": state.get("transaction_id"),
        "attempt_id": state.get("attempt_id"),
        "from_state": ctx.get("_from_state"),
        "event": event,
        "matrix_id": row["id"],
        "orchestra": row["orchestra"],
        "guards": row.get("guards", []),
        "result": result,
        "to_state": state["state"],
        "error_class": state.get("last_error_class"),
        "error_detail": state.get("last_error_detail"),
    }


def _bounded_append(items: list, value, limit: int = 64) -> list:
    items = list(items or [])
    items.append(value)
    return items[-limit:]


def _record_service_failure(state: dict, event: str) -> None:
    policy_class = FAILURE_EVENT_TO_CLASS.get(event, event)
    policy = FAILURE_POLICY.get("classes", {}).get(policy_class, {})
    current = now_dt()
    window = int(FAILURE_POLICY.get("circuit_breaker", {}).get("cooldown_seconds", 60))
    threshold = int(FAILURE_POLICY.get("circuit_breaker", {}).get("window_failures", 3))
    timestamps = []
    for value in state.get("service_failure_timestamps", []):
        parsed = parse_time(value)
        if parsed and (current - parsed).total_seconds() <= window:
            timestamps.append(parsed.isoformat())
    timestamps.append(current.isoformat())
    state["service_failure_timestamps"] = timestamps[-32:]
    state["failure_streak"] = len(timestamps)
    backoff = int(policy.get("backoff_seconds", 0))
    state["retry_not_before"] = (current + dt.timedelta(seconds=backoff)).isoformat() if backoff else None
    if len(timestamps) >= threshold:
        state["circuit_open"] = True
        state["circuit_open_until"] = (current + dt.timedelta(seconds=window)).isoformat()


def transition(input_state: dict, event: str, ctx: dict | None = None):
    state = copy.deepcopy(input_state)
    ctx = dict(ctx or {})
    if event not in EVENTS:
        raise ValueError(f"UNKNOWN EVENT {event}")
    old = state["state"]
    ctx["_from_state"] = old
    row = resolve_row(old, event)
    guard_errors = apply_builtin_guards(state, event, ctx, row)
    if guard_errors:
        target = row.get("failure_state", "FAILED_TERMINAL")
        state["state"] = old if target == "$SAME" else target
        state["last_error_class"] = "GUARD_FAILURE"
        state["last_error_detail"] = ",".join(guard_errors)
        return state, journal(state, event, row, "GUARD_FAIL", ctx), None

    target = row["next_state"]
    target = old if target == "$SAME" else target
    if event not in FAILURE_EVENT_TO_CLASS and event not in {"SOURCE_CORRUPT", "SOURCE_UNSUPPORTED"}:
        state["last_error_class"] = None
        state["last_error_detail"] = None

    if event == "NEW_IMAGE":
        previous_tx = state.get("transaction_id")
        if previous_tx and old in GROUPS["ACTIVE_INFLIGHT"]:
            state["superseded_transactions"] = _bounded_append(state.get("superseded_transactions", []), previous_tx)
        state["transaction_id"] = ctx.get("transaction_id") or f"PRG-TX-{uuid.uuid4().hex[:12]}"
        state["parent_transaction_id"] = ctx.get("parent_transaction_id")
        state["source_id"] = ctx.get("source_id")
        state["source_hash"] = ctx.get("source_hash")
        state["source_hash_provenance"] = ctx.get("source_hash_provenance") or ("HOST_SUPPLIED_CONTENT_DIGEST" if ctx.get("source_hash") else None)
        state["source_status"] = "PRESENT" if state.get("source_id") else "MISSING"
        state["output_status"] = "NONE"
        state["attempt"] = 0
        state["repair_attempt"] = 0
        state["intent"] = (ctx.get("intent") or state.get("intent") or "photorealistic transformation").strip()
        state["prompt_hash"] = None
        state["prompt_manifest_hash"] = None
        state["compiled_prompt"] = None
        state["prompt_modules"] = []
        state["repair_directives"] = []
        state["attempt_id"] = None
        state["dispatch_channel"] = None
        state["active_dispatch_key"] = None
        state["output_id"] = None
        state["output_hash"] = None
        state["qa_report"] = None
        state["qa_score"] = None
        state["retry_not_before"] = None
    elif event == "SOURCE_RESOLVED":
        state["source_status"] = "USABLE"
    elif event == "SOURCE_CORRUPT":
        state["source_status"] = "CORRUPT"
        state["last_error_class"] = "SOURCE_CORRUPT"
    elif event == "SOURCE_UNSUPPORTED":
        state["source_status"] = "UNSUPPORTED"
        state["last_error_class"] = "SOURCE_UNSUPPORTED"
    elif event == "PROMPT_COMPILE_FAILED":
        state["last_error_class"] = "PROMPT_COMPILE_FAILED"
        state["last_error_detail"] = str(ctx.get("error") or "Prompt compiler failed.")
        state["compiled_prompt"] = None
        state["prompt_hash"] = None
        state["prompt_manifest_hash"] = None
        state["prompt_modules"] = []
    elif event == "PROMPT_COMPILED":
        state["compiled_prompt"] = ctx["compiled_prompt"]
        state["prompt_hash"] = ctx["prompt_hash"]
        state["prompt_manifest_hash"] = ctx.get("prompt_manifest_hash")
        state["prompt_modules"] = list(ctx.get("prompt_modules") or [])
    elif event == "DISPATCH_ACCEPTED":
        state["attempt"] += 1
        state["attempt_id"] = ctx.get("attempt_id") or f"PRG-ATT-{uuid.uuid4().hex[:12]}"
        state["dispatch_channel"] = "commentary"
        state["last_dispatch_at"] = now()
        state["active_dispatch_key"] = dispatch_key({**state, "attempt": state["attempt"] - 1})
        receipt = make_receipt(
            state,
            "DISPATCH",
            "DISPATCH_ACCEPTED",
            sequence=state["journal_sequence"] + 1,
            dispatch_channel="commentary",
            dispatch_key=state["active_dispatch_key"],
        )
        receipt_errors = validate_receipt(receipt)
        if receipt_errors:
            state["state"] = row.get("failure_state", "RETRY_READY")
            state["last_error_class"] = "RECEIPT_SCHEMA_FAILURE"
            state["last_error_detail"] = ";".join(receipt_errors)
            return state, journal(state, event, row, "GUARD_FAIL", ctx), None
        state["dispatch_receipts"] = _bounded_append(state.get("dispatch_receipts", []), receipt)
    elif event == "TOOL_RETURNED":
        state["output_status"] = "PRESENT"
        state["output_id"] = ctx.get("output_id") or state.get("output_id")
        state["output_hash"] = ctx.get("output_hash") or state.get("output_hash")
        key = output_key(ctx)
        if key:
            state["seen_output_keys"] = _bounded_append([x for x in state.get("seen_output_keys", []) if x != key], key)
        state["failure_streak"] = 0
        state["service_failure_timestamps"] = []
        state["circuit_open"] = False
        state["circuit_open_until"] = None
        state["retry_not_before"] = None
    elif event == "OUTPUT_OBJECT_VALID":
        state["output_status"] = "OWNERSHIP_VALIDATED"
    elif event == "OUTPUT_OBJECT_INVALID":
        state["output_status"] = "INVALID"
        state["last_error_class"] = "INVALID_OUTPUT_OBJECT"
    elif event == "STALE_TOOL_RETURN":
        state["output_status"] = "STALE"
        state["last_error_class"] = "STALE_OUTPUT"
    elif event == "DUPLICATE_TOOL_RETURN":
        state["output_status"] = "DUPLICATE"
        state["last_error_class"] = "DUPLICATE_OUTPUT"
    elif event == "VISUAL_QA_PASS":
        evaluation = QA_ENGINE.evaluate(ctx.get("qa_report"))
        state["output_status"] = "QA_PASSED"
        state["qa_report"] = evaluation
        state["qa_score"] = evaluation["weighted_score"]
    elif event == "VISUAL_QA_REPAIRABLE_FAIL":
        evaluation = QA_ENGINE.evaluate(ctx.get("qa_report"))
        state["output_status"] = "QA_REPAIRABLE"
        state["qa_report"] = evaluation
        state["qa_score"] = evaluation["weighted_score"]
        state["repair_directives"] = [f"Repair {x}" for x in evaluation.get("failed_checks", [])]
        state["last_error_class"] = "VISUAL_QA_REPAIRABLE"
    elif event == "VISUAL_QA_TERMINAL_FAIL":
        state["last_error_class"] = "VISUAL_QA_TERMINAL"
    elif event == "REPAIR_ALLOWED":
        state["repair_attempt"] += 1
        state["prompt_hash"] = None
        state["compiled_prompt"] = None
        state["prompt_modules"] = []
        state["active_dispatch_key"] = None
        state["output_status"] = "NONE"
        state["output_id"] = None
        state["output_hash"] = None
        state["qa_report"] = None
        state["qa_score"] = None
    elif event == "RETRY_ALLOWED":
        state["prompt_hash"] = None
        state["compiled_prompt"] = None
        state["prompt_modules"] = []
        state["active_dispatch_key"] = None
        state["output_status"] = "NONE"
        state["output_id"] = None
        state["output_hash"] = None
        state["qa_report"] = None
        state["qa_score"] = None
    elif event == "USER_INTENT_CHANGED":
        state["intent"] = (ctx.get("intent") or state["intent"]).strip()
        state["prompt_hash"] = None
        state["compiled_prompt"] = None
        state["prompt_modules"] = []
        state["active_dispatch_key"] = None
    elif event == "USER_SELECT_SOURCE":
        state["source_id"] = ctx.get("source_id")
        state["source_hash"] = ctx.get("source_hash")
        state["source_hash_provenance"] = ctx.get("source_hash_provenance") or ("HOST_SUPPLIED_CONTENT_DIGEST" if ctx.get("source_hash") else None)
        state["source_status"] = "PRESENT" if state.get("source_id") else "MISSING"
        state["prompt_hash"] = None
        state["compiled_prompt"] = None
        state["prompt_modules"] = []
        state["active_dispatch_key"] = None
    elif event == "USER_CANCEL":
        state["last_error_class"] = "USER_CANCELLED"
        state["active_dispatch_key"] = None
    elif event == "FRAME_REQUEST" and old == "COMPLETE":
        state["frame_stage"] = "ON"
    elif event == "COMMIT_SUCCESS":
        state["active_dispatch_key"] = None
        state["last_commit_at"] = now()

    if event in {"TOOL_EMPTY", "TOOL_TEMPORARY_ERROR", "TOOL_RATE_LIMIT", "TOOL_CHANNEL_ERROR", "WATCHDOG_TIMEOUT"}:
        state["last_error_class"] = FAILURE_EVENT_TO_CLASS[event]
        _record_service_failure(state, event)
    elif event in {"TOOL_UNAVAILABLE", "TOOL_POLICY_REJECTION"}:
        state["last_error_class"] = FAILURE_EVENT_TO_CLASS[event]

    state["state"] = target
    host_action = None
    if event == "DISPATCH_ACCEPTED" and state["state"] == "DISPATCHING":
        receipt = state["dispatch_receipts"][-1]
        host_action = {
            "action": "CALL_IMAGE_TOOL",
            "channel": "commentary",
            "transaction_id": state["transaction_id"],
            "attempt_id": state["attempt_id"],
            "source_id": state["source_id"],
            "source_hash": state["source_hash"],
            "prompt_hash": state["prompt_hash"],
            "prompt_manifest_hash": state.get("prompt_manifest_hash"),
            "prompt_modules": list(state.get("prompt_modules", [])),
            "prompt": state["compiled_prompt"],
            "dispatch_key": state["active_dispatch_key"],
            "receipt": receipt,
        }
    record = journal(state, event, row, "PASS", ctx)
    return state, record, host_action


def compile_context(state: dict, *, source_traits: list[str] | None = None, cyber_garden_state: dict | None = None, cyber_garden_approval: dict | None = None) -> dict:
    result = PROMPT_COMPILER.compile_prompt(
        state.get("intent", ""),
        source_traits=source_traits,
        frame_stage=state.get("frame_stage", "OFF"),
        repair_directives=state.get("repair_directives", []),
        cyber_garden_state=cyber_garden_state,
        cyber_garden_approval=cyber_garden_approval,
    )
    return {
        "compiled_prompt": result["compiled_prompt"],
        "prompt_hash": result["prompt_hash"],
        "prompt_manifest_hash": result["prompt_manifest_hash"],
        "prompt_modules": result["selected_modules"],
        "intent": state.get("intent"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--state")
    parser.add_argument("--event")
    parser.add_argument("--context", default="{}")
    parser.add_argument("--init", action="store_true")
    args = parser.parse_args()
    state = initial_state() if args.init or not args.state else json.loads(Path(args.state).read_text(encoding="utf-8"))
    if args.event:
        state, record, action = transition(state, args.event, json.loads(args.context))
        print(json.dumps({"state": state, "journal": record, "host_action": action}, indent=2, ensure_ascii=False))
    else:
        print(json.dumps(state, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
