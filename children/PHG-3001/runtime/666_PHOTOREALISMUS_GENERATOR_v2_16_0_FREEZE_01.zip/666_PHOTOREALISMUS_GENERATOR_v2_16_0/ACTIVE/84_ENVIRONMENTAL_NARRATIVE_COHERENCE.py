#!/usr/bin/env python3
"""ENSC-004 additive environmental narrative coherence runtime for PHG v2.16.0."""
from __future__ import annotations
import re

def _n(v): return re.sub(r"\s+"," ",(v or '').casefold()).strip()
def _has(t,*terms): return any(x in t for x in terms)

def analyze(intent:str, *, source_traits:list[str]|None=None)->dict:
    t=_n(intent+' '+' '.join(source_traits or []))
    explicit=_has(t,'environmental_narrative','environmental narrative','ensc-004','ensc_004','weather_story_mapping','wet_material_realism','scene_text_symbol_coherence','name_side_binding')
    rain=_has(t,'rain','rainy','regen','storm','sturm')
    fog=_has(t,'fog','mist','nebel')
    sunset=_has(t,'sunset','sonnenuntergang')
    city=_has(t,'city night','night city','stadt bei nacht','city_night')
    wet=_has(t,'wet','nass','rain','regen','storm','sturm')
    text=_has(t,'text','caption','name','names','nameplate','schrift','namen')
    symbolic=_has(t,'heart frame','symbolic frame','symbolischer rahmen','symbol','heart','herz','infinity','unendlich')
    narrative=explicit or rain or fog or sunset or city or _has(t,'story','narrative','geschichte','meaning','bedeutung')
    name_side=explicit or _has(t,'name side','name-side','name binding','namen seite','name links','name rechts','left name','right name')
    active=narrative or name_side
    event='NONE'; story=[]
    if _has(t,'storm','sturm'): event='STORM'; story=['CONFLICT','PRESSURE','SURVIVAL','PROTECTION']
    elif _has(t,'rain','rainy','regen'): event='RAIN'; story=['TRIAL','PERSISTENCE','PASSION','TOGETHERNESS']
    elif fog: event='FOG'; story=['MYSTERY','DISTANCE','UNKNOWABILITY']
    elif sunset: event='SUNSET'; story=['DEVOTION','SOFTNESS','TRANSITION','MEMORY']
    elif city: event='CITY_NIGHT'; story=['INTENSITY','MODERN_ROMANCE','MYSTERY']
    consequences=[]
    if wet: consequences=['HAIR_WETNESS','SKIN_WETNESS','FABRIC_WETNESS','MATERIAL_SPECULAR_RESPONSE','GROUND_REFLECTION','LIGHT_DIFFUSION']
    return {
      'active':active,'addon_id':'PRG-ADDON-ENVIRONMENTAL-NARRATIVE-COHERENCE-004','version':'1.0.0','host_version':'2.16.0','integration':'ADD_ONLY',
      'event':event,'story_possibilities':story,'environmental_causality_required':bool(event!='NONE'),
      'physical_consequences':consequences,'wet_material_realism':wet,
      'scene_text_symbol_coherence':bool(active and (text or symbolic)),
      'name_side_binding':{'active':name_side or text,'mandatory':True,'name_person_match':'HARD_LOCK','name_swap':'FORBIDDEN','name_follows_person_side':True},
      'connector_policy':{'center_connector_allowed':True,'joint_title_without_side_binding':'REJECT_UNLESS_EXPLICIT'},
      'core_replacement':False,'cvice_replacement':False,'frame_router_replacement':False,'identity_engine_replacement':False,'foreign_system_mutation':False
    }

def compact_directive(r:dict)->str:
    if not r.get('active'): return ''
    p=['ENSC-004 ADD_ONLY']
    if r.get('event')!='NONE': p.append(f"environment event={r['event']} carries possible narrative meaning {','.join(r['story_possibilities'])}; render physical consequences causally, not as decorative overlay")
    if r.get('wet_material_realism'): p.append('wet realism: skin soft sheen/droplets; hair darker/clumped/weighted; fabric darkened/clinging; leather/road higher specular response; coherent reflections and light diffusion')
    if r.get('scene_text_symbol_coherence'): p.append('SCENE↔TEXT↔SYMBOL must tell one non-contradictory story; text is semantic data, not decoration')
    if r['name_side_binding']['active']: p.append('NAME_SIDE_BINDING HARD_LOCK: each name follows its person current side; no name swap; center connector may remain neutral; ambiguous joint title forbidden unless explicitly approved')
    return '; '.join(p)
