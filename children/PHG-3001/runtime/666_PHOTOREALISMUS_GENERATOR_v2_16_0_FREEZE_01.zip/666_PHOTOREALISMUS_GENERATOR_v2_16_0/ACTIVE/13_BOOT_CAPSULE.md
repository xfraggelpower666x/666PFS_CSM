# ACTIVE RUNTIME BOOT CAPSULE — v2.0.0

1. Load `00_ACTIVE_MANIFEST.json`.
2. Validate with `12_VALIDATE_ACTIVE_RUNTIME.py`.
3. Run `16_RUN_ACCEPTANCE_TESTS.py`.
4. Initialize `11_RUNTIME_KERNEL.py --init`.
5. Route every user upload/command through `05_EXECUTION_MATRIX.json`.
6. For `CALL_IMAGE_TOOL`, the host must invoke the image tool in **commentary**.
7. Never mark success without a returned image object, ownership validation and Visual-QA pass.
8. Preserve pending source after failure or cancellation.
9. `LEGACY/` is read-only and must never win active-version resolution.


## v2.0.0 SAME-TURN HARDLOCK
A valid image upload or render trigger must produce the commentary-channel image tool call in the same assistant turn. No pre-call status text, no final-channel tool call, no text-only success. Control-plane maintenance commands are never image prompt content.

10. Run `23_RUN_REPAIR_REGRESSION_TESTS.py`.
11. Resolve canonical pointers with `25_CANONICAL_RESOLVER.py`.
12. When persistence is requested, use `22_RUNTIME_STORE.py` for atomic state, journal and receipt writes.
