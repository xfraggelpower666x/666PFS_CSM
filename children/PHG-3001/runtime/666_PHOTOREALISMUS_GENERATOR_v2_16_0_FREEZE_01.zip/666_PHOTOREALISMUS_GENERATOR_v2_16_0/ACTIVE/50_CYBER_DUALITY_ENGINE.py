#!/usr/bin/env python3
"""Cyber Duality Character & Couple Engine v1.0.0 for PHG-3001 v2.6.0."""
from __future__ import annotations
import re

VERSION="1.0.0"
ADDON_ID="PG-CDCCE-001"

DUALITY_PHRASES=(
    "cyber angel and devil","cyber angel devil","angel demon hybrid","angel-demon hybrid",
    "angelic and demonic","heaven and hell","light and darkness","holy and infernal","duality character",
    "angel and devil","angel devil hybrid","angel demon","cyber angel / devil",
    "cyber engel und teufel","engel und teufel","engel dämon hybrid","engel demon hybrid",
    "himmmel und hölle","himmel und hölle","licht und dunkelheit","heilig und infernal","dualitätscharakter"
)
MULTI_PHRASES=(
    "couple","two people","two persons","two characters","two previously established","both characters",
    "partners","lovers","duo","pair","together","romantic pair","power couple","battle duo",
    "one angel and one devil","an angel and a devil","2 people","2 persons","2 characters",
    "paar","zwei personen","zwei charaktere","beide","zusammen","partner","liebespaar","duo"
)
FACE_BODY_FAILURE_PHRASES=(
    "face looks pasted","face pasted","face does not fit the body","face doesn't fit the body",
    "gesicht passt nicht zum körper","gesicht passt nicht zum koerper","kopf passt nicht zum körper",
    "floating head","unnatural neck","head body ratio"
)

PRIORITY_STACK=[
    "P0_IDENTITY","P1_FACE_BODY_NATURALISM","P2_ANATOMY","P3_REQUESTED_PERSON_COUNT",
    "P4_CHARACTER_CONTINUITY","P5_ANGEL_DEMON_DUALITY","P6_CLOTHING_CYBER_ARCHITECTURE",
    "P7_WINGS_HALO_HORN","P8_ENVIRONMENT","P9_EFFECTS"
]
QUALITY_TARGETS={
    "IDENTITY_FIDELITY":95,"FACE_BODY_INTEGRATION":95,"ANATOMICAL_PLAUSIBILITY":95,
    "REFERENCE_CONTINUITY":95,"PHOTOREALISM":95,"CYBER_DESIGN_COHERENCE":95,
    "DUALITY_READABILITY":90,"COUPLE_IDENTITY_SEPARATION":98
}

def _norm(s:str)->str:
    return re.sub(r"\s+"," ",(s or "").casefold()).strip()

def _contains_any(text:str, phrases)->bool:
    return any(p in text for p in phrases)

def _explicit_multi(text:str)->bool:
    if _contains_any(text,MULTI_PHRASES): return True
    if re.search(r"\b(two|2|zwei)\s+(people|persons|characters|personen|charaktere)\b",text): return True
    return False

def _interaction_mode(text:str)->str:
    if any(x in text for x in ("battle duo","back-to-back","combat","kampf","battle")): return "BATTLE_DUO"
    if any(x in text for x in ("foreheads touching","close embrace","intimate","stirn","innige umarm")): return "INTIMATE"
    if any(x in text for x in ("walking","walk together","gehend","laufen zusammen")): return "WALKING"
    if any(x in text for x in ("protective","around or behind","beschützend","beschuetzend")): return "PROTECTIVE"
    if any(x in text for x in ("portrait","upper-body","oberkörper","oberkoerper")): return "PORTRAIT"
    if any(x in text for x in ("power couple","strong frontal","frontal")): return "POWER_COUPLE"
    return "AUTO_NATURAL"

def analyze(intent:str, *, source_traits:list[str]|None=None)->dict:
    text=_norm((intent or "")+" "+" ".join(source_traits or []))
    active=_contains_any(text,DUALITY_PHRASES)
    # Also activate when angel+demon semantics co-occur, even if wording differs.
    angel=any(x in text for x in ("angel","angelic","celestial","holy","heaven","engel","himmlisch"))
    demon=any(x in text for x in ("devil","demon","demonic","infernal","hell","teufel","dämon","daemon","hölle","hoelle"))
    active=active or (angel and demon)
    multi=_explicit_multi(text) if active else False
    person_count=2 if multi else (1 if active else None)
    failure=_contains_any(text,FACE_BODY_FAILURE_PHRASES)
    mode=_interaction_mode(text) if multi else None
    return {
        "active":active,
        "addon_id":ADDON_ID,
        "engine_version":VERSION,
        "requested_person_count":person_count,
        "single_being_hardlock":bool(active and not multi),
        "couple_mode":bool(active and multi),
        "couple_interaction_mode":mode,
        "identity_protection":"HARD" if active else None,
        "face_body_naturalism":"HARD" if active else None,
        "anatomy_protection":"HARD" if active else None,
        "reference_consistency":"HARD" if active else None,
        "multi_person_consistency":"HARD" if active else None,
        "transformation_hierarchy":"HUMAN_TO_ENHANCED_HUMAN_TO_CYBER_HYBRID" if active else None,
        "duality_balance":{"angel_energy":50,"demon_energy":50,"one_identity":100} if active and not multi else None,
        "face_body_integration_failure":failure if active else False,
        "repair_order":[
            "preserve identity","correct head scale","correct neck geometry","correct shoulder relationship",
            "match skin lighting","match texture/grain","match camera perspective","preserve existing armor",
            "preserve existing wings","preserve existing environment"
        ] if failure else [],
        "priority_stack":PRIORITY_STACK if active else [],
        "quality_targets":QUALITY_TARGETS if active else {},
        "no_random_text":bool(active),
        "external_lyvra_mutated":False,
    }

def compact_directive(report:dict)->str:
    if not report.get("active"): return ""
    if report.get("single_being_hardlock"):
        count=("ONE PERSON ONLY: one body, one protected identity, angelic and demonic energies coexist in the same anatomy; "
               "never duplicate the face/body or create a separate angel and devil. ")
    else:
        count=("TWO PROTECTED IDENTITIES: keep Character A and Character B distinct; never average, merge or swap faces, hair, beard, body or armor identity; "
               f"interaction={report.get('couple_interaction_mode')}. ")
    repair=""
    if report.get("face_body_integration_failure"):
        repair=("FACE_BODY_INTEGRATION_REPAIR: keep the reference face; reconstruct head scale, neck, shoulders, skin light/grain and perspective around it before touching armor, wings or environment. ")
    return (
        count+
        "Identity and face/body naturalism outrank all fantasy styling. Keep realistic head/body ratio, neck-clavicle-shoulder connection, skin continuity, matching sharpness/grain and anatomically plausible hands/contact. "
        "Use Human -> Enhanced Human -> Cyber Hybrid, not full robot unless explicitly requested. "
        "Duality should be organically interwoven: celestial white/cyan/silver and infernal black/crimson structures may cross the center through shared armor/core; avoid a crude straight 50/50 split. "
        "Default single-being architecture: one cyber-angel wing plus one biomechanical demon wing, halo/halo segment plus one dominant cyber horn, believable scapular wing roots, no detached/duplicate wings or extra horns. "
        "Preserve original facial geometry, apparent age, skin tone, hairline/hairstyle, beard/moustache and distinctive details; no generic fantasy beautification. "
        "No random text/logos/glyphs. Photographic realism first: natural pores/hair, plausible metal/feather/membrane response, coherent global illumination and shadows. "+repair+
        "Priority: P0 identity > P1 face-body naturalism > P2 anatomy > P3 person count > P4 continuity > P5 duality > P6 armor > P7 wings/halo/horn > P8 environment > P9 effects."
    )
