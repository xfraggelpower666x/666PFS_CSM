#!/usr/bin/env python3
"""PHLF-CYBER extension acceptance tests for 666 PRG v2.0.0."""
from pathlib import Path
import importlib.util
import json
import sys

R=Path(__file__).resolve().parent

def load(name, file):
    spec=importlib.util.spec_from_file_location(name,R/file)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

ext=load("phlf","36_PHLF_CYBER_EXTENSION.py")
compiler=load("compiler","26_PROMPT_COMPILER.py")
fails=[]

def check(name, cond, detail=""):
    if not cond: fails.append(f"{name}:{detail}")

r=ext.analyze("Clearly adult woman with cyber hair, black chrome fingernails, neon makeup and visor")
check("P01_ACTIVE",r["active"],str(r))
check("P02_FEATURES",all(r["features"][k] for k in ("hair","nails","makeup","accessories")),str(r["features"]))

c=compiler.compile_prompt("Create a clearly adult cyber-love couple embracing inside a neon-glass heart with music notes")
check("P03_MODULE","PHLF_CYBER_LIFESTYLE_EXTENSION" in c["selected_modules"],str(c["selected_modules"]))
check("P04_DIRECTIVE","[PHLF_CYBER]" in c["compiled_prompt"],c["compiled_prompt"])
check("P05_NONEXPLICIT","non-explicit" in c["compiled_prompt"].casefold(),c["compiled_prompt"])

c2=compiler.compile_prompt("Create an ordinary landscape")
check("P06_NOT_FORCED","PHLF_CYBER_LIFESTYLE_EXTENSION" not in c2["selected_modules"],str(c2["selected_modules"]))

if fails:
    print("PHLF EXTENSION TESTS = FAIL")
    print("\n".join(fails)); sys.exit(1)
print("PHLF EXTENSION TESTS = PASS (6/6)")
