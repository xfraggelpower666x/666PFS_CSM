#!/usr/bin/env python3
"""Structured visual QA evidence validator for 666 PRG v2.0.0."""
from __future__ import annotations
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
PROFILE = json.loads((ROOT / "08_VISUAL_QA_PROFILE.json").read_text(encoding="utf-8"))


def evaluate(report: dict | None) -> dict:
    if not isinstance(report, dict):
        return {"valid": False, "decision": "TERMINAL_FAIL", "errors": ["QA_REPORT_MISSING"], "weighted_score": 0.0}
    supplied = report.get("checks")
    if not isinstance(supplied, dict):
        return {"valid": False, "decision": "TERMINAL_FAIL", "errors": ["QA_CHECKS_MISSING"], "weighted_score": 0.0}
    errors: list[str] = []
    weighted = 0.0
    failed: list[str] = []
    repairable_failed: list[str] = []
    normalized: dict[str, dict] = {}
    for spec in PROFILE.get("checks", []):
        qid = spec["id"]
        item = supplied.get(qid)
        if not isinstance(item, dict):
            errors.append(f"QA_CHECK_MISSING:{qid}")
            continue
        passed = item.get("passed")
        score = item.get("score")
        observations = item.get("observations")
        if not isinstance(passed, bool):
            errors.append(f"QA_PASSED_FLAG_INVALID:{qid}")
        if not isinstance(score, (int, float)) or isinstance(score, bool) or not 0.0 <= float(score) <= 1.0:
            errors.append(f"QA_SCORE_INVALID:{qid}")
            score = 0.0
        if not isinstance(observations, str) or not observations.strip():
            errors.append(f"QA_OBSERVATION_MISSING:{qid}")
        score = float(score)
        weighted += score * float(spec.get("weight", 0.0))
        normalized[qid] = {"passed": bool(passed), "score": score, "observations": observations or ""}
        if passed is False:
            failed.append(qid)
            if spec.get("repairable", False):
                repairable_failed.append(qid)
    minimum = float(PROFILE.get("minimum_photorealism_score", 0.82))
    all_present = len(normalized) == len(PROFILE.get("checks", []))
    if errors or not all_present:
        decision = "TERMINAL_FAIL"
    elif not failed and weighted >= minimum:
        decision = "PASS"
    elif failed and len(failed) == len(repairable_failed):
        decision = "REPAIRABLE_FAIL"
    elif weighted < minimum:
        decision = "REPAIRABLE_FAIL"
    else:
        decision = "TERMINAL_FAIL"
    return {
        "valid": not errors and all_present,
        "decision": decision,
        "errors": errors,
        "weighted_score": round(weighted, 6),
        "minimum_score": minimum,
        "failed_checks": failed,
        "repairable_failed_checks": repairable_failed,
        "checks": normalized,
    }


def perfect_report(observation: str = "Verified by host visual inspection.") -> dict:
    return {"checks": {spec["id"]: {"passed": True, "score": 1.0, "observations": observation} for spec in PROFILE.get("checks", [])}}


if __name__ == "__main__":
    import sys
    data = json.load(sys.stdin)
    print(json.dumps(evaluate(data), ensure_ascii=False, indent=2))
