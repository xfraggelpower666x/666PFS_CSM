#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('d',R/'86_DYNAMIC_SIDE_REMAPPING.py'); d=importlib.util.module_from_spec(s); s.loader.exec_module(d)
t=[]
def ck(n,c): t.append((n,bool(c)))
r=d.analyze('couple swapped sides: Amaris right blue, Amarin left pink, names and frame colors follow each person')
ck('DSR01 active',r['active']); ck('DSR02 side allowed',r['side_swap_allowed']); ck('DSR03 owner person',r['identity_owns_visual_properties']); ck('DSR04 name no swap',r['name_side_binding']['name_swap']=='FORBIDDEN'); ck('DSR05 color owner',r['color_person_binding']['owner']=='PERSON_ID'); ck('DSR06 frame owner',r['frame_region_remapping']['owner']=='PERSON_ID'); ck('DSR07 no side stickiness',r['color_person_binding']['side_stickiness']=='FORBIDDEN'); ck('DSR08 no core replace',not r['core_replacement']); ck('DSR09 no ENSC replace',not r['ensc_replacement'])
m=d.remap({'A':{'current_side':'RIGHT'},'B':{'current_side':'LEFT'}},{'A':{'NAME':'AMARIS','SIGNATURE_COLOR':'BLUE'},'B':{'NAME':'AMARIN','SIGNATURE_COLOR':'PINK'},'_GLOBAL_':{'CENTER_CONNECTOR':'&'}})
ck('DSR10 A right',m['persons']['A']['current_side']=='RIGHT'); ck('DSR11 blue moves with A',m['persons']['A']['properties']['SIGNATURE_COLOR']=='BLUE'); ck('DSR12 B left',m['persons']['B']['current_side']=='LEFT'); ck('DSR13 connector global',m['globals']['CENTER_CONNECTOR']=='&'); ck('DSR14 directive','PROPERTY_OWNER=PERSON_ID' in d.compact_directive(r))
r2=d.analyze('single neutral portrait')
ck('DSR15 unrelated off',not r2['active'])
reg=json.loads((R/'87_DSR_REGISTRY.json').read_text())
ck('DSR16 registry active',reg['status']=='INTEGRATED_ACTIVE'); ck('DSR17 add only',reg['integration_mode']=='ADD_ONLY'); ck('DSR18 004 compatibility','PRG-ADDON-ENVIRONMENTAL-NARRATIVE-COHERENCE-004' in reg['parent_compatibility'])
for n,p in t: print(('PASS' if p else 'FAIL'),n)
if not all(p for _,p in t): raise SystemExit(1)
print(f'DSR-005 TESTS = PASS ({len(t)}/{len(t)})')
