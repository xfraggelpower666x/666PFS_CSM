#!/usr/bin/env python3
"""Host-turn executor for 666 PRG v2.0.0.

Preserves original creative text, separates explicit control-plane commands,
compiles prompts deterministically, repairs retry/repair recompilation and emits
exactly one same-turn CALL_IMAGE_TOOL action after fail-closed preflight.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import importlib.util
import json
import re

ROOT = Path(__file__).resolve().parent


def module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


k = module("prg_kernel", "11_RUNTIME_KERNEL.py")
store = module("prg_store", "22_RUNTIME_STORE.py")
REG = json.loads((ROOT / "17_CONTROL_TRIGGER_REGISTRY.json").read_text(encoding="utf-8"))
PHG_UI = module("phg_interaction", "79_PHG_INTERACTION_ENGINE.py")


def norm(text: str | None) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().casefold())


def phrase_pattern(value: str, *, anchored: bool = False) -> re.Pattern:
    escaped = re.escape(norm(value)).replace(r"\ ", r"\s+")
    prefix = r"^\s*" if anchored else r"(?<!\w)"
    suffix = r"(?!\w)"
    return re.compile(prefix + escaped + suffix, re.IGNORECASE)


def starts_with_phrase(text: str, value: str) -> bool:
    return bool(phrase_pattern(value, anchored=True).search(text or ""))


def has_phrase(text: str, value: str) -> bool:
    return bool(phrase_pattern(value).search(text or ""))


def maintenance_command(text: str) -> bool:
    t = norm(text)
    if not t:
        return False
    if any(starts_with_phrase(text, p) for p in REG.get("maintenance_prefix_patterns", [])):
        return True
    exact = {norm(x) for x in REG.get("exact_maintenance_commands", [])}
    if t in exact:
        return True
    heads = REG.get("system_maintenance_command_heads", [])
    targets = REG.get("system_target_phrases", [])
    return any(starts_with_phrase(text, h) for h in heads) and any(has_phrase(text, target) for target in targets)


def _starts_any(text: str, key: str) -> bool:
    return any(starts_with_phrase(text, alias) for alias in REG.get(key, []))


def classify(text: str, image_present: bool = False) -> str:
    if not norm(text) and image_present:
        return "AUTO_EXECUTE"
    # PHG owns exactly two direct interface triggers. They are control-plane UI, never image prompts.
    if PHG_UI.classify_trigger(text) != "NONE":
        return "PHG_INTERFACE"
    # A bare canonical/numeric mode selection opens guidance + copy prompts instead of rendering.
    try:
        selection = PHG_UI.resolve_selection(text)
        if selection.get("selection_only"):
            return "MODE_SELECTION_GUIDANCE"
    except Exception:
        pass
    if maintenance_command(text):
        return "SYSTEM_MAINTENANCE"
    if _starts_any(text, "status_query_aliases"):
        return "STATUS_QUERY"
    if _starts_any(text, "cancel_aliases"):
        return "CANCEL"
    if _starts_any(text, "resume_aliases"):
        return "RESUME"
    if _starts_any(text, "frame_aliases"):
        return "FRAME_REQUEST"
    if _starts_any(text, "manual_retry_aliases"):
        return "MANUAL_RETRY"
    if _starts_any(text, "execute_aliases"):
        return "EXECUTE"
    return "CREATIVE_INTENT" if norm(text) else "NOOP"


def strip_leading_alias(text: str, aliases: list[str]) -> str:
    original = text or ""
    for alias in sorted(aliases, key=len, reverse=True):
        match = phrase_pattern(alias, anchored=True).search(original)
        if match:
            return re.sub(r"\s+", " ", original[match.end():]).strip(" .,!;:-\t\r\n")
    return original.strip()


def clean_creative_intent(text: str, classification: str | None = None) -> str:
    c = classification or classify(text)
    mapping = {
        "MANUAL_RETRY": "manual_retry_aliases",
        "EXECUTE": "execute_aliases",
        "FRAME_REQUEST": "frame_aliases",
        "RESUME": "resume_aliases",
        "CANCEL": "cancel_aliases",
    }
    return strip_leading_alias(text, REG.get(mapping[c], [])) if c in mapping else (text or "").strip()


def _step(state: dict, event: str, ctx: dict, records: list[dict]):
    state, record, action = k.transition(state, event, ctx)
    records.append(record)
    return state, action


def _proof_context(state: dict, ctx: dict) -> dict:
    return {
        **ctx,
        "transaction_id": state.get("transaction_id"),
        "attempt_id": state.get("attempt_id"),
        "source_hash": state.get("source_hash"),
        "prompt_hash": state.get("prompt_hash"),
    }


def _persist_result(result: dict, runtime_root: str | Path | None, expected_revision: int | None) -> dict:
    if runtime_root is None:
        return result
    state_errors = k.validate_runtime_state(result["state"])
    if state_errors:
        raise RuntimeError("PERSISTENCE_STATE_VALIDATION_FAILED:" + ";".join(state_errors))
    action = result.get("host_action")
    receipts = [action["receipt"]] if action and action.get("receipt") else []
    for receipt in receipts:
        receipt_errors = k.validate_receipt(receipt)
        if receipt_errors:
            raise RuntimeError("PERSISTENCE_RECEIPT_VALIDATION_FAILED:" + ";".join(receipt_errors))
    persisted = store.persist_transaction(
        Path(runtime_root), result["state"], result.get("journal", []), receipts,
        expected_revision=expected_revision,
    )
    result["state"] = persisted["state"]
    result["persistence"] = persisted["commit"]
    return result


def _fresh_transaction(state: dict, ctx: dict, records: list[dict], intent: str, *, parent_transaction_id: str | None = None):
    return _step(state, "NEW_IMAGE", {
        **ctx,
        "source_id": ctx.get("source_id") or state.get("source_id"),
        "source_hash": ctx.get("source_hash") or state.get("source_hash"),
        "source_hash_provenance": ctx.get("source_hash_provenance") or state.get("source_hash_provenance"),
        "intent": intent,
        "parent_transaction_id": parent_transaction_id,
    }, records)


def execute_turn(
    state: dict | None = None,
    text: str = "",
    image_present: bool = False,
    source_id: str | None = None,
    source_hash: str | None = None,
    source_hash_provenance: str | None = None,
    source_traits: list[str] | None = None,
    creative_intent: str | None = None,
    tool_available: bool | None = None,
    runtime_root: str | Path | None = None,
    expected_revision: int | None = None,
    host_channel: str = "commentary",
    cyber_garden_state: dict | None = None,
    cyber_garden_approval: dict | None = None,
) -> dict:
    s = state or k.initial_state()
    classification = classify(text, image_present)
    result = {
        "classification": classification,
        "state": s,
        "journal": [],
        "host_action": None,
        "hardlock": {
            "same_turn_tool_call_required": False,
            "channel": host_channel,
            "precall_text_allowed": False,
            "final_before_result_allowed": False,
            "post_success_text_allowed": False,
        },
    }

    if classification == "PHG_INTERFACE":
        kind = PHG_UI.classify_trigger(text)
        payload = PHG_UI.systemstart_payload() if kind == "START_INTERFACE" else PHG_UI.help_payload()
        result.update(route="PHG_INTERFACE", reason="PHG guided interface; never dispatches the image tool.", interface_payload=payload)
        return result
    if classification == "MODE_SELECTION_GUIDANCE":
        result.update(route="MODE_SELECTION_GUIDANCE", reason="Mode selection is guidance-only until a substantive image instruction is provided.", guidance=PHG_UI.build_guidance(text, uploaded_reference=image_present))
        return result
    if classification == "SYSTEM_MAINTENANCE":
        result.update(route="SYSTEM_MAINTENANCE", reason="Explicit control-plane command; not image prompt content.")
        return result
    if classification == "STATUS_QUERY":
        result.update(
            route="STATUS_QUERY",
            reason="Status query never dispatches the image tool.",
            pending_state=s.get("state"),
            pending_source=bool(s.get("source_id")),
            last_error=s.get("last_error_detail"),
            retry_available=s.get("state") == "RETRY_READY",
        )
        return result
    if host_channel != "commentary":
        result.update(
            route="CHANNEL_VIOLATION",
            reason=f"IMAGE_TOOL_CHANNEL_INVALID:{host_channel};EXPECTED:commentary",
            required_channel="commentary",
            state=s,
        )
        return result
    if classification == "NOOP":
        result["route"] = "NOOP"
        return result
    if classification == "CANCEL":
        if s.get("state") in k.GROUPS.get("ACTIVE_INFLIGHT", []):
            s, _ = _step(s, "USER_CANCEL", {}, result["journal"])
            result.update(route="CANCELLED", state=s)
            return _persist_result(result, runtime_root, expected_revision)
        else:
            result.update(route="NO_HOST_ACTION", reason="No active transaction to cancel.")
        return result
    if classification == "RESUME":
        if s.get("state") in {"FAILED_TERMINAL", "CANCELLED"}:
            s, _ = _step(s, "RESUME_COMMAND", {"intent": s.get("intent")}, result["journal"])
        else:
            result.update(route="NO_HOST_ACTION", reason="Resume requires FAILED_TERMINAL or CANCELLED.")
            return result

    if image_present and (not source_id or not source_hash or not k.valid_sha256(source_hash)):
        result.update(route="NEED_SOURCE_PROOF", reason="Image upload requires source_id and a trusted 64-character SHA-256 content digest.")
        return result
    if not image_present and not s.get("source_id"):
        result.update(route="NEED_SOURCE", reason="No usable pending image source.")
        return result
    if s.get("state") == "DISPATCHING" and not image_present:
        result.update(route="ALREADY_INFLIGHT", reason="An active dispatch already owns the source.")
        return result

    cleaned = clean_creative_intent(text, classification)
    intent = creative_intent or cleaned or s.get("intent") or "Photorealistic transformation preserving identity, pose, composition and environment."
    ctx = {
        "channel": host_channel,
        "source_present": bool(source_id or s.get("source_id")),
        "tool_available": tool_available is True,
        "source_id": source_id or s.get("source_id"),
        "source_hash": source_hash or s.get("source_hash"),
        "source_hash_provenance": source_hash_provenance or s.get("source_hash_provenance") or ("HOST_SUPPLIED_CONTENT_DIGEST" if (source_hash or s.get("source_hash")) else None),
        "intent": intent,
        "source_traits": list(source_traits or []),
    }
    terminal = {"COMPLETE", "FAILED_TERMINAL", "CANCELLED", "FRAME_READY"}

    if classification == "FRAME_REQUEST":
        if s.get("state") != "COMPLETE" or not (s.get("output_id") or s.get("output_hash")):
            result.update(route="NO_HOST_ACTION", reason="Frame Stage 2 requires a validated COMPLETE output.")
            return result
        parent = s["transaction_id"]
        frame_intent = cleaned or "Add the explicitly requested frame to the validated image without altering its protected content."
        output_source_id, output_source_hash = s.get("output_id"), s.get("output_hash")
        s, _ = _step(s, "FRAME_REQUEST", {}, result["journal"])
        frame_ctx = {**ctx, "source_id": output_source_id, "source_hash": output_source_hash, "source_hash_provenance": "VALIDATED_STAGE1_OUTPUT", "intent": frame_intent}
        s, _ = _fresh_transaction(s, frame_ctx, result["journal"], frame_intent, parent_transaction_id=parent)
        s["frame_stage"] = "ON"
        ctx = frame_ctx
    elif image_present:
        s, _ = _step(s, "NEW_IMAGE", ctx, result["journal"])
    elif classification == "MANUAL_RETRY":
        s, _ = _fresh_transaction(s, ctx, result["journal"], cleaned or s.get("intent") or intent)
    elif classification in {"EXECUTE", "CREATIVE_INTENT"} and s.get("state") in terminal:
        s, _ = _fresh_transaction(s, ctx, result["journal"], intent)
    elif classification == "CREATIVE_INTENT" and s.get("state") in k.GROUPS.get("PENDING_SOURCE", []):
        s, _ = _step(s, "USER_INTENT_CHANGED", {**ctx, "intent": intent}, result["journal"])

    if s.get("state") == "IMAGE_RECEIVED":
        s, _ = _step(s, "SOURCE_RESOLVED", ctx, result["journal"])
    if s.get("state") == "RETRY_READY":
        s, _ = _step(s, "RETRY_ALLOWED", ctx, result["journal"])
    if s.get("state") == "REPAIR_READY":
        s, _ = _step(s, "REPAIR_ALLOWED", ctx, result["journal"])
    if s.get("state") == "SOURCE_REGISTERED":
        try:
            compiled = k.PROMPT_COMPILER.compile_prompt(
                s.get("intent", intent),
                source_traits=source_traits,
                frame_stage=s.get("frame_stage", "OFF"),
                repair_directives=s.get("repair_directives", []),
                cyber_garden_state=cyber_garden_state,
                cyber_garden_approval=cyber_garden_approval,
            )
        except Exception as exc:
            s, _ = _step(s, "PROMPT_COMPILE_FAILED", {"error": str(exc)}, result["journal"])
            result.update(route="FAILED_TERMINAL", state=s, reason=f"PROMPT_COMPILE_FAILED:{exc}")
            return _persist_result(result, runtime_root, expected_revision)
        compile_ctx = {
            **ctx,
            "compiled_prompt": compiled["compiled_prompt"],
            "prompt_hash": compiled["prompt_hash"],
            "prompt_manifest_hash": compiled["prompt_manifest_hash"],
            "prompt_modules": compiled["selected_modules"],
        }
        s, _ = _step(s, "PROMPT_COMPILED", compile_ctx, result["journal"])
        ctx = compile_ctx
    if s.get("state") == "PROMPT_READY":
        s, _ = _step(s, "PREFLIGHT_PASSED", ctx, result["journal"])

    action = None
    if s.get("state") == "DISPATCH_REQUESTED":
        s, action = _step(s, "DISPATCH_ACCEPTED", ctx, result["journal"])

    result["state"] = s
    result["host_action"] = action
    if action:
        result["route"] = "CALL_IMAGE_TOOL"
        result["hardlock"]["same_turn_tool_call_required"] = True
    else:
        detail = s.get("last_error_detail") or "Atomic chain did not reach dispatch."
        if "TOOL_AVAILABILITY" in detail:
            result["route"] = "TOOL_UNAVAILABLE"
        elif "RETRY_BACKOFF_ACTIVE" in detail:
            result["route"] = "RETRY_BACKOFF_ACTIVE"
        elif "CIRCUIT_BREAKER" in detail:
            result["route"] = "CIRCUIT_OPEN"
        elif s.get("state") == "FAILED_TERMINAL":
            result["route"] = "FAILED_TERMINAL"
        else:
            result["route"] = "NO_HOST_ACTION"
        result["reason"] = detail

    return _persist_result(result, runtime_root, expected_revision)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--state")
    p.add_argument("--text", default="")
    p.add_argument("--image-present", action="store_true")
    p.add_argument("--source-id")
    p.add_argument("--source-hash")
    p.add_argument("--source-hash-provenance")
    p.add_argument("--creative-intent")
    p.add_argument("--tool-available", action="store_true")
    p.add_argument("--runtime-root")
    p.add_argument("--host-channel", default="commentary")
    args = p.parse_args()
    state = json.loads(Path(args.state).read_text(encoding="utf-8")) if args.state else None
    print(json.dumps(execute_turn(
        state, args.text, args.image_present, args.source_id, args.source_hash,
        args.source_hash_provenance, creative_intent=args.creative_intent,
        tool_available=args.tool_available, runtime_root=args.runtime_root, host_channel=args.host_channel,
    ), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
