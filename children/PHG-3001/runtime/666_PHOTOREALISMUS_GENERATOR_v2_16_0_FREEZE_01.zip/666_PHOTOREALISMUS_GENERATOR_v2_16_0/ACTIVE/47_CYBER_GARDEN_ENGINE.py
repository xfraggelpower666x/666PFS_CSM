#!/usr/bin/env python3
"""Adaptive Cyber Garden & Idea Evolution engine for 666 PRG v2.5.0.
Pure analysis/state-transition helper. It does not autonomously retrain models or write persistent memory.
Durable preference changes require explicit USER_APPROVAL or CANONICAL status by the host/user workflow.
"""
from __future__ import annotations
from pathlib import Path
import copy, json, re
ROOT=Path(__file__).resolve().parent
REG=json.loads((ROOT/'48_CYBER_GARDEN_REGISTRY.json').read_text(encoding='utf-8'))

ACTIVATION_TERMS=(
 'cyber garden','cyber-garden','idea egg','idea-egg','cyber egg','knowledge tree','memory forest','idea nursery','relationship garden','sonic garden','dream lab','creature sanctuary','dark garden','bloom district','future self projection','garden biome','living visual knowledge ecosystem','adaptive garden','ideen-ei','wissensbaum','cyber garten','cybergarten'
)
INFLUENCES={
 'MUSIC':('music','song','audio','sonic','sound','track','beat','musik','klang'),
 'FOREST':('forest','tree','plant','ecology','garden','wald','baum','pflanze','ökologie'),
 'EMOTION':('love','trust','relationship','emotion','family','friend','mentor','liebe','vertrauen','beziehung','familie','freund'),
 'ENGINEERING':('engineering','builder','build','machine','architecture','system','code','engineer','technik','bauen','architektur'),
 'ART':('art','artist','creative','painting','design','story','kunst','kreativ','malerei','geschichte'),
}
FUTURE_FORMS={'MUSIC':'Sonic Architect','FOREST':'Ecosystem Guardian','EMOTION':'Connection Keeper','ENGINEERING':'Cyber Builder','ART':'Creative Vision Entity'}


def _norm(s:str)->str: return re.sub(r'\s+',' ',(s or '').casefold()).strip()
def _contains(text:str, term:str)->bool:
    t=_norm(text); q=_norm(term)
    return bool(re.search(r'(?<!\w)'+re.escape(q).replace(r'\ ',r'\s+')+r'(?!\w)',t,re.I))

def is_active(intent:str, source_traits:list[str]|None=None)->bool:
    blob=' '.join([intent or '',*(source_traits or [])])
    return any(_contains(blob,t) for t in ACTIVATION_TERMS)

def classify_influences(intent:str)->list[str]:
    blob=_norm(intent)
    return [name for name,terms in INFLUENCES.items() if any(_contains(blob,t) for t in terms)]

def future_self_projection(influences:list[str])->dict:
    forms=[FUTURE_FORMS[x] for x in influences if x in FUTURE_FORMS]
    if len(forms)>1:
        forms.append('Unique Hybrid Identity')
    if not forms: forms=['Emergent Creative Entity']
    return {'type':'FUTURE_SELF_PROJECTION','possible_forms':forms,'irreversible':False}

def default_state()->dict:
    return {
      'world_mode':'EVOLUTION','identity_protection':'MAX','creative_variation':'MEDIUM_HIGH','continuity':'HIGH','photorealism':'HIGH','world_coherence':'MAX',
      'idea_egg':{'stage':'SEED','learned_traits':[],'head_growth':'small glowing seed','possible_future_forms':[]},
      'relationships':[], 'creatures':{}, 'knowledge_tree':{'roots':[],'branches':[],'leaves':[],'flowers':[],'fruit':[]},
      'learning':{'state':'NEW','durable_preferences':[],'rejected_patterns':[]}, 'history':[]
    }

def preservation_mask(current_state:dict|None=None)->dict:
    s=current_state or {}
    keep=[]
    if s.get('idea_egg'): keep.append('IDEA_EGG_CONTINUITY')
    if s.get('knowledge_tree'): keep.append('CENTRAL_KNOWLEDGE_TREE_CONTINUITY')
    return {'MUST_KEEP':keep,'CAN_EVOLVE':['IDEA_EGG_FORM','PLANTS','INTERFACES','RELATIONSHIP_VISUALS'],'CAN_ADD':['LOGICALLY_EMERGENT_CREATURE','NEW_RELATIONSHIP','APPROVED_GROWTH'],'MUST_REMOVE':[],'DO_NOT_TOUCH':['PROTECTED_CHARACTER_IDENTITY']}

def learning_decision(user_approval:bool=False, canonical:bool=False, rejected:bool=False, variant:bool=False)->str:
    if canonical: return 'CANONICAL'
    if rejected: return 'REJECTED'
    if variant: return 'EXPERIMENTAL'
    if user_approval: return 'PREFERRED'
    return 'OBSERVED'

def evolve_state(current_state:dict|None, *, intent:str, user_approval:bool=False, canonical:bool=False, rejected:bool=False, variant:bool=False)->dict:
    base=copy.deepcopy(current_state or default_state())
    influences=classify_influences(intent)
    projection=future_self_projection(influences)
    egg=base.setdefault('idea_egg',{})
    egg['possible_future_forms']=projection['possible_forms']
    if influences:
        traits=egg.setdefault('learned_traits',[])
        # Traits become proposed/observed immediately but durable preference changes only after approval/canonical.
        for x in influences:
            token='OBSERVED_'+x
            if token not in traits: traits.append(token)
    decision=learning_decision(user_approval,canonical,rejected,variant)
    base.setdefault('learning',{})['state']=decision
    if decision in {'PREFERRED','CANONICAL'}:
        durable=base['learning'].setdefault('durable_preferences',[])
        for x in influences:
            if x not in durable: durable.append(x)
    if decision=='REJECTED':
        rej=base['learning'].setdefault('rejected_patterns',[])
        for x in influences:
            if x not in rej: rej.append(x)
    base.setdefault('history',[]).append({'intent':intent,'influences':influences,'learning_decision':decision,'durable_write_allowed':decision in {'PREFERRED','CANONICAL'}})
    return base

def analyze(intent:str, source_traits:list[str]|None=None, world_state:dict|None=None, approval:dict|None=None)->dict:
    active=is_active(intent,source_traits)
    if not active:
        return {'active':False,'addon_id':'PG-ACGIE-001','reason':'NO_CYBER_GARDEN_INTENT','external_lyvra_mutated':False}
    ap=approval or {}
    state=evolve_state(world_state,intent=intent,user_approval=bool(ap.get('user_approval')),canonical=bool(ap.get('canonical')),rejected=bool(ap.get('rejected')),variant=bool(ap.get('variant')))
    infl=classify_influences(intent)
    return {
      'active':True,'addon_id':'PG-ACGIE-001','world_mode':state.get('world_mode','EVOLUTION'),'identity_protection':'MAX','continuity':'HIGH','world_coherence':'MAX',
      'influences':infl,'future_self_projection':future_self_projection(infl),'preservation_mask':preservation_mask(world_state),'state':state,
      'learning_decision':state.get('learning',{}).get('state','OBSERVED'),'durable_learning':state.get('learning',{}).get('state') in {'PREFERRED','CANONICAL'},
      'photorealism_guard':REG['photorealism_guard'],'reference_priority':REG['reference_priority'],'external_lyvra_mutated':False
    }

def compact_directive(report:dict)->str:
    if not report.get('active'): return ''
    infl=', '.join(report.get('influences') or ['context-driven'])
    forms=', '.join(report.get('future_self_projection',{}).get('possible_forms') or ['Emergent Creative Entity'])
    return (
      'Activate Adaptive Cyber Garden continuity only for this garden-related request. Preserve protected character identity and established world architecture; use KEEP -> EXTEND -> INTEGRATE -> REBALANCE, not full regeneration. '
      f'World mode={report.get("world_mode","EVOLUTION")}; influences={infl}; Idea Egg future forms are possibilities only: {forms}. '
      'Show relationships visually through plausible light, positioning, filaments, shared structures or growth. Keep creatures meaningful, central knowledge-tree continuity intact, semantic color use coherent, and fantasy physically photorealistic with correct anatomy, materials, reflections, shadows, perspective and scale. '
      f'Learning state={report.get("learning_decision","OBSERVED")}; do not make durable visual-memory changes unless user approval or explicit CANONICAL status is present. External LYVRA remains unchanged.'
    )
