#!/usr/bin/env python3
"""PHG-3001 v2.10.0 I LOVE YOU / ENDLESS Cyber Love preset family."""
from __future__ import annotations
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
VERSION="1.0.0"
REGISTRY=json.loads((ROOT/"65_CYBER_LOVE_PRESET_REGISTRY.json").read_text(encoding="utf-8"))
PRESET_IDS=tuple(REGISTRY["presets"].keys())
ALIASES={
 "PRG-PRESET-ILY-ENDLESS-001":("i love you endless preset","i love you endless cyber love frame","ily endless","prg-preset-ily-endless-001"),
 "PRG-PRESET-ILY-ENDLESS-NEON-EMBRACE-001":("i love you endless neon embrace","neon embrace display","photo derived i love you endless","prg-preset-ily-endless-neon-embrace-001"),
}
def _norm(v:str|None)->str: return re.sub(r"\s+"," ",(v or "").casefold()).strip()
def detect(text:str,preset_id:str|None=None)->str|None:
    if preset_id in PRESET_IDS: return preset_id
    t=_norm(text)
    for pid in PRESET_IDS:
        if _norm(pid) in t: return pid
    for pid,aliases in ALIASES.items():
        if any(a in t for a in aliases): return pid
    return None

def analyze(text:str, *, preset_id:str|None=None)->dict:
    pid=detect(text,preset_id)
    if not pid: return {"active":False,"version":VERSION}
    p=dict(REGISTRY["presets"][pid])
    return {"active":True,"version":VERSION,"preset_id":pid,"preset":p,"parent_addon":p["parent_addon"],"requires_parent_addon":True,
            "top_text":p["top_text"],"bottom_text":p["bottom_text"],"text_accuracy":"HARD_LOCK","text_mutation":"FORBIDDEN","additional_visible_words":"FORBIDDEN",
            "frame_mode":p.get("frame_mode","FRAME_MODE_CYBER_LOVE_HOLO"),"safe_add_only":True}

def compact_directive(r:dict)->str:
    if not r.get("active"): return ""
    p=r["preset"]; base=(
      f"Load {r['preset_id']} as an ADD-ONLY child of PRG-ADDON-CYBER-LOVE-FRAME-001. "
      f"Render only the exact frame texts '{r['top_text']}' at TOP_CENTER and '{r['bottom_text']}' at BOTTOM_CENTER; text mutation, silent translation, additional visible words, random labels, logos and watermarks are forbidden. "
      "Use FRAME_MODE_CYBER_LOVE_HOLO with Level-2 balanced black-titanium/dark-chrome/smoked-tech-glass/optical-neon-fiber construction, physically shared magenta/cyan/violet/electric-blue lighting, realistic reflections and source-image preservation. "
    )
    if r['preset_id']=="PRG-PRESET-ILY-ENDLESS-001":
      return base + "Keep cyber hearts and infinity modules subordinate; adapt frame thickness to the source aspect ratio, prefer outward canvas expansion, and preserve the source scene, faces, objects and existing content."
    return base + (
      "Use the photo-derived 4:5 composition DNA: central adult couple in a tender forehead-to-forehead close embrace; futuristic neon cyber-city depth; a large holographic network-heart halo behind the couple; deep-red roses and petals across the lower foreground; a central intertwined heart/infinity hologram above the ENDLESS panel; glowing cyber-heart top corners; narrow side rails with abstract non-textual holo-HUD rings, infinity modules, ECG waveforms and optical channels; circular infinity-energy bottom corner modules. Keep the couple dominant and photorealistic."
    )
