#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
def load(name,file):
    s=importlib.util.spec_from_file_location(name,ROOT/file); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
E=load("cvice","66_CVICE_ENGINE.py")
C=load("compiler","26_PROMPT_COMPILER.py")
M=json.loads((ROOT/"00_ACTIVE_MANIFEST.json").read_text(encoding="utf-8"))
R=json.loads((ROOT/"68_CVICE_REGISTRY.json").read_text(encoding="utf-8"))
checks=[]
def ok(n,c): checks.append((n,bool(c)))

r=E.analyze("PRG-CVICE-002 causal visual intelligence with multiple references and identity continuity")
ok("CVI01 explicit active",r["active"])
ok("CVI02 id exact",r["engine_id"]=="PRG-CVICE-002" and r["version"]=="2.0.0")
ok("CVI03 add only",r["mode"]=="ADD_ONLY")
ok("CVI04 umip mutation forbidden",r["umip_mutation"]=="FORBIDDEN" and r["umip_dependency"]=="NONE")
ok("CVI05 nine layers",len(r["layers"])==9 and r["layers"][0]=="REFERENCE_INTELLIGENCE_CORE" and r["layers"][-1]=="VISUAL_AUDIT_CORE")
ok("CVI06 reference roles complete",len(R["reference_roles"])==19)
ok("CVI07 authority levels",R["authority_levels"]=={"P0":"CANONICAL","P1":"DOMINANT","P2":"SUPPORTING","P3":"OPTIONAL","P4":"HISTORICAL"})
ok("CVI08 album cover route",E.analyze("causal album cover with reference identity")["profile"]=="PRG_PRESET_ALBUM_COVER")
ok("CVI09 evolution route",E.analyze("visual evolution sequence with reference stages and identity")["profile"]=="PRG_PRESET_EVOLUTION_SEQUENCE")
ok("CVI10 duality route",E.analyze("PRG-CVICE-002 single being duality human machine")["profile"]=="PRG_PRESET_SINGLE_BEING_DUALITY")
ok("CVI11 couple route",E.analyze("PRG-CVICE-002 couple continuity two identities")["profile"]=="PRG_PRESET_COUPLE_CONTINUITY")
ok("CVI12 world fusion route",E.analyze("world-native fusion multiple references one world")["profile"]=="PRG_PRESET_WORLD_NATIVE_FUSION")
ok("CVI13 symbolic route",E.analyze("PRG-CVICE-002 symbolic story scene")["profile"]=="PRG_PRESET_SYMBOLIC_STORY_SCENE")
roles=E.classify_reference_roles("face hair pose lighting camera environment composition reference")
ok("CVI14 role classification",set(("FACE_REFERENCE","HAIR_REFERENCE","POSE_REFERENCE","LIGHTING_REFERENCE","CAMERA_REFERENCE","ENVIRONMENT_REFERENCE","COMPOSITION_REFERENCE")).issubset(set(roles)))
graph=E.validate_reference_graph([
 {"id":"A","authority":"P0","roles":["FACE_REFERENCE"],"binding":"PERSON_1"},
 {"id":"B","authority":"P1","roles":["CLOTHING_REFERENCE"],"binding":"PERSON_1"},
])
ok("CVI15 graph pass",graph["status"]=="PASS")
under=E.validate_reference_graph([{"id":"A","authority":"P2","roles":[]}])
ok("CVI16 underuse",under["status"]=="REFERENCE_UNDERUSE")
conf=E.validate_reference_graph([
 {"id":"A","authority":"P0","roles":["FACE_REFERENCE"],"binding":"PERSON_1"},
 {"id":"B","authority":"P0","roles":["FACE_REFERENCE"],"binding":"PERSON_1"},
])
ok("CVI17 conflict hold",conf["status"]=="REFERENCE_CONFLICT_HOLD")
ok("CVI18 identity root",r["identity_root_chain"]==["ORIGINAL_REFERENCE","APPROVED_TRANSFORMATION","APPROVED_CHARACTER_STATE","CURRENT_SCENE"])
ok("CVI19 multi identity hard",r["multi_person_identity_isolation"]=="HARD")
ok("CVI20 contact anatomy",r["limb_ownership"]=="REQUIRED" and r["contact_anatomy"]=="REQUIRED")
ev=E.analyze("visual evolution sequence with reference stages and identity")
ok("CVI21 evolution not upgrade",ev["evolution_not_upgrade"] and ev["robotization_drift_guard"]=="ACTIVE")
ok("CVI22 world native",r["world_native_fusion"]=="ACTIVE" and r["collage_detector"]=="ACTIVE")
ok("CVI23 minimal repair",r["minimal_invasive_repair"]=="ACTIVE")
ok("CVI24 quality targets",r["quality_targets_percent"]["IDENTITY_FIDELITY"]>=95 and r["quality_targets_percent"]["MULTI_CHARACTER_IDENTITY_ISOLATION"]>=98)
ok("CVI25 repair directive face",E.repair_directive("FACE_BODY_INTEGRATION_FAILURE").startswith("Keep the recognizable face"))
ok("CVI26 robot repair","natural surface" in E.repair_directive("ROBOTIZATION_DRIFT"))
ok("CVI27 unrelated off",not E.analyze("photorealistic mountain at noon")["active"])
cp=C.compile_prompt("PRG-CVICE-002 multi-reference identity continuity world-native fusion")
ok("CVI28 compiler report",cp["cvice_report"]["active"])
ok("CVI29 compiler block","[CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY]" in cp["compiled_prompt"])
ok("CVI30 module selected","CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY" in cp["selected_modules"])
ok("CVI31 compiler umip forbidden",cp["cvice_report"]["umip_mutation"]=="FORBIDDEN")
ok("CVI32 manifest integration",M["cvice_engine_id"]=="PRG-CVICE-002" and M["cvice_version"]=="2.0.0" and M["cvice_umip_mutation"]=="FORBIDDEN")
failed=[n for n,v in checks if not v]
for n,v in checks: print(("PASS" if v else "FAIL"),n)
print(f"CVICE INTEGRATION TESTS = {len(checks)-len(failed)}/{len(checks)} PASS")
if failed: sys.exit(1)
