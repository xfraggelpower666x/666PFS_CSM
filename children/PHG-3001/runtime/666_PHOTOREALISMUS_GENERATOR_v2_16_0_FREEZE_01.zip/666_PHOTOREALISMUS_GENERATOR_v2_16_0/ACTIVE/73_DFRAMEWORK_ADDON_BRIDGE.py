#!/usr/bin/env python3
"""Additive causal adapter bridge for DFramework addons integrated in PHG v2.13.0."""
from __future__ import annotations
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
REGISTRY=json.loads((ROOT/'72_DFRAMEWORK_ADDON_REGISTRY.json').read_text(encoding='utf-8'))

def _n(v): return re.sub(r"\s+"," ",(v or '').casefold()).strip()
def _any(t, terms): return any(x in t for x in terms)

def analyze(intent:str, *, source_traits:list[str]|None=None)->dict:
    t=_n(intent+' '+' '.join(source_traits or []))
    lyvra=_any(t,('lyvra frame','lyvra rahmen','ornate lyvra','dual world','dual-world','deutsche lyvra','american lyvra','amerikanische lyvra','purple gold frame','violet gold frame'))
    ccre=_any(t,('cyber creature','cyberwesen','creature duo','duo creatures','hybrid creature','hybridwesen','rider mount','reitend','mount relationship','detail transfer','shared tech dna'))
    evm=_any(t,('deeper visual meaning','deep visual meaning','visuelle bedeutung','tiefere visuelle bedeutung','emotional visual meaning','relationship meaning','symbolic emotional','emotion visually','emotionale bedeutung'))
    lyvra_mode=None
    if lyvra:
        if _any(t,('dual world','dual-world','deutsche lyvra','american lyvra','amerikanische lyvra')): lyvra_mode='LYVRA_DUAL_WORLD_COMPARE'
        elif _any(t,('minimal','minimal frame','minimaler rahmen')): lyvra_mode='LYVRA_MINIMAL_FRAME'
        else: lyvra_mode='LYVRA_ORNATE_FRAME'
    ccre_mode=None
    if ccre:
        if _any(t,('rider','reitend','mount')): ccre_mode='CCRE_04_RIDER'
        elif _any(t,('hybrid','verschmelz','fusion')): ccre_mode='CCRE_03_HYBRID'
        elif _any(t,('duo','together','zusammen')): ccre_mode='CCRE_02_DUO'
        elif _any(t,('shared tech','tech dna','technologie dna')): ccre_mode='CCRE_05_TECH_DNA'
        else: ccre_mode='CCRE_01_DETAIL_TRANSFER'
    active=lyvra or ccre or evm
    return {
      'active':active,'bridge_version':'1.0.0','host_version':'2.13.0',
      'lyvra_frame':{'active':lyvra,'mode':lyvra_mode,'source_preservation':'MAXIMUM','outward_canvas_expansion':True if lyvra else None,'external_lyvra_mutation':False},
      'creature_relationship':{'active':ccre,'mode':ccre_mode,'identity_collapse':'FORBIDDEN','anti_collage':True if ccre else None,'anatomy_guard':True if ccre else None},
      'emotional_visual_meaning':{'active':evm,'mapping_contract':'SOURCE_MEANING->VISUAL_DEVICE->INTENDED_READING' if evm else None,'symbol_density':'1_DOMINANT_PLUS_1_TO_3_SUPPORTING' if evm else None,'invent_biography':'FORBIDDEN'},
      'dedupe':{'cnsc':'PRESERVED_EXISTING','reference_continuity':'MAP_TO_CVICE','photorealism':'MAP_TO_CORE','composition':'MAP_TO_EXISTING_ENGINE'},
      'repair_policy':'TARGET_AFFECTED_LAYER_ONLY_THEN_REAUDIT'
    }

def compact_directive(report:dict)->str:
    if not report.get('active'): return ''
    parts=[]
    lf=report['lyvra_frame']; cr=report['creature_relationship']; ev=report['emotional_visual_meaning']
    if lf['active']: parts.append(f"LYVRA_FRAME={lf['mode']}; preserve source identity; extend canvas outward before inward overlap; violet dominant, gold structural accent; no external LYVRA mutation")
    if cr['active']: parts.append(f"CCRE={cr['mode']}; causal relationship geometry, coherent anatomy/contact/weight/scale, shared technology without identity collapse, no collage/morph artifacts")
    if ev['active']: parts.append("EVM=CAUSAL_VISUAL_MEANING; every symbolic device must have a source meaning and intended reading; prefer physically plausible light/material/pose/space carriers; no invented biography")
    return ' | '.join(parts)
