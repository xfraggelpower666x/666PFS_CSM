#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('b',R/'73_DFRAMEWORK_ADDON_BRIDGE.py'); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
tests=[]
def ck(n,c): tests.append((n,bool(c)))
r=m.analyze('Put both cyber creatures together as a duo with deeper visual meaning')
ck('ADD01 active',r['active']); ck('ADD02 ccre duo',r['creature_relationship']['mode']=='CCRE_02_DUO'); ck('ADD03 evm',r['emotional_visual_meaning']['active'])
r=m.analyze('create an ornate LYVRA frame around the source image')
ck('ADD04 lyvra',r['lyvra_frame']['active']); ck('ADD05 preserve',r['lyvra_frame']['source_preservation']=='MAXIMUM'); ck('ADD06 no lyvra mutation',r['lyvra_frame']['external_lyvra_mutation'] is False)
r=m.analyze('ordinary photorealistic portrait')
ck('ADD07 unrelated off',not r['active']); ck('ADD08 cnsc dedupe',r['dedupe']['cnsc']=='PRESERVED_EXISTING')
reg=json.loads((R/'72_DFRAMEWORK_ADDON_REGISTRY.json').read_text())
ck('ADD09 four addon records',len(reg['addons'])==4); ck('ADD10 additive',reg['integration_mode']=='ADD_ONLY_ADAPTER')
for n,p in tests: print(('PASS' if p else 'FAIL'),n)
if not all(p for _,p in tests): raise SystemExit(1)
print(f'DFRAMEWORK ADDON TESTS = PASS ({len(tests)}/{len(tests)})')
