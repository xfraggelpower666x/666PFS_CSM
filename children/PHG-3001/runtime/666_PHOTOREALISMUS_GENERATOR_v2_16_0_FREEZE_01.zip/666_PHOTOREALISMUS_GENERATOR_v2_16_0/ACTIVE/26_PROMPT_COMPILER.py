#!/usr/bin/env python3
"""Deterministic modular prompt compiler for 666 PRG v2.13.0."""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
REGISTRY = json.loads((ROOT / "09_PROMPT_MODULE_REGISTRY.json").read_text(encoding="utf-8"))

import importlib.util

def _load_director():
    spec=importlib.util.spec_from_file_location("prg_director", ROOT / "33_CHARACTER_TRANSFORMATION_DIRECTOR.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
DIRECTOR=_load_director()

def _load_phlf_extension():
    spec=importlib.util.spec_from_file_location("phlf_extension", ROOT / "36_PHLF_CYBER_EXTENSION.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
PHLF_EXTENSION=_load_phlf_extension()

def _load_frame_modes():
    spec=importlib.util.spec_from_file_location("frame_modes", ROOT / "38_FRAME_MODES.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
FRAME_MODES=_load_frame_modes()

def _load_aspect_ratio_engine():
    spec=importlib.util.spec_from_file_location("aspect_ratio_engine", ROOT / "40_ASPECT_RATIO_ENGINE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
ASPECT_RATIO_ENGINE=_load_aspect_ratio_engine()

def _load_preset_expansion_engine():
    spec=importlib.util.spec_from_file_location("preset_expansion_engine", ROOT / "43_PRESET_EXPANSION_ENGINE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
PRESET_EXPANSION_ENGINE=_load_preset_expansion_engine()

def _load_cyber_garden_engine():
    spec=importlib.util.spec_from_file_location("cyber_garden_engine", ROOT / "47_CYBER_GARDEN_ENGINE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CYBER_GARDEN_ENGINE=_load_cyber_garden_engine()

def _load_cyber_duality_engine():
    spec=importlib.util.spec_from_file_location("cyber_duality_engine", ROOT / "50_CYBER_DUALITY_ENGINE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CYBER_DUALITY_ENGINE=_load_cyber_duality_engine()

def _load_realism_control_addon():
    spec=importlib.util.spec_from_file_location("realism_control_addon", ROOT / "53_REALISM_CONTROL_ADDON.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
REALISM_CONTROL_ADDON=_load_realism_control_addon()

def _load_cyber_love_holo_dance():
    spec=importlib.util.spec_from_file_location("cyber_love_holo_dance", ROOT / "56_CYBER_LOVE_HOLO_DANCE_PRESET.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CYBER_LOVE_HOLO_DANCE=_load_cyber_love_holo_dance()

def _load_cyber_morning_ihc():
    spec=importlib.util.spec_from_file_location("cyber_morning_ihc", ROOT / "57_CYBER_MORNING_IHC_ADDON.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CYBER_MORNING_IHC=_load_cyber_morning_ihc()

def _load_cyber_love_frame_addon():
    spec=importlib.util.spec_from_file_location("cyber_love_frame_addon", ROOT / "60_CYBER_LOVE_FRAME_ADDON.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CYBER_LOVE_FRAME_ADDON=_load_cyber_love_frame_addon()

def _load_cyber_love_preset_family():
    spec=importlib.util.spec_from_file_location("cyber_love_preset_family", ROOT / "63_CYBER_LOVE_PRESET_FAMILY.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CYBER_LOVE_PRESET_FAMILY=_load_cyber_love_preset_family()


def _load_cvice_engine():
    spec=importlib.util.spec_from_file_location("cvice_engine", ROOT / "66_CVICE_ENGINE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CVICE_ENGINE=_load_cvice_engine()

def _load_cnsc_engine():
    spec=importlib.util.spec_from_file_location("cnsc_engine", ROOT / "69_CYBER_NEON_SYMBOLIC_COMPOSITION_ADDON.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
CNSC_ENGINE=_load_cnsc_engine()

def _load_dframework_addon_bridge():
    spec=importlib.util.spec_from_file_location("dframework_addon_bridge", ROOT / "73_DFRAMEWORK_ADDON_BRIDGE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
DFRAMEWORK_ADDON_BRIDGE=_load_dframework_addon_bridge()

def _load_ensc_engine():
    spec=importlib.util.spec_from_file_location("ensc_engine", ROOT / "84_ENVIRONMENTAL_NARRATIVE_COHERENCE.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
ENSC_ENGINE=_load_ensc_engine()

def _load_dsr_engine():
    spec=importlib.util.spec_from_file_location("dsr_engine", ROOT / "86_DYNAMIC_SIDE_REMAPPING.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
DSR_ENGINE=_load_dsr_engine()

MODULE_TEXT = {
    "CORE_PHOTOREALISM": "Create convincing high-end photographic realism with natural skin, hair, anatomy, materials, lighting, depth and reflections; avoid plastic CGI or illustration artifacts.",
    "CGI_TO_PHOTOREAL_RECONSTRUCTION": "Fully reconstruct the stylized 3D/CGI source as a believable real photograph while retaining recognizable people, person count, approximate pose, composition and defining marks.",
    "IDENTITY_PRESERVATION": "Preserve the recognizable identity, facial structure, age range, ethnicity, hairstyle, body proportions and defining features of every referenced person; do not substitute or merge identities.",
        "ANATOMY_PRECISION": "Keep anatomy, hands, contact points and perspective believable.",
    "FRAMELESS_STAGE1": "Do not add an outer decorative frame unless requested.",
    "NO_UNAUTHORIZED_TEXT": "Do not invent visible text or watermarks.",
    "COUPLE_INTERACTION": "For two-person interaction, preserve both identities and render physically believable embrace, gaze, weight distribution, hand placement, fabric compression and natural emotional proximity.",
    "CYBER_NEON_ENVIRONMENT": "Build a coherent cyber-neon environment with controlled neon blue, cyan, violet, magenta and neon-pink accents, realistic emissive spill, atmospheric depth and grounded reflections.",
    "REFLECTION_CONTROL": "Reflections and refractions must obey scene geometry, camera position, surface roughness and occlusion; no duplicate people or impossible mirror anatomy.",
    "MATERIAL_REALISM": "Render skin, fabric, glass, metal, hair and environmental surfaces with distinct physically plausible roughness, translucency, microstructure and wear.",
    "GAME_TO_REAL_PERSON": "Translate stylized or game-like source characters into believable real people while preserving identity cues, wardrobe logic, silhouette and character-specific features.",
    "OUTFIT_TRANSFORMATION": "If the request changes clothing or styling, generate the requested wardrobe faithfully while preserving identity, age-appropriate presentation, body proportions, natural fabric behavior, seams, layering and accessory logic.",
    "POSE_DIRECTION": "If a pose or body action is requested, follow it precisely with believable balance, limb placement, muscle tension, gaze direction and scene contact; preserve natural posture and avoid broken or mirrored anatomy.",
    "CAMERA_REFRAMING": "If the request changes framing or camera distance, obey the requested zoom in, zoom out, close-up, medium shot, full-body, wide shot or camera angle while preserving identity, perspective coherence and scene continuity.",
    "EFFECT_STYLING": "If the request adds atmospheric or optical effects, apply only the requested effects such as rain, fog, smoke, glow, motion blur, lens flare, particles or depth-of-field accents in a controlled photorealistic way without obscuring the subject.",
    "ADULT_SWIMWEAR_TATTOO_VISIBILITY": "For unmistakably adult subjects, non-explicit visible skin, swimwear, male bare torso and tattoo visibility are normal human presentation, including in photorealism. Upper and lower body follow the same rule: intimate areas must stay covered by opaque swimwear, underwear, shorts, bikini, bodysuit or comparable clothing.",
    "ROMANTIC_AFFECTION_NORMALIZATION": "Kissing, embrace and romantic closeness are affection by default, not automatic sexual activity. Preserve them as non-explicit emotional human contact unless the user explicitly requests sexual content, which must remain blocked.",
    "PHLF_CYBER_LIFESTYLE_EXTENSION": "Apply the PHLF-CYBER lifestyle layer for realistic cyber outfits, hair, fingernails, makeup, accessories, cyber-love symbols and coherent neon environments. Adult means age clarity only; keep the scene non-explicit and change only requested elements.",
    "FRAME_MODES_FAMILY": "Activate the semantic frame family only when frame intent is present; use the selected frame mode as an additive outer layer, preserve the central image, honor explicit user style first, and infer only missing frame parameters.",
    "ASPECT_RATIO_AND_BROADCAST_PRESET": "Honor explicit aspect ratios before inferred defaults. For the LYVRA cyber-holo broadcast preset, use the exact requested branding, the holographic cyber frame and the configured variant count without mutating any external LYVRA system.",
    "PHOTOREALISTIC_PRESET_EXPANSION": "Apply the registered reference-preservation, photorealism quality, safe-frame, strict typography, semantic asset and failure-diagnosis rules only when relevant; preserve existing identities, pose, outfit, scene and camera unless explicitly overridden.",
    "TEXT_MODE_ROUTER": "Classify requested text into FRAME_TEXT, NARRATIVE_MESSAGE or HYBRID_FRAME_NARRATIVE and preserve the exact wording.",
    "NARRATIVE_TYPOGRAPHY_ENGINE": "Use narrative typography with clear title/message/emphasis/signature zones, readability checks and strict no-occlusion rules.",
    "SEMANTIC_SCENE_BINDING_ENGINE": "Allow emotional meaning to shape mood, lighting and decorative accents while never overriding exact text or locked identity attributes.",
    "CONTENT_AWARE_COMPOSITION_ENGINE": "Allocate message zones from real negative space, preserve faces and keep the layout minimally invasive relative to the reference.",
    "CYBER_LOVE_ADDON_ENGINE": "Enable the cyber-holo love/birthday layer with embraced holographic heart, controlled barbed-wire frame, exact corner-hearts and strict decoration budget when explicitly requested.",
    "ADAPTIVE_CYBER_GARDEN": "Activate the Adaptive Cyber Garden only for garden-related intent; preserve protected identities and continuity, evolve ideas/relationships/creatures causally, and allow durable learning only after explicit approval or canonical status.",
    "CYBER_DUALITY_CHARACTER_COUPLE": "For cyber angel/devil duality, preserve photographic human identity and face/body naturalism first; default to one coherent being unless multiple people are explicitly requested, and keep couple identities strictly separate.",
    "CYBER_LOVE_HOLO_DANCE_PRESET": "Activate the PRESET_09 photorealistic cyber-love dance family and route the requested partner-dance pose without identity drift.",
    "CYBER_MORNING_IHC_ADDON": "Activate the additive cyber-morning physical-scene composition with exact GOOD MORNING text, coffee, infinity energy and cyber heart while forbidding collage behavior.",
    "CYBER_LOVE_FRAME_ADDON": "Activate the additive physical Cyber Love Frame System only for explicit/semantic cyber-love frame intent; preserve source identity/composition, enforce exact integrated frame text and share photorealistic lighting with the source scene.",
    "CYBER_LOVE_ILY_ENDLESS_PRESET_FAMILY": "Activate the I LOVE YOU / ENDLESS Cyber Love preset family with exact text, parent-frame dependency, source preservation and photo-derived composition routing when requested.",
    "CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY": "Use one causal reference graph for multi-reference role/authority binding, identity continuity, photorealistic world coherence, evolution, world-native fusion, key-art/cover compression, symbolic causality and minimal-invasive repair; do not duplicate visual authority or mutate UMIP.",
    "CYBER_NEON_SYMBOLIC_COMPOSITION": "Preserve source-symbol topology and characteristic asymmetry; create continuous material-aware neon color fusion, spatially coherent interwoven geometry, physically sourced laser/electric energy and secondary HUD composition without replacing existing identity/photorealism authority.",

}

TRIGGER_MAP = {
    "human": ("person", "people", "human", "man", "woman", "male", "female", "face", "portrait", "couple", "he", "she", "ihn", "sie", "mann", "frau"),
    "character": ("character", "avatar", "figur", "person"),
    "face": ("face", "facial", "portrait", "gesicht"),
    "hands": ("hand", "hands", "finger", "hände", "hand"),
    "full_body": ("full body", "standing", "lying", "body", "körper", "liegend", "stehend"),
    "couple": ("couple", "two people", "embrace", "hug", "kiss", "paar", "umarm", "kuss", "brust", "couch"),
    "two_people": ("couple", "two people", "both", "paar", "beide"),
    "embrace": ("embrace", "hug", "arms around", "umarm*"),
    "intimate_scene": ("intimate", "close", "couch", "heart", "chest", "kiss", "intim", "herzschlag", "brust"),
    "cyberpunk": ("cyberpunk", "cyber"),
    "neon": ("neon",),
    "futuristic": ("futuristic", "future", "sci-fi", "zukunft"),
    "mirror": ("mirror", "spiegel"),
    "window": ("window", "fenster"),
    "glass": ("glass", "glas"),
    "water": ("water", "wasser"),
    "metal": ("metal", "metall"),
    "fabric": ("fabric", "clothing", "cloth", "stoff", "kleidung"),
    "skin": ("skin", "haut"),
    "game_character": ("game character", "videogame", "game avatar", "spielcharakter"),
    "3d_character": ("3d character", "3d avatar", "render character"),
    "avatar": ("avatar",),
    "outfit": ("outfit", "wardrobe", "clothes", "clothing", "dress", "jacket", "coat", "hoodie", "shirt", "pants", "trousers", "skirt", "armor", "uniform", "costume", "wearing", "kleidung", "jacke", "mantel", "anzug", "rüstung", "uniform", "kostüm"),
    "wardrobe": ("outfit", "wardrobe", "clothes", "clothing", "kleidung", "kostüm"),
    "pose": ("pose", "posing", "stance", "posture", "leaning", "arms crossed", "hands on hips", "looking back", "walking", "running", "jumping", "sitting", "kneeling", "lying", "haltung", "sitzend", "stehend", "kniend", "liegend"),
    "stance": ("stance", "pose", "posture", "haltung"),
    "sitting": ("sitting", "seated", "sit", "sitzend"),
    "standing": ("standing", "stand", "stehend"),
    "kneeling": ("kneeling", "kneel", "kniend"),
    "action_pose": ("action pose", "dynamic pose", "running", "jumping", "fighting", "sprung", "dynamische pose"),
    "zoom_in": ("zoom in", "close-up", "close up", "tight crop", "headshot", "nahaufnahme", "detailaufnahme", "portrait crop"),
    "zoom_out": ("zoom out", "wide shot", "wider shot", "pull back", "totale", "weitwinkel", "weiter weg"),
    "close_up": ("close-up", "close up", "headshot", "tight crop", "nahaufnahme"),
    "wide_shot": ("wide shot", "full scene", "environment shot", "totale", "establishing shot"),
    "camera_angle": ("camera angle", "low angle", "high angle", "overhead", "from above", "from below", "frontal", "side view", "profil", "kamerawinkel"),
    "effect": ("effect", "effects", "fx", "special effect", "effekt", "effekte"),
    "fx": ("fx", "vfx", "effects"),
    "rain": ("rain", "rainy", "regen"),
    "fog": ("fog", "mist", "haze", "nebel"),
    "smoke": ("smoke", "smoky", "rauch"),
    "motion_blur": ("motion blur", "bewegungsunschärfe"),
    "glow": ("glow", "glowing", "bloom", "light spill", "schein", "leuchten"),
    "cgi": ("cgi", "computer generated", "computer-generated"),
    "3d": ("3d", "3-d"),
    "game_render": ("game render", "game-render", "videogame render"),
    "stylized_render": ("stylized render", "stilisierter render", "game art"),
    "frame_risk": ("frame", "rahmen", "border"),
    "text_risk": ("text", "logo", "caption", "schrift", "name"),
    "adult_visibility": ("adult", "erwachsen", "volljährig", "mature adult", "clearly adult"),
    "swimwear": ("swimwear", "bikini", "swimsuit", "badeanzug", "badehose", "pool", "beach", "strand", "schwimmbad", "summer", "sommer"),
    "bikini": ("bikini",),
    "swim_trunks": ("swim trunks", "badehose", "shorts"),
    "male_bare_torso": ("male bare torso", "bare torso", "shirtless", "männlicher nackter oberkörper", "oberkörper frei"),
    "tattoo_visibility": ("tattoo", "tattoos", "tätowierung", "tätowierungen", "body art"),
    "upper_body_skin": ("upper body", "oberkörper", "nackte haut", "bare skin"),
    "lower_body_skin": ("lower body", "unterkörper", "legs", "beine", "bare legs"),
    "pool": ("pool", "swimming pool", "schwimmbad"),
    "beach": ("beach", "strand"),
    "summer": ("summer", "sommer"),
    "kiss_affection": ("kiss", "kissing", "kuss", "küssen"),
    "embrace_affection": ("embrace", "hug", "umarmung", "umarmen"),
    "romantic_couple": ("romantic", "romantisch", "zuneigung", "affection"),
    "phlf_hair": ("hair", "hairstyle", "frisur", "haare", "undercut", "braid"),
    "phlf_nails": ("nails", "fingernails", "fingernägel", "manicure", "chrome nails", "nageldesign"),
    "phlf_makeup": ("makeup", "make-up", "eyeliner", "lipstick", "lippenstift"),
    "phlf_accessories": ("accessories", "accessoire", "accessoires", "visor", "choker", "ear cuffs"),
    "phlf_cyber_outfit": ("techwear", "cyber outfit", "cyber fashion", "clubwear", "cyber swimwear", "cyber bikini"),
    "phlf_cyber_love": ("cyber love", "neon heart", "neon-glass heart", "neon glasherz", "barbed-wire heart", "stacheldraht-herz", "love you over all"),
    "phlf_music_fx": ("music notes", "musiknoten", "waveform light", "rhythm pulse"),
    "frame_intent": ("frame", "framed", "border", "rahmen", "eingerahmt", "umrandung", "bildrand", "neonrahmen", "hologrammrahmen", "cyberrahmen", "herzrahmen", "stacheldrahtrahmen"),
    "aspect_ratio_intent": ("aspect ratio", "seitenverhältnis", "seitenverhaeltnis", "16:9", "9:16", "4:3", "3:4", "1:1", "widescreen", "horizontal banner", "vertical banner"),
    "broadcast_preset_intent": ("webradio", "web radio", "broadcaster", "broadcast", "discord banner", "youtube banner"),
    "preset_expansion_intent": ("love frame neon pink", "love frame electric blue", "old omen rose stars", "stars blue tang fate", "deep dark crazy neon", "gods scribed my fate in stars", "a love older than the stars still calls my name", "fate answers in your voice"),
    "semantic_asset_intent": ("blue fish", "blue tang", "paletten-doktorfisch"),
    "strict_typography_intent": ("exact text", "strict text", "uppercase", "exakter text", "genau dieser text", "veluna", "fraggel"),
    "reference_preservation_intent": ("reference image", "reference photo", "referenzbild", "referenzfoto", "same image", "same pose", "vorlage"),
    "cyber_garden_intent": ("cyber garden", "cyber-garden", "cyber garten", "cybergarten", "idea egg", "idea-egg", "cyber egg", "ideen-ei", "knowledge tree", "wissensbaum", "memory forest", "idea nursery", "relationship garden", "sonic garden", "dream lab", "creature sanctuary", "dark garden", "bloom district", "future self projection", "living visual knowledge ecosystem"),
    "cyber_duality_intent": ("cyber angel and devil", "angel demon hybrid", "angelic and demonic", "heaven and hell", "light and darkness", "holy and infernal", "duality character", "angel and devil", "engel und teufel", "engel dämon hybrid", "engel demon hybrid", "himmel und hölle", "licht und dunkelheit"),
    "cyber_love_holo_dance_intent": ("cyber love holo dance", "preset_09", "holo dance", "tanzpose"),
    "cyber_morning_ihc_intent": ("cyber morning", "good morning", "cyber coffee", "coffee heart infinity", "holographic coffee steam"),
    "cyber_love_frame_addon_intent": ("cyber love frame system", "cyber love frame", "cyber love border", "prg-addon-cyber-love-frame-001"),
    "ily_endless_preset_intent": ("prg-preset-ily-endless-001", "i love you endless preset", "ily endless", "prg-preset-ily-endless-neon-embrace-001", "neon embrace display"),
    "cvice_intent": ("prg-cvice-002", "causal visual intelligence", "visual intelligence continuity engine", "multi-reference identity continuity", "world-native fusion", "causal key art"),
    "cnsc_intent": ("prg-cnsc-addon-001", "cyber neon symbolic composition", "symbol reconstruction", "continuous color fusion", "interwoven geometry", "relational neon heart")
}


def digest_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _normalized(value: str) -> str:
    return re.sub(r"\s+", " ", value.casefold()).strip()


def _phrase_matches(token: str, haystack: str) -> bool:
    """Match complete words/phrases; a trailing * enables an explicit word-prefix stem."""
    normalized = _normalized(str(token))
    if not normalized:
        return False
    stem = normalized.endswith("*")
    if stem:
        normalized = normalized[:-1].strip()
    escaped = re.escape(normalized).replace(r"\ ", r"\s+")
    suffix = r"\w*" if stem else r"(?!\w)"
    return bool(re.search(r"(?<!\w)" + escaped + suffix, haystack, flags=re.IGNORECASE))


def _trigger_matches(trigger: str, haystack: str, source_traits: set[str]) -> bool:
    if trigger == "always":
        return True
    if trigger in source_traits:
        return True
    return any(_phrase_matches(token, haystack) for token in TRIGGER_MAP.get(trigger, (trigger,)))


def compile_prompt(
    intent: str,
    *,
    source_traits: list[str] | None = None,
    frame_stage: str = "OFF",
    repair_directives: list[str] | None = None,
    cyber_garden_state: dict | None = None,
    cyber_garden_approval: dict | None = None,
) -> dict:
    original_intent = (intent or "").strip()
    if not original_intent:
        raise ValueError("PROMPT_INTENT_EMPTY")
    traits = {str(x).casefold() for x in (source_traits or [])}
    haystack = _normalized(original_intent + " " + " ".join(traits))
    mandatory = list(REGISTRY.get("mandatory_modules", []))
    selected: list[str] = []
    for module in REGISTRY.get("modules", []):
        mid = module["id"]
        if mid in mandatory or any(_trigger_matches(t, haystack, traits) for t in module.get("triggers", [])):
            if mid not in selected:
                selected.append(mid)
    missing = [mid for mid in mandatory if mid not in selected]
    if missing:
        raise ValueError("MANDATORY_PROMPT_MODULE_MISSING:" + ",".join(missing))
    director_plan = DIRECTOR.build_plan(original_intent, source_traits=list(source_traits or []))
    phlf_report = PHLF_EXTENSION.analyze(original_intent)
    frame_modes_report = FRAME_MODES.analyze(original_intent, scene_traits=list(source_traits or []))
    if frame_modes_report.get("active") and "FRAME_MODES_FAMILY" not in selected:
        selected.append("FRAME_MODES_FAMILY")
    aspect_ratio_report = ASPECT_RATIO_ENGINE.analyze(original_intent)
    if aspect_ratio_report.get("active") and "ASPECT_RATIO_AND_BROADCAST_PRESET" not in selected:
        selected.append("ASPECT_RATIO_AND_BROADCAST_PRESET")
    preset_expansion_report = PRESET_EXPANSION_ENGINE.analyze(original_intent, source_traits=list(source_traits or []))
    if preset_expansion_report.get("active") and "PHOTOREALISTIC_PRESET_EXPANSION" not in selected:
        selected.append("PHOTOREALISTIC_PRESET_EXPANSION")
    cyber_garden_report = CYBER_GARDEN_ENGINE.analyze(original_intent, source_traits=list(source_traits or []), world_state=cyber_garden_state, approval=cyber_garden_approval)
    if cyber_garden_report.get("active") and "ADAPTIVE_CYBER_GARDEN" not in selected:
        selected.append("ADAPTIVE_CYBER_GARDEN")
    cyber_duality_report = CYBER_DUALITY_ENGINE.analyze(original_intent, source_traits=list(source_traits or []))
    if cyber_duality_report.get("active") and "CYBER_DUALITY_CHARACTER_COUPLE" not in selected:
        selected.append("CYBER_DUALITY_CHARACTER_COUPLE")
    realism_control_report = REALISM_CONTROL_ADDON.analyze(original_intent, source_traits=list(source_traits or []))
    cyber_love_holo_dance_report = CYBER_LOVE_HOLO_DANCE.analyze(original_intent, preset_active=(preset_expansion_report.get("preset_id") == "PRESET_09"))
    cyber_morning_ihc_report = CYBER_MORNING_IHC.analyze(original_intent, source_traits=list(source_traits or []))
    cyber_love_preset_report = CYBER_LOVE_PRESET_FAMILY.analyze(original_intent, preset_id=preset_expansion_report.get("preset_id"))
    cvice_report = CVICE_ENGINE.analyze(original_intent, source_traits=list(source_traits or []))
    if cvice_report.get("active") and "CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY" not in selected:
        selected.append("CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY")
    cnsc_report = CNSC_ENGINE.analyze(original_intent, source_traits=list(source_traits or []))
    dframework_addon_report = DFRAMEWORK_ADDON_BRIDGE.analyze(original_intent, source_traits=list(source_traits or []))
    ensc_report = ENSC_ENGINE.analyze(original_intent, source_traits=list(source_traits or []))
    dsr_report = DSR_ENGINE.analyze(original_intent, source_traits=list(source_traits or []))
    if cnsc_report.get("active") and "CYBER_NEON_SYMBOLIC_COMPOSITION" not in selected:
        selected.append("CYBER_NEON_SYMBOLIC_COMPOSITION")
    clf_intent = original_intent
    if cyber_love_preset_report.get("active"):
        clf_intent += " cyber love frame system"
        if "CYBER_LOVE_ILY_ENDLESS_PRESET_FAMILY" not in selected:
            selected.append("CYBER_LOVE_ILY_ENDLESS_PRESET_FAMILY")
    cyber_love_frame_report = CYBER_LOVE_FRAME_ADDON.analyze(clf_intent, source_traits=list(source_traits or []))
    if cyber_love_frame_report.get("active") and "CYBER_LOVE_FRAME_ADDON" not in selected:
        selected.append("CYBER_LOVE_FRAME_ADDON")
    blocks = [original_intent, DIRECTOR.compact_contract(director_plan)]
    max_blocks = int(director_plan.get("prompt_max_blocks", 4))
    preferred = []
    if director_plan.get("profile") == "CGI_TO_PHOTOREAL_RECONSTRUCTION":
        preferred = ["CORE_PHOTOREALISM", "CGI_TO_PHOTOREAL_RECONSTRUCTION"]
        if "ANATOMY_PRECISION" in selected: preferred.append("ANATOMY_PRECISION")
    else:
        preferred = [mid for mid in selected if mid not in {"FRAMELESS_STAGE1", "NO_UNAUTHORIZED_TEXT"}]
        if "PHLF_CYBER_LIFESTYLE_EXTENSION" in preferred:
            preferred.remove("PHLF_CYBER_LIFESTYLE_EXTENSION")
            preferred.insert(0, "PHLF_CYBER_LIFESTYLE_EXTENSION")
        for mid in ("FRAMELESS_STAGE1", "NO_UNAUTHORIZED_TEXT"):
            if mid in selected: preferred.append(mid)
    selected = list(dict.fromkeys(preferred))
    for mid in selected:
        if len(blocks) >= max_blocks: break
        text = MODULE_TEXT.get(mid)
        if not text: raise ValueError(f"PROMPT_MODULE_IMPLEMENTATION_MISSING:{mid}")
        blocks.append(f"[{mid}] {text}")
    if frame_stage == "ON":
        blocks.append("[FRAME_STAGE_2] Apply the explicitly requested frame only to the already validated Stage-1 output; do not alter the protected image content inside the frame.")
    if frame_modes_report.get("active"):
        blocks.append("[FRAME_MODES] " + FRAME_MODES.compact_directive(frame_modes_report))
    if aspect_ratio_report.get("active"):
        label = "BROADCAST_PRESET" if aspect_ratio_report.get("preset_id") else "ASPECT_RATIO"
        blocks.append(f"[{label}] " + ASPECT_RATIO_ENGINE.compact_directive(aspect_ratio_report))
    if preset_expansion_report.get("active"):
        blocks.append("[PRESET_EXPANSION] " + PRESET_EXPANSION_ENGINE.compact_directive(preset_expansion_report))
    if cyber_garden_report.get("active"):
        blocks.append("[CYBER_GARDEN] " + CYBER_GARDEN_ENGINE.compact_directive(cyber_garden_report))
    if cyber_duality_report.get("active"):
        blocks.append("[CYBER_DUALITY] " + CYBER_DUALITY_ENGINE.compact_directive(cyber_duality_report))
    if realism_control_report.get("active"):
        rig_line = REALISM_CONTROL_ADDON.compact_directive(realism_control_report)
        if rig_line:
            blocks.append("[REALISM_CONTROL_ADDON] " + rig_line)
    if cyber_love_holo_dance_report.get("active"):
        blocks.append("[CYBER_LOVE_HOLO_DANCE] " + CYBER_LOVE_HOLO_DANCE.compact_directive(cyber_love_holo_dance_report))
    if cyber_morning_ihc_report.get("active"):
        blocks.append("[CYBER_MORNING_IHC] " + CYBER_MORNING_IHC.compact_directive(cyber_morning_ihc_report))
    if cyber_love_frame_report.get("active"):
        blocks.append("[CYBER_LOVE_FRAME_ADDON] " + CYBER_LOVE_FRAME_ADDON.compact_directive(cyber_love_frame_report))
    if cyber_love_preset_report.get("active"):
        blocks.append("[CYBER_LOVE_ILY_ENDLESS_PRESET] " + CYBER_LOVE_PRESET_FAMILY.compact_directive(cyber_love_preset_report))
    if cvice_report.get("active"):
        blocks.append("[CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY] " + CVICE_ENGINE.compact_directive(cvice_report))
    if cnsc_report.get("active"):
        blocks.append("[CYBER_NEON_SYMBOLIC_COMPOSITION] " + CNSC_ENGINE.compact_directive(cnsc_report))
    if dframework_addon_report.get("active"):
        blocks.append("[DFRAMEWORK_ADDONS] " + DFRAMEWORK_ADDON_BRIDGE.compact_directive(dframework_addon_report))
    if ensc_report.get("active"):
        blocks.append("[ENSC-004] " + ENSC_ENGINE.compact_directive(ensc_report))
    if dsr_report.get("active"):
        blocks.append("[DSR-005] " + DSR_ENGINE.compact_directive(dsr_report))
    for directive in repair_directives or []:
        d = str(directive).strip()
        if d:
            blocks.append(f"[TARGETED_REPAIR] {d}")
    compiled = "\n".join(blocks)
    manifest = {
        "compiler_version": "2.16.0",
        "original_intent": original_intent,
        "selected_modules": selected,
        "frame_stage": frame_stage,
        "repair_directives": [str(x) for x in (repair_directives or []) if str(x).strip()],
        "director_plan": director_plan,
        "phlf_cyber_report": phlf_report,
        "frame_modes_report": frame_modes_report,
        "aspect_ratio_report": aspect_ratio_report,
        "preset_expansion_report": preset_expansion_report,
        "cyber_garden_report": cyber_garden_report,
        "cyber_duality_report": cyber_duality_report,
        "realism_control_report": realism_control_report,
        "cyber_love_holo_dance_report": cyber_love_holo_dance_report,
        "cyber_morning_ihc_report": cyber_morning_ihc_report,
        "cyber_love_frame_report": cyber_love_frame_report,
        "cyber_love_preset_report": cyber_love_preset_report,
        "cvice_report": cvice_report,
        "cnsc_report": cnsc_report,
        "dframework_addon_report": dframework_addon_report,
        "ensc_report": ensc_report,
        "dsr_report": dsr_report,
        "governance_in_prompt": False,
    }
    manifest_hash = digest_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return {
        "compiled_prompt": compiled,
        "prompt_hash": digest_text(compiled),
        "prompt_manifest": manifest,
        "prompt_manifest_hash": manifest_hash,
        "selected_modules": selected,
        "director_plan": director_plan,
        "phlf_cyber_report": phlf_report,
        "frame_modes_report": frame_modes_report,
        "aspect_ratio_report": aspect_ratio_report,
        "preset_expansion_report": preset_expansion_report,
        "cyber_garden_report": cyber_garden_report,
        "cyber_duality_report": cyber_duality_report,
        "realism_control_report": realism_control_report,
        "cyber_love_holo_dance_report": cyber_love_holo_dance_report,
        "cyber_morning_ihc_report": cyber_morning_ihc_report,
        "cyber_love_frame_report": cyber_love_frame_report,
        "cyber_love_preset_report": cyber_love_preset_report,
        "cvice_report": cvice_report,
        "cnsc_report": cnsc_report,
        "dframework_addon_report": dframework_addon_report,
        "ensc_report": ensc_report,
        "dsr_report": dsr_report,
    }


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("intent")
    p.add_argument("--traits", default="")
    args = p.parse_args()
    print(json.dumps(compile_prompt(args.intent, source_traits=[x for x in args.traits.split(",") if x]), ensure_ascii=False, indent=2))
