#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, sys
R=Path(__file__).resolve().parent

def load(name,file):
    sp=importlib.util.spec_from_file_location(name,R/file); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m
E=load('cyber_garden','47_CYBER_GARDEN_ENGINE.py'); C=load('compiler','26_PROMPT_COMPILER.py')
fail=[]
def ck(name,cond,detail=''):
    print(('PASS' if cond else 'FAIL'),name,detail)
    if not cond: fail.append(name)
ck('CG01_INACTIVE_ORDINARY', not E.analyze('ordinary photorealistic portrait').get('active'))
r=E.analyze('Create a photorealistic Cyber Garden with an Idea Egg beside the Knowledge Tree')
ck('CG02_ACTIVE',r.get('active'))
ck('CG03_IDENTITY_MAX',r.get('identity_protection')=='MAX')
ck('CG04_NO_DURABLE_AUTOLEARN',r.get('learning_decision')=='OBSERVED' and not r.get('durable_learning'))
r2=E.analyze('Cyber Garden Idea Egg learns from music in the Sonic Garden',approval={'user_approval':True})
ck('CG05_APPROVAL_PREFERRED',r2.get('learning_decision')=='PREFERRED' and r2.get('durable_learning'))
r3=E.analyze('Cyber Garden Idea Egg learns from forest ecology and love')
forms=r3['future_self_projection']['possible_forms']
ck('CG06_CONTEXT_FORMS','Ecosystem Guardian' in forms and 'Connection Keeper' in forms and 'Unique Hybrid Identity' in forms,str(forms))
ck('CG07_NONIRREVERSIBLE',r3['future_self_projection']['irreversible'] is False)
ck('CG08_DO_NOT_TOUCH_IDENTITY','PROTECTED_CHARACTER_IDENTITY' in r3['preservation_mask']['DO_NOT_TOUCH'])
ck('CG09_LYVRA_EXTERNAL_UNCHANGED',r3.get('external_lyvra_mutated') is False)
c=C.compile_prompt('Create a photorealistic Cyber Garden with Idea Egg and Knowledge Tree')
ck('CG10_COMPILER_SELECT','ADAPTIVE_CYBER_GARDEN' in c['selected_modules'],str(c['selected_modules']))
ck('CG11_COMPILER_DIRECTIVE','[CYBER_GARDEN]' in c['compiled_prompt'])
c2=C.compile_prompt('ordinary photorealistic landscape')
ck('CG12_NO_UNRELATED_INJECTION','ADAPTIVE_CYBER_GARDEN' not in c2['selected_modules'] and '[CYBER_GARDEN]' not in c2['compiled_prompt'])
c3=C.compile_prompt('Cyber Garden Idea Egg with music',cyber_garden_approval={'canonical':True})
ck('CG13_CANONICAL_LEARNING',c3['cyber_garden_report']['learning_decision']=='CANONICAL' and c3['cyber_garden_report']['durable_learning'])
st=E.evolve_state(None,intent='Cyber Garden Idea Egg music',variant=True)
ck('CG14_VARIANT_EXPERIMENTAL',st['learning']['state']=='EXPERIMENTAL')
st2=E.evolve_state(None,intent='Cyber Garden Idea Egg music',rejected=True)
ck('CG15_REJECTED_NOT_DURABLE',st2['learning']['state']=='REJECTED' and not st2['learning'].get('durable_preferences'))
if fail:
    print('CYBER GARDEN TESTS = FAIL',fail); sys.exit(1)
print('CYBER GARDEN TESTS = PASS (15/15)')
