#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys
R=Path(__file__).resolve().parent

def load(name,file):
    sp=importlib.util.spec_from_file_location(name,R/file); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m
E=load('duality','50_CYBER_DUALITY_ENGINE.py'); C=load('compiler','26_PROMPT_COMPILER.py')
fail=[]
def ck(name,cond,detail=''):
    print(('PASS' if cond else 'FAIL'),name,detail)
    if not cond: fail.append(name)

ck('CD01_INACTIVE_ORDINARY', not E.analyze('ordinary photorealistic portrait').get('active'))
r=E.analyze('Create a photorealistic cyber angel and devil hybrid from this portrait')
ck('CD02_ACTIVE_SINGLE',r['active'] and r['requested_person_count']==1)
ck('CD03_SINGLE_BEING_HARDLOCK',r['single_being_hardlock'] and not r['couple_mode'])
ck('CD04_IDENTITY_HARD',r['identity_protection']=='HARD' and r['face_body_naturalism']=='HARD')
ck('CD05_BALANCE_ONE_IDENTITY',r['duality_balance']=={'angel_energy':50,'demon_energy':50,'one_identity':100})
r2=E.analyze('Create a couple together, both cyber angel and devil hybrids')
ck('CD06_EXPLICIT_COUPLE_OVERRIDE',r2['requested_person_count']==2 and r2['couple_mode'] and not r2['single_being_hardlock'])
ck('CD07_COUPLE_MODE',r2['couple_interaction_mode']=='AUTO_NATURAL')
r3=E.analyze('Power couple: two people, angelic and demonic cyber hybrids')
ck('CD08_POWER_COUPLE',r3['couple_interaction_mode']=='POWER_COUPLE')
r4=E.analyze('Cyber angel and devil hybrid. Das Gesicht passt nicht zum Körper.')
ck('CD09_FACE_BODY_FAILURE',r4['face_body_integration_failure'] and len(r4['repair_order'])==10)
ck('CD10_LYVRA_UNCHANGED',r4['external_lyvra_mutated'] is False)
c=C.compile_prompt('Create a photorealistic cyber angel and devil hybrid from this portrait')
ck('CD11_COMPILER_SELECT','CYBER_DUALITY_CHARACTER_COUPLE' in c['selected_modules'],str(c['selected_modules']))
ck('CD12_COMPILER_DIRECTIVE','[CYBER_DUALITY]' in c['compiled_prompt'])
ck('CD13_DIRECTIVE_ONE_PERSON','ONE PERSON ONLY' in c['compiled_prompt'])
c2=C.compile_prompt('ordinary photorealistic landscape')
ck('CD14_NO_UNRELATED_INJECTION','CYBER_DUALITY_CHARACTER_COUPLE' not in c2['selected_modules'] and '[CYBER_DUALITY]' not in c2['compiled_prompt'])
c3=C.compile_prompt('Couple portrait, two people together, angelic and demonic cyber hybrids')
ck('CD15_TWO_IDENTITIES','TWO PROTECTED IDENTITIES' in c3['compiled_prompt'])
ck('CD16_NO_RANDOM_TEXT',c3['cyber_duality_report']['no_random_text'] is True)
ck('CD17_PRIORITY_STACK',c3['cyber_duality_report']['priority_stack'][0]=='P0_IDENTITY' and c3['cyber_duality_report']['priority_stack'][3]=='P3_REQUESTED_PERSON_COUNT')
ck('CD18_QUALITY_TARGETS',c3['cyber_duality_report']['quality_targets']['COUPLE_IDENTITY_SEPARATION']==98)
c4=C.compile_prompt('Cyber angel and devil hybrid. The face does not fit the body.')
ck('CD19_MINIMAL_REPAIR','FACE_BODY_INTEGRATION_REPAIR' in c4['compiled_prompt'])
ck('CD20_PHOTOREAL_PRIORITY','Photographic realism first' in c4['compiled_prompt'])
if fail:
    print('CYBER DUALITY TESTS = FAIL',fail); sys.exit(1)
print('CYBER DUALITY TESTS = PASS (20/20)')
