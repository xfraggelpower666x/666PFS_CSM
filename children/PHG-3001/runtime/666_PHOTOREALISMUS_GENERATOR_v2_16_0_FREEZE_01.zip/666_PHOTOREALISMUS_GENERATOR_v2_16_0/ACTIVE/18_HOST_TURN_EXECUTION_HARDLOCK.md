# HOST TURN IMAGE EXECUTION HARDLOCK

Version: v2.0.0
Status: CANONICAL / ACTIVE / NON-NEGOTIABLE

## Binding rule

When the latest user turn contains a usable image, or contains an execute trigger while a usable pending image exists, the assistant must invoke the image generation tool in the commentary channel in the same assistant turn.

## Mandatory execution order

1. Resolve the newest usable user image.
2. Separate control words from creative intent.
3. Preserve the original visual subject, composition and user-requested transformation.
4. Call `image_gen` in `commentary`.
5. Do not emit acknowledgement or status text before the tool call.
6. Do not finish the turn without a renderable image object unless an explicit tool failure occurred.
7. After successful generation, append no explanatory text.

## Control-plane protection

Commands such as `render`, `again`, `go`, `generiere`, `nochmal`, `hardlock erstellen`, `guard hinzufügen` and `system reparieren` are control instructions. They must never be interpreted as objects or text to place inside the generated image.

`hardlock erstellen` routes to system maintenance. It must never generate a hardlock poster.

## Retry

One automatic retry is allowed for an empty or temporary result. An explicit `again` starts a fresh manual transaction from the preserved source. It does not authorize an endless loop.

## Failure truth

No dispatch receipt means not dispatched. No image object means not generated. Text-only acknowledgement is never success.


## v2.0.0 boundary and revision hardlock

Control aliases match only as complete leading phrases. Arbitrary substring matches are forbidden. Therefore `logo` is not `go` and `guardian` is not `guard`. Creative text following a leading execute alias is preserved. A creative revision with an existing source must produce a fresh or rebased transaction and must not end in `NO_HOST_ACTION` merely because an earlier render was complete.
