#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json, hashlib, re
ROOT=Path(__file__).resolve().parent
REG=json.loads((ROOT/'81_PORTABLE_PARITY_REGISTRY.json').read_text(encoding='utf-8'))

def stable_runtime_inventory(active:Path)->dict:
    files={}
    for p in sorted(active.iterdir()):
        if not p.is_file(): continue
        # Edition-specific portable governance files may differ by design.
        if p.name in {'82_PORTABLE_PARITY_ENGINE.py','83_RUN_PORTABLE_PARITY_TESTS.py'}: continue
        files[p.name]={'size':p.stat().st_size,'suffix':p.suffix}
    return files

def compare_contract(canonical_active:Path, portable_active:Path)->dict:
    cm=json.loads((canonical_active/'00_ACTIVE_MANIFEST.json').read_text(encoding='utf-8'))
    pm=json.loads((portable_active/'00_ACTIVE_MANIFEST.json').read_text(encoding='utf-8'))
    checks={
      'VERSION': cm.get('version')==pm.get('version'),
      'SYSTEM_ID': cm.get('system_id')==pm.get('system_id'),
      'RUNTIME_ENTRY': cm.get('runtime_entry')==pm.get('runtime_entry'),
      'HOST_TURN_EXECUTOR': cm.get('host_turn_executor')==pm.get('host_turn_executor'),
      'MENU_ENGINE': (canonical_active/'76_MODE_MENU_ENGINE.py').exists() and (portable_active/'76_MODE_MENU_ENGINE.py').exists(),
      'INTERACTION_ENGINE': (canonical_active/'79_PHG_INTERACTION_ENGINE.py').exists() and (portable_active/'79_PHG_INTERACTION_ENGINE.py').exists(),
    }
    cr=json.loads((canonical_active/'75_MODE_MENU_REGISTRY.json').read_text(encoding='utf-8'))
    pr=json.loads((portable_active/'75_MODE_MENU_REGISTRY.json').read_text(encoding='utf-8'))
    checks['MENU_SECTION_COUNT']=len(cr.get('sections',[]))==len(pr.get('sections',[]))
    checks['MENU_MODE_IDS']=[m for s in cr.get('sections',[]) for m in s.get('modes',[])]==[m for s in pr.get('sections',[]) for m in s.get('modes',[])]
    ci=json.loads((canonical_active/'78_PHG_INTERACTION_REGISTRY.json').read_text(encoding='utf-8'))
    pi=json.loads((portable_active/'78_PHG_INTERACTION_REGISTRY.json').read_text(encoding='utf-8'))
    checks['TRIGGERS']=ci.get('exact_triggers')==pi.get('exact_triggers')
    checks['CAPABILITY_CLASSES']=ci.get('capability_classes')==pi.get('capability_classes')
    return {'pass':all(checks.values()),'checks':checks}

def portable_language_scan(paths:list[Path])->dict:
    # Targeted guard for known German user-facing PHG phrases. Technical aliases may remain in trigger registries.
    bad=re.compile(r'\b(Neues Bild|bestehendes Bild|Was ist|Was darf|Soll fotorealistisch|Gibt es exakten|Welcher Frame|Beschreibe Motiv|Hauptmotiv klar|Das hochgeladene|Schreibweise exakt|Modus wählen|Bild hochladen|bloße Moduswahl|Wähle Modus|Empfohlene Kombinationen|Fehlervermeidung)\b',re.I)
    hits=[]
    for p in paths:
        if not p.exists(): continue
        txt=p.read_text(encoding='utf-8',errors='ignore')
        if bad.search(txt): hits.append(p.name)
    return {'pass':not hits,'hits':hits}
