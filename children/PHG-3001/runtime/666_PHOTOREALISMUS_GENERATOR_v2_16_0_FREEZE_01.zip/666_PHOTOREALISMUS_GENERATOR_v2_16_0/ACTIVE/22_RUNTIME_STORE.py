#!/usr/bin/env python3
"""Crash-recoverable transaction store for 666 PRG v2.0.0.

State, journal and receipts are protected by one process lock and a revision/CAS
contract. Every commit is staged with before-images and SHA-256 metadata. If a
process stops between file replacements, the next read/write deterministically
finalizes a fully written generation or rolls the whole generation back.
"""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
import copy
import hashlib
import json
import os
import shutil
import tempfile
import time
import uuid

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


@contextmanager
def file_lock(lock_path: Path, timeout_seconds: float = 10.0):
    if fcntl is None:
        raise RuntimeError("ATOMIC_RUNTIME_STORE_REQUIRES_POSIX_FILE_LOCKING")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fh = lock_path.open("a+", encoding="utf-8")
    start = time.monotonic()
    locked = False
    try:
        while True:
            try:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
                break
            except BlockingIOError:
                if time.monotonic() - start >= timeout_seconds:
                    raise TimeoutError(f"Runtime lock timeout: {lock_path}")
                time.sleep(0.05)
        yield fh
    finally:
        if locked:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        fh.close()


def _fsync_dir(path: Path) -> None:
    fd = os.open(str(path), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hash_file(path: Path) -> str | None:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def _read_json(path: Path, default):
    if not path.is_file():
        return copy.deepcopy(default)
    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    records: list[dict] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise RuntimeError(f"JSONL_RECORD_NOT_OBJECT:{path.name}:{line_no}")
        records.append(value)
    return records


def _stage_bytes(path: Path, data: bytes) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
    except Exception:
        Path(tmp_name).unlink(missing_ok=True)
        raise
    return Path(tmp_name)


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    temporary = _stage_bytes(path, data)
    try:
        os.replace(temporary, path)
        _fsync_dir(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def _atomic_write_json(path: Path, value: dict) -> None:
    _atomic_write_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def _atomic_copy(source: Path, target: Path) -> None:
    if not source.is_file():
        raise RuntimeError(f"RECOVERY_SOURCE_MISSING:{source}")
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=target.name + ".copy.", dir=target.parent)
    try:
        with source.open("rb") as src, os.fdopen(fd, "wb") as dst:
            shutil.copyfileobj(src, dst)
            dst.flush()
            os.fsync(dst.fileno())
        os.replace(tmp_name, target)
        _fsync_dir(target.parent)
    finally:
        Path(tmp_name).unlink(missing_ok=True)


def _safe_remove_tree(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)


def _validate_new_records(state: dict, existing_journal: list[dict], journal: list[dict], existing_receipts: list[dict], receipts: list[dict]) -> None:
    if not isinstance(state, dict):
        raise RuntimeError("STATE_NOT_OBJECT")
    if not isinstance(journal, list) or not all(isinstance(x, dict) for x in journal):
        raise RuntimeError("JOURNAL_NOT_OBJECT_LIST")
    if not isinstance(receipts, list) or not all(isinstance(x, dict) for x in receipts):
        raise RuntimeError("RECEIPTS_NOT_OBJECT_LIST")

    previous_sequence = int(existing_journal[-1].get("sequence", 0)) if existing_journal else 0
    sequences = [x.get("sequence") for x in journal]
    if any(not isinstance(x, int) or x <= 0 for x in sequences):
        raise RuntimeError("JOURNAL_SEQUENCE_INVALID")
    if sequences and sequences != list(range(previous_sequence + 1, previous_sequence + 1 + len(sequences))):
        raise RuntimeError(f"JOURNAL_SEQUENCE_NON_MONOTONIC:previous={previous_sequence}:new={sequences}")
    if sequences and int(state.get("journal_sequence", -1)) != sequences[-1]:
        raise RuntimeError("STATE_JOURNAL_SEQUENCE_MISMATCH")

    old_ids = {x.get("receipt_id") for x in existing_receipts if x.get("receipt_id")}
    new_ids = [x.get("receipt_id") for x in receipts]
    if any(not isinstance(x, str) or not x for x in new_ids):
        raise RuntimeError("RECEIPT_ID_MISSING")
    if len(new_ids) != len(set(new_ids)) or old_ids.intersection(new_ids):
        raise RuntimeError("DUPLICATE_RECEIPT_ID")
    transaction_id = state.get("transaction_id")
    for receipt in receipts:
        if receipt.get("transaction_id") != transaction_id:
            raise RuntimeError("RECEIPT_TRANSACTION_MISMATCH")
        seq = receipt.get("journal_sequence")
        if not isinstance(seq, int) or seq <= 0 or seq > int(state.get("journal_sequence", 0)):
            raise RuntimeError("RECEIPT_JOURNAL_SEQUENCE_INVALID")


def _recovery_commit_from_wal(wal: dict, *, status: str, recovery_action: str) -> dict:
    return {
        **wal,
        "status": status,
        "recovery_action": recovery_action,
        "state_revision": wal.get("to_revision"),
    }


def _recover_locked(runtime: Path) -> dict | None:
    wal_path = runtime / "transaction.wal.json"
    if not wal_path.is_file():
        return None
    wal = _read_json(wal_path, {})
    if not isinstance(wal, dict) or not wal.get("commit_id") or not isinstance(wal.get("files"), list):
        raise RuntimeError("WAL_CORRUPT_OR_UNSUPPORTED")

    stage_dir = runtime / str(wal.get("stage_dir", ""))
    entries = wal["files"]
    all_new = bool(entries) and all(
        _hash_file(runtime / item["target"]) == item.get("new_sha256")
        for item in entries
    )

    if all_new:
        commit = _recovery_commit_from_wal(wal, status="COMMITTED", recovery_action="FINALIZED_COMPLETE_GENERATION")
        _atomic_write_json(runtime / "last_commit.json", commit)
        wal_path.unlink(missing_ok=True)
        _safe_remove_tree(stage_dir)
        _fsync_dir(runtime)
        return commit

    for item in entries:
        target = runtime / item["target"]
        if item.get("previous_existed"):
            previous = stage_dir / item["previous_rel"]
            if _hash_file(previous) != item.get("previous_sha256"):
                raise RuntimeError(f"WAL_PREVIOUS_IMAGE_INVALID:{item['target']}")
            _atomic_copy(previous, target)
        else:
            target.unlink(missing_ok=True)
            _fsync_dir(runtime)

    for item in entries:
        target = runtime / item["target"]
        expected = item.get("previous_sha256") if item.get("previous_existed") else None
        if _hash_file(target) != expected:
            raise RuntimeError(f"WAL_ROLLBACK_READBACK_FAILED:{item['target']}")

    recovery = _recovery_commit_from_wal(wal, status="ROLLED_BACK", recovery_action="ROLLED_BACK_PARTIAL_GENERATION")
    _atomic_write_json(runtime / "last_recovery.json", recovery)
    wal_path.unlink(missing_ok=True)
    _safe_remove_tree(stage_dir)
    _fsync_dir(runtime)
    return recovery


def recover_runtime(root: Path) -> dict | None:
    runtime = root / "RUNTIME_STATE"
    runtime.mkdir(parents=True, exist_ok=True)
    with file_lock(runtime / "runtime.transaction.lock"):
        return _recover_locked(runtime)


def load_state(root: Path) -> dict | None:
    runtime = root / "RUNTIME_STATE"
    runtime.mkdir(parents=True, exist_ok=True)
    with file_lock(runtime / "runtime.transaction.lock"):
        _recover_locked(runtime)
        return _read_json(runtime / "current_state.json", None)


def persist_transaction(
    root: Path,
    state: dict,
    journal: list[dict],
    receipts: list[dict] | None = None,
    *,
    expected_revision: int | None = None,
    lease_owner: str | None = None,
) -> dict:
    runtime = root / "RUNTIME_STATE"
    runtime.mkdir(parents=True, exist_ok=True)
    lock_path = runtime / "runtime.transaction.lock"
    with file_lock(lock_path):
        recovery = _recover_locked(runtime)
        current_path = runtime / "current_state.json"
        journal_path = runtime / "transaction_journal.jsonl"
        receipt_path = runtime / "receipts.jsonl"
        wal_path = runtime / "transaction.wal.json"
        commit_path = runtime / "last_commit.json"

        current = _read_json(current_path, {}) or {}
        current_revision = int(current.get("revision", 0))
        if expected_revision is not None and expected_revision != current_revision:
            raise RuntimeError(f"REVISION_CONFLICT expected={expected_revision} actual={current_revision}")

        existing_journal = _read_jsonl(journal_path)
        existing_receipts = _read_jsonl(receipt_path)
        new_receipt_records = list(receipts or [])
        _validate_new_records(state, existing_journal, list(journal or []), existing_receipts, new_receipt_records)

        new_state = copy.deepcopy(state)
        new_state["revision"] = current_revision + 1
        new_journal = existing_journal + list(journal or [])
        new_receipts = existing_receipts + new_receipt_records
        commit_id = f"PRG-COMMIT-{uuid.uuid4().hex[:12]}"
        stage_dir = runtime / ".transactions" / commit_id
        new_dir = stage_dir / "new"
        previous_dir = stage_dir / "previous"
        new_dir.mkdir(parents=True, exist_ok=False)
        previous_dir.mkdir(parents=True, exist_ok=False)

        payloads = {
            "current_state.json": (json.dumps(new_state, ensure_ascii=False, indent=2) + "\n").encode("utf-8"),
            "transaction_journal.jsonl": "".join(json.dumps(x, ensure_ascii=False, separators=(",", ":")) + "\n" for x in new_journal).encode("utf-8"),
            "receipts.jsonl": "".join(json.dumps(x, ensure_ascii=False, separators=(",", ":")) + "\n" for x in new_receipts).encode("utf-8"),
        }
        entries: list[dict] = []
        for target_name, data in payloads.items():
            target = runtime / target_name
            new_path = new_dir / target_name
            new_path.write_bytes(data)
            with new_path.open("rb") as fh:
                os.fsync(fh.fileno())
            previous_existed = target.is_file()
            previous_rel = f"previous/{target_name}"
            previous_hash = None
            if previous_existed:
                previous_path = previous_dir / target_name
                shutil.copy2(target, previous_path)
                with previous_path.open("rb") as fh:
                    os.fsync(fh.fileno())
                previous_hash = _hash_file(previous_path)
            entries.append({
                "target": target_name,
                "new_rel": f"new/{target_name}",
                "new_sha256": _hash_bytes(data),
                "previous_existed": previous_existed,
                "previous_rel": previous_rel if previous_existed else None,
                "previous_sha256": previous_hash,
            })
        _fsync_dir(new_dir)
        _fsync_dir(previous_dir)
        _fsync_dir(stage_dir)

        wal = {
            "commit_id": commit_id,
            "from_revision": current_revision,
            "to_revision": new_state["revision"],
            "transaction_id": new_state.get("transaction_id"),
            "lease_owner": lease_owner,
            "status": "PREPARED",
            "stage_dir": stage_dir.relative_to(runtime).as_posix(),
            "files": entries,
            "journal_records": len(new_journal),
            "receipt_records": len(new_receipts),
            "recovery_before_commit": recovery,
        }
        _atomic_write_json(wal_path, wal)

        for item in entries:
            _atomic_copy(stage_dir / item["new_rel"], runtime / item["target"])

        for item in entries:
            if _hash_file(runtime / item["target"]) != item["new_sha256"]:
                raise RuntimeError(f"POST_WRITE_READBACK_GUARD:{item['target']}")

        commit = {
            **wal,
            "status": "COMMITTED",
            "state_revision": new_state["revision"],
            "recovery_action": None,
        }
        _atomic_write_json(commit_path, commit)
        wal_path.unlink(missing_ok=True)
        _safe_remove_tree(stage_dir)
        _fsync_dir(runtime)
        return {"state": new_state, "commit": commit}


def persist(root: Path, state: dict, journal: list[dict], host_action: dict | None) -> None:
    receipts = [host_action["receipt"]] if host_action and host_action.get("receipt") else []
    persist_transaction(root, state, journal, receipts)
