#!/usr/bin/env python3
from pathlib import Path
import json, importlib.util, sys
ROOT=Path(__file__).resolve().parent
reg=json.loads((ROOT/'81_PORTABLE_PARITY_REGISTRY.json').read_text(encoding='utf-8'))
checks=[]
def ck(name,cond): checks.append((name,bool(cond)))
ck('portable_required',reg['portable_parity_required'] is True)
ck('locale_en_us',reg['portable_locale']=='en-US')
ck('not_lite',reg['portable_is_lite'] is False)
ck('same_version_dimension','VERSION' in reg['parity_dimensions'])
ck('menu_dimension','MODE_MENU' in reg['parity_dimensions'])
ck('trigger_dimension','INTERFACE_TRIGGERS' in reg['parity_dimensions'])
ck('prompt_dimension','PROMPT_TEMPLATE_LOGIC' in reg['parity_dimensions'])
ck('freeze_both','FREEZE_BOTH' in reg['lifecycle'])
ck('backup_both','SYSTEM_BACKUP_BOTH' in reg['lifecycle'])
ck('zip_both','ZIP_BOTH' in reg['lifecycle'])
for n,v in checks: print(('PASS' if v else 'FAIL'),n)
print(f'{sum(v for _,v in checks)}/{len(checks)} PASS')
sys.exit(0 if all(v for _,v in checks) else 1)
