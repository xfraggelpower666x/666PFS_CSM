#!/usr/bin/env python3
"""DSR-005 additive dynamic person-side remapping runtime for PHG v2.16.0."""
from __future__ import annotations
import re
IDENTITY_BOUND_PROPERTIES=('NAME','TYPOGRAPHY_COLOR','SIGNATURE_COLOR','RELATIONAL_COLOR_ROLE','FRAME_REGION_COLOR','PERSON_SYMBOL','PERSON_NAMEPLATE','PERSON_HUD_COLOR','PERSON_LIGHT_ACCENT','OPTIONAL_ORNAMENT_COLOR')
GLOBAL_PROPERTIES=('CENTER_CONNECTOR','GLOBAL_CAPTION','GLOBAL_BACKGROUND','GLOBAL_SCENE_EVENT')
def _n(v): return re.sub(r"\s+"," ",(v or '').casefold()).strip()
def _has(t,*terms): return any(x in t for x in terms)

def analyze(intent:str, *, source_traits:list[str]|None=None)->dict:
    t=_n(intent+' '+' '.join(source_traits or []))
    explicit=_has(t,'dynamic_side_remapping','dynamic side remapping','dsr-005','dsr_005','person_side_remap','identity_property_remap','color_person_binding','frame_region_remap')
    side=_has(t,'left','right','links','rechts','side','seite','swap','wechsel','remap','position','person a','person b')
    names=_has(t,'name','names','namen','nameplate','schrift')
    colors=_has(t,'color','colour','farbe','blue','pink','magenta','cyan','violet','purple')
    frame=_has(t,'frame','rahmen','cartouche','nameplate','sideplate','edge glow')
    couple=_has(t,'couple','pair','two people','beide','paar','duo')
    active=explicit or (side and (names or colors or frame or couple))
    return {
      'active':active,'addon_id':'PRG-ADDON-DYNAMIC-SIDE-REMAPPING-005','version':'1.0.0','host_version':'2.16.0','integration':'ADD_ONLY',
      'person_side_state_required':active,'side_swap_allowed':True,'identity_owns_visual_properties':True,
      'identity_bound_properties':list(IDENTITY_BOUND_PROPERTIES),'global_non_identity_properties':list(GLOBAL_PROPERTIES),
      'name_side_binding':{'mandatory':True,'dynamic_from_person_side':True,'name_swap':'FORBIDDEN'},
      'color_person_binding':{'owner':'PERSON_ID','side_stickiness':'FORBIDDEN'},
      'frame_region_remapping':{'owner':'PERSON_ID','side_stickiness':'FORBIDDEN'},
      'connector_neutrality':{'allowed':['&','and','♡','∞','EMBLEM'],'owner':'GLOBAL_NEUTRAL'},
      'joint_title_without_side_binding':'REJECT_UNLESS_EXPLICIT',
      'core_replacement':False,'ensc_replacement':False,'frame_router_replacement':False,'identity_engine_replacement':False,'foreign_system_mutation':False
    }

def remap(person_states:dict, property_registry:dict)->dict:
    """Map properties by PERSON_ID to current screen side; never by previous side."""
    out={'persons':{},'globals':{}}
    for pid,state in person_states.items():
        side=state.get('current_side')
        props=dict(property_registry.get(pid,{}))
        out['persons'][pid]={'current_side':side,'properties':props}
    for k,v in property_registry.get('_GLOBAL_',{}).items(): out['globals'][k]=v
    return out

def compact_directive(r:dict)->str:
    if not r.get('active'): return ''
    return ('DSR-005 ADD_ONLY; detect each person current side per image; PROPERTY_OWNER=PERSON_ID not screen side; when a person changes side, move name, identity/signature color, frame-region color, symbol/nameplate/HUD/light accent with that person; preserve identity and relationship; NAME_PERSON_MATCH HARD_LOCK; reject name/color/frame side-stickiness and ambiguous joint-title; neutral center connector may stay centered')
