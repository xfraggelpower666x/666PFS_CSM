#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, sys
ROOT=Path(__file__).resolve().parent
def load(name,file):
    s=importlib.util.spec_from_file_location(name, ROOT/file); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
D=load("dance","56_CYBER_LOVE_HOLO_DANCE_PRESET.py")
M=load("morning","57_CYBER_MORNING_IHC_ADDON.py")
E=load("preset","43_PRESET_EXPANSION_ENGINE.py")
C=load("compiler","26_PROMPT_COMPILER.py")
checks=[]
def ok(name,cond):
    checks.append((name,bool(cond)))
# Dance family
r=D.analyze("CYBER LOVE HOLO DANCE tango")
ok("dance active",r["active"] and r["subpreset"]["id"]=="PRESET_09_A")
for token,expected in [("dramatic dip","PRESET_09_B"),("extended line","PRESET_09_C"),("spin","PRESET_09_D"),("club dance","PRESET_09_E"),("stage showcase","PRESET_09_F"),("slow dance forehead","PRESET_09_G"),("side dip","PRESET_09_H")]:
    ok("route "+expected,D.analyze("CYBER LOVE HOLO DANCE "+token)["subpreset"]["id"]==expected)
# Registry/expansion
reg=json.loads((ROOT/"44_PHOTOREALISTIC_PRESET_REGISTRY.json").read_text())
ok("preset09 registry","PRESET_09" in reg["presets"])
e=E.analyze("use PRESET_09 cyber love holo dance")
ok("preset09 expansion",e.get("preset_id")=="PRESET_09")
# Morning
m=M.analyze("GOOD MORNING cyber coffee heart infinity")
ok("morning active",m["active"] and m["canonical_text"]=="GOOD MORNING" and m["default_aspect_ratio"]=="16:9")
ok("morning no collage",m["collage"]=="FORBIDDEN")
# Compiler report integration
c=C.compile_prompt("CYBER LOVE HOLO DANCE with a spin")
ok("compiler dance report",c["cyber_love_holo_dance_report"]["active"] and c["cyber_love_holo_dance_report"]["subpreset"]["id"]=="PRESET_09_D")
cm=C.compile_prompt("GOOD MORNING cyber coffee with infinity and cybernetic heart")
ok("compiler morning report",cm["cyber_morning_ihc_report"]["active"])
ok("morning text exact","GOOD MORNING" in cm["compiled_prompt"])
# Safety/nonactivation
plain=C.compile_prompt("photorealistic portrait of one adult")
ok("no accidental morning",not plain["cyber_morning_ihc_report"]["active"])
ok("no accidental dance",not plain["cyber_love_holo_dance_report"]["active"])
failed=[n for n,v in checks if not v]
for n,v in checks: print(("PASS" if v else "FAIL"),n)
print(f"V2.8 PENDING HANDOFF TESTS = {len(checks)-len(failed)}/{len(checks)} PASS")
if failed: sys.exit(1)
