#!/usr/bin/env python3
"""Semantic FRAME_MODES family for 666 PRG v2.1.0."""
from __future__ import annotations
import re

VERSION = "1.1.0"

FRAME_MODES = {
    "FRAME_MODE_NONE": {},
    "FRAME_MODE_CLEAN_BORDER": {"intensity":"low","thickness":"thin","coverage":"edge_only","glow":"none"},
    "FRAME_MODE_POSTER_EDGE": {"intensity":"medium","thickness":"medium","coverage":"decorative","glow":"subtle"},
    "FRAME_MODE_CYBER_HOLO": {"intensity":"medium","holographic":True,"cyber_ui":True,"primary_color":"holo_neon_blue","secondary_color":"neon_purple"},
    "FRAME_MODE_CYBER_LOVE_HOLO": {"intensity":"strong","holographic":True,"barbed_wire":True,"love_symbols":True,"cyber_ui":True,"primary_color":"holo_neon_blue","secondary_color":"neon_purple","accent_color":"neon_pink","heart_color":"red_neon"},
    "FRAME_MODE_ROMANTIC_NEON_SIGNATURE": {"intensity":"medium","love_symbols":True,"signature_style":"neon","glow":"medium"},
    "FRAME_MODE_TECHNO_POSTER": {"intensity":"strong","music_symbols":True,"cyber_ui":True,"glow":"medium"},
    "FRAME_MODE_LUXURY_GLOW": {"intensity":"medium","ornaments":True,"glow":"medium"},
    "FRAME_MODE_DARK_ORNAMENT": {"intensity":"medium","ornaments":True,"glow":"subtle"},
    "FRAME_MODE_CUSTOM": {},
}

FRAME_TERMS = (
    "frame", "framed", "border", "picture border", "outer border", "rahmen", "bilderrahmen", "bildrahmen",
    "eingerahmt", "umrandung", "bildrand", "rand ums bild", "rand um das bild", "außen herum", "aussen herum",
    "drum herum", "drumherum", "außen rum", "aussen rum", "neonrahmen", "hologrammrahmen", "holo rahmen",
    "cyberrahmen", "herzrahmen", "stacheldrahtrahmen", "posterrahmen", "um das motiv", "um das bild"
)

CYBER_TERMS = ("cyber", "cyberpunk", "holo", "holographic", "holograf", "neon", "futuristic", "techno", "sci-fi")
LOVE_TERMS = ("love", "liebe", "heart", "herz", "romantic", "romantisch", "couple", "paar", "kiss", "kuss", "umarm")
TECHNO_TERMS = ("techno", "rave", "club", "music", "musik", "dj", "poster")
LUXURY_TERMS = ("luxury", "luxus", "elegant", "premium", "glamour")
DARK_TERMS = ("dark", "ornament", "occult", "okkult", "mystic", "mystisch")
CLEAN_TERMS = ("simple", "clean", "schlicht", "einfach", "thin", "dünn", "neutral", "black frame", "white frame", "schwarzer rahmen", "weißer rahmen")
SIGNATURE_TERMS = ("name", "names", "namen", "signature", "signatur", "fraggle", "veluna")
BARBED_TERMS = ("barbed wire", "barbed-wire", "stacheldraht")
ROSE_TERMS = ("rose", "roses", "rosen")
MUSIC_TERMS = ("music note", "music notes", "musiknote", "musiknoten", "waveform")
NO_HEART_TERMS = ("without heart", "without hearts", "no hearts", "ohne herz", "ohne herzen")
NO_BARBED_TERMS = ("without barbed wire", "no barbed wire", "ohne stacheldraht")


def _norm(value: str | None) -> str:
    return re.sub(r"\s+", " ", (value or "").casefold()).strip()


def _contains(text: str, terms) -> bool:
    t = _norm(text)
    return any(term in t for term in terms)


def detect_frame_intent(text: str) -> bool:
    """Natural-language frame intent detector. Terms are examples, not user-facing commands."""
    t = _norm(text)
    if not t:
        return False
    if _contains(t, FRAME_TERMS):
        return True
    # Indirect German/English constructions: 'mach/gib ... außen/around ... bild/image'.
    indirect_patterns = (
        r"\b(mach|mache|bau|baue|setz|setze|gib|pack|integrier|integriere)\b.{0,80}\b(außen|aussen|rand|border|around|surround)\b",
        r"\b(image|bild|motiv|photo|foto)\b.{0,60}\b(border|surround|edge|umrand|eingerahm)\w*\b",
    )
    return any(re.search(p, t) for p in indirect_patterns)


def _extract_explicit_colors(text: str) -> list[str]:
    t = _norm(text)
    colors = []
    for c in ("black","white","blue","cyan","purple","violet","pink","red","gold","silver","schwarz","weiß","weiss","blau","lila","violett","rosa","rot","gold","silber"):
        if re.search(r"(?<!\w)" + re.escape(c) + r"(?!\w)", t): colors.append(c)
    return colors


def choose_mode(text: str, *, scene_traits: list[str] | None = None) -> str:
    t = _norm(text + " " + " ".join(scene_traits or []))
    if not detect_frame_intent(text):
        return "FRAME_MODE_NONE"
    # Explicit style has priority.
    if _contains(t, CLEAN_TERMS): return "FRAME_MODE_CLEAN_BORDER"
    if _contains(t, DARK_TERMS): return "FRAME_MODE_DARK_ORNAMENT"
    if _contains(t, LUXURY_TERMS): return "FRAME_MODE_LUXURY_GLOW"
    if _contains(t, TECHNO_TERMS) and not _contains(t, LOVE_TERMS): return "FRAME_MODE_TECHNO_POSTER"
    if _contains(t, SIGNATURE_TERMS) and _contains(t, LOVE_TERMS): return "FRAME_MODE_ROMANTIC_NEON_SIGNATURE"
    if _contains(t, CYBER_TERMS) and _contains(t, LOVE_TERMS): return "FRAME_MODE_CYBER_LOVE_HOLO"
    if _contains(t, CYBER_TERMS): return "FRAME_MODE_CYBER_HOLO"
    if _contains(t, LOVE_TERMS): return "FRAME_MODE_CYBER_LOVE_HOLO"
    if "poster" in t or "cover" in t: return "FRAME_MODE_POSTER_EDGE"
    # Context fallback: cyber-romantic -> love holo; cyber -> cyber holo; otherwise clean.
    if _contains(t, CYBER_TERMS) and _contains(t, LOVE_TERMS): return "FRAME_MODE_CYBER_LOVE_HOLO"
    if _contains(t, CYBER_TERMS): return "FRAME_MODE_CYBER_HOLO"
    return "FRAME_MODE_CLEAN_BORDER"


def analyze(text: str, *, scene_traits: list[str] | None = None) -> dict:
    active = detect_frame_intent(text)
    mode = choose_mode(text, scene_traits=scene_traits) if active else "FRAME_MODE_NONE"
    params = dict(FRAME_MODES.get(mode, {}))
    t = _norm(text)
    colors = _extract_explicit_colors(t)
    if colors: params["explicit_colors"] = colors
    if _contains(t, BARBED_TERMS): params["barbed_wire"] = True
    if _contains(t, NO_BARBED_TERMS): params["barbed_wire"] = False
    if _contains(t, ROSE_TERMS): params["rose_symbols"] = True
    if _contains(t, MUSIC_TERMS): params["music_symbols"] = True
    if _contains(t, NO_HEART_TERMS): params["love_symbols"] = False
    if "thin" in t or "dünn" in t: params["thickness"] = "thin"
    if "thick" in t or "dick" in t: params["thickness"] = "thick"
    # Signature is contextual. Fraggle/Veluna exact preset when named or clearly present in intent.
    signature = {"enabled": False}
    if "fraggle" in t and "veluna" in t:
        signature = {
            "enabled": True,
            "left_text": "Fraggle",
            "center_symbol": "heart",
            "right_text": "Veluna",
            "name_color": "holo_neon_blue",
            "center_symbol_color": "red_neon",
            "style": "holographic_neon",
        }
    elif _contains(t, SIGNATURE_TERMS):
        signature = {"enabled": True, "style": "auto", "left_text": None, "center_symbol": None, "right_text": None}
    return {
        "active": active,
        "mode": mode,
        "parameters": params,
        "signature": signature,
        "preservation": {
            "additive_layer": True,
            "protect_identity": True,
            "protect_faces": True,
            "protect_eyes": True,
            "protect_main_subject": True,
            "protect_pose": True,
            "protect_clothing": True,
            "protect_background": True,
            "protect_existing_text": True,
            "protect_camera": True,
            "protect_hair": True,
            "protect_tattoos": True,
            "protect_relative_positions": True,
        },
    }


def compact_directive(report: dict) -> str:
    if not report.get("active"):
        return ""
    mode = report["mode"]
    p = report.get("parameters", {})
    sig = report.get("signature", {})
    bits = [
        f"Activate {mode} as an additive outer frame layer.",
        "Preserve the validated central image, identities, faces, pose, clothing, background, camera perspective and existing important text unless explicitly requested otherwise.",
        "Keep frame decoration at edge priority and do not cover faces, eyes, hands or important contact zones.",
        "Explicit user frame instructions override defaults; infer only missing parameters.",
        "Keep the complete frame fully visible on all four sides with a 4-6% safe-margin target (5% default), edge padding and no cropped border or text elements.",
        "Maintain a subject-clear zone: do not cover faces, eyes, hands, important tattoos, the central pose or important contact zones.",
    ]
    if p.get("holographic"): bits.append("Use a coherent holographic treatment.")
    if p.get("barbed_wire") is True: bits.append("Integrate holographic or style-matched barbed-wire elements.")
    if p.get("barbed_wire") is False: bits.append("Do not use barbed wire.")
    if p.get("love_symbols") is True: bits.append("Integrate restrained love-symbol motifs.")
    if p.get("love_symbols") is False: bits.append("Do not use heart/love symbols.")
    if p.get("music_symbols"): bits.append("Integrate restrained music-symbol motifs.")
    if p.get("rose_symbols"): bits.append("Integrate restrained rose motifs.")
    if p.get("explicit_colors"): bits.append("Honor explicit frame colors: " + ", ".join(p["explicit_colors"]) + ".")
    if sig.get("enabled") and sig.get("left_text") == "Fraggle" and sig.get("right_text") == "Veluna":
        bits.append('At the lower edge render "Fraggle  [red neon holographic heart]  Veluna"; both names holographic neon blue, center heart red neon.')
    return " ".join(bits)
