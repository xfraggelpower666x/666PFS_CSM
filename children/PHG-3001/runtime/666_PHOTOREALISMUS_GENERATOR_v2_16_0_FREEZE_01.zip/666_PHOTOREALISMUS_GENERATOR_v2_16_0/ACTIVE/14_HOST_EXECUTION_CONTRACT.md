# HOST EXECUTION CONTRACT — v2.0.0

The local runtime kernel is executable for state routing, guard checks, journaling and receipts. It cannot independently call ChatGPT's image-generation service.

When the kernel emits:

```json
{"action":"CALL_IMAGE_TOOL","channel":"commentary"}
```

the host must:

1. call the current image-generation/edit tool in the **commentary** channel;
2. bind the current conversation image as the edit target;
3. return a transaction-linked result event;
4. send `TOOL_RETURNED` only when a tool result exists;
5. send `TOOL_EMPTY`, `TOOL_TEMPORARY_ERROR`, `TOOL_RATE_LIMIT`, `TOOL_POLICY_REJECTION`, or `TOOL_UNAVAILABLE` honestly when applicable;
6. perform visual inspection and submit one of the Visual-QA events;
7. never use a final-channel tool call;
8. never replace a missing tool result with a text-only success message.


## v2.0.0 SAME-TURN HARDLOCK
A valid image upload or render trigger must produce the commentary-channel image tool call in the same assistant turn. No pre-call status text, no final-channel tool call, no text-only success. Control-plane maintenance commands are never image prompt content.


## v2.0.0 Receipt contract

Every emitted host action must carry `transaction_id`, `attempt_id`, `source_id`, `source_hash`, `prompt_hash`, `dispatch_key`, `channel`, `prompt`, and the immutable receipt object. A creative revision with a preserved source is a valid same-turn generation request even after the previous transaction reached `COMPLETE`.

## v2.0.0 Host-result recovery hardlock

- `image_gen` must be invoked in `commentary`, never in `final`.
- A nominal tool success without an image object or valid output hash is normalized to `TOOL_EMPTY`.
- `TOOL_EMPTY` preserves the source and intent and permits exactly one bounded automatic retry.
- A channel violation is retryable only after the channel is corrected to `commentary`.
- The host must not report completion, display an empty final response, or launch an uncontrolled duplicate call when no image object was returned.
