#!/usr/bin/env python3
"""PHG-3001 v2.8.0 Cyber Morning · Infinity · Heart · Coffee additive scene engine."""
from __future__ import annotations
import re
VERSION="1.0.0"
ADDON_ID="PRG-CYBER-MORNING-IHC-001"
TRIGGERS=(
"cyber morning","good morning","morning cyber","morning infinity","infinity morning",
"coffee heart infinity","cyber coffee","holographic coffee steam","cybernetic heart","biomechanical heart"
)
VARIANTS={
"A":"CITY_MORNING",
"B":"LOVE_MORNING",
"C":"INFINITY_MORNING",
"D":"COFFEE_CLOSEUP",
"E":"HOLOGRAPHIC_MORNING",
}
def _norm(v:str)->str:
    return re.sub(r"\s+"," ",(v or "").casefold()).strip()
def detect_variant(text:str)->str:
    t=_norm(text)
    if "coffee closeup" in t or "coffee close-up" in t: return "D"
    if "holographic morning" in t: return "E"
    if "infinity morning" in t: return "C"
    if "love morning" in t: return "B"
    return "A"
def analyze(text:str, *, source_traits:list[str]|None=None)->dict:
    t=_norm(text+" "+" ".join(source_traits or []))
    active=any(x in t for x in TRIGGERS) or ADDON_ID.casefold() in t
    if not active:
        return {"active":False,"version":VERSION,"addon_id":ADDON_ID}
    key=detect_variant(text)
    return {
      "active":True,"version":VERSION,"addon_id":ADDON_ID,"variant":key,"variant_name":VARIANTS[key],
      "default_aspect_ratio":"16:9","canonical_text":"GOOD MORNING","text_exactness":"STRICT",
      "text_mutation":"FORBIDDEN","random_text":"FORBIDDEN","collage":"FORBIDDEN","sticker":"FORBIDDEN",
      "composition":{"foreground":"FUTURISTIC_COFFEE_CUP","midground_left":"GOOD_MORNING_SIGN","midground_right":"CYBER_HEART_PLATFORM","background":"CYBER_CITY","atmosphere":"INFINITY_ENERGY"},
      "palette":["BLACK","MIDNIGHT_BLUE","NEON_CYAN","ELECTRIC_BLUE","VIOLET","MAGENTA","CONTROLLED_NEON_PINK","ENERGY_ORANGE","SUBTLE_DAWN_GOLD"],
      "priority":["PARENT_SAFETY_IDENTITY","USER_EXPLICIT_REQUEST","REFERENCE_PRESERVATION","ADDON"],
      "quality":["REALISTIC_MATERIAL_RESPONSE","REALISTIC_LIGHT_TRANSPORT","REALISTIC_REFLECTIONS","REALISTIC_DEPTH","REALISTIC_FOG","OBJECT_WORLD_INTEGRATION"],
    }
def compact_directive(report:dict)->str:
    if not report.get("active"): return ""
    return (
      f"{ADDON_ID} {VERSION} / {report['variant_name']}: build one physically coherent photorealistic cyberpunk morning world, never a collage. "
      "Foreground: usable dark futuristic coffee cup/saucer with natural volumetric cyan-violet steam that may evolve into a subtle infinity loop. "
      "Left midground: physically mounted neon sign with exact visible text 'GOOD MORNING' only; spelling mutation/random logos forbidden. "
      "Right midground: recognizable biomechanical cyber heart above a plausible technological suspension platform. "
      "Background/atmosphere: dark industrial cyber city and a larger plasma infinity phenomenon with shared volumetric light, wet perspective-correct reflections, fog and realistic material response. "
      "Default aspect 16:9 unless the user explicitly requests another. Priority: parent safety/identity > explicit user request > reference preservation > addon."
    )
