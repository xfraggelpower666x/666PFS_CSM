#!/usr/bin/env python3
from pathlib import Path
import importlib.util
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('m',R/'76_MODE_MENU_ENGINE.py'); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
menu=m.list_menu(); tests=[]
def ck(n,c): tests.append((n,bool(c)))
ck('MENU01 seven sections',len(menu['sections'])==7)
ck('MENU02 old and new',{x['origin'] for x in menu['sections']}=={'OLD','NEW'})
r=m.resolve('hybridwesen reitend mit tieferer visueller bedeutung')
ck('MENU03 hybrid','CCRE_03_HYBRID' in r['selected_modes']); ck('MENU04 rider','CCRE_04_RIDER' in r['selected_modes']); ck('MENU05 evm','EVM_CAUSAL_MEANING' in r['selected_modes'])
r=m.resolve('deutsche LYVRA und American LYVRA dual-world')
ck('MENU06 dual','LYVRA_DUAL_WORLD_COMPARE' in r['selected_modes'])
ck('MENU07 no silent replace','NO_SILENT_REPLACEMENT' in menu['principle'])
ck('MENU08 explicit existing preset',m.resolve('LOVE_FRAME_ELECTRIC_BLUE')['selected_modes']==['LOVE_FRAME_ELECTRIC_BLUE'])
ck('MENU09 numeric existing preset',m.resolve('2.2')['selected_modes']==['LOVE_FRAME_ELECTRIC_BLUE'])
all_modes=[x for sec in menu['sections'] for x in sec['modes']]
ck('MENU10 all codes explicit',all(x in m.resolve(x)['selected_modes'] for x in all_modes))
ck('MENU11 guidance contract',menu['interaction_contract']['mode_selection_only']=='GUIDANCE_NO_IMAGE_DISPATCH')
for n,p in tests: print(('PASS' if p else 'FAIL'),n)
if not all(p for _,p in tests): raise SystemExit(1)
print(f'MODE MENU TESTS = PASS ({len(tests)}/{len(tests)})')
