#!/usr/bin/env python3
"""PHG-3001 v2.12.0 additive Cyber Neon Symbolic Composition adapter engine."""
from __future__ import annotations
import re

VERSION="1.0.0"
ADDON_ID="PRG-CNSC-ADDON-001"
NAME="PHOTOREALISTIC_CYBER_NEON_SYMBOLIC_COMPOSITION_ADDON"
MODE="ADD_ONLY"
HOOK="POST_SOURCE_ANALYSIS_TO_PRE_RENDER_COMPOSITION"

EXPLICIT_TERMS=(
    "prg-cnsc-addon-001",
    "photorealistic cyber neon symbolic composition",
    "cyber neon symbolic composition",
    "symbol reconstruction",
    "continuous color fusion",
    "interwoven geometry",
    "relational neon heart",
    "relational_neon_heart",
)
SYMBOL_TERMS=("symbol","emblem","logo","rune","heart","herz","infinity","unendlich","rings","ring","braid","knot","cable","zeichen","symbolic")
CYBER_TERMS=("cyber","neon","holo","holographic","laser","electric","magenta","cyan","violet")
MATERIALS=("NEON_GLASS","TRANSLUCENT_POLYMER","POLISHED_METAL","CYBER_CERAMIC","FIBER_OPTIC","LIQUID_LIGHT_CHANNEL","HYBRID_GLASS_METAL")
ENERGY_STYLES=("neon","laser","lightning","hybrid")
ASPECTS=("16:9","1:1","4:5")
BACKGROUNDS=("clean_dark","cyber_city","abstract_circuit","custom")
COLOR_FLOW=("PINK","MAGENTA","VIOLET","ELECTRIC_BLUE","CYAN")

def _norm(v:str|None)->str:
    return re.sub(r"\s+"," ",(v or "").casefold()).strip()

def _extract(text:str,key:str)->str|None:
    m=re.search(rf"(?im)\b{re.escape(key)}\s*[:=]\s*([^\n\r]+)",text or "")
    if not m: return None
    v=m.group(1).strip().strip("\"' ")
    return v or None

def _int_value(text:str,key:str,default:int,low:int,high:int)->int:
    raw=_extract(text,key)
    if raw is None: return default
    try: n=int(raw)
    except ValueError: return default
    return max(low,min(high,n))

def active_for(text:str, source_traits:list[str]|None=None)->bool:
    t=_norm((text or "")+" "+" ".join(source_traits or []))
    if any(x in t for x in EXPLICIT_TERMS): return True
    return any(x in t for x in SYMBOL_TERMS) and any(x in t for x in CYBER_TERMS) and any(x in t for x in ("reconstruct","rekonstru","fusion","gradient","verlauf","interwoven","verschlung","laser","symbol"))

def detect_preset(text:str)->str|None:
    t=_norm(text)
    if "relational_neon_heart" in t or "relational neon heart" in t:
        return "RELATIONAL_NEON_HEART"
    return None

def analyze(text:str, *, source_traits:list[str]|None=None)->dict:
    if not active_for(text,source_traits):
        return {"active":False,"addon_id":ADDON_ID,"version":VERSION}
    preset=detect_preset(text)
    left=_extract(text,"COLOR_LEFT") or ("PINK_MAGENTA" if preset else "PINK")
    right=_extract(text,"COLOR_RIGHT") or ("ELECTRIC_BLUE_CYAN" if preset else "CYAN")
    midpoint=_extract(text,"TRANSITION_MIDPOINT") or ("VIOLET_FUSION" if preset else "VIOLET")
    transition=(_extract(text,"COLOR_TRANSITION") or "continuous").casefold()
    if transition not in {"continuous","segmented","none"}: transition="continuous"
    material=(_extract(text,"MATERIAL_PROFILE") or "HYBRID_GLASS_METAL").upper()
    if material not in MATERIALS: material="HYBRID_GLASS_METAL"
    energy=(_extract(text,"ENERGY_STYLE") or "hybrid").casefold()
    if energy not in ENERGY_STYLES: energy="hybrid"
    aspect=_extract(text,"ASPECT_RATIO") or ("16:9" if preset else None)
    background=(_extract(text,"BACKGROUND") or "clean_dark").casefold()
    if background not in BACKGROUNDS: background="custom"
    symbol_fidelity=(_extract(text,"SYMBOL_FIDELITY") or "high").casefold()
    if symbol_fidelity not in {"low","medium","high","strict"}: symbol_fidelity="high"
    typography=(_extract(text,"TYPOGRAPHY_ENABLED") or "false").casefold() in {"1","true","yes","on"}
    human_priority=(_extract(text,"HUMAN_PRIORITY") or "true").casefold() in {"1","true","yes","on"}
    return {
        "active":True,
        "addon_id":ADDON_ID,
        "name":NAME,
        "version":VERSION,
        "mode":MODE,
        "core_replacement":"FORBIDDEN",
        "existing_module_rename":"FORBIDDEN",
        "existing_prompt_logic_delete":"FORBIDDEN",
        "hook_strategy":"ADAPTER",
        "hook":HOOK,
        "preset_id":preset,
        "symbol_fidelity":symbol_fidelity,
        "source_symbol_authority":"HIGH",
        "topology_preservation":"REQUIRED",
        "interweave_continuity":"REQUIRED",
        "accidental_symmetrization":"FORBIDDEN",
        "accidental_infinity_replacement":"FORBIDDEN",
        "source_character_loss":"FORBIDDEN",
        "color_left":left,
        "color_right":right,
        "transition_midpoint":midpoint,
        "color_transition":transition,
        "default_color_flow":list(COLOR_FLOW),
        "material_profile":material,
        "material_translation_may_change_topology":False,
        "energy_style":energy,
        "energy_intensity":_int_value(text,"ENERGY_INTENSITY",8 if preset else 7,1,10),
        "human_priority":human_priority,
        "typography_enabled":typography,
        "aspect_ratio":aspect,
        "background":background,
        "hud_density":_int_value(text,"HUD_DENSITY",5 if preset else 4,0,10),
        "photorealism":_int_value(text,"PHOTOREALISM",9,1,10),
        "modules":[
            "SYMBOL_RECONSTRUCTION_ENGINE",
            "CONTINUOUS_COLOR_FUSION_ENGINE",
            "INTERWOVEN_GEOMETRY_ENGINE",
            "NEON_ENERGY_LASER_ENGINE",
            "PHOTOREALISTIC_MATERIAL_TRANSLATION",
            "HUMAN_SYMBOL_INTEGRATION_ENGINE",
            "SEMANTIC_TYPOGRAPHY_ENGINE",
            "CINEMATIC_CYBER_INTERFACE_COMPOSITOR",
        ],
        "guards":["SYMBOL_FIDELITY_GUARD","PHOTOREALISM_GUARD","GLOW_GUARD","TEXT_GUARD"],
        "composition_priority":["HUMAN_SUBJECT_OR_PRIMARY_OBJECT","SOURCE_SYMBOL","SYMBOLIC_RELATIONSHIP","LIGHT_AND_ENERGY","TYPOGRAPHY","ENVIRONMENT","HUD_AND_DECORATIVE_DETAIL"],
        "duplicate_capability_map":{
            "IDENTITY_AND_MULTI_REFERENCE":"PRG-CVICE-002",
            "BASE_PHOTOREALISM":"CORE_PHOTOREALISM",
            "MATERIAL_REALISM":"MATERIAL_REALISM",
            "TEXT_ACCURACY":"EXACT_TYPOGRAPHY_ENGINE",
            "ASPECT_ROUTING":"ASPECT_RATIO_ENGINE",
            "HUD_COMPOSITION":"CONTENT_AWARE_COMPOSITION_ENGINE",
        },
        "specialized_new_authority":[
            "SOURCE_SYMBOL_TOPOLOGY",
            "CONTINUOUS_FORM_COLOR_FUSION",
            "INTERWOVEN_FRONT_BACK_GEOMETRY",
            "SEMANTIC_ENERGY_CONVERGENCE",
        ],
        "repair_policy":"TARGET_AFFECTED_LAYER_ONLY_THEN_REAUDIT",
        "umip_primary_target":False,
        "destructive_integration":False,
    }

def compact_directive(r:dict)->str:
    if not r.get("active"): return ""
    preset = f" Load preset {r['preset_id']}." if r.get("preset_id") else ""
    typo = " Enable semantic typography only when explicitly requested; preserve exact spelling and forbid unrequested text." if r.get("typography_enabled") else " Do not invent visible text."
    return (
        f"{ADDON_ID} v{VERSION}: ADD-ONLY symbolic composition adapter after source analysis and before render composition.{preset} "
        f"Preserve source-symbol identity and topology at fidelity={r['symbol_fidelity']}; keep loops, crossings, characteristic asymmetry and interwoven front/back continuity. "
        f"Never replace an individual symbol with a generic infinity mark and never auto-symmetrize it. "
        f"Run continuous physical color fusion {r['color_left']} -> {r['transition_midpoint']} -> {r['color_right']} with transition={r['color_transition']}; interpolate material color, emission and reflected light together along the connected form without hard seams. "
        f"Translate geometry to {r['material_profile']} without changing topology. Apply {r['energy_style']} neon/laser/electrical energy at intensity {r['energy_intensity']}/10 with controlled bloom, retained color core, plausible source points, micro-sparks and environmental light spill. "
        f"Human priority={str(r['human_priority']).upper()}; if people exist, protect face anatomy, natural skin and identity above decoration, and make symbol light physically affect skin, hair, clothing and environment. "
        f"HUD density={r['hud_density']}/10; HUD/circuit/ECG/holographic/particle/skyline/botanical/frame layers remain secondary and may not cover the symbol, primary object or faces."
        + typo +
        " Use CVICE for multi-reference/identity authority and existing host realism/material/aspect/text modules where equivalent; do not duplicate them. On audit failure repair only the affected layer and re-audit."
    )
