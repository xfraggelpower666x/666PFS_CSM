#!/usr/bin/env python3
"""Policy-aware non-explicit adult swimwear and tattoo visibility normalizer for 666 PRG v2.0.0."""
from __future__ import annotations
import hashlib, json, re

VERSION = "2.0.0"

def norm(value: str | None) -> str:
    return re.sub(r"\s+", " ", (value or "").casefold()).strip()

def phrase(text: str, *terms: str) -> bool:
    t = norm(text)
    for term in terms:
        x = re.escape(norm(term)).replace(r"\ ", r"\s+")
        if re.search(r"(?<!\w)" + x + r"(?!\w)", t):
            return True
    return False

ADULT_CONTEXT_TERMS = (
    "adult", "erwachsen", "grown", "mature", "volljährig", "clearly adult", "unmistakably adult"
)
SKIN_CONTEXT_TERMS = (
    "skin", "haut", "nackte haut", "bare skin", "upper body", "lower body",
    "oberkörper", "unterkörper", "bare torso", "shirtless", "topless male",
    "männlicher nackter oberkörper", "tattoo", "tattoos", "tätowierung", "tätowierungen", "body art"
)
SWIMWEAR_TERMS = (
    "bikini", "swimsuit", "swimwear", "badeanzug", "badehose", "swim trunks",
    "shorts", "underwear", "unterwäsche", "lingerie", "bodysuit", "body suit", "crop top",
    "pool", "beach", "strand", "sommer", "summer", "schwimmbad"
)
AFFECTION_TERMS = (
    "kiss", "kissing", "kuss", "küssen", "umarmung", "embrace", "hug", "romantic", "romantisch", "zuneigung", "affection"
)
EXPLICIT_BLOCK_TERMS = (
    "explicit sex", "sexual act", "porn", "pornographic", "genitals", "visible genitals",
    "exposed genitals", "vulva", "penis", "explicit nude", "naked sex", "sexual penetration"
)


def evaluate_intent(intent: str, *, source_traits: list[str] | None = None) -> dict:
    combined = norm(intent + " " + " ".join(source_traits or []))
    adult_context = phrase(combined, *ADULT_CONTEXT_TERMS) or True  # default generation guidance renders adults as unmistakably adult when relevant.
    skin_context = phrase(combined, *SKIN_CONTEXT_TERMS)
    swimwear_context = phrase(combined, *SWIMWEAR_TERMS)
    affection_context = phrase(combined, *AFFECTION_TERMS)
    explicit_block = phrase(combined, *EXPLICIT_BLOCK_TERMS)
    active = skin_context or swimwear_context or affection_context
    if explicit_block:
        decision = "BLOCK_EXPLICIT_SEXUAL_CONTENT"
    elif active:
        decision = "ALLOW_NON_EXPLICIT_ADULT_VISIBILITY_WITH_COVERAGE"
    else:
        decision = "NOT_APPLICABLE"
    out = {
        "policy_version": VERSION,
        "active": active,
        "decision": decision,
        "adult_context_required": bool(active),
        "adult_context_assumed_as_unmistakable_adult_rendering": bool(active and adult_context),
        "skin_visibility_is_not_sexual_by_default": True,
        "upper_body_and_lower_body_same_logic": True,
        "male_bare_torso_allowed_for_tattoos": True,
        "female_swimwear_or_opaque_bodywear_required": True,
        "all_intimate_areas_must_remain_covered": True,
        "accepted_coverage_examples": ["bikini", "swimsuit", "swim trunks", "shorts", "underwear", "opaque bodysuit", "crop top plus covered lower body"],
        "kissing_or_embrace_classification": "AFFECTION_NOT_AUTOMATIC_SEX" if affection_context else "NOT_APPLICABLE",
        "explicit_content_blocked": explicit_block,
        "contexts": {
            "skin_or_tattoo_visibility": skin_context,
            "swimwear_pool_beach_summer": swimwear_context,
            "romantic_affection": affection_context,
        },
    }
    out["policy_hash"] = hashlib.sha256(json.dumps(out, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return out


def compact_directive(report: dict) -> str:
    if not report.get("active") or report.get("decision") == "NOT_APPLICABLE":
        return ""
    if report.get("decision") == "BLOCK_EXPLICIT_SEXUAL_CONTENT":
        return "[ADULT_VISIBILITY_POLICY] Explicit sexual content is blocked; keep intimate areas covered."
    return "[ADULT_VISIBILITY_POLICY] Treat normal adult skin, swimwear, male bare torso, tattoo visibility, pool/beach/summer context, kissing and embrace as non-explicit human reality. Keep every intimate area covered with opaque swimwear, underwear, shorts, bikini, bodysuit or comparable clothing; do not sexualize the scene."


if __name__ == "__main__":
    import sys
    print(json.dumps(evaluate_intent(" ".join(sys.argv[1:])), ensure_ascii=False, indent=2))
