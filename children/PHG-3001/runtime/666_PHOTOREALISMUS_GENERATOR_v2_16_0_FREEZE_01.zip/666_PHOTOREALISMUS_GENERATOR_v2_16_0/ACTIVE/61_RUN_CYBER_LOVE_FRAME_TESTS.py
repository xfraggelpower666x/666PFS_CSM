#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, sys
ROOT=Path(__file__).resolve().parent

def load(name,file):
    s=importlib.util.spec_from_file_location(name, ROOT/file); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
F=load("clf","60_CYBER_LOVE_FRAME_ADDON.py")
C=load("compiler","26_PROMPT_COMPILER.py")
M=load("frame","38_FRAME_MODES.py")
checks=[]
def ok(name,cond): checks.append((name,bool(cond)))

r=F.analyze("CYBER LOVE FRAME SYSTEM")
ok("CLF01 active explicit",r["active"])
ok("CLF02 id exact",r["addon_id"]=="PRG-ADDON-CYBER-LOVE-FRAME-001")
ok("CLF03 default top",r["top_text"]=="I LOVE YOU")
ok("CLF04 default bottom",r["bottom_text"]=="ENDLESS")
ok("CLF05 additive",r["mode"]=="ADD_ONLY" and r["core_replacement"]=="FORBIDDEN")
ok("CLF06 preservation",r["reference_preservation"]=="MANDATORY")
ok("CLF07 balanced default",r["complexity_level"]==2)
ok("CLF08 minimal",F.analyze("cyber love frame level 1 minimal frame")["complexity_level"]==1)
ok("CLF09 extreme",F.analyze("cyber love frame level 3 extreme frame")["complexity_level"]==3)
ok("CLF10 infinity route",F.analyze("cyber love frame cyber infinity")["variation"]=="CYBER_INFINITY")
ok("CLF11 distance route",F.analyze("cyber love frame distance love")["variation"]=="DISTANCE_LOVE")
custom=F.analyze("cyber love frame TOP_TEXT=HELLRAISER + ANGELIQUE\nBOTTOM_TEXT=Two Bloods One Heart")
ok("CLF12 custom top exact",custom["top_text"]=="HELLRAISER + ANGELIQUE")
ok("CLF13 custom bottom exact",custom["bottom_text"]=="Two Bloods One Heart")
ok("CLF14 safe occupancy",r["frame_occupancy_recommended_percent"]==[6,12] and r["frame_occupancy_max_percent"]==15)
ok("CLF15 no plain activation",not F.analyze("photorealistic romantic portrait of a couple")["active"])
fm=M.analyze("cyber love frame with infinity")
ok("CLF16 existing frame base",fm["active"] and fm["mode"]=="FRAME_MODE_CYBER_LOVE_HOLO")
cp=C.compile_prompt("cyber love frame TOP_TEXT=I LOVE YOU\nBOTTOM_TEXT=ENDLESS")
ok("CLF17 compiler report",cp["cyber_love_frame_report"]["active"])
ok("CLF18 compiler directive","[CYBER_LOVE_FRAME_ADDON]" in cp["compiled_prompt"])
ok("CLF19 exact text in prompt","'I LOVE YOU'" in cp["compiled_prompt"] and "'ENDLESS'" in cp["compiled_prompt"])
ok("CLF20 no unrelated injection",not C.compile_prompt("photorealistic city at noon")["cyber_love_frame_report"]["active"])
ok("CLF21 registry selected","CYBER_LOVE_FRAME_ADDON" in cp["selected_modules"])
ok("CLF22 no random text",cp["cyber_love_frame_report"]["random_text"]=="FORBIDDEN")
ok("CLF23 four sides",cp["cyber_love_frame_report"]["frame_zones"]==["TOP_FRAME","BOTTOM_FRAME","LEFT_SIDE_FRAME","RIGHT_SIDE_FRAME"])
ok("CLF24 shared lighting","PINK_TOP_SPILL" in cp["cyber_love_frame_report"]["light_interaction"] and "CYAN_BOTTOM_REFLECTION" in cp["cyber_love_frame_report"]["light_interaction"])
failed=[n for n,v in checks if not v]
for n,v in checks: print(("PASS" if v else "FAIL"),n)
print(f"CYBER LOVE FRAME ADDON TESTS = {len(checks)-len(failed)}/{len(checks)} PASS")
if failed: sys.exit(1)
