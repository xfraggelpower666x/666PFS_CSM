#!/usr/bin/env python3
"""PHG-3001 v2.8.0 Cyber Love Holo Dance preset family."""
from __future__ import annotations
import re

VERSION="1.0.0"
PRESET_ID="PRESET_09"
PRESET_NAME="CYBER_LOVE_HOLO_DANCE"

SUBPRESETS={
"A":{"id":"PRESET_09_A","name":"CYBER_LOVE_HOLO_DANCE_TANGO_CLOSE","pose":"TANGO_CLOSE_HOLD","body":"CLOSE_CONNECTED,INTENSE,ELEGANT,CONTROLLED","arms":"CLASSIC_PARTNER_HOLD","legs":"CROSSED_STEP,FORWARD_PRESSURE","torso":"CLOSE","head":"PARTNER_LOCK","energy":"MEDIUM_HIGH","priority":"FACE_CONTACT,HAND_CLARITY,LEG_LINE,POSTURE_BALANCE"},
"B":{"id":"PRESET_09_B","name":"CYBER_LOVE_HOLO_DANCE_DIP","pose":"ROMANTIC_DIP","body":"DRAMATIC,ELEGANT,TRUSTED,CONNECTED","arms":"SUPPORT_BACK,HAND_EXTENSION","legs":"ONE_LEG_EXTENDED,ONE_LEG_SUPPORTED","torso":"DIPPED_CURVE","head":"ROMANTIC_GAZE","energy":"HIGH","priority":"SAFE_ANATOMY,BACK_SUPPORT,HAND_PLACEMENT,LEG_EXTENSION"},
"C":{"id":"PRESET_09_C","name":"CYBER_LOVE_HOLO_DANCE_EXTENDED_LINE","pose":"EXTENDED_LINE_POSE","body":"LONG,ELEGANT,STRETCHED,DYNAMIC","arms":"ONE_ARM_EXTENDED,ONE_ARM_SUPPORT","legs":"LONG_FRONT_LINE,REAR_SUPPORT","torso":"OPEN_ANGLE","head":"SIDE_PROFILE_OR_PARTNER_GAZE","energy":"MEDIUM_HIGH","priority":"FULL_BODY_VISIBILITY,LINE_CLEANNESS,SILHOUETTE_READABILITY"},
"D":{"id":"PRESET_09_D","name":"CYBER_LOVE_HOLO_DANCE_ROTATION","pose":"ROTATIONAL_PARTNER_POSE","body":"FLOWING,DYNAMIC,LIGHTLY_SPINNING,CONNECTED","arms":"ROTATION_GUIDE,HAND_CONNECTION","legs":"TURN_STEP,WEIGHT_SHIFT","torso":"SEMI_OPEN","head":"MOTION_OR_PARTNER_TRACK","energy":"HIGH","priority":"MOTION_READABILITY,BALANCE,HAND_LINK,SKIRT_AND_PANTS_FLOW"},
"E":{"id":"PRESET_09_E","name":"CYBER_LOVE_HOLO_DANCE_CLOSE_CLUB","pose":"CLOSE_CLUB_DANCE","body":"INTIMATE,RELAXED,SENSUAL,CONNECTED","arms":"WAIST_HOLD,SHOULDER_TOUCH","legs":"SOFT_STEP,CLOSE_STANCE","torso":"VERY_CLOSE","head":"FOREHEAD_NEAR,SOFT_GAZE","energy":"MEDIUM","priority":"EMOTIONAL_PROXIMITY,FACE_VISIBILITY,SOFT_POSTURE,NATURAL_CONTACT"},
"F":{"id":"PRESET_09_F","name":"CYBER_LOVE_HOLO_DANCE_STAGE_SHOW","pose":"STAGE_SHOWCASE_POSE","body":"PERFORMATIVE,POWERFUL,ELEGANT,DISPLAY_READY","arms":"HIGH_FRAME,SHOWCASE_EXTENSION","legs":"WIDE_BASE,SHOW_POSE","torso":"OPEN_PRESENTATION","head":"PROUD_FORWARD_OR_PARTNER_GAZE","energy":"HIGH","priority":"STAGE_PRESENCE,FULL_BODY,SYMMETRY,FRAME_BALANCE"},
"G":{"id":"PRESET_09_G","name":"CYBER_LOVE_HOLO_DANCE_FOREHEAD_INTIMACY","pose":"FOREHEAD_TO_FOREHEAD_HOLD","body":"STILL_INTIMATE,SLOW_DANCE,EMOTIONAL","arms":"CHEST_TO_WAIST_HOLD","legs":"SOFT_CLOSE_STEP","torso":"CLOSE","head":"FOREHEAD_CONTACT","energy":"LOW_MEDIUM","priority":"FACIAL_EMOTION,INTIMACY,CONTACT_REALISM,SOFT_LIGHT_RESPONSE"},
"H":{"id":"PRESET_09_H","name":"CYBER_LOVE_HOLO_DANCE_SIDE_DIP","pose":"SIDE_DIP","body":"DRAMATIC,SIDE_SWEEP,ELEGANT","arms":"SIDE_SUPPORT,OUTER_ARM_EXTENSION","legs":"SIDE_EXTENSION,BALANCED_SUPPORT","torso":"SIDE_CURVE","head":"OUTWARD_OR_PARTNER_GAZE","energy":"HIGH","priority":"CLEAR_SILHOUETTE,SAFE_SUPPORT,ARM_EXTENSION,LEG_SHAPE"},
}
ROUTES=[
(("side dip","side lean"),"H"),
(("forehead","slow dance","soft romance"),"G"),
(("stage","showcase","performance","hero pose"),"F"),
(("close club","club dance","intimate dance"),"E"),
(("spin","turn","rotation","twirl"),"D"),
(("extended line","elegant line","extended pose","long pose"),"C"),
(("dramatic dip","lean back","dip"),"B"),
(("tango","close hold"),"A"),
]
TRIGGERS=("cyber love holo dance","cyber_love_holo_dance","preset_09","dance holo","holo dance","tanzpose","tanz pose")

def _norm(v:str)->str:
    return re.sub(r"\s+"," ",(v or "").casefold()).strip()

def active_for(text:str)->bool:
    t=_norm(text)
    return any(x in t for x in TRIGGERS)

def route(text:str)->dict:
    t=_norm(text)
    # exact subpreset id/name wins
    for key,item in SUBPRESETS.items():
        if item["id"].casefold() in t or item["name"].casefold() in t:
            return dict(item)
    for terms,key in ROUTES:
        if any(term in t for term in terms):
            return dict(SUBPRESETS[key])
    return dict(SUBPRESETS["A"])

def analyze(text:str, *, preset_active:bool=False)->dict:
    active=bool(preset_active or active_for(text))
    if not active:
        return {"active":False,"version":VERSION,"preset_id":PRESET_ID}
    sub=route(text)
    return {
        "active":True,
        "version":VERSION,
        "preset_id":PRESET_ID,
        "preset_name":PRESET_NAME,
        "subpreset":sub,
        "frame_mode":"CYBER_LOVE_HOLO",
        "scene_style":"PHOTOREALISTIC_CINEMATIC",
        "subject_mode":"COUPLE",
        "couple_engine":"ACTIVE",
        "identity_protection":"HIGH",
        "face_body_integration":"HARDLOCK",
        "photorealism_priority":"MAX",
        "top_text_default":"HELLRAISER + ANGELIQUE",
        "bottom_text_default":"Two Bloods One Heart",
        "text_exactness":"STRICT",
        "text_content_mutation":"FORBIDDEN",
        "frame_elements":["HEARTS","ROSES","HOLO_CIRCUITS","MUSIC_SYMBOLS","ECG_LINE","SPARKS","NEON_CORNERS"],
        "frame_safe_margin_percent":5,
        "full_body_preference":"HIGH",
    }

def compact_directive(report:dict)->str:
    if not report.get("active"): return ""
    s=report["subpreset"]
    return (
        f"PRESET_09 CYBER_LOVE_HOLO_DANCE: preserve two distinct adult identities and photographic anatomy; "
        f"use FRAME_MODE=CYBER_LOVE_HOLO with hearts, roses, holo circuits, music/ECG accents and a complete 5% safe frame. "
        f"Route pose to {s['id']} {s['pose']}: body={s['body']}; arms={s['arms']}; legs={s['legs']}; torso={s['torso']}; head={s['head']}; "
        f"render priority={s['priority']}. Keep hands/legs plausible and full body readable where possible. "
        f"Default frame text if not overridden: top exact 'HELLRAISER + ANGELIQUE'; bottom exact 'Two Bloods One Heart'. "
        f"User-supplied text overrides defaults only for the specified zone; never mutate wording and never cover faces/eyes/body core."
    )
