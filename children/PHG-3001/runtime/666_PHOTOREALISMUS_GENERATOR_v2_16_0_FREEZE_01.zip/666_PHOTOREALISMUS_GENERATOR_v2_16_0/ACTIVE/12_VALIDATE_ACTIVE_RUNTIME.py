#!/usr/bin/env python3
"""Deep structural and executable-component validator for 666 PRG current child release (runtime schema baseline v2.0.0)."""
from pathlib import Path
import ast
import json
import sys

R = Path(__file__).resolve().parent

def load(name): return json.loads((R / name).read_text(encoding="utf-8"))

manifest=load('00_ACTIVE_MANIFEST.json'); model=load('01_CANONICAL_STATE_MODEL.json'); events=load('02_EVENT_CATALOG.json')
orch=load('03_ORCHESTRA_REGISTER.json'); guards=load('04_GUARD_REGISTER.json'); mx=load('05_EXECUTION_MATRIX.json')
config=load('06_RUNTIME_KERNEL_CONFIG.json'); handlers=load('29_GUARD_HANDLER_REGISTRY.json')
errors=[]

def unique(items,key,label):
    vals=[x[key] for x in items]
    if len(vals)!=len(set(vals)): errors.append(f'DUPLICATE {label}')
    return set(vals)

states=set(model['states']); groups=model.get('state_groups',{}); event_ids=unique(events['events'],'id','EVENT_ID')
oids=unique(orch['orchestras'],'id','ORCHESTRA_ID'); gids=unique(guards['guards'],'id','GUARD_ID'); mids=unique(mx['rows'],'id','MATRIX_ID')
if manifest.get('version')!=manifest.get('child_release_version'): errors.append('ACTIVE MANIFEST / CHILD RELEASE VERSION MISMATCH')
if config.get('version')!='2.0.0': errors.append('RUNTIME SCHEMA BASELINE VERSION MISMATCH')
if manifest.get('active_root')!='ACTIVE': errors.append('ACTIVE ROOT POINTER INVALID')
if orch.get('supervisor') not in oids: errors.append('SUPERVISOR MISSING')
if guards.get('default_policy')!='DENY_UNREGISTERED_PATH' or config.get('default_policy')!='DENY_UNREGISTERED_PATH': errors.append('DEFAULT DENY MISSING')
for filename in ('11_RUNTIME_KERNEL.py','19_HOST_TURN_EXECUTOR.py','22_RUNTIME_STORE.py','26_PROMPT_COMPILER.py','27_VISUAL_QA_ENGINE.py','28_HOST_RESULT_EXECUTOR.py','29_GUARD_HANDLER_REGISTRY.json','30_RUN_V154_ACCEPTANCE_TESTS.py','33_CHARACTER_TRANSFORMATION_DIRECTOR.py','34_CREATIVE_RUNTIME_PROFILES.json','31_IDENTITY_CORE.py','32_IDENTITY_PROFILE_SCHEMA.json','47_CYBER_GARDEN_ENGINE.py','48_CYBER_GARDEN_REGISTRY.json','49_RUN_CYBER_GARDEN_TESTS.py'):
    if not (R/filename).is_file(): errors.append(f'MISSING ACTIVE FILE {filename}')
for p in R.glob('*.py'):
    try: ast.parse(p.read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'PYTHON_PARSE:{p.name}:{exc}')
for group,values in groups.items():
    for state in values:
        if state not in states: errors.append(f'GROUP {group} UNKNOWN STATE {state}')
seen=set()
for row in mx['rows']:
    pair=(row['state'],row['event'])
    if pair in seen: errors.append(f'DUPLICATE MATRIX PAIR {pair}')
    seen.add(pair)
    if row['state'].startswith('@'):
        if row['state'][1:] not in groups: errors.append(f"{row['id']} UNKNOWN GROUP")
    elif row['state'] not in states: errors.append(f"{row['id']} UNKNOWN STATE")
    if row['event'] not in event_ids: errors.append(f"{row['id']} UNKNOWN EVENT")
    if row['orchestra'] not in oids: errors.append(f"{row['id']} UNKNOWN ORCHESTRA")
    for gid in row.get('guards',[]):
        if gid not in gids: errors.append(f"{row['id']} UNKNOWN GUARD {gid}")
    for field in ('next_state','failure_state'):
        if row[field]!='$SAME' and row[field] not in states: errors.append(f"{row['id']} UNKNOWN {field}")

# Reachability and safe complete path.
adj={s:set() for s in states}
for row in mx['rows']:
    sources=groups.get(row['state'][1:],[]) if row['state'].startswith('@') else [row['state']]
    for src in sources:
        for dest in (row['next_state'],row['failure_state']): adj[src].add(src if dest=='$SAME' else dest)
reachable={model.get('initial_state','IDLE')}
while True:
    nxt=reachable|{d for s in reachable for d in adj.get(s,set())}
    if nxt==reachable: break
    reachable=nxt
for state in states-reachable: errors.append(f'UNREACHABLE STATE {state}')
for row in mx['rows']:
    if row['next_state']=='COMPLETE' and not (row['state']=='VISUAL_QA_PASSED' and row['event']=='COMMIT_SUCCESS'):
        errors.append(f"UNSAFE COMPLETE PATH {row['id']}")

# Retry and repair must re-enter compiler.
for rid in ('MX-029','MX-031'):
    row=next((x for x in mx['rows'] if x['id']==rid),None)
    if not row or row['next_state']!='SOURCE_REGISTERED': errors.append(f'{rid} DOES NOT REENTER COMPILER')

# Every hard guard has an active executable component mapping.
handler_map={x['guard_id']:x for x in handlers.get('handlers',[])}
for guard in guards['guards']:
    if guard.get('severity') not in {'HARD','HARDLOCK'}: errors.append(f"GUARD METADATA INCOMPLETE {guard['id']}")
    h=handler_map.get(guard['id'])
    if not h: errors.append(f"NO HANDLER {guard['id']}"); continue
    if h.get('enforcement')!='EXECUTABLE_COMPONENT' or h.get('status')!='ACTIVE': errors.append(f"INACTIVE HANDLER {guard['id']}")
    if not (R/h.get('component','')).is_file(): errors.append(f"BROKEN HANDLER COMPONENT {guard['id']}")
for gid in handler_map:
    if gid not in gids: errors.append(f'ORPHAN HANDLER {gid}')

# Version/meta drift.
for collection,label in ((orch['orchestras'],'ORCHESTRA'),(guards['guards'],'GUARD')):
    for item in collection:
        if item.get('binding_version')!='2.0.0': errors.append(f"{label} VERSION DRIFT {item['id']}")
        if item.get('status')!='ACTIVE': errors.append(f"{label} STATUS DRIFT {item['id']}")

actual={'registered_states':len(states),'registered_events':len(event_ids),'registered_orchestras':len(oids),'registered_guards':len(gids),'execution_matrix_rows':len(mids)}
for key,value in actual.items():
    if manifest.get(key)!=value: errors.append(f'MANIFEST COUNT MISMATCH {key}')

if errors:
    print('ACTIVE RUNTIME VALIDATION = FAIL'); print('\n'.join(errors)); sys.exit(1)
print(f"ACTIVE RUNTIME VALIDATION = PASS ({len(states)} states, {len(event_ids)} events, {len(oids)} orchestras, {len(gids)} guards, {len(mids)} matrix rows, {len(handler_map)} executable guard bindings)")
