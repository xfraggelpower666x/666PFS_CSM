#!/usr/bin/env python3
"""PHG-3001 v2.4.0 preset/reference/typography/narrative/cyber expansion engine."""
from __future__ import annotations
from pathlib import Path
import json, re

VERSION = "2.12.0"
ROOT = Path(__file__).resolve().parent
REGISTRY = json.loads((ROOT / "44_PHOTOREALISTIC_PRESET_REGISTRY.json").read_text(encoding="utf-8"))

PRESET_ALIASES = {
    "LOVE_FRAME_NEON_PINK": ("love frame neon pink", "neon pink love frame", "pink love frame"),
    "LOVE_FRAME_ELECTRIC_BLUE": ("love frame electric blue", "electric blue love frame", "blue love frame"),
    "OLD_OMEN_ROSE_STARS": ("old omen rose stars", "gods scribed my fate in stars", "love rose from the old omen"),
    "STARS_BLUE_TANG_FATE": ("stars blue tang fate", "a love older than the stars still calls my name", "fate answers in your voice"),
    "DEEP_DARK_CRAZY_NEON": ("deep dark crazy neon", "deep dark crazy"),
    "EMOTIONAL_LOVE_MESSAGE": ("emotional love message", "long romantic message"),
    "SUNSET_ACCEPTANCE_MESSAGE": ("sunset acceptance message", "acceptance message", "be yourself message"),
    "DARK_ROMANTIC_MESSAGE": ("dark romantic message", "dark romance message"),
    "CYBER_BIRTHDAY_PURPLE_PINK_LOVE": ("cyber birthday purple pink love", "purple pink birthday love", "holographic birthday heart"),
    "CYBER_BIRTHDAY_ELECTRIC_BLUE": ("cyber birthday electric blue", "electric blue cyber birthday", "blue cyber love"),
    "CYBER_BIRTHDAY_HYBRID_BLUE_PURPLE_PINK": ("cyber birthday hybrid blue purple pink", "hybrid blue purple pink cyber birthday", "preferred cyber birthday combination"),
    "PRESET_09": ("cyber love holo dance", "cyber love holographic dance", "holo dance preset", "romantic cyber dance"),
    "PRG-PRESET-ILY-ENDLESS-001": ("i love you endless preset", "i love you endless cyber love frame", "ily endless"),
    "PRG-PRESET-ILY-ENDLESS-NEON-EMBRACE-001": ("i love you endless neon embrace", "neon embrace display", "photo derived i love you endless"),
    "RELATIONAL_NEON_HEART": ("relational neon heart", "relational_neon_heart", "interwoven neon heart symbol"),
}
REFERENCE_TERMS=("reference image","reference photo","referenzbild","referenzfoto","source image","source photo","same image","same people","same pose","gleiches bild","dieses bild","vorlage","original image")
FRAME_TERMS=("frame","border","rahmen","umrandung","bildrand","neonrahmen","hologrammrahmen","barbed wire")
EXACT_TEXT_TERMS=("exact text","exactly","strict text","exakter text","genau dieser text","uppercase","groß geschrieben","gross geschrieben")
TEXT_OVERRIDE_BLUE_FISH=("write blue fish","text blue fish","words blue fish","schreibe blue fish","blue fish als text")
LONG_MESSAGE_TERMS=("message","long text","narrative","paragraph","manifest","romantic message","birthday message","acceptance","be yourself","trust","warmth")
HYBRID_TERMS=("plus long message","frame labels plus","hybrid frame narrative","i love you","happy birthday my angel")
CYBER_TERMS=("cyber","holo","holographic heart","barbed wire","birthday my angel","winged heart")
ENGLISH_ONLY_TERMS=("text only english","only english","all visible text language english")
GERMAN_HEART_TEXT=("happy birthday mein engel",)

def _norm(v:str|None)->str:
    return re.sub(r"\s+"," ",(v or "").casefold()).strip()

def _contains_any(text:str,terms)->bool:
    return any(term in text for term in terms)

def detect_preset(text:str)->str|None:
    t=_norm(text)
    for preset_id in REGISTRY["presets"]:
        if _norm(preset_id) in t:
            return preset_id
    for preset_id,aliases in PRESET_ALIASES.items():
        if any(alias in t for alias in aliases):
            return preset_id
    if "happy birthday my angel" in t and "cyber" in t:
        if "electric blue" in t:
            return "CYBER_BIRTHDAY_ELECTRIC_BLUE"
        if all(x in t for x in ("purple","pink")):
            return "CYBER_BIRTHDAY_PURPLE_PINK_LOVE"
        return "CYBER_BIRTHDAY_HYBRID_BLUE_PURPLE_PINK"
    return None

def extract_quoted_literals(text:str)->list[str]:
    found=[]
    for m in re.finditer(r'(["“”])(.+?)\1|\'([^\']+)\'', text or ""):
        value=(m.group(2) or m.group(3) or "").strip()
        if value and value not in found:
            found.append(value)
    return found

def resolve_semantic_assets(text:str)->list[dict]:
    t=_norm(text); resolved=[]
    if "blue fish" in t and not _contains_any(t,TEXT_OVERRIDE_BLUE_FISH):
        item=dict(REGISTRY["semantic_assets"]["BLUE FISH"]); item["token"]="BLUE FISH"; resolved.append(item)
    return resolved

def classify_text_mode(text:str,preset:dict|None,quoted_literals:list[str])->str:
    t=_norm(text)
    if preset and preset.get("text_mode"):
        return str(preset.get("text_mode"))
    if _contains_any(t,HYBRID_TERMS) and (quoted_literals or _contains_any(t,FRAME_TERMS)):
        return "HYBRID_FRAME_NARRATIVE"
    if len(quoted_literals) >= 2 and len(" ".join(quoted_literals).split()) > 12:
        return "NARRATIVE_MESSAGE"
    if _contains_any(t,LONG_MESSAGE_TERMS):
        return "NARRATIVE_MESSAGE"
    if quoted_literals or _contains_any(t,FRAME_TERMS):
        return "FRAME_TEXT"
    return "AUTO"

def _preset_text_zones(preset:dict|None)->dict:
    if not preset:
        return {}
    mapping={}
    for key in ("top_text","bottom_left","bottom_center","bottom_right","bottom_text","hero_heart_text","lower_text"):
        if key in preset:
            mapping[key]=preset[key]
    return mapping

def analyze(text:str, *, source_traits:list[str]|None=None)->dict:
    t=_norm(text); traits={_norm(x) for x in (source_traits or [])}
    preset_id=detect_preset(text)
    preset=dict(REGISTRY["presets"].get(preset_id,{})) if preset_id else None
    reference_present=bool(_contains_any(t,REFERENCE_TERMS) or traits.intersection({"reference_image","reference_photo","source_image","image_reference","uploaded_image"}))
    semantic_assets=resolve_semantic_assets(text)
    quoted_literals=extract_quoted_literals(text)
    text_mode=classify_text_mode(text,preset,quoted_literals)
    frame_active=bool(preset_id or _contains_any(t,FRAME_TERMS))
    exact_text_active=bool(preset_id or _contains_any(t,EXACT_TEXT_TERMS) or quoted_literals or re.search(r"\bVELUNA\b|\bFRAGGEL\b", text or "", re.I))
    narrative_active=text_mode in {"NARRATIVE_MESSAGE","HYBRID_FRAME_NARRATIVE"}
    cyber_addon=bool((preset_id or "").startswith("CYBER_BIRTHDAY_") or _contains_any(t,CYBER_TERMS))
    policy=REGISTRY["policy"]
    active=bool(reference_present or preset_id or semantic_assets or frame_active or exact_text_active or cyber_addon or narrative_active)
    language='ENGLISH' if _contains_any(t,ENGLISH_ONLY_TERMS) else (('GERMAN' if _contains_any(t,GERMAN_HEART_TEXT) else None) or (preset or {}).get('text_language') or (policy['text_language_default'] if text_mode=='FRAME_TEXT' else policy['text_language_narrative_default']))
    casing=(preset or {}).get('text_case') or (policy['text_case_default'] if text_mode=='FRAME_TEXT' else policy['text_case_narrative_default'])
    layout='NARRATIVE' if narrative_active else 'FRAME'
    reference_mode='EDIT_NOT_REBUILD' if reference_present else None
    keep_composition=bool(reference_present and (narrative_active or cyber_addon or 'keep composition' in t or 'only change' in t or 'so in ordnung' in t))
    return {
        'active':active,
        'engine_version':VERSION,
        'components':list(REGISTRY['components']),
        'reference_present':reference_present,
        'reference_lock':policy['reference_image_lock'] if reference_present else None,
        'photorealism_priority':policy['photorealism_priority'],
        'locks':{
            'character':bool(reference_present and policy['character_lock']),
            'pose':bool(reference_present and policy['pose_lock']),
            'outfit':bool(reference_present and policy['outfit_lock']),
            'background':bool(reference_present and policy['background_lock_default']),
            'camera':bool(reference_present),'hair':bool(reference_present),'tattoos':bool(reference_present),'relative_positions':bool(reference_present),
            'composition':keep_composition,
        },
        'romantic_erotic_level':policy['romantic_erotic_level'],
        'preset_id':preset_id,'preset':preset,
        'text_mode':text_mode,
        'frame':{
            'active':frame_active or cyber_addon,
            'full_visibility':policy['frame_full_visibility'] if (frame_active or cyber_addon) else None,
            'safe_margin_percent':int((preset or {}).get('frame_safe_margin_percent', policy['frame_safe_margin_percent_default'])) if (frame_active or cyber_addon) else None,
            'edge_padding':policy['frame_edge_padding'] if (frame_active or cyber_addon) else None,
            'density':policy['frame_density_default'] if (frame_active or cyber_addon) else None,
            'subject_clear_zone':policy['subject_clear_zone'] if (frame_active or cyber_addon) else None,
            'layer_order':list(REGISTRY['layer_order']) if (frame_active or cyber_addon) else [],
            'style':(preset or {}).get('frame_style') or (preset or {}).get('frame_preset')
        },
        'typography':{
            'active':exact_text_active or narrative_active or cyber_addon,
            'language':language,
            'case':casing,
            'exactness':policy['text_exactness'],
            'fixed_name_locks':list(REGISTRY['fixed_name_locks']),
            'quoted_literals':quoted_literals,
            'preset_text_zones':_preset_text_zones(preset),
            'text_layout_mode':layout,
            'text_content_mutation':'FORBIDDEN',
            'semantic_text_emphasis':'STYLE_ONLY',
        },
        'narrative':{
            'active':narrative_active,
            'layout_mode':layout,
            'message_zone': narrative_active,
            'face_occlusion':'FORBIDDEN' if narrative_active else None,
            'eye_occlusion':'FORBIDDEN' if narrative_active else None,
            'text_subject_collision_check': narrative_active,
            'text_frame_collision_check': narrative_active,
            'readability_check': narrative_active,
            'content_aware_layout': 'ON' if narrative_active else None,
            'recommended_layouts': list(REGISTRY.get('composition_layouts',[])) if narrative_active else [],
        },
        'semantic_scene_binding':{
            'active': narrative_active,
            'style_only': True,
            'bindings': dict(REGISTRY.get('semantic_scene_binding',{})) if narrative_active else {},
        },
        'composition':{
            'reference_mode':reference_mode,
            'keep_composition':keep_composition,
            'change_only_requested_layers': keep_composition,
            'force_exact_request_mode': bool(keep_composition and cyber_addon),
        },
        'cyber_love_addon':{
            'active': cyber_addon,
            'hero_object':'HOLOGRAPHIC_HEART' if cyber_addon else None,
            'hero_object_interaction':'EMBRACED_BY_SUBJECT' if cyber_addon else None,
            'hero_heart_text': (preset or {}).get('hero_heart_text') or ('HAPPY BIRTHDAY MEIN ENGEL!' if _contains_any(t,GERMAN_HEART_TEXT) else 'HAPPY BIRTHDAY MY ANGEL!') if cyber_addon else None,
            'corner_heart_count': (preset or {}).get('corner_heart_count', 4) if cyber_addon else None,
            'lower_text': (preset or {}).get('lower_text','I LOVE YOU') if cyber_addon else None,
            'decoration_budget': 'LIMITED' if cyber_addon else None,
            'color_target_routing': bool(cyber_addon),
            'english_only_text': bool(_contains_any(t,ENGLISH_ONLY_TERMS)) if cyber_addon else False,
        },
        'semantic_assets': semantic_assets,
        'external_lyvra_system_mutation': False,
    }

def compact_directive(report:dict)->str:
    if not report.get('active'): return ''
    bits=[]
    if report.get('reference_present'):
        bits.extend([
            'Use the reference image as the primary composition and identity source.',
            'Preserve the same people, faces, hair, tattoos, outfits, pose, relative positioning, background, camera perspective and crop unless the user explicitly requests that specific element to change.',
        ])
    bits.append('Prioritize true photographic realism: natural skin texture, realistic hair strands, physically plausible lighting, realistic fabric/material response, photographic dynamic range, natural shadows/reflections and cinematic lens behavior.')
    bits.append('Reject 3D-render/game-screenshot drift, CGI plastic skin, anime, illustration, painterly rendering, waxy faces and doll-like anatomy; stylized decoration may affect only the requested frame/environment, not the human realism core.')
    preset=report.get('preset') or {}
    if report.get('preset_id'):
        bits.append(f"Load preset {report['preset_id']} exactly as registered; user-provided overrides supersede preset defaults only for the explicitly overridden field.")
        if report.get('preset_id') == 'PRESET_09':
            bits.append("PRESET_09 is the CYBER_LOVE_HOLO_DANCE family: keep two distinct adult identities, photorealistic anatomy, FRAME_MODE=CYBER_LOVE_HOLO, complete frame visibility, exact frame typography and a clearly readable partner-dance pose; pose-specific routing is delegated to the v2.8 dance router.")
        if report.get('preset_id') in {'PRG-PRESET-ILY-ENDLESS-001','PRG-PRESET-ILY-ENDLESS-NEON-EMBRACE-001'}:
            bits.append("This preset belongs to the I LOVE YOU / ENDLESS Cyber Love family and requires PRG-ADDON-CYBER-LOVE-FRAME-001; exact top/bottom text and no-additional-visible-words are hard requirements.")
    if report.get('text_mode') and report['text_mode'] != 'AUTO':
        bits.append(f"Classify visible text as {report['text_mode']} and keep TEXT_CONTENT_MUTATION=FORBIDDEN.")
    typo=report.get('typography') or {}
    if typo.get('active'):
        bits.append('Visible text is literal-locked: do not paraphrase, grammar-correct, synonymize, rename, add words, duplicate words or silently alter spelling/case. Preserve VELUNA and FRAGGEL exactly when present.')
        bits.append(f"Language policy: {typo.get('language')}. Case policy: {typo.get('case')}.")
        zones=typo.get('preset_text_zones') or {}
        if zones: bits.append('Preset text zones: ' + '; '.join(f"{k}={v}" for k,v in zones.items()) + '.')
        if typo.get('quoted_literals'): bits.append('Render quoted visible text literally where requested: ' + ' | '.join(typo['quoted_literals']) + '.')
    narrative=report.get('narrative') or {}
    if narrative.get('active'):
        bits.append('Use a dedicated narrative message zone with content-aware composition. Reserve negative space, protect faces/eyes and ensure readability before adding ornaments.')
        bits.append('Semantic emphasis may change typography only, never wording. Semantic scene binding may influence lighting/mood/decorative accents but must never override text, identity, locked pose, locked outfit or locked background.')
    for asset in report.get('semantic_assets') or []:
        bits.append(f"Resolve semantic token {asset['token']} as visual asset {asset['asset_id']}; TEXT_RENDER=OFF and ASSET_RENDER=ON. Asset definition: {asset['definition']}.")
    frame=report.get('frame') or {}
    if frame.get('active'):
        bits.append(f"Keep the complete frame fully visible on all four sides with {frame['safe_margin_percent']}% safe margin, edge padding, no cropped border elements and no text touching the canvas edge.")
        bits.append('Maintain a subject-clear zone: frame/ornaments/text/symbols/glow must not cover faces, eyes, hands, important tattoos, the central pose or important contact zones.')
        bits.append('Composite in this order: ' + ' -> '.join(frame.get('layer_order') or []) + '.')
    cyber=report.get('cyber_love_addon') or {}
    if cyber.get('active'):
        bits.append('Keep the human real, make the world cyber, make the love holographic, make the text exact, keep the frame complete and keep the symbols controlled.')
        bits.append('Use a holographic 3D heart as the primary emotional object, visibly embraced by the subject with plausible arm/hand interaction and no face occlusion.')
        bits.append(f"Render exact hero-heart text: {cyber.get('hero_heart_text')}.")
        bits.append('Render exactly four secondary corner hearts, a lower I LOVE YOU zone and a winged-heart motif without cluttering the face, hands or main text. Apply color-target routing so frame, love symbols, corner hearts, hero heart and lower symbol keep their requested colors without globally recoloring the whole image.')
        if report.get('composition',{}).get('keep_composition'):
            bits.append('REFERENCE_MODE=EDIT_NOT_REBUILD. Preserve the accepted composition and change only the requested layers.')
    bits.append('Non-explicit sensual romance may use intimacy, kissing, eye contact, embraces and sensual body language; do not introduce unnecessary nudity or explicit sexual activity.')
    return ' '.join(bits)

def diagnose_failure(flags:dict|None)->dict:
    flags=flags or {}
    mapping={
        'frame_cropped':'FRAME_CROPPED','cgi_drift':'STYLE_DRIFT_TO_CGI','text_reinterpreted':'TEXT_REINTERPRETATION','symbol_as_text':'SYMBOL_AS_TEXT','generic_fish':'GENERIC_FISH','overdecoration':'OVERDECORATION','identity_or_pose_drift':'IDENTITY_OR_POSE_DRIFT',
        'long_text_forced_into_frame':'LONG_TEXT_FORCED_INTO_FRAME','text_subject_collision':'TEXT_SUBJECT_COLLISION','face_occlusion_by_typography':'FACE_OCCLUSION_BY_TYPOGRAPHY','semantic_rewrite':'SEMANTIC_REWRITE','frame_style_contaminates_subject':'FRAME_STYLE_CONTAMINATES_SUBJECT','unreadable_long_message':'UNREADABLE_LONG_MESSAGE','overdecoration_with_long_text':'OVERDECORATION_WITH_LONG_TEXT','emphasis_changes_wording':'EMPHASIS_CHANGES_WORDING',
        'too_many_symbols':'TOO_MANY_SYMBOLS','wrong_color_target':'WRONG_COLOR_TARGET','german_text_in_english_mode':'GERMAN_TEXT_REMAINS_IN_ENGLISH_MODE','hero_heart_not_embraced':'HERO_HEART_NOT_EMBRACED','corner_hearts_wrong_count':'CORNER_HEARTS_WRONG_COUNT','corner_heart_wrong_gradient':'CORNER_HEART_WRONG_GRADIENT','frame_color_drift':'FRAME_COLOR_DRIFT','winged_heart_wrong_color':'WINGED_HEART_WRONG_COLOR','unrequested_composition_rebuild':'UNREQUESTED_COMPOSITION_REBUILD','cyber_outfit_looks_cgi':'CYBER_OUTFIT_LOOKS_CGI','main_heart_competes_with_decoration':'MAIN_HEART_COMPETES_WITH_DECORATION'
    }
    found=[code for key,code in mapping.items() if flags.get(key) is True]
    repairs=[REGISTRY['failure_modes'][code] for code in found if code in REGISTRY.get('failure_modes',{})]
    return {'failure_codes':found,'repair_directives':repairs,'repairable':bool(found)}

if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('intent'); p.add_argument('--traits', default=''); a=p.parse_args()
    print(json.dumps(analyze(a.intent, source_traits=[x for x in a.traits.split(',') if x]), ensure_ascii=False, indent=2))
