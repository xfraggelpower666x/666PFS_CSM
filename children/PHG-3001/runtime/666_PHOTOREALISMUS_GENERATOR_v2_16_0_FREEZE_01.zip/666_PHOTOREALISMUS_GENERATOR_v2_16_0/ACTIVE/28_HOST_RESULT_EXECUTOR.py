#!/usr/bin/env python3
"""Post-tool result lifecycle executor for 666 PRG v2.0.0."""
from __future__ import annotations
from pathlib import Path
import argparse
import importlib.util
import json

ROOT = Path(__file__).resolve().parent


def module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


k = module("prg_kernel", "11_RUNTIME_KERNEL.py")
qa = module("prg_qa", "27_VISUAL_QA_ENGINE.py")
store = module("prg_store", "22_RUNTIME_STORE.py")

ERROR_EVENT_MAP = {
    "EMPTY": "TOOL_EMPTY",
    "TEMPORARY_ERROR": "TOOL_TEMPORARY_ERROR",
    "RATE_LIMIT": "TOOL_RATE_LIMIT",
    "CHANNEL_ERROR": "TOOL_CHANNEL_ERROR",
    "UNAVAILABLE": "TOOL_UNAVAILABLE",
    "POLICY_REJECTION": "TOOL_POLICY_REJECTION",
    "WATCHDOG_TIMEOUT": "WATCHDOG_TIMEOUT",
}


def _step(state: dict, event: str, ctx: dict, journal: list[dict]):
    state, record, action = k.transition(state, event, ctx)
    journal.append(record)
    return state, action


def _ownership(state: dict, **extra) -> dict:
    return {
        "transaction_id": state.get("transaction_id"),
        "attempt_id": state.get("attempt_id"),
        "source_hash": state.get("source_hash"),
        "prompt_hash": state.get("prompt_hash"),
        **extra,
    }


def _persist_result(result: dict, runtime_root: str | Path | None, expected_revision: int | None) -> dict:
    if runtime_root is None:
        return result
    state_errors = k.validate_runtime_state(result["state"])
    if state_errors:
        raise RuntimeError("PERSISTENCE_STATE_VALIDATION_FAILED:" + ";".join(state_errors))
    for receipt in result.get("receipts", []):
        receipt_errors = k.validate_receipt(receipt)
        if receipt_errors:
            raise RuntimeError("PERSISTENCE_RECEIPT_VALIDATION_FAILED:" + ";".join(receipt_errors))
    persisted = store.persist_transaction(
        Path(runtime_root), result["state"], result.get("journal", []), result.get("receipts", []),
        expected_revision=expected_revision,
    )
    result["state"] = persisted["state"]
    result["persistence"] = persisted["commit"]
    return result


def process_result(
    state: dict,
    *,
    result_kind: str,
    output_id: str | None = None,
    output_hash: str | None = None,
    qa_report: dict | None = None,
    runtime_root: str | Path | None = None,
    expected_revision: int | None = None,
) -> dict:
    s = state
    journal: list[dict] = []
    receipts: list[dict] = []
    if s.get("state") != "DISPATCHING":
        return {"route": "REJECTED", "reason": "RESULT_REQUIRES_DISPATCHING_STATE", "state": s, "journal": journal, "receipts": receipts}

    kind = result_kind.strip().upper()
    # Host-boundary repair: a nominal SUCCESS without a renderable output proof is
    # an empty tool return, never a successful image result. This avoids a false
    # success path and routes the preserved source into the bounded retry policy.
    if kind == "SUCCESS" and (not output_id or not output_hash or not k.valid_sha256(output_hash)):
        kind = "EMPTY"
    if kind != "SUCCESS":
        event = ERROR_EVENT_MAP.get(kind)
        if not event:
            return {"route": "REJECTED", "reason": f"UNKNOWN_RESULT_KIND:{kind}", "state": s, "journal": journal, "receipts": receipts}
        s, _ = _step(s, event, {}, journal)
        terminal_type = "TERMINAL" if s.get("state") == "FAILED_TERMINAL" else "OUTPUT"
        receipt = k.make_receipt(s, terminal_type, event, sequence=journal[-1]["sequence"])
        receipts.append(receipt)
        route = "FAILED_TERMINAL" if s.get("state") == "FAILED_TERMINAL" else "RETRY_READY"
        if kind == "EMPTY":
            s["last_error_detail"] = "IMAGE_TOOL_RETURNED_NO_IMAGE_OBJECT;SOURCE_AND_INTENT_PRESERVED"
    else:
        ctx = _ownership(s, output_present=True, output_id=output_id, output_hash=output_hash)
        s, _ = _step(s, "TOOL_RETURNED", ctx, journal)
        if journal[-1]["result"] != "PASS":
            receipts.append(k.make_receipt(s, "OUTPUT", "TOOL_RETURNED_GUARD_FAIL", sequence=journal[-1]["sequence"]))
            route = "FAILED_TERMINAL" if s.get("state") == "FAILED_TERMINAL" else "RETRY_READY"
            return _persist_result({"route": route, "reason": s.get("last_error_detail"), "state": s, "journal": journal, "receipts": receipts}, runtime_root, expected_revision)
        receipts.append(k.make_receipt(s, "OUTPUT", "TOOL_RETURNED", sequence=journal[-1]["sequence"]))
        ctx = _ownership(s, output_present=True, output_id=s.get("output_id"), output_hash=s.get("output_hash"))
        s, _ = _step(s, "OUTPUT_OBJECT_VALID", ctx, journal)
        if journal[-1]["result"] != "PASS":
            receipts.append(k.make_receipt(s, "OUTPUT", "OUTPUT_OBJECT_VALID_GUARD_FAIL", sequence=journal[-1]["sequence"]))
            route = "FAILED_TERMINAL" if s.get("state") == "FAILED_TERMINAL" else "RETRY_READY"
            return _persist_result({"route": route, "reason": s.get("last_error_detail"), "state": s, "journal": journal, "receipts": receipts}, runtime_root, expected_revision)
        evaluation = qa.evaluate(qa_report)
        qa_ctx = {**ctx, "qa_report": qa_report}
        event = {"PASS": "VISUAL_QA_PASS", "REPAIRABLE_FAIL": "VISUAL_QA_REPAIRABLE_FAIL", "TERMINAL_FAIL": "VISUAL_QA_TERMINAL_FAIL"}[evaluation["decision"]]
        s, _ = _step(s, event, qa_ctx, journal)
        receipts.append(k.make_receipt(s, "QA", event, sequence=journal[-1]["sequence"], output_hash=s.get("output_hash")))
        if event == "VISUAL_QA_PASS" and journal[-1]["result"] == "PASS":
            commit_ctx = _ownership(s, output_present=True, output_id=s.get("output_id"), output_hash=s.get("output_hash"), qa_report=qa_report)
            s, _ = _step(s, "COMMIT_SUCCESS", commit_ctx, journal)
            if journal[-1]["result"] == "PASS":
                receipts.append(k.make_receipt(s, "TERMINAL", "COMMIT_SUCCESS", sequence=journal[-1]["sequence"], output_hash=s.get("output_hash")))
                route = "COMPLETE"
            else:
                route = "FAILED_TERMINAL"
        elif event == "VISUAL_QA_REPAIRABLE_FAIL" and journal[-1]["result"] == "PASS":
            route = "REPAIR_READY"
        else:
            route = "RETRY_READY" if s.get("state") == "RETRY_READY" else "FAILED_TERMINAL"

    result = {"route": route, "state": s, "journal": journal, "receipts": receipts, "qa_evaluation": qa.evaluate(qa_report) if qa_report is not None else None}
    return _persist_result(result, runtime_root, expected_revision)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--state", required=True)
    p.add_argument("--result-kind", required=True)
    p.add_argument("--output-id")
    p.add_argument("--output-hash")
    p.add_argument("--qa-report")
    p.add_argument("--runtime-root")
    args = p.parse_args()
    state = json.loads(Path(args.state).read_text(encoding="utf-8"))
    report = json.loads(Path(args.qa_report).read_text(encoding="utf-8")) if args.qa_report else None
    print(json.dumps(process_result(state, result_kind=args.result_kind, output_id=args.output_id, output_hash=args.output_hash, qa_report=report, runtime_root=args.runtime_root), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
