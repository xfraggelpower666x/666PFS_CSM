#!/usr/bin/env python3
"""PHG-3001 v2.9.0 additive Cyber Love Frame System runtime engine."""
from __future__ import annotations
import re

VERSION = "1.0.0"
ADDON_ID = "PRG-ADDON-CYBER-LOVE-FRAME-001"
SHORT_ID = "CLF"

EXPLICIT_TRIGGERS = (
    "cyber love frame system",
    "cyber love frame",
    "cyber love border",
    "cyber-love frame",
    "prg-addon-cyber-love-frame-001",
)
FRAME_TERMS = ("frame","border","rahmen","umrandung","bildrand")
LOVE_CYBER_TERMS = ("cyber love","cyber-love","infinity","endless","heart","hearts","herz","herzen","neon love")

VARIATIONS = (
    "CYBER_LOVE","CYBER_INFINITY","CYBER_ROMANCE","DARK_LOVE","NEON_LOVE",
    "ETERNAL_CONNECTION","GOOD_MORNING_LOVE","NIGHT_LOVE","DISTANCE_LOVE","FUTURE_LOVE",
)

def _norm(v:str)->str:
    return re.sub(r"\s+"," ",(v or "").casefold()).strip()

def _contains_any(t:str, terms)->bool:
    return any(x in t for x in terms)

def active_for(text:str)->bool:
    t=_norm(text)
    if any(x in t for x in EXPLICIT_TRIGGERS): return True
    # Secondary semantic activation remains strict: frame intent + cyber/love/infinity concept.
    return _contains_any(t,FRAME_TERMS) and ("cyber" in t) and _contains_any(t,LOVE_CYBER_TERMS)

def detect_variation(text:str)->str:
    t=_norm(text)
    pairs=(
        (("good morning love","morning love"),"GOOD_MORNING_LOVE"),
        (("distance love","long distance"),"DISTANCE_LOVE"),
        (("future love","future romance"),"FUTURE_LOVE"),
        (("night love","night romance"),"NIGHT_LOVE"),
        (("dark love",),"DARK_LOVE"),
        (("neon love",),"NEON_LOVE"),
        (("eternal connection","eternal"),"ETERNAL_CONNECTION"),
        (("cyber infinity","infinity","endless"),"CYBER_INFINITY"),
        (("cyber romance",),"CYBER_ROMANCE"),
    )
    for terms,mode in pairs:
        if any(x in t for x in terms): return mode
    return "CYBER_LOVE"

def detect_complexity(text:str)->int:
    t=_norm(text)
    if any(x in t for x in ("level 3","extreme frame","extreme cyber frame","heavy cyber architecture")): return 3
    if any(x in t for x in ("level 1","minimal frame","minimal cyber frame","thin cyber frame")): return 1
    return 2

def _extract_named_value(text:str, names:tuple[str,...])->str|None:
    # Explicit key/value syntax is deterministic and preferred.
    for name in names:
        m=re.search(rf"(?im)\b{re.escape(name)}\s*[:=]\s*([^\n\r]+)", text or "")
        if m:
            value=m.group(1).strip().strip('"\' ')
            if value: return value
    return None

def analyze(text:str, *, source_traits:list[str]|None=None)->dict:
    t=_norm((text or "")+" "+" ".join(source_traits or []))
    active=active_for(t) or ADDON_ID.casefold() in t
    if not active:
        return {"active":False,"version":VERSION,"addon_id":ADDON_ID}
    top=_extract_named_value(text,("TOP_TEXT","TOP TEXT","TOP-TEXT"))
    bottom=_extract_named_value(text,("BOTTOM_TEXT","BOTTOM TEXT","BOTTOM-TEXT"))
    complexity=detect_complexity(text)
    return {
        "active":True,
        "version":VERSION,
        "addon_id":ADDON_ID,
        "short_id":SHORT_ID,
        "mode":"ADD_ONLY",
        "core_replacement":"FORBIDDEN",
        "reference_preservation":"MANDATORY",
        "photorealism_parent_rules":"INHERIT",
        "text_accuracy":"HARD_LOCK",
        "frame_mode":"FRAME_MODE_CYBER_LOVE_HOLO",
        "variation":detect_variation(text),
        "supported_variations":list(VARIATIONS),
        "complexity_level":complexity,
        "complexity_name":{1:"MINIMAL",2:"BALANCED",3:"EXTREME"}[complexity],
        "top_text":top if top is not None else "I LOVE YOU",
        "bottom_text":bottom if bottom is not None else "ENDLESS",
        "top_text_source":"USER_EXPLICIT" if top is not None else "ADDON_DEFAULT",
        "bottom_text_source":"USER_EXPLICIT" if bottom is not None else "ADDON_DEFAULT",
        "text_mutation":"FORBIDDEN",
        "random_text":"FORBIDDEN",
        "frame_zones":["TOP_FRAME","BOTTOM_FRAME","LEFT_SIDE_FRAME","RIGHT_SIDE_FRAME"],
        "materials":["DARK_TITANIUM","BLACK_CHROME","CARBON_COMPOSITE","SMOKED_GLASS","OPTICAL_FIBER","NEON_TUBES","HOLOGRAPHIC_SECTIONS","CYBERNETIC_CIRCUITRY","METALLIC_JOINTS","ENERGY_CONDUITS"],
        "symbols":["CYBER_HEARTS","INFINITY_STRUCTURES","INTERTWINED_ENERGY_LINES","PULSE_LINES","NEURAL_CIRCUITS","SUBTLE_WAVEFORMS","PAIRED_LIGHT_PATHS"],
        "palette_primary":["NEON_MAGENTA","NEON_CYAN","ELECTRIC_BLUE","VIOLET"],
        "palette_secondary":["HOT_PINK","DEEP_PURPLE","BLACK","MIDNIGHT_BLUE"],
        "optional_color":"ENERGY_ORANGE",
        "frame_occupancy_recommended_percent":[6,12],
        "frame_occupancy_max_percent":15,
        "scene_preservation":["MAIN_SUBJECTS","FACES","BODY_PROPORTIONS","CENTRAL_OBJECTS","ENVIRONMENTAL_STORY","MAJOR_LIGHTING_DIRECTION","READABLE_EXISTING_TEXT","COMPOSITION_HIERARCHY","EMOTIONAL_CONTENT"],
        "light_interaction":["PINK_TOP_SPILL","CYAN_BOTTOM_REFLECTION","SIDE_GLOW_IN_FOG","GLOSSY_SURFACE_REFLECTION","METAL_EDGE_RESPONSE","ATMOSPHERIC_BLOOM"],
        "priority":["SOURCE_IDENTITY","PARENT_PHOTOREALISM","EXISTING_COMPOSITION","EXACT_REQUESTED_TEXT","PHYSICAL_FRAME_INTEGRATION","LIGHTING_COHERENCE","CYBER_LOVE_DESIGN","DECORATIVE_MICRODETAIL"],
        "forbidden":["FLAT_GRAPHIC_FRAME","COLLAGE_APPEARANCE","CARTOON_HEARTS","EMOJI_HEARTS","CHILDISH_VALENTINE","RANDOM_TYPOGRAPHY","MISSPELLED_TEXT","UNWANTED_LOGOS","SIGNATURES","WATERMARKS"],
    }

def compact_directive(report:dict)->str:
    if not report.get("active"): return ""
    return (
        f"{ADDON_ID} v{VERSION}: apply an ADD-ONLY physically constructed four-sided cyber-romantic frame using existing FRAME_MODE_CYBER_LOVE_HOLO as the compatible base, never replacing the source scene. "
        f"Variation={report['variation']}; complexity Level {report['complexity_level']} {report['complexity_name']}. "
        "Build connected dark titanium/black chrome/carbon/smoked-glass architecture with optical fiber, recessed holographic sections, circuitry, joints, bevels, light cavities and realistic depth; flat graphic borders/collage appearance are forbidden. "
        f"Install exact top-frame text '{report['top_text']}' and exact bottom-frame text '{report['bottom_text']}' physically inside the frame; preserve spelling/case exactly, no silent translation, paraphrase, random text, logos or watermarks. "
        "Use technological hearts and infinity structures only as subordinate support; no cartoon/emoji/clip-art hearts. Keep all four frame sides connected and visible, target 6-12% occupancy and never exceed 15% under normal conditions. "
        "Prefer outward canvas extension over covering the source. Preserve identities, faces, body proportions, central objects, existing readable text, composition hierarchy and emotional story. "
        "Make frame emission interact with the photograph: magenta/pink inward top spill, cyan lower reflections, side glow in fog, plausible glossy/metal reflections and atmospheric bloom, all within one shared lighting universe. "
        "Priority: source identity > parent photorealism > existing composition > exact requested text > physical frame integration > lighting coherence > cyber-love design > microdetail."
    )
