#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('e',R/'84_ENVIRONMENTAL_NARRATIVE_COHERENCE.py'); e=importlib.util.module_from_spec(s); s.loader.exec_module(e)
t=[]
def ck(n,c): t.append((n,bool(c)))
r=e.analyze('two people in heavy rain, names left and right, heart frame, caption stay together through the rain')
ck('ENSC01 active',r['active']); ck('ENSC02 rain',r['event']=='RAIN'); ck('ENSC03 causality',r['environmental_causality_required']); ck('ENSC04 wet',r['wet_material_realism']); ck('ENSC05 scene text symbol',r['scene_text_symbol_coherence']); ck('ENSC06 name lock',r['name_side_binding']['mandatory']); ck('ENSC07 no swap',r['name_side_binding']['name_swap']=='FORBIDDEN'); ck('ENSC08 no core replace',not r['core_replacement']); ck('ENSC09 no foreign mutation',not r['foreign_system_mutation']); ck('ENSC10 directive','NAME_SIDE_BINDING' in e.compact_directive(r))
r2=e.analyze('plain studio portrait')
ck('ENSC11 unrelated off',not r2['active'])
reg=json.loads((R/'85_ENSC_REGISTRY.json').read_text())
ck('ENSC12 registry active',reg['status']=='INTEGRATED_ACTIVE'); ck('ENSC13 add only',reg['integration_mode']=='ADD_ONLY'); ck('ENSC14 source',reg['source'].startswith('ADDONS/'))
for n,p in t: print(('PASS' if p else 'FAIL'),n)
if not all(p for _,p in t): raise SystemExit(1)
print(f'ENSC-004 TESTS = PASS ({len(t)}/{len(t)})')
