#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import importlib.util, json, re
ROOT=Path(__file__).resolve().parent
REG=json.loads((ROOT/'78_PHG_INTERACTION_REGISTRY.json').read_text(encoding='utf-8'))
_spec=importlib.util.spec_from_file_location('menu_engine',ROOT/'76_MODE_MENU_ENGINE.py')
MENU_ENGINE=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(MENU_ENGINE)
MENU=MENU_ENGINE.list_menu()

def classify_trigger(text:str)->str:
    t=re.sub(r'\s+',' ',(text or '').strip()).upper()
    return REG['exact_triggers'].get(t,'NONE')

def _all_modes():
    return [m for s in MENU['sections'] for m in s['modes']]

def _section_and_number(mode:str):
    for si,s in enumerate(MENU['sections'],1):
        for mi,m in enumerate(s['modes'],1):
            if m==mode: return s['title'],f'{si}.{mi}'
    return None,None

def _mode_only(text:str,selected:list[str])->bool:
    t=re.sub(r'\s+',' ',(text or '').strip())
    if not selected: return False
    residue=t
    for m in selected: residue=re.sub(re.escape(m), ' ', residue, flags=re.I)
    residue=re.sub(r'(?<!\d)\d+\.\d+(?!\d)',' ',residue)
    residue=re.sub(r'[+,&/|;:\-]+',' ',residue)
    return not re.search(r'[A-Za-zÄÖÜäöüß]{3,}',residue)

def resolve_selection(text:str)->dict:
    r=MENU_ENGINE.resolve(text)
    r['selection_only']=_mode_only(text,r['selected_modes'])
    r['action']='SHOW_GUIDANCE_AND_COPY_PROMPTS' if r['selection_only'] else ('ALLOW_CREATIVE_FLOW' if r['selected_modes'] else 'NO_MODE_SELECTION')
    r['image_dispatch_allowed']=False if r['selection_only'] else None
    return r

def _companions(modes:list[str])->list[str]:
    out=[]
    for m in modes:
        for x in REG['preset_defaults'].get(m,{}).get('recommended_companions',[]):
            if x not in modes and x not in out: out.append(x)
    return out

def _classes(modes:list[str])->list[str]:
    return list(dict.fromkeys(REG['capability_classes'].get(m,'MODE') for m in modes))

def _base_mode_line(modes:list[str])->str:
    return ' + '.join(modes)

def build_guidance(text_or_mode:str, *, uploaded_reference:bool=False, exact_text_requested:bool=False)->dict:
    sel=resolve_selection(text_or_mode)
    modes=sel['selected_modes']
    if not modes:
        return {'status':'NO_MODE','selection':sel,'message':'No registered PHG mode selected.'}
    companions=_companions(modes)
    classes=_classes(modes)
    base=_base_mode_line(modes)
    recommended=' + '.join(modes+companions)
    minimal=(base+'\nBeschreibe Motiv, gewünschte Wirkung und wichtige Prioritäten.').strip()
    robust=(recommended+'\nHauptmotiv klar priorisieren. Fotorealistische menschliche Darstellung mit natürlicher Haut, Haaren, Augen, Materialien, Lichtreflexen und Schatten. Keine unbeabsichtigte CGI-, Game- oder Plastikoptik. Gewählten Stil/Frame kausal integrieren, ohne das Hauptmotiv zu überdecken.').strip()
    edit=(recommended+'\nDas hochgeladene Referenzbild bearbeiten. Hauptfiguren und gewünschte Identitätsmerkmale erhalten. Pose, Position, räumliche Komposition und Interaktion nur verändern, wenn ausdrücklich verlangt. Gewählten Stil/Frame integrieren.').strip()
    if any(m in modes for m in ('NAME_SIDE_BINDING','DYNAMIC_SIDE_REMAPPING','IDENTITY_PROPERTY_REMAP','COLOR_PERSON_BINDING','FRAME_REGION_REMAP')):
        edit += '\nPersonenseiten pro Bild neu bestimmen. Namen, Identitätsfarben, personengebundene Frame-Regionen, Symbole und Lichtakzente folgen immer der zugehörigen Person; niemals an LEFT/RIGHT festkleben.'
    if any(m in modes for m in ('ENVIRONMENTAL_NARRATIVE','WEATHER_STORY_MAPPING','WET_MATERIAL_REALISM','SCENE_TEXT_SYMBOL_COHERENCE')):
        edit += '\nUmweltereignisse kausal darstellen: sichtbares Wetter muss glaubwürdige Folgen auf Haar, Haut, Stoff, Materialreflexionen, Boden und Licht haben. Szene, Text und Symbolik dürfen sich nicht widersprechen.'
    templates=[{'type':'MINIMAL','text':minimal},{'type':'ROBUST','text':robust},{'type':'REFERENCE_EDIT','text':edit}]
    if exact_text_requested:
        templates.append({'type':'TEXT_SAFE','text':edit+'\nText exakt integrieren: [TEXT] an [POSITION]. Schreibweise exakt; nicht vertauschen, nicht umformulieren, nicht ergänzen.'})
    notices=[]
    if any(REG['capability_classes'].get(m) in ('STYLE_PRESET','FRAME') for m in modes):
        notices.append('Style/Frame allein garantiert keinen vollständigen fotorealistischen Rebuild.')
    if uploaded_reference:
        notices.append('Bei Referenzbildern Preservation-Ziele explizit nennen: Identität, Pose, Komposition, Kleidung, Hintergrund.')
    details=[]
    for m in modes:
        sec,num=_section_and_number(m); d=REG['preset_defaults'].get(m,{})
        details.append({'mode':m,'menu_number':num,'section':sec,'class':d.get('class',REG['capability_classes'].get(m,'MODE')),'guarantees':d.get('guarantees',[]),'does_not_automatically_guarantee':d.get('does_not_automatically_guarantee',[])})
    return {'status':'GUIDANCE_READY','selection':sel,'modes':details,'capability_classes':classes,'recommended_companions':companions,'notices':notices,'templates':templates,'image_dispatch_allowed':False if sel['selection_only'] else None}

def systemstart_payload()->dict:
    return {
      'trigger':'PHG SYSTEMSTART','identity':REG['identity_name'],
      'intro':'PHG ist die geführte Bedienebene für fotorealistische Bildgenerierung und Bildbearbeitung. Die normale Steuerung funktioniert weiterhin ohne PHG-Präfix.',
      'how_to_use':['Modus per Name, Menünummer oder natürlicher Sprache wählen.','Nach Moduswahl erzeugt PHG Copy-Prompt-Vorschläge statt sofort zu rendern.','Bild hochladen und im Prompt sagen, was erhalten, verändert und exakt geschrieben werden soll.','Rendern erst mit einer konkreten Bildanweisung; bloße Moduswahl rendert nicht.'],
      'required_inputs':REG['input_checklist'],'menu':MENU,
      'quickstart_copy_prompts':[
        'CORE_PHOTOREALISM + REALISM_CONTROL\n[Motiv] als glaubwürdige fotorealistische Szene darstellen. Natürliche Haut, Haare, Materialien, Licht und Schatten. Keine CGI-/Game-Optik.',
        'IDENTITY_PRESERVATION + REFERENCE_PRESERVATION + CORE_PHOTOREALISM\nReferenzbild bearbeiten. Identität, Pose und Komposition erhalten. [gewünschte Änderung].',
        'LOVE_FRAME_ELECTRIC_BLUE + CORE_PHOTOREALISM + REALISM_CONTROL + IDENTITY_PRESERVATION + REFERENCE_PRESERVATION\nHauptfiguren fotorealistisch neu interpretieren; Pose, Position und Interaktion erhalten. Elektrisch-blauen Love-Frame integrieren. Text exakt: [LINKS] / [RECHTS].'
      ]
    }

def help_payload()->dict:
    return {
      'trigger':'PHG HELP','identity':REG['identity_name'],
      'quick_usage':'Wähle Modus/Nummer ohne PHG-Präfix. PHG SYSTEMSTART und PHG HELP sind die einzigen PHG-eigenen Interface-Trigger.',
      'menu':MENU,
      'recommended_combinations':[
        'CORE_PHOTOREALISM + REALISM_CONTROL',
        'IDENTITY_PRESERVATION + REFERENCE_PRESERVATION + CORE_PHOTOREALISM',
        'LOVE_FRAME_ELECTRIC_BLUE + CORE_PHOTOREALISM + REALISM_CONTROL',
        'LYVRA_FRAME+EVM + IDENTITY_PRESERVATION + REFERENCE_PRESERVATION',
        'CCRE+EVM + CORE_PHOTOREALISM + REALISM_CONTROL',
        'ENVIRONMENTAL_NARRATIVE + WET_MATERIAL_REALISM + SCENE_TEXT_SYMBOL_COHERENCE',
        'DYNAMIC_SIDE_REMAPPING + NAME_SIDE_BINDING + COLOR_PERSON_BINDING + FRAME_REGION_REMAP'
      ],
      'error_prevention':REG['error_prevention']
    }
