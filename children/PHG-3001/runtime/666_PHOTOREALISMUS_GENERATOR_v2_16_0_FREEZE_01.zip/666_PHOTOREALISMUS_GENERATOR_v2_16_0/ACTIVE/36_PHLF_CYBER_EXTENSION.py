#!/usr/bin/env python3
"""PHLF-CYBER lifestyle extension for 666 PRG v2.0.0."""
from __future__ import annotations
import hashlib
import json
import re

VERSION = "2.0.0"

TRIGGERS = {
    "hair": ("hair", "hairstyle", "frisur", "haare", "undercut", "braid", "zopf"),
    "nails": ("nails", "fingernails", "fingernägel", "manicure", "chrome nails", "nageldesign"),
    "makeup": ("makeup", "make-up", "eyeliner", "lipstick", "lippenstift"),
    "accessories": ("accessories", "accessoire", "accessoires", "visor", "choker", "rings", "ringe", "ear cuffs"),
    "cyber_outfit": ("techwear", "cyber outfit", "cyber fashion", "clubwear", "cyber swimwear", "cyber bikini"),
    "cyber_love": ("cyber love", "neon heart", "neon-glass heart", "neon glasherz", "barbed-wire heart", "stacheldraht-herz", "love you over all"),
    "music_fx": ("music notes", "musiknoten", "waveform light", "rhythm pulse"),
}

def _norm(value: str | None) -> str:
    return re.sub(r"\s+", " ", (value or "").casefold()).strip()

def _has(text: str, terms: tuple[str, ...]) -> bool:
    t = _norm(text)
    return any(re.search(r"(?<!\w)" + re.escape(_norm(term)).replace(r"\ ", r"\s+") + r"(?!\w)", t) for term in terms)

def analyze(intent: str) -> dict:
    features = {name: _has(intent, terms) for name, terms in TRIGGERS.items()}
    active = any(features.values())
    result = {
        "extension": "PHLF-CYBER",
        "version": VERSION,
        "active": active,
        "features": features,
        "adult_age_semantics": "AGE_CLARITY_ONLY",
        "non_explicit_boundary": True,
        "change_only_rule": True,
        "identity_lock_required_for_edits": True,
    }
    result["hash"] = hashlib.sha256(
        json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return result

def compact_directive(report: dict) -> str:
    if not report.get("active"):
        return ""
    active = [name for name, enabled in report.get("features", {}).items() if enabled]
    return (
        "[PHLF_CYBER] Requested lifestyle features: " + ", ".join(active) + ". "
        "Keep every subject unmistakably adult; adult means age clarity only. "
        "Use grounded photorealistic cyber design, wearable context-appropriate clothing, "
        "real hair strands, anatomically correct hands and nails, identity-preserving makeup, "
        "coherent accessories, physically plausible neon light and non-explicit affection. "
        "Change only requested elements."
    )

if __name__ == "__main__":
    import sys
    print(json.dumps(analyze(" ".join(sys.argv[1:])), ensure_ascii=False, indent=2))
