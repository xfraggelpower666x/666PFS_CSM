#!/usr/bin/env python3
"""Lean creative director for 666 PRG v2.0.0."""
from __future__ import annotations
from pathlib import Path
import json, re, hashlib, importlib.util

ROOT = Path(__file__).resolve().parent
PROFILES = json.loads((ROOT / '34_CREATIVE_RUNTIME_PROFILES.json').read_text(encoding='utf-8'))

def _load_adult_policy():
    spec = importlib.util.spec_from_file_location('adult_policy', ROOT / '35_ADULT_SWIMWEAR_TATTOO_VISIBILITY_POLICY.py')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
ADULT_POLICY = _load_adult_policy()

def _load_phlf_extension():
    spec = importlib.util.spec_from_file_location('phlf_extension', ROOT / '36_PHLF_CYBER_EXTENSION.py')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
PHLF_EXTENSION = _load_phlf_extension()

def norm(v: str) -> str:
    return re.sub(r'\s+', ' ', (v or '').casefold()).strip()

def has(text: str, *terms: str) -> bool:
    t = norm(text)
    return any(re.search(r'(?<!\w)' + re.escape(x.casefold()).replace(r'\ ', r'\s+') + r'(?!\w)', t) for x in terms)

def choose_profile(intent: str) -> str:
    if has(intent, '3d', 'cgi', 'game render', 'game-render', 'stylized render', 'fotorealismus', 'photorealism', 'real photo', 'echtes foto'):
        return 'CGI_TO_PHOTOREAL_RECONSTRUCTION'
    if has(intent, 'exact face', 'face exact', 'identity critical', 'gesicht exakt', 'identität exakt'):
        return 'IDENTITY_CRITICAL'
    if has(intent, 'replace background', 'new environment', 'world rebuild', 'hintergrund ersetzen', 'komplette umgebung'):
        return 'WORLD_REBUILD'
    return 'CHARACTER_TRANSFORMATION'

def build_plan(intent: str, source_traits: list[str] | None = None) -> dict:
    if not (intent or '').strip():
        raise ValueError('DIRECTOR_INTENT_EMPTY')
    profile = choose_profile(intent)
    cfg = PROFILES['profiles'][profile]
    edits = []
    checks = [
        ('OUTFIT', ('outfit','wardrobe','clothes','kleidung','jacke','dress','uniform','bikini','badeanzug','badehose','shorts','swimwear')),
        ('POSE', ('pose','sitting','standing','kneeling','haltung','sitzend','stehend')),
        ('CAMERA', ('zoom in','zoom out','close-up','close up','wide shot','full body','kamerawinkel','nahaufnahme')),
        ('ENVIRONMENT', ('background','environment','scene','hintergrund','umgebung','bar','city','pool','beach','strand','schwimmbad')),
        ('LIGHTING', ('lighting','light','neon','beleuchtung','licht','laser')),
        ('EFFECTS', ('rain','fog','smoke','glow','motion blur','regen','nebel','rauch','effekt')),
        ('TATTOO_VISIBILITY', ('tattoo','tattoos','tätowierung','tätowierungen','body art','oberkörper','unterkörper','bare torso','shirtless')),
        ('ROMANTIC_AFFECTION', ('kiss','kissing','kuss','küssen','umarmung','embrace','hug','zuneigung','romantic','romantisch')),
        ('HAIR_DESIGN', ('hair','hairstyle','frisur','haare','undercut','braid')),
        ('NAIL_DESIGN', ('nails','fingernails','fingernägel','manicure','nageldesign')),
        ('MAKEUP_DESIGN', ('makeup','make-up','eyeliner','lipstick','lippenstift')),
        ('ACCESSORY_DESIGN', ('accessories','accessoire','accessoires','visor','choker','ear cuffs')),
        ('CYBER_LOVE', ('cyber love','neon heart','neon-glass heart','neon glasherz','barbed-wire heart','stacheldraht-herz','love you over all')),
    ]
    for name, terms in checks:
        if has(intent, *terms):
            edits.append(name)
    if profile == 'CGI_TO_PHOTOREAL_RECONSTRUCTION':
        edits.insert(0, 'FULL_PHOTOREAL_RECONSTRUCTION')
    if not edits:
        edits = ['STYLE_AND_QUALITY']
    adult_report = ADULT_POLICY.evaluate_intent(intent, source_traits=source_traits or [])
    phlf_report = PHLF_EXTENSION.analyze(intent)
    steps = ['SOURCE_BIND','MINIMAL_IDENTITY_ANCHOR','EDIT_PLAN','COMPACT_PROMPT','IMAGE_TOOL','VISUAL_READBACK']
    plan = {
        'director_version': '2.0.0',
        'profile': profile,
        'identity_weight': cfg['identity_weight'],
        'creative_weight': cfg['creative_weight'],
        'prompt_max_blocks': cfg['prompt_max_blocks'],
        'edits': edits,
        'steps': steps,
        'source_traits': list(source_traits or []),
        'governance_in_prompt': False,
        'adult_visibility_policy': adult_report,
        'phlf_cyber_extension': phlf_report,
    }
    plan['plan_hash'] = hashlib.sha256(json.dumps(plan, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode()).hexdigest()
    return plan

def compact_contract(plan: dict) -> str:
    policy_line = ADULT_POLICY.compact_directive(plan.get('adult_visibility_policy', {}))
    phlf_line = PHLF_EXTENSION.compact_directive(plan.get('phlf_cyber_extension', {}))
    suffix = ((' ' + policy_line) if policy_line else '') + ((' ' + phlf_line) if phlf_line else '')
    if plan['profile'] == 'CGI_TO_PHOTOREAL_RECONSTRUCTION':
        return '[PHOTOREAL_RECONSTRUCTION] Fully rebuild the CGI/3D rendering as a believable real photograph. Preserve only recognizable identities, person count, approximate pose/composition and defining marks; freely reconstruct skin, hair, anatomy, materials, light, depth and reflections for true realism.' + suffix
    edits = ', '.join(plan['edits'])
    return f"[CREATIVE_DIRECTOR] Profile={plan['profile']}; requested edits: {edits}; preserve recognizable people and person separation; produce one coherent final image." + suffix
