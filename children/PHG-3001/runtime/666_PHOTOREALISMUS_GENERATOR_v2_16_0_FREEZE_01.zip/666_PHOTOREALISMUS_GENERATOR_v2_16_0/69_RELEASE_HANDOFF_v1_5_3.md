# RELEASE HANDOFF — 666 PHOTOREALISMUS GENERATOR v1.5.3

## Aktiver Einstieg

- Runtime: `ACTIVE/11_RUNTIME_KERNEL.py`
- Host Turn: `ACTIVE/19_HOST_TURN_EXECUTOR.py`
- Prompt Compiler: `ACTIVE/26_PROMPT_COMPILER.py`
- Visual QA: `ACTIVE/27_VISUAL_QA_ENGINE.py`
- Host Result: `ACTIVE/28_HOST_RESULT_EXECUTOR.py`
- Guard Handler Registry: `ACTIVE/29_GUARD_HANDLER_REGISTRY.json`
- Deep Tests: `ACTIVE/30_RUN_V153_ACCEPTANCE_TESTS.py`
- Runtime Store: `ACTIVE/22_RUNTIME_STORE.py`

## Verbindlicher Host-Ablauf

1. Bildquelle mit `source_id` und vertrauenswürdigem `source_hash` registrieren.
2. `execute_turn(..., tool_available=True)` ausführen.
3. Nur bei Route `CALL_IMAGE_TOOL` den Bildtool-Aufruf im Commentary-Kanal durchführen.
4. Reales Toolresultat an `process_result(...)` übergeben.
5. Vollständigen Visual-QA-Bericht übergeben.
6. `COMPLETE` nur akzeptieren, wenn Output, Ownership, QA und Terminal-Receipt gültig sind.
7. State, Journal und Receipts gemeinsam über `persist_transaction(...)` sichern.

## Hardlocks

- Kein textlicher Erfolg ohne Bildobjekt.
- Keine stillen True-Defaults für Source, Tool oder Output.
- Kein Commit ohne vollständige Ownership.
- Keine QA-Freigabe ohne alle sieben Prüfbeweise.
- Kein Retry oder Repair ohne erneute Prompt-Compilation.
- Keine zufällige Kleinschreibung exakter Marken-/Eigennamen.
- Kein Stage-2-Frame ohne validiertes Stage-1-Ergebnis.
