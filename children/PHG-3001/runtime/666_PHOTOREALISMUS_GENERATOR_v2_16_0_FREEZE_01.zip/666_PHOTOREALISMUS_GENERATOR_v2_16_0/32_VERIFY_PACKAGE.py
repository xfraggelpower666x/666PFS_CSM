#!/usr/bin/env python3
"""Verify current PHG package manifest, SHA-256 list and inventory."""
from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
manifest_path=root/'08_PACKAGE_MANIFEST.json'; sums_path=root/'09_SHA256SUMS.txt'; active_path=root/'ACTIVE'/'00_ACTIVE_MANIFEST.json'
errors=[]
manifest=json.loads(manifest_path.read_text(encoding='utf-8')); active=json.loads(active_path.read_text(encoding='utf-8'))
manifest_files={item['path']:item for item in manifest.get('files',[])}
sum_entries={}
for line_no,line in enumerate(sums_path.read_text(encoding='utf-8').splitlines(),1):
    if not line.strip(): continue
    try: expected,rel=line.split('  ',1)
    except ValueError: errors.append(f'INVALID CHECKSUM LINE {line_no}'); continue
    if rel in sum_entries: errors.append('DUPLICATE CHECKSUM ENTRY: '+rel)
    sum_entries[rel]=expected
actual_files={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='09_SHA256SUMS.txt'}
for rel,path in actual_files.items():
    actual_hash=hashlib.sha256(path.read_bytes()).hexdigest(); expected=sum_entries.get(rel)
    if expected is None: errors.append('NOT HASHED: '+rel)
    elif expected!=actual_hash: errors.append('HASH ERROR: '+rel)
    item=manifest_files.get(rel)
    if item is None and rel!='08_PACKAGE_MANIFEST.json': errors.append('NOT IN MANIFEST: '+rel)
    elif item is not None:
        if item.get('sha256')!=actual_hash: errors.append('MANIFEST HASH ERROR: '+rel)
        if item.get('size_bytes')!=path.stat().st_size: errors.append('MANIFEST SIZE ERROR: '+rel)
for rel in sum_entries:
    if rel not in actual_files: errors.append('CHECKSUM TARGET MISSING: '+rel)
for rel in manifest_files:
    if rel not in actual_files: errors.append('MANIFEST TARGET MISSING: '+rel)
expected_count=len([x for x in actual_files if x!='08_PACKAGE_MANIFEST.json'])
if manifest.get('file_count_excluding_manifest_and_checksum')!=expected_count: errors.append(f"MANIFEST COUNT ERROR: {manifest.get('file_count_excluding_manifest_and_checksum')} != {expected_count}")
if manifest.get('version')!=active.get('version'): errors.append(f"MANIFEST VERSION ERROR: {manifest.get('version')} != ACTIVE {active.get('version')}")
if manifest.get('system_id')!=active.get('system_id'): errors.append('MANIFEST SYSTEM ID ERROR')
if errors:
    print('VERIFY = FAIL'); print('\n'.join(errors)); sys.exit(1)
print(f"VERIFY = PASS ({len(actual_files)} hashed files; version {active.get('version')}; checksum self-excluded)")
