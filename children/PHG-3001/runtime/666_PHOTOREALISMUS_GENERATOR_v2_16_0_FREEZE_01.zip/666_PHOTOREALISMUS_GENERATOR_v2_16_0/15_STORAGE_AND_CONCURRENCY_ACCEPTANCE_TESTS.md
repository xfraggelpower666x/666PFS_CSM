# STORAGE AND CONCURRENCY ACCEPTANCE TESTS
## v1.2.1

| Test | Input | Expected | Result |
|---|---|---|---|
| A | Active connector `dirk.meereis@icloud.com`, target owner matches | Continue to lock | DEFINED |
| B | Active connector `fraggelpower666@googlemail.com` | Block before write | PASS — live verified |
| C | iCloud-owned folder but uploaded file owner becomes FragglePower | Invalid commit and rollback | PASS — live verified |
| D | No lease | Block | PASS — rule verified |
| E | Owner readback unavailable | Commit unverified | PASS — rule verified |
| F | Owner, target, lock and base state all valid | Commit may verify | PENDING correct connector |
