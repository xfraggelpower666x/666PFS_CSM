# v2.0.0 - PHLF-CYBER INTEGRATION - 2026-08-02

- Integrated PHLF-CYBER v1.2.0 as a controlled extension.
- Added cyber hair, nail, makeup, accessory, outfit and Cyber-Love prompt capability.
- Preserved all prior runtime, guard, audit, legacy and recovery architecture.
- Added interruption-continuation documentation without creating a second router or update path.
- Adult remains an age-clarity term; explicit-content boundary remains unchanged.

# CHANGELOG

## v2.0.0 — Channel / Status Query Recovery
- hard pre-dispatch block for every non-commentary image-tool channel
- STATUS_QUERY classification for Ergebnis?/Status?/Wo ist das Bild?
- status queries cannot create host actions
- empty tool returns preserve source and intent and expose an explicit error reason
- regression tests added

## v2.0.0 — Creative Hot Path Separation

- Creative Image Runtime von Audit/Freeze/Backup/Storage-Governance getrennt
- Character Transformation Director als kompakter Hauptpfad integriert
- Multi-Step-Plan für Outfit, Pose, Kamera, Umgebung, Licht und Effekte integriert
- Identitätsanker bleibt aktiv, blockiert jedoch keine legitimen Pose-/Kameraänderungen
- Governance-Blöcke dürfen nicht mehr in kreative Bildprompts injiziert werden
- drei adaptive Creative Profiles: CHARACTER_TRANSFORMATION, IDENTITY_CRITICAL, WORLD_REBUILD
- Deep-Acceptance-Suite auf 40/40 PASS erweitert


## v1.6.0 — Edit Directive Expansion — 2026-07-14

- modulare Outfit-/Wardrobe-Steuerung integriert
- modulare Pose-/Body-Direction-Steuerung integriert
- Kamera-Reframing für Zoom In, Zoom Out, Close-up, Medium und Wide Shot integriert
- modulare Effektsteuerung für Regen, Nebel, Rauch, Glow, Motion Blur und ähnliche sichtbare Effekte integriert
- Edit-Konfiguration erweitert, ohne den Stage-2-Rahmenpfad zu beschädigen
- Prompt-Compiler um neue Triggerfamilien und Implementierungstexte erweitert
- Deep-Acceptance-Suite um Modulaktivierungs- und Boundary-Tests erweitert
- bestehende Identitäts-, Anatomie-, QA-, Receipt- und Persistenz-Hardlocks unverändert erhalten


## v1.5.2 — Complete Runtime Repair

- Root-Validator auf den kanonischen `ACTIVE/`-Pfad repariert
- vollständige Manifest-/Checksum-/Inventarprüfung ergänzt
- Trigger-Erkennung von Teilstring- auf Ganzphrasenprüfung umgestellt
- Fehlklassifikationen wie `logo → go` und `guardian → guard` blockiert
- kreative Folgeanweisungen mit erhaltener Quelle starten nach `COMPLETE` wieder einen echten Renderlauf
- Tool-Verfügbarkeit als ausführbarer Preflight-Guard integriert
- Dispatch-Idempotenz und vollständige Dispatch-Receipts integriert
- Output-Ownership um Attempt-, Source- und Prompt-Hash-Prüfung erweitert
- kritische Runtime-State-Prüfung vor Preflight, Dispatch und Output-Verarbeitung aktiviert
- lock-geschützte atomare Runtime-Persistenz ergänzt
- Canonical-Resolver isoliert `ACTIVE` verbindlich von `LEGACY`
- Guard-Register von 55 auf 65 Guards erweitert
- 18 Host-Turn-Tests und 10 zusätzliche Regressionstest-Gruppen integriert
- Root-Mirror-Register mit `ACTIVE/` synchronisiert


## v1.4.0 — Runtime Orchestration Matrix Repair

- Generation Supervisor Orchestra integrated as highest runtime authority
- machine-readable orchestra register with 9 orchestras added
- machine-readable guard register with 22 guards added
- state/event execution matrix with 13 deterministic paths added
- image tool invocation hard-locked to commentary channel
- final-channel image tool invocation explicitly blocked
- dispatch receipt and output-object receipt made mandatory
- runtime watchdog added against silent no-op and missing-return paths
- failure escalation and pending-source survival matrix added
- host execution contract added
- deterministic registry/matrix validator added
- v1.3.0 stability baseline preserved; image core and USBO unchanged

## v1.3.0 — Runtime Stability Repair

- new-image event now automatically dispatches Stage 1
- image-only messages are executable generation requests
- generation transaction state machine integrated
- returned-image completion gate integrated
- empty or missing tool output triggers exactly one automatic retry
- pending source can resume through `go` without re-upload
- newest user-supplied image becomes the default active target
- text-only success, empty responses and no-op paths blocked
- Stage-2 frame question blocked until Stage-1 output is validated
- malformed workflow Markdown codeblock repaired
- image core, identity, anatomy, frame and storage architecture preserved

## v1.2.1 — Security Repair

- live Drive owner-readback audit performed
- proved uploaded objects remained FragglePower-owned inside iCloud-owned folder
- rolled back and removed all test artifacts and folders
- replaced actor-to-target write permission with active identity + created-object ownership hardlock
- remote writes blocked until `dirk.meereis@icloud.com` is the active connector
- image-generation behavior unchanged

## v1.0.0 — 2026-07-14

### Erstveröffentlichung

- Eigenständiges System unter dem Namen `666 PHOTOREALISMUS GENERATOR`
- universelle fotorealistische Bildtransformation
- intelligente Presetauswahl
- Game-Character-to-Live-Action-Übersetzung
- vollständige Gelände-, Architektur- und Welttransformation
- Cyberpunk-, Cybertechnik-, Neon- und Future-Routing
- kontrollierter Erwachsenenmodus für eindeutig volljährige Personen
- strikte Anatomie-, Augen-, Hand-, Finger- und Objekt-Hardlocks
- rahmenloser Stage-1-Master
- optionale Stage-2-Rahmenversion nach Benutzerbestätigung
- Symbol-, Hauptsymbol-, Farb- und Namenskonfiguration
- kontrolliert zufällige Cyber-Typografie
- gezielte Rahmenänderungen bei unverändertem Masterbild

### Verpackungskorrektur

Die Funktion wurde zunächst irrtümlich als Versionsfortschreibung eines übergeordneten Bootstrap-Pakets behandelt. Diese Zuordnung wurde aufgehoben. Das Bildsystem besitzt ab dieser Veröffentlichung eine unabhängige Versionslinie ab `v1.0.0`.

## v1.1.0 — 2026-07-14

### Prompt-System Storage Identity Guard

- exakte Schreibidentitäts-Whitelist `dirk.meereis@icloud.com`
- Default-Deny für alle anderen Connector-Konten
- automatische Prüfung vor Upload, Update, Move, Rename, Delete, Freeze und Backup
- Schreibrechte oder freigegebene Zielordner gelten nicht als Bypass
- strikte Trennung zwischen zusätzlichen Promptsystemen und LYVRA-Speicheridentitäten
- Read-before-write und Post-write Read-back verpflichtend
- kein automatischer Konto-Fallback
- lokale Systemsicherung bleibt bei Drive-Blockade möglich


## v1.2.1 — 2026-07-14

### Technische Basis aktualisiert

- vollständige Bindung an `USBO v3.1.0 WITH STORAGE ROUTING AND CONCURRENCY GUARD v1.2.1`
- bisherige Exact-Connector-Whitelist des Generator-v1.1.0-Guards korrigiert
- Actor-to-Target-Autorisierungsmodell integriert
- FragglePower Googlemail/Gmail als ausdrücklich zugelassene technische Akteure
- Speicherung ausschließlich in den verifizierten Ziel-Drive von `dirk.meereis@icloud.com`
- kanonischer Root `Chat GPT Systeme` mit fester Root-ID verankert
- Speicherung in FragglePower-, LYVRA- oder `dirk.meereis@gmail.com`-eigenen Drives blockiert
- Cross-Chat Concurrent Write Coordination Guard integriert
- Drive-native Lease-Kandidatenwahl und mehrfacher Lock-Read-back
- Lease-Dauer, Heartbeat und kontrollierte Stale-Lock-Recovery integriert
- optimistische Base-Version-/Base-Hash-Prüfung integriert
- Zwei-Phasen-Commit und verifizierte Lease-Freigabe integriert
- getrennte Locks für Projektzweig, Release-Pointer, Registry und Katalog integriert
- vollständiges Parent-USBO als gebundene Unterstruktur mitgeliefert
- Bildkern, Presets, Anatomie-Hardlocks und Rahmenworkflow unverändert erhalten


## v1.5.1 — COMPLETE REPAIR

- Unified canonical states and legacy aliases.
- Added executable runtime kernel, expanded validator and 12 acceptance tests.
- Added 13 orchestras, 46 guards and 40 matrix paths.
- Added Visual QA, targeted repair, receipt schema, journal sequencing, modular prompt compiler and failure policy.
- Added Active/Legacy isolation and preserved v1.4.0 runtime.


## v1.5.1
- Same-turn image-tool dispatch hardlock.
- Atomic image-upload autorun.
- Control-plane versus creative-prompt separation.
- Manual retry triggers and host-action receipt requirements.


## v1.5.3 — Deep Runtime Integration Repair — 2026-07-14

- fail-closed Output- und Ownership-Beweiskette
- schema-konforme DISPATCH/OUTPUT/QA/TERMINAL-Receipts
- Retry- und Targeted-Repair-Recompile vollständig repariert
- deterministischer modularer Prompt-Compiler integriert
- strukturiertes Visual-QA-Evidence-Gate integriert
- Post-Tool Host Result Executor bis COMMIT_SUCCESS integriert
- Originalschreibweise und exakter sichtbarer Text geschützt
- kreative Guard/Matrix/Orchestra-Begriffe von Systemwartung getrennt
- transaktionsweiter Runtime-Store mit Revision/CAS, WAL und Readback
- Circuit Breaker/Failure Policy vereinheitlicht
- Frame Stage 2 als Child-Transaction umgesetzt
- 65/65 Hard Guards an ausführbare Komponenten gebunden
- 20/20 Deep-Acceptance-Tests bestanden

## v1.5.4 — Persistence Recovery and Boundary Repair — 2026-07-14

- abgewiesene Toolresultate werden jetzt vollständig persistiert
- Cancel- und Compilerfehlerpfade werden durable journalisiert
- WAL enthält gehashte New-/Before-Images und kann Teilwrites automatisch zurückrollen oder vollständig finalisieren
- Source-, Prompt- und Output-Hashes werden strikt als SHA-256 validiert
- Hash-Provenienz wird fail-closed geprüft
- Receipt-Validierung bleibt auch ohne `jsonschema` kritisch vollständig
- Prompt-Modultrigger verwenden Wort-/Phrasengrenzen statt unbeabsichtigter Teilworttreffer
- neues Ereignis `PROMPT_COMPILE_FAILED` und neuer Matrixpfad `MX-048` integriert
- Acceptance-Suite von 20 auf 28 Tests erweitert

## v2.0.0 — Identity Core and Creative Drift Control — 2026-07-14

- source-hash-bound identity profile introduced
- separate identity records for every visible person
- protected versus mutable trait policy introduced
- creativity budget and identity-drift veto introduced
- cross-person merging forbidden
- identity-core prompt module made mandatory
- acceptance suite expanded to 35 tests


## v2.1.0 — 2026-08-07
- Added FRAME_MODES family v1.0.0.
- Added semantic auto-frame intent routing.
- Added CYBER_LOVE_HOLO, CYBER_HOLO, CLEAN, POSTER, ROMANTIC_SIGNATURE, TECHNO, LUXURY, DARK and CUSTOM routes.
- Added contextual Fraggle / red holo heart / Veluna signature preset.
- Preserved v2.0.0 architecture and PHLF-CYBER v1.2.0.
- Drive publication pending because connector is unavailable in current host.

## v2.2.0 — 2026-08-11
- Added ASPECT_RATIO_ENGINE v1.0.0 with explicit user override priority.
- Added supported ratios 1:1, 4:3, 3:4, 16:9 and 9:16.
- Added PRESET_LYVRA_CYBER_HOLO_BROADCAST_16_9 as visual branding context only.
- Added exact broadcast title preservation and five-variant default output.
- Preserved all v2.0.0 runtime, PHLF-CYBER v1.2.0 and FRAME_MODES v1.0.0 components.
- External LYVRA system mutation remains forbidden.


## v2.3.0 — 2026-08-11
- Additive photorealistic preset expansion from verified chat handoff.
- Added strict reference preservation, CGI-drift guard, safe-frame margins, exact typography, semantic visual assets and failure diagnosis.
- Added 5 reusable visual presets.
- BLUE FISH semantic token resolves to BLUE_PALETTE_SURGEONFISH unless user explicitly requests literal text.
- FRAME_MODES extended in place to v1.1.0; no duplicate router.
- LYVRA external system unchanged.


## v2.9.0 — Cyber Love Frame System
- Integrated PRG-ADDON-CYBER-LOVE-FRAME-001 v1.0.0 ADD_ONLY.
- Added physical four-sided cyber-love frame engine with exact top/bottom text lock, infinity/heart modules, photorealistic shared-light interaction, 6–12% recommended occupancy and 15% normal maximum.
- Preserved all prior frame presets, PRESET_09, Cyber Morning IHC, Cyber Garden, Cyber Duality and Realism Control.
- External LYVRA unchanged.

## v2.11.0 — 2026-08-19
- Added PRG-CVICE-002 Causal Visual Intelligence & Continuity Engine as one ADD-ONLY visual intelligence core.
- Added role/authority reference graph, identity continuity, causal evolution, world-native fusion, causal key-art/cover compression, symbolic causality, minimal-invasive repair and visual audit subprofiles.
- UMIP visual ownership/mutation explicitly forbidden; existing PHG modules preserved.
## v2.12.0 — 2026-08-20
- Integrated PRG-CNSC-ADDON-001 v1.0.0 ADD_ONLY.
- Added source-symbol topology preservation, continuous material-aware cyber-neon color fusion, interwoven front/back geometry and semantic neon/laser energy convergence.
- Added optional RELATIONAL_NEON_HEART preset; general preset count 14 → 15.
- Reused CVICE and existing photorealism/material/typography/aspect/composition capabilities instead of duplicating visual authority.
- Preserved CVICE, I LOVE YOU/ENDLESS presets, Cyber Love Frame, Cyber Morning IHC, Cyber Garden, Cyber Duality and Realism Control.
- UMIP remains unmodified; external LYVRA remains unchanged.



## v2.13.0 — 2026-08-26
- Integrated LYVRA Frame/Dual-World DFramework addon via additive adapter.
- Integrated Causal Cyber Creature Relationship Engine via additive adapter.
- Integrated Emotional Visual Meaning addon via additive adapter.
- Detected CNSC as already integrated in v2.12.0 and prevented duplicate runtime insertion.
- Added unified old/new causal mode menu and resolver.
- Extended prompt compiler with DFramework adapter report/directive.
- No external LYVRA mutation; no deletion or silent replacement of existing modules/presets.
