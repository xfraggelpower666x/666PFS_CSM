# PHOTOREALISTIC CYBER NEON SYMBOLIC COMPOSITION ADDON
VERSION=1.0.0
STATUS=VORGESCHLAGEN_STANDALONE_ADDON
TARGET=PHOTOREALISTIC_GENERATOR
SCOPE=SYMBOL_RECONSTRUCTION|COLOR_FUSION|INTERWEAVE|NEON_ENERGY|PHOTOREAL_MATERIALS|HUMAN_SYMBOL_INTEGRATION|TYPOGRAPHY|CINEMATIC_COMPOSITION
UMIP_PRIMARY_TARGET=false
DESTRUCTIVE_INTEGRATION=false

## 1. Zweck
Dieses Add-on erweitert einen bestehenden fotorealistischen Generator um eine kontrollierte Cyber-Neon-Symbolinszenierung. Es abstrahiert die in der Referenzserie entwickelten Bildprinzipien, ohne konkrete Personen, Namen, Texte oder Liebesmotive fest in den Kern einzubauen.

Grundsatz:
SOURCE_IDENTITY ERHALTEN → TOPOLOGIE PRÜFEN → MATERIAL ÜBERSETZEN → LICHT PHYSISCH INTEGRIEREN → SZENE KOMPOSITORISCH AUFBAUEN → OUTPUT PRÜFEN.

## 2. Kernmodule

### M01 SYMBOL_RECONSTRUCTION_ENGINE
- erkennt Außenkontur, Innenformen, Schleifen, Kreuzungen und charakteristische Asymmetrien
- bewahrt die visuelle Identität einer einfachen Zeichnung oder eines Symbols
- entfernt Papier, Linien, Scan-Hintergrund oder Aufnahmeuntergrund nur auf Wunsch bzw. bei aktivierter Freistellung
- rekonstruiert nicht automatisch zu einem generischen Logo

### M02 CONTINUOUS_COLOR_FUSION_ENGINE
Ziel: organische, ununterbrochene Farbüberleitung entlang derselben Form.

Default Cyber Fusion:
PINK → MAGENTA → VIOLET → ELECTRIC_BLUE → CYAN

Regeln:
- keine harte Farbkante an geometrisch zusammenhängenden Segmenten
- Übergangszone folgt Materialkrümmung und Lichtfluss
- Emission, Reflexion und Materialfarbe werden gemeinsam interpoliert
- Kreuzungen dürfen unterschiedliche Vorder-/Hinterebenen besitzen, ohne visuell abzubrechen

### M03 INTERWOVEN_GEOMETRY_ENGINE
- räumlich konsistente Vorder-/Hinterführung
- kontinuierliche Rohr-, Band-, Kabel- oder Glasgeometrie
- Kontaktpunkte und Kreuzungen bleiben nachvollziehbar
- keine zufälligen Schnitte oder verschmolzenen Tangenten
- unterstützt Heart, Infinity, Rings, Braids, Cables, Runes und freie Symbole

### M04 NEON_ENERGY_LASER_ENGINE
Komponenten:
- emissive neon
- volumetric glow
- laser rays
- electric arcs
- micro sparks
- controlled bloom
- energy convergence points
- reflective light spill

ENERGY_CENTER kann an einem semantisch wichtigen Verbindungspunkt liegen.

### M05 PHOTOREALISTIC_MATERIAL_TRANSLATION
Materialprofile:
- NEON_GLASS
- TRANSLUCENT_POLYMER
- POLISHED_METAL
- CYBER_CERAMIC
- FIBER_OPTIC
- LIQUID_LIGHT_CHANNEL
- HYBRID_GLASS_METAL

Materialübersetzung darf die Quelltopologie nicht verändern.

### M06 HUMAN_SYMBOL_INTEGRATION_ENGINE
Optional.
- Symbollicht beeinflusst Haut, Haare, Kleidung und Umgebung
- Contact Light, Bounce Light und Reflections müssen zur Lichtquelle passen
- Personen bleiben primäres Motiv, wenn HUMAN_PRIORITY=true
- Gesichtsanatomie und natürliche Hautstruktur werden vor dekorativen Cyberdetails priorisiert

### M07 SEMANTIC_TYPOGRAPHY_ENGINE
Optional und instanzbasiert.
Slots:
LEFT_NAME
RIGHT_NAME
CENTER_STATEMENT
TOP_HEADLINE
SUBLINE
SIDE_MANTRA_LEFT
SIDE_MANTRA_RIGHT

Keine Namen oder Aussagen sind im Framework fest verdrahtet.
Text muss lesbar, korrekt geschrieben und kompositorisch integriert sein.

### M08 CINEMATIC_CYBER_INTERFACE_COMPOSITOR
Sekundäre Ebenen:
- HUD
- circuitry
- ECG / frequency traces
- holographic panels
- particles
- skyline
- botanical/rose accents
- technical frame
- atmospheric haze

Sekundäre Ebenen dürfen Hauptmotiv, Symbol oder Gesichter nicht überdecken.

## 3. Guards

### SYMBOL_FIDELITY_GUARD
SOURCE_SYMBOL_AUTHORITY=HIGH
GEOMETRIC_IDENTITY_PRESERVATION=REQUIRED
TOPOLOGY_PRESERVATION=REQUIRED
INTERWEAVE_CONTINUITY=REQUIRED
COLOR_CONTINUITY=REQUIRED
ACCIDENTAL_SYMMETRIZATION=FORBIDDEN
ACCIDENTAL_INFINITY_REPLACEMENT=FORBIDDEN
SOURCE_CHARACTER_LOSS=FORBIDDEN
BACKGROUND_PAPER_RECONSTRUCTION=FORBIDDEN_WHEN_CLEAN_BACKGROUND_REQUESTED

### PHOTOREALISM_GUARD
PHYSICAL_LIGHT_INTERACTION=REQUIRED
COHERENT_REFLECTIONS=REQUIRED
MATERIAL_CONSISTENCY=REQUIRED
DEPTH_CONSISTENCY=REQUIRED
REALISTIC_BLOOM=REQUIRED
CONTACT_ILLUMINATION=REQUIRED
ATMOSPHERIC_INTEGRATION=REQUIRED
PLASTIC_SKIN=FORBIDDEN
UNINTENTIONAL_CGI_FACE=FORBIDDEN

### GLOW_GUARD
WHITE_CLIP_DOMINANCE=FORBIDDEN
COLOR_CORE_RETENTION=REQUIRED
EDGE_DETAIL_RETENTION=REQUIRED
BLOOM_RADIUS=CONTROLLED
LASER_SOURCE_LOGIC=REQUIRED

### TEXT_GUARD
SPELLING_PRESERVATION=REQUIRED
UNREQUESTED_TEXT=FORBIDDEN
GIBBERISH_UI_TEXT=DISCOURAGED
PRIMARY_TEXT_READABILITY=HIGH

## 4. Kompositionspriorität
1. HUMAN_SUBJECT oder PRIMARY_OBJECT
2. SOURCE_SYMBOL
3. SYMBOLIC_RELATIONSHIP
4. LIGHT_AND_ENERGY
5. TYPOGRAPHY
6. ENVIRONMENT
7. HUD_AND_DECORATIVE_DETAIL

## 5. Seitenverhältnisse

### 16:9 CINEMATIC
- horizontale Story-Fläche
- Namen/Identitäten können links/rechts verankert werden
- Zentrum für Verbindungssymbol und Energiepunkt
- ausreichend Negativraum für Headline und UI

### 1:1 EMBLEM
- Symbol dominant und zentriert
- Typografie reduziert
- Energie radial
- UI nur als Rahmen/Atmosphäre

### 4:5 PORTRAIT_POSTER
- vertikale Hierarchie
- Personen/Symbol zentral
- Headline oben, Statement unten
- Seiten-HUD kompakt

## 6. Universelles Input-Schema
SOURCE_IMAGE=<optional>
SOURCE_SYMBOL_DESCRIPTION=<optional>
PRIMARY_SUBJECT=<symbol|object|human_pair|human_single>
SYMBOL_FIDELITY=<low|medium|high|strict>
COLOR_LEFT=<color>
COLOR_RIGHT=<color>
COLOR_TRANSITION=<continuous|segmented|none>
TRANSITION_MIDPOINT=<color>
MATERIAL_PROFILE=<profile>
ENERGY_STYLE=<neon|laser|lightning|hybrid>
ENERGY_INTENSITY=<1-10>
HUMAN_PRIORITY=<true|false>
TYPOGRAPHY_ENABLED=<true|false>
ASPECT_RATIO=<16:9|1:1|4:5|custom>
BACKGROUND=<clean_dark|cyber_city|abstract_circuit|custom>
HUD_DENSITY=<0-10>
PHOTOREALISM=<1-10>

## 7. Output-Pipeline
P01 SOURCE_ANALYSIS
P02 TOPOLOGY_MAP
P03 SEMANTIC_LAYER_MAP
P04 MATERIAL_ASSIGNMENT
P05 COLOR_FLOW_MAP
P06 LIGHT_ENERGY_PLAN
P07 COMPOSITION_PLAN
P08 PHOTOREAL_RENDER
P09 FIDELITY_AUDIT
P10 LIGHT_MATERIAL_AUDIT
P11 TYPOGRAPHY_AUDIT
P12 FINAL_OUTPUT

Bei Fehlern:
AUDIT_FAIL → gezielte Reparatur des betroffenen Layers → Re-Audit.
Keine vollständige Neuinterpretation, wenn eine lokale Reparatur genügt.

## 8. Preset: RELATIONAL_NEON_HEART
TYPE=OPTIONAL_PRESET
LEFT_IDENTITY_COLOR=PINK_MAGENTA
RIGHT_IDENTITY_COLOR=ELECTRIC_BLUE_CYAN
CONNECTION_ZONE=VIOLET_FUSION
CENTRAL_ENERGY=NEON_LIGHTNING_LASER_HEART
RELATIONSHIP_GEOMETRY=INTERWOVEN_NOT_SEPARATED
BOTTOM_STATEMENT_SLOT=ENABLED
DEFAULT_BOTTOM_STATEMENT=EMPTY
ASPECT_RATIO=16:9
HUD_DENSITY=5
PHOTOREALISM=9
ENERGY_INTENSITY=8

Hinweis:
Namen wie Dirk/Erin und Aussagen wie WE ARE ONE sind Nutzdaten eines konkreten Renderings und keine kanonischen Bestandteile des Add-ons.

## 9. Negativregeln
- keine harte Pink/Blau-Trennkante bei gewünschtem Verlauf
- keine abgeschnittenen Schleifen
- keine zufällige Umwandlung eines individuellen Symbols in ein Standard-Infinity-Zeichen
- kein Papierhintergrund bei gewünschter sauberer Freistellung
- keine überstrahlten Gesichter
- keine unphysikalischen Reflexionen
- keine dekorative Überladung vor dem Primärmotiv
- keine ungefragten Wörter, Logos oder Namen
- keine Veränderung des bestehenden Generator-Kerns durch dieses Standalone-Paket

## 10. Integrationsvertrag
INTEGRATION_MODE=ADD_ONLY
CORE_REPLACEMENT=FORBIDDEN
EXISTING_MODULE_RENAME=FORBIDDEN
EXISTING_PROMPT_LOGIC_DELETE=FORBIDDEN
HOOK_STRATEGY=ADAPTER
REQUIRED_HOST_CAPABILITIES:
- image/reference input optional
- prompt composition
- aspect-ratio routing
- negative constraints
- photoreal rendering target

Empfohlener Adapter-Hook:
POST_SOURCE_ANALYSIS → CYBER_NEON_SYMBOLIC_ADDON → PRE_RENDER_COMPOSITION

Falls der Host bereits gleichwertige Symbol-, Licht- oder Materialmodule besitzt:
DUPLICATE_FUNCTION → MAP_EXISTING_CAPABILITY → DO_NOT_DUPLICATE.

## 11. Audit-Checkliste
- [ ] Quellsymbol wiedererkennbar
- [ ] Topologie erhalten
- [ ] Verschlingungen räumlich plausibel
- [ ] Farbverlauf kontinuierlich
- [ ] Violette Übergangszone natürlich
- [ ] Neon behält Farbkern
- [ ] Laser/Blitze haben nachvollziehbare Quelle
- [ ] Materialien reagieren konsistent auf Licht
- [ ] Gesichter/Haut bleiben fotorealistisch, falls vorhanden
- [ ] Typografie korrekt und lesbar
- [ ] Sekundärdetails überdecken nichts Wesentliches
- [ ] Seitenverhältnis kompositorisch genutzt
- [ ] Keine ungefragten Texte
- [ ] Keine Host-Core-Mutation

## 12. Freeze-Metadaten
ADDON_ID=PRG-CNSC-ADDON-001
VERSION=1.0.0
FREEZE_SCOPE=STANDALONE_ADDON_DEFINITION
HOST_INTEGRATION=NOT_PERFORMED
HOST_COMPATIBILITY=NOT_VERIFIED
SOURCE_REFERENCES=CONVERSATION_IMAGE_SERIES
