# PHG-3001 v2.7.0 REPAIR LEDGER

- PRESERVED: entire v2.6.0 runtime including Cyber Garden 47-49 and Cyber Duality 50-52.
- ADDED: Realism Control Suite v1.0.0 under `EXTENSIONS/REALISM_CONTROL_SUITE_v1_0_0`.
- ADDED/RENAMED: `ACTIVE/53_REALISM_CONTROL_ADDON.py`, `54_RUN_REALISM_CONTROL_TESTS.py`, `55_REALISM_CONTROL_REGISTRY.json`.
- PATCHED: `ACTIVE/26_PROMPT_COMPILER.py` with additive Realism Control analysis/directive/report.
- PATCHED: `ACTIVE/00_ACTIVE_MANIFEST.json`, `ACTIVE/09_PROMPT_MODULE_REGISTRY.json`.
- REPAIRED: `32_VERIFY_PACKAGE.py` current-version validation.
- REPAIRED: `117_REBUILD_PACKAGE_MANIFEST.py` current-version manifest generation.
- NOT IMPORTED: source v2.4 host runtime replacements and source pre-change backup folder.
- LYVRA: external / unchanged.

- RE-AUDIT REPAIR: lone `RIG-01-PHOTOREALISM_LOCK` directive is deduplicated when PHG core already supplies equivalent photoreal reconstruction constraints; report remains active, prompt stays within compact-block contract.
