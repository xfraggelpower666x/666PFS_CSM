# 666 PHOTOREALISMUS GENERATOR — RELEASE HANDOFF v1.5.4

## Aktiver Stand

- System: `666 PHOTOREALISMUS GENERATOR`
- System-ID: `666-PRG-001`
- Aktive Version: `1.5.4`
- Kanonischer Root: `ACTIVE/`
- Vorherige gefrorene Basis: `1.5.3`
- Status: `CANONICAL_FROZEN_PERSISTENCE_RECOVERY_AND_BOUNDARY_REPAIR_STABLE`

## Verbindlicher Start

```bash
python3 ACTIVE/25_CANONICAL_RESOLVER.py
python3 ACTIVE/12_VALIDATE_ACTIVE_RUNTIME.py
python3 ACTIVE/30_RUN_V154_ACCEPTANCE_TESTS.py
python3 66_FULL_SYSTEM_AUDIT.py
```

## Runtime-Einstiege

- Host-Turn: `ACTIVE/19_HOST_TURN_EXECUTOR.py`
- Toolresultat: `ACTIVE/28_HOST_RESULT_EXECUTOR.py`
- Runtime-Store: `ACTIVE/22_RUNTIME_STORE.py`
- Prompt-Compiler: `ACTIVE/26_PROMPT_COMPILER.py`
- Visual QA: `ACTIVE/27_VISUAL_QA_ENGINE.py`

## Recovery-Regel

Vor jedem State-Read und jedem Commit prüft der Runtime-Store eine vorhandene WAL. Vollständig geschriebene Generationen werden finalisiert; Teilwrites werden aus gehashten Before-Images vollständig zurückgerollt. Eine korrupte oder nicht wiederherstellbare WAL blockiert fail-closed.

## Fortsetzungsregel

Nur `ACTIVE/` darf automatisch geladen werden. Historische Releases und `LEGACY/` bleiben Referenz und Fallback, dürfen aber den aktiven Stand nicht überschreiben.
