#!/usr/bin/env python3
"""Rebuild current PHG package manifest/checksum without hardcoded legacy version."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent; MANIFEST=ROOT/'08_PACKAGE_MANIFEST.json'; SUMS=ROOT/'09_SHA256SUMS.txt'; ACTIVE=ROOT/'ACTIVE'/'00_ACTIVE_MANIFEST.json'
def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()
active=json.loads(ACTIVE.read_text(encoding='utf-8'))
old=json.loads(MANIFEST.read_text(encoding='utf-8')) if MANIFEST.exists() else {}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p not in {MANIFEST,SUMS})
items=[{'path':p.relative_to(ROOT).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha256(p)} for p in files]
manifest={
 'system_name':active.get('system_name','666 PHOTOREALISMUS GENERATOR'),
 'system_id':active.get('system_id','666-PRG-001'),
 'child_entry_id':'PHG-3001',
 'version':active['version'],
 'freeze_id':old.get('freeze_id',f"666-PRG-001-v{active['version']}-FREEZE-01"),
 'status':old.get('status','LOCAL_FREEZE_BUILD'),
 'previous_drive_baseline':old.get('previous_drive_baseline'),
 'integrated_extensions':old.get('integrated_extensions',[]),
 'file_count_excluding_manifest_and_checksum':len(items),
 'files':items,
}
MANIFEST.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sum_files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p!=SUMS)
SUMS.write_text(''.join(f"{sha256(p)}  {p.relative_to(ROOT).as_posix()}\n" for p in sum_files),encoding='utf-8')
print(f"MANIFEST REBUILD = PASS ({len(items)} files plus manifest; version {active['version']})")
