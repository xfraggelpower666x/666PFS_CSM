# REMOTE OBJECT OWNERSHIP HARDLOCK
## Version 1.0.0

```text
REQUIRED_ACTIVE_CREATOR = dirk.meereis@icloud.com
REQUIRED_CREATED_OBJECT_OWNER = dirk.meereis@icloud.com
FAILURE_MODE = FAIL_CLOSED
```

Folder ownership and parent location are insufficient. Every file and folder created, copied, imported or uploaded must be read back and must report the approved owner. Wrong-owner artifacts are invalid and must be rolled back when safe.
