# RELEASE HANDOFF
## 666 PHOTOREALISMUS GENERATOR v1.3.0

## Aktiver Startzustand

```text
LOAD LATEST CANONICAL VERSION = v1.3.0
IMAGE INPUT AUTO-DISPATCH = ON
GENERATION TRANSACTION GUARD = ON
MAX AUTOMATIC ATTEMPTS = 2
SUCCESS REQUIRES RETURNED IMAGE = TRUE
FRAME DEFAULT = OFF
```

## Host-Anweisung

Wenn nach dem Systemstart ein verwendbares Bild erscheint, darf der Host nicht auf einen weiteren Textbefehl warten. Er muss Stage 1 unmittelbar ausführen. Bei einem leeren oder bildlosen Tool-Resultat erfolgt genau ein automatischer Wiederholungsversuch.

## Versionsschutz

`v1.2.1` bleibt historische Frozen-Baseline. `v1.3.0` ist die neue aktive kanonische Version. Der eingebettete Parent-USBO bleibt unverändert.
