# PHG v2.16.0 — Repair Ledger

Repairs performed:
1. Rebuild stale package manifest/checksum index that remained at v2.13 metadata inside v2.15.
2. Exclude transient __pycache__ artifacts from package verification.
3. Preserve seven-section mode-menu topology while extending the existing Special section with ENSC/DSR modes.
4. Keep Remote/Drive publication outside this local freeze; no false pointer promotion.
