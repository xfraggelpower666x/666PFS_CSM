# PHG MODE MENU v2.13.0

The machine-readable menu is `ACTIVE/75_MODE_MENU_REGISTRY.json`.

Selection priority:
1. Explicit user mode
2. Semantic intent routing
3. Combine compatible modes causally
4. Identity/reference preservation outranks style
5. Reuse existing engines; do not duplicate capabilities
6. Targeted layer repair only, followed by re-audit

Sections: Core, existing presets, existing special modes, LYVRA Frame/Dual World, CCRE, Emotional Visual Meaning, causal combinations.
