# 666 PHOTOREALISMUS GENERATOR — MASTER v2.9.0

SYSTEM_ID=666-PRG-001
ENTRY_ID=PHG-3001
VERSION=2.9.0
BASELINE=2.8.0

## New in v2.9.0
PRG-ADDON-CYBER-LOVE-FRAME-001 v1.0.0 is integrated as an additive physical cyber-romantic frame architecture. It uses the existing FRAME_MODE_CYBER_LOVE_HOLO as a compatible base and does not replace existing frame families.

Canonical defaults when this addon is explicitly active:
- TOP_FRAME text: I LOVE YOU
- BOTTOM_FRAME text: ENDLESS
- Complexity: LEVEL 2 BALANCED
- Recommended frame occupancy: 6–12%
- Normal maximum: 15%

User-provided exact text overrides the relevant default slot. No silent translation, paraphrase, spelling mutation, random text, logos, signatures or watermarks.

Source identity, parent photorealism and source composition remain higher priority than decorative frame detail. Physical materials, depth, realistic light spill and shared scene/frame lighting are mandatory.

All v2.8.0 capabilities remain preserved. External LYVRA is unchanged.
