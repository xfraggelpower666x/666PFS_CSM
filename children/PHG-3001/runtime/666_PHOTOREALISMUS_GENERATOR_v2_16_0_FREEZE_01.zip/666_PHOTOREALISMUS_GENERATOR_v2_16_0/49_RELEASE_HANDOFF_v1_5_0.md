# RELEASE HANDOFF — v1.5.0

Start with `ACTIVE/13_BOOT_CAPSULE.md`.

Active runtime is `ACTIVE/11_RUNTIME_KERNEL.py`. Legacy runtime under `LEGACY/v1.4.0_RUNTIME/` is read-only fallback. The host must call the image tool in commentary and return explicit result events. Completion is forbidden until output ownership and Visual QA pass.
