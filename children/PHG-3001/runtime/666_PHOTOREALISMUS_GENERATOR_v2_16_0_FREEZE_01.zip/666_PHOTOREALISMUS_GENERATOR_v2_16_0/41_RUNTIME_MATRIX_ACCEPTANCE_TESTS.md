> **LEGACY RELEASE RECORD:** This v1.4.0 document is preserved for audit/history. Active execution is defined under `ACTIVE/`.

# RUNTIME MATRIX ACCEPTANCE TESTS
## 666 PHOTOREALISMUS GENERATOR v1.4.0

| ID | Test | Erwartung |
|---|---|---|
| R01 | Registry JSON parse | alle Register valide |
| R02 | Unique orchestra IDs | keine Duplikate |
| R03 | Unique guard IDs | keine Duplikate |
| R04 | Matrix orchestra references | alle referenzierten Orchestras vorhanden |
| R05 | Matrix guard references | alle referenzierten Guards vorhanden |
| R06 | New image path | `IDLE + NEW_IMAGE` vorhanden |
| R07 | Resume path | `FAILED_TERMINAL + RESUME_COMMAND` vorhanden |
| R08 | Commentary channel guard | vorhanden und HARD |
| R09 | Final-channel prohibition | explizit vorhanden |
| R10 | Dispatch receipt | Pflichtguard vorhanden |
| R11 | Missing output recovery | Matrixpfad vorhanden |
| R12 | Retry exhaustion | Terminalpfad vorhanden |
| R13 | Success object gate | Pflichtguard vorhanden |
| R14 | Stage-2 gate | nur nach Output validation |
| R15 | Pending source survival | Pflichtguard vorhanden |
| R16 | No unregistered paths | Default policy deny |

Die Tests werden durch `44_VALIDATE_RUNTIME_REGISTRY.py` statisch und deterministisch geprüft.
