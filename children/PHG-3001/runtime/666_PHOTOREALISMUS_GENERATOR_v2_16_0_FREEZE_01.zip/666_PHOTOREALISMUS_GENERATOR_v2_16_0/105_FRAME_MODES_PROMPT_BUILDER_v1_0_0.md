# FRAME_MODES PROMPT BUILDER v1.0.0

1. Detect frame intent from natural language.
2. Resolve mode using explicit style first.
3. Preserve validated central image.
4. Apply the selected frame as an additive perimeter layer.
5. Add only requested/inferred missing decorations.
6. Apply contextual signature only when requested or clearly specified.
7. Audit face/eye/hand/contact/text occlusion.

Compiler contract:
`[FRAME_MODES] Activate <MODE> as an additive outer frame layer. Preserve protected central content. Explicit user instructions override defaults; infer only missing parameters.`
