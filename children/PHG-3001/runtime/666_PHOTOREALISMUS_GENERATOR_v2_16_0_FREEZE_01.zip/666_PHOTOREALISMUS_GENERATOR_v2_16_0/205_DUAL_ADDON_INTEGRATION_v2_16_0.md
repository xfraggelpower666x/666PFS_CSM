# PHG v2.16.0 — ENSC-004 + DSR-005 Integration

Status: INTEGRATED

ENSC-004 adds environmental narrative, weather/story mapping, environmental causality, wet-material realism, scene↔text↔symbol coherence and hard name-side binding.

DSR-005 adds per-image person-side state, identity-owned property remapping, color-person binding, frame-region remapping, connector neutrality and side-swap protection.

Integration is additive. Existing Core/CVICE/Identity/Frame authority remains unchanged. DSR-005 composes downstream of ENSC-004 for name-side enforcement.
