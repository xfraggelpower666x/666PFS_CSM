# COMPLETE REPAIR LEDGER — v1.5.0

- Canonical state model unified; all legacy state names mapped explicitly.
- Active/Legacy split introduced without deleting v1.4.0 runtime files.
- Executable deterministic runtime kernel added.
- Event catalog, state groups and default-deny routing added.
- Matrix expanded to 40 paths including supersession, cancel, intent change, source switch, stale/duplicate output, policy rejection, rate limit and frame gating.
- Registry expanded to 13 orchestras and 46 guards.
- Structured dispatch/output/QA/terminal receipt schema added.
- Visual-QA profile and targeted repair route added.
- Modular prompt compiler registry added.
- Failure policy, backoff and circuit breaker specification added.
- Deep graph validator and executable acceptance suite added.
- Runtime journals excluded from frozen backup; templates only.
- Parent USBO v3.1.0 retained unchanged.
