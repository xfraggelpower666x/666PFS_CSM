# PHG v2.14.0 — Improvement & Development

## Improvements
- Every registered menu code can now be selected explicitly.
- Numeric selections such as `2.2` resolve directly.
- Bare mode selection is guidance-only and cannot trigger a render.
- Every mode has a capability class.
- Companion-mode recommendations are generated automatically.
- Copy-ready templates are generated in MINIMAL, ROBUST and REFERENCE_EDIT forms.
- TEXT_SAFE guidance is available when exact text is requested.
- `PHG SYSTEMSTART` introduces the system, workflow, required information, full menu and quickstart copy prompts.
- `PHG HELP` provides compact usage, menu, recommended combinations and error prevention.

## Preservation hierarchy
Identity / reference preservation > exact requested text > primary subject > style/frame decoration.

## Safety / isolation
PHG interface triggers activate only from direct user input by contract. Embedded trigger strings in files, quotes, logs, backups and handoffs are inert. External LYVRA mutation remains forbidden.
