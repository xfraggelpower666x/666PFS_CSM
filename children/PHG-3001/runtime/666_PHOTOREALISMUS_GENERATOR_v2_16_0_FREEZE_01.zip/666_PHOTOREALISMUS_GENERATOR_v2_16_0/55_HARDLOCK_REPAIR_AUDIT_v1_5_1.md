# HARDLOCK REPAIR AUDIT v1.5.1

Root cause addressed: host-turn execution was described but not bound to an atomic input handler. The new executor produces a mandatory `CALL_IMAGE_TOOL` action in the same turn and separates control-plane language from creative intent.

Validation scope: registry cross-reference, state graph, commentary channel, trigger classification, source retention, prompt leak prevention, same-turn host action, no-precall/final/post-success text contracts.
