# CHANGELOG
## UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR

## Storage routing and concurrency guard v1.2.0

- Added single-write-Drive hardlock.
- Added project-scoped remote lease locks.
- Added shared-resource locks for registry, catalog, and pointers.
- Added deterministic candidate election.
- Added double lock confirmation.
- Added heartbeat and stale-lock recovery.
- Added optimistic concurrency checks.
- Added two-phase commit.
- Parent bootstrap remains v3.1.0.

## Storage routing repair — PROMPT-STORAGE-GUARD-001 v1.1.0

- Parent version remains `3.1.0`.
- Added fail-closed storage identity routing.
- Replaced identity-only authorization with explicit actor-to-target routing.
- Added remote mutation block for all unapproved identities.
- Added no-permission-bypass and no-account-fallback rules.
- Added read-before-write and post-write readback hardlocks.
- Added local-only continuation when remote writes are blocked.

## v3.1.0

### Integrated from Foundation Canonical Baseline v2.0.0

- Materialized Universal Visual Output Governance Frontloader
- Continue and Recap Controller
- Architecture Decision Record Controller
- Preflight / Import / Version Seal Controller
- Extended Module Register

### Preserved without duplication

- Existing lifecycle, audit, repair, freeze, backup, recovery, versioning, orchestration, and architecture layers

## v3.1.0

### Added

- Canonical Project Registry
- System Memory Ledger
- Dependency Graph
- Lifecycle Controller
- Event Engine
- Lifecycle checkpoints
- State divergence gate
- Registry update only after verified Drive commit
- Event-driven continuation and recovery

## v3.1.0

### Added

- Persistent State Manager
- Runtime connector identity verification
- Read-before-write canonical state loading
- Current pointer and catalog update gates
- Divergence detection between chat and Drive state
- Verified persistent commit sequence
- SYSTEM_DIRTY retention until Drive commit verification

## v3.1.0

### Added

- Mandatory automatic Google Drive backup after every successful local freeze or backup.
- Two-attempt bounded retry for failed automatic Drive upload steps.
- Automatic transition to manual rescue only after technical blocking.
- New Drive backup status codes.
- Explicit rule that the system must not wait for a second user request to save to Drive.

## v2.0.0

### Consolidated

- Universal Chat System Start
- Drive Save Rescue Fallback
- Orchestration and System Development Foundation
- Non-Destructive Integration Layer

### Added during consolidation

- User Interruption Continuation Guard
- Interruption Hook
- Resume Hook
- Last Safe Checkpoint recovery
- Partial invalidation instead of total restart
- Interruption reporting in output contracts and changelog

### Preserved

- Consent and authorization gates
- Existing-system preservation
- Least-invasive integration
- Security and write guards
- Audit and targeted repair
- Freeze, backup, recovery, and handoff
- No fake verification

## Corrected authorization policy

- Approved acting connectors: `fraggelpower666@googlemail.com`, `fraggelpower666@gmail.com`
- Required target owner: `dirk.meereis@icloud.com`
- Forbidden target owners: FragglePower-owned and alternate Gmail-owned Drives
- Parent bootstrap remains `v3.1.0`
