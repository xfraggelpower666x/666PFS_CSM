# STORAGE AND CONCURRENCY ACCEPTANCE TESTS

**Generated UTC:** `2026-07-14T13:55:59Z`

| Test | Scenario | Expected | Result |
|---|---|---|---|
| A | No lock exists | One deterministic winner | PASS |
| B | Another chat holds active lock | Second chat blocked | PASS |
| C | Two candidates created together | Lowest `(created_at, lock_id)` wins | PASS |
| D | Lock listing incomplete | Fail closed | PASS |
| E | Heartbeat stops | Stale recovery required | PASS |
| F | Base state changes after acquisition | Commit aborted | PASS |
| G | Artifacts staged, pointer not committed | Second writer blocked | PASS |
| H | Pointer and registry readback match | Commit verified, lease released | PASS |
| I | Different systems and branches | Preparation may run concurrently | PASS |
| J | Both need registry update | Registry mutations serialized | PASS |
| K | Target owner differs from `dirk.meereis@icloud.com` | Write blocked | PASS |
| L | Target root ID differs from `1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3` | Write blocked | PASS |

```text
TEST_RESULT = 12 / 12 PASS
```
