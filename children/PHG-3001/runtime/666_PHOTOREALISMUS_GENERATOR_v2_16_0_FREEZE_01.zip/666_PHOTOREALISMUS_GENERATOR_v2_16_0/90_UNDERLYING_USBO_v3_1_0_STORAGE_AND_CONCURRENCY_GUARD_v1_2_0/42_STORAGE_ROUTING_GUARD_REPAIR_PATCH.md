# STORAGE ROUTING GUARD REPAIR PATCH

```text
PATCH_ID = PROMPT-STORAGE-GUARD-REPAIR-001
FROM_MODULE_VERSION = 1.0.0
TO_MODULE_VERSION = 1.1.0
PARENT_VERSION = 3.1.0
PARENT_VERSION_MUTATION = FALSE
REPAIR_TYPE = AUTHORIZATION_MODEL_CORRECTION
```

## Incorrect old model

```text
ACTIVE_CONNECTOR_EMAIL must equal dirk.meereis@icloud.com
```

## Correct model

```text
ACTIVE_CONNECTOR_EMAIL must be an approved actor
AND
TARGET_OWNER must equal dirk.meereis@icloud.com
```

Approved actors:

```text
fraggelpower666@googlemail.com
fraggelpower666@gmail.com
```

Forbidden target owners:

```text
fraggelpower666@googlemail.com
fraggelpower666@gmail.com
dirk.meereis@gmail.com
```

This permits the FragglePower connector to use its granted Writer permission
inside the canonical Drive owned by `dirk.meereis@icloud.com`, while preventing storage
on LYVRA-related or alternate Gmail-owned Drives.
