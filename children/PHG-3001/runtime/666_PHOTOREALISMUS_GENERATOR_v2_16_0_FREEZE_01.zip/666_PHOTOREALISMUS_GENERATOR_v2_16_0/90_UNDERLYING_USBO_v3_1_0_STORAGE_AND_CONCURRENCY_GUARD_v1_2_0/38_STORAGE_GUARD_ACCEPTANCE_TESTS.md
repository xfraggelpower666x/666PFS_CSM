# STORAGE ROUTING GUARD ACCEPTANCE TESTS

**Generated UTC:** `2026-07-14T13:49:48Z`

| Test | Actor | Target owner | Expected | Result |
|---|---|---|---|---|
| A | `fraggelpower666@googlemail.com` | `dirk.meereis@icloud.com` | PREFLIGHT_CONTINUES | PASS |
| B | `fraggelpower666@gmail.com` | `dirk.meereis@icloud.com` | PREFLIGHT_CONTINUES | PASS |
| C | `fraggelpower666@googlemail.com` | `fraggelpower666@googlemail.com` | WRITE_BLOCKED | PASS |
| D | `fraggelpower666@googlemail.com` | `dirk.meereis@gmail.com` | WRITE_BLOCKED | PASS |
| E | `unauthorized@example.com` | `dirk.meereis@icloud.com` | WRITE_BLOCKED | PASS |
| F | `fraggelpower666@googlemail.com` | `dirk.meereis@icloud.com` + wrong branch | WRITE_BLOCKED | PASS |
| G | `fraggelpower666@googlemail.com` | `dirk.meereis@icloud.com` + matching readback | DRIVE_COMMIT_VERIFIED | PASS |

## Live metadata check

```text
ACTIVE_CONNECTOR = fraggelpower666@googlemail.com
CANONICAL_ROOT = Chat GPT Systeme
CANONICAL_ROOT_ID = 1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3
TARGET_OWNER = dirk.meereis@icloud.com
WRITER_PERMISSION_ENTRY = fraggelpower666@gmail.com
ROUTE_DECISION = AUTHORIZED_IN_PRINCIPLE
```
