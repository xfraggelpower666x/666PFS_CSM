# SINGLE WRITE DRIVE HARDLOCK
## Additional Prompt Systems

```text
MODULE_ID = SINGLE-WRITE-DRIVE-HARDLOCK-001
MODULE_VERSION = 1.0.0
STATUS = CANONICAL_HARDLOCK
FAILURE_MODE = FAIL_CLOSED
```

# Canonical target

```text
OWNER = dirk.meereis@icloud.com
ROOT_NAME = Chat GPT Systeme
ROOT_ID = 1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3
```

# Authorized actors

```text
fraggelpower666@googlemail.com
fraggelpower666@gmail.com
```

# Governing rule

```text
The actor may differ from the owner.
The write destination may not.
```

Every target folder must have an ancestor chain that resolves to the canonical
root ID `1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3`.

The following are forbidden as storage destinations for independent prompt
systems:

```text
connector root
FragglePower-owned Drive
LYVRA / LÜVRA / LIBRA branches
dirk.meereis@gmail.com-owned Drive
unknown owner
unknown ancestor chain
parallel replacement root
```

When owner, root ID, or ancestor chain cannot be verified:

```text
REMOTE_WRITE_AUTHORIZATION = DENIED
LOCAL_BACKUP = RETAINED
```
