# RECOVERY GUIDE
## UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR v3.1.0

## Restore sequence

1. Obtain `UNIVERSAL_SYSTEM_BOOTSTRAP_ORCHESTRATOR_v2_0_0.zip`.
2. Verify ZIP integrity.
3. Extract into an isolated folder.
4. Verify `12_SHA256SUMS.txt`.
5. Open `00_START_HERE.md`.
6. Load `01_MASTER_BOOTSTRAP_LOADER.md`.
7. Confirm System ID `USBO-CORE-001`.
8. Confirm version `2.0.0`.
9. Run context detection before live actions.
10. Preserve existing systems before integration.

## Interrupted recovery

If recovery is interrupted by new user information:

```text
CAPTURE NEW INFORMATION
→ UPDATE RESTORE PLAN
→ PRESERVE VERIFIED EXTRACTED FILES
→ RESUME FROM LAST VERIFIED FILE
```

## Failure handling

If checksum verification fails:

```text
RECOVERY_STATUS = BLOCKED
```

Do not use corrupted files.
