# UNIVERSAL VISUAL OUTPUT GOVERNANCE FRONTLOADER
## UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR v3.1.0

**Module ID:** `USBO-VISUAL-OUTPUT-001`  
**Created UTC:** `2026-07-12T19:36:13Z`  
**Mode:** `ADDITIVE_PRESENTATION_LAYER`

---

# 1. PURPOSE

Transform technical system output into a visually structured, readable, and operationally useful presentation without changing the underlying facts, execution logic, data, or output contract.

The visual layer is applied after factual result generation and before final user presentation.

```text
RAW VERIFIED RESULT
→ SEMANTIC CLASSIFICATION
→ VISUAL STRUCTURING
→ ACCESSIBILITY CHECK
→ FINAL PRESENTATION
```

---

# 2. NON-DESTRUCTIVE RULE

```text
VISUAL_LAYER_MUST_NOT_CHANGE_FACTS = TRUE
VISUAL_LAYER_MUST_NOT_HIDE_WARNINGS = TRUE
VISUAL_LAYER_MUST_NOT_INVENT_PROGRESS = TRUE
VISUAL_LAYER_MUST_NOT_REPLACE_RAW_ARTIFACTS = TRUE
VISUAL_LAYER_MUST_PRESERVE_COPYABILITY = TRUE
```

Visual output is a frontloader and renderer, not a decision-maker.

---

# 3. OUTPUT PROFILES

Select one profile based on task type.

## COMPACT

For short operational results:

```text
TITLE
STATUS
KEY RESULT
NEXT ACTION
```

## STANDARD

For ordinary system work:

```text
TITLE
EXECUTIVE STATUS
PROGRESS
RESULTS
WARNINGS
FILES
NEXT ACTION
```

## AUDIT

For audits:

```text
AUDIT TITLE
OVERALL SCORE
CATEGORY SCORECARD
FINDINGS BY SEVERITY
REPAIR STATUS
EVIDENCE TYPE
FINAL VERDICT
```

## REPAIR

For repairs:

```text
DEFECT
ROOT CAUSE
ORIGINAL STATE
CHANGE
SIDE EFFECTS
ROLLBACK
VERIFICATION
```

## RELEASE

For freeze and backup:

```text
SYSTEM ID
VERSION
RELEASE ID
AUDIT VERDICT
FREEZE STATUS
BACKUP STATUS
DRIVE STATUS
CHECKSUM
ARTIFACT LINKS
```

## HANDOFF

For continuation:

```text
LAST VERIFIED STATE
COMPLETED
OPEN
BLOCKERS
NEXT REQUIRED ACTION
START FILE
```

---

# 4. SEMANTIC STATUS SYSTEM

Use consistent semantic markers:

```text
✅ VERIFIED / PASSED / COMPLETED
🟢 RELEASE_READY / HEALTHY
🟡 WARNING / PARTIAL / REVIEW_REQUIRED
🟠 REPAIR_REQUIRED / DEGRADED
🔴 BLOCKED / FAILED / CRITICAL
🔵 ACTIVE / IN_PROGRESS
⚪ PENDING / NOT_EXECUTED
```

Color meaning must never be the only carrier of information. Always include text labels.

---

# 5. PROGRESS BARS

Use 20-segment bars only for measured or deterministically calculated progress.

```text
████████████████████ 100 %
██████████████░░░░░░ 70 %
████████░░░░░░░░░░░░ 40 %
```

Rules:

```text
SEGMENTS = 20
ONE_SEGMENT = 5_PERCENT
NO_FICTIONAL_PROGRESS = TRUE
UNKNOWN_PROGRESS = "not measured"
```

For audit category scores, include exact percentages.

---

# 6. AUDIT SCORECARD

Preferred format:

| Category | Weight | Score | Evidence | Status |
|---|---:|---:|---|---|
| Completeness | 15% | 98% | Measured | ✅ |
| Security | 10% | 95% | Readback verified | ✅ |
| Drive verification | 5% | 0% | Not executed | ⚪ |

Weighted total must be mathematically consistent.

---

# 7. VISUAL HIERARCHY

Every major output should use:

1. One clear title.
2. One short status block.
3. Section separators.
4. Tables for comparable structured data.
5. Code blocks for machine states and commands.
6. Links grouped under artifacts.
7. Warnings near the affected result, not hidden at the end.
8. A single clear next action.

Avoid:

- walls of unstructured text,
- decorative noise,
- excessive emoji,
- repeated status blocks,
- misleading green status when partial,
- giant filenames without a human-readable label.

---

# 8. HUMAN-READABLE NAMING

Every artifact link must include a human-readable description.

Bad:

```text
UNIVERSAL_SYSTEM_BOOTSTRAP_ORCHESTRATOR_COMPLETE_FULL_FINAL_v3_1_0.zip
```

Good:

```text
Master Bootstrap Backup v3.1.0
```

The technical filename remains available, but the user-facing label explains purpose.

---

# 9. LEGEND

For complex reports, include a compact legend once:

```text
✅ verified   🟡 warning   🟠 repair required   🔴 blocked   ⚪ pending
```

Do not repeat the legend in every section.

---

# 10. ACCESSIBILITY AND COPYABILITY

```text
TEXT_LABELS_REQUIRED = TRUE
COLOR_ONLY_MEANING_FORBIDDEN = TRUE
MOBILE_READABILITY = REQUIRED
COPY_READY_BLOCKS = REQUIRED_WHEN_APPLICABLE
LONG_TABLES = SPLIT_OR_SUMMARIZED
```

Output must remain readable on mobile devices.

---

# 11. VISUAL VALIDATION GATE

Before final presentation verify:

```text
FACTS_UNCHANGED
STATUS_CONSISTENT
PERCENTAGES_VALID
WARNINGS_VISIBLE
LINKS_LABELED
NEXT_ACTION_CLEAR
MOBILE_LAYOUT_ACCEPTABLE
NO_DECORATIVE_OVERLOAD
```

Status:

```text
VISUAL_OUTPUT_VALIDATED
VISUAL_OUTPUT_WITH_WARNINGS
VISUAL_OUTPUT_REPAIR_REQUIRED
```
