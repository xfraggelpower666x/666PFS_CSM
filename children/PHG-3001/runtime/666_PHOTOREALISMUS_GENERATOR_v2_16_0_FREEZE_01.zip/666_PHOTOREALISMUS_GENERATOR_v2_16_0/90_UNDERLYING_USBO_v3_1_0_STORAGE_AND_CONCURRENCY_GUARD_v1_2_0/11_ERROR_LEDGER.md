# ERROR LEDGER

## Open errors

None.

## Controlled warnings

### W-001

```text
EXTERNAL_DRIVE_UPLOAD = NOT_EXECUTED
```

The local package is verified. Drive saving must be performed and verified separately if required.
