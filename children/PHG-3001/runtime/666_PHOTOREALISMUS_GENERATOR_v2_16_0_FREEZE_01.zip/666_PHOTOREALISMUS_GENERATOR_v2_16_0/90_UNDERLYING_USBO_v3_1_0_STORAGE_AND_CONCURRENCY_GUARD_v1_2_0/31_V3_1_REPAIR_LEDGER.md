# v3.1.0 REPAIR LEDGER

## V31-R-001 — Visual Output Governance Materialization

Added output profiles, semantic status system, exact progress rules, audit scorecards, accessibility rules, human-readable labels, and visual validation.

## V31-R-002 — Continue and Recap Controller

Added verified-fact separation, safe checkpoint detection, anti-restart guard, and continuation state model.

## V31-R-003 — Architecture Decision Records

Added ADR schema, triggers, statuses, dependency links, and rollback documentation.

## V31-R-004 — Preflight / Import / Version Seal

Added safe import inspection, preflight completeness checks, and mandatory version seal before release.

## V31-R-005 — Extended Module Register

Added module IDs, roles, modes, and governance requirement.
