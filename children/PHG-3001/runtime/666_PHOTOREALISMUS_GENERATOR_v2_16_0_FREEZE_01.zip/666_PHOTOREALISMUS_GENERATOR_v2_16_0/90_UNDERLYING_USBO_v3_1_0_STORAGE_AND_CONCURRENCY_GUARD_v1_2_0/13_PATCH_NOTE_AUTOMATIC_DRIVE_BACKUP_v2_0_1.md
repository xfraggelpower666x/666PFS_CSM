# PATCH NOTE
## AUTOMATIC DRIVE BACKUP RULE v3.1.0

**Created UTC:** `2026-07-12T19:17:12Z`  
**Base:** `v2.0.0`  
**Patch type:** targeted operational safety patch

## Change

Correct term and rule:

```text
DRIVE, not driver.
AUTOMATIC_DRIVE_BACKUP = ALWAYS_REQUIRED
```

After every successful local freeze or backup:

```text
LOCAL_BACKUP_READY
→ automatic Drive backup attempt
→ bounded retry
→ Drive metadata verification
→ manual rescue only if automatic upload is blocked
```

## Preserved

- local artifact first,
- connector capability test,
- no fake verification,
- non-destructive integration,
- interruption continuation,
- least-invasive repair,
- manual rescue fallback.

## Completion rule

```text
FULLY_COMPLETED
```

is permitted only when the required local artifacts exist and the Drive stage is either:

```text
AUTOMATIC_DRIVE_BACKUP_VERIFIED
```

or:

```text
RESCUE_BACKUP_VERIFIED
```
