# CANONICAL PROJECT REGISTRY
## UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR v3.1.0

**System ID:** `USBO-CORE-001`  
**Release ID:** `USBO_v3_1_0_20260712`  
**Created UTC:** `2026-07-12T19:26:02Z`

---

# 1. PURPOSE

Maintain one authoritative registry entry per managed project or system.

The registry prevents:

- duplicate canonical systems,
- parallel untracked releases,
- ambiguous current versions,
- unknown Drive locations,
- missing recovery references,
- accidental cross-system writes.

---

# 2. REQUIRED REGISTRY FIELDS

```text
PROJECT_ID
SYSTEM_ID
DISPLAY_NAME
SYSTEM_SLUG
SYSTEM_TYPE
CURRENT_VERSION
CURRENT_RELEASE_ID
CURRENT_POINTER
CANONICAL_DRIVE_ROOT_ID
CANONICAL_SYSTEM_FOLDER_ID
LATEST_FREEZE_ID
LATEST_BACKUP_ID
LATEST_HANDOFF_ID
LATEST_VERIFIED_TIMESTAMP
LIFECYCLE_STATUS
DEPENDENCY_GRAPH_ID
MEMORY_LEDGER_ID
SYSTEM_DIRTY
COMMIT_STATUS
```

---

# 3. PROJECT IDENTITY RULE

```text
PROJECT_ID = IMMUTABLE
SYSTEM_ID = IMMUTABLE
DISPLAY_NAME = EDITABLE_WITH_AUDIT
SYSTEM_SLUG = STABLE
```

Session numbers are temporary and must never replace permanent IDs.

---

# 4. REGISTRY LOOKUP

At startup:

```text
1. Resolve PROJECT_ID or SYSTEM_ID.
2. Search the registry.
3. Read the current pointer.
4. Read the latest verified release metadata.
5. Compare Drive state with current chat state.
6. Continue from the latest verified canonical state.
```

---

# 5. REGISTRY WRITE GATE

Registry updates are allowed only after:

```text
POST_AUDIT = PASS
FREEZE = VERIFIED
BACKUP = VERIFIED
DRIVE_COMMIT = VERIFIED
```

Then:

```text
UPDATE_CURRENT_POINTER
UPDATE_LATEST_FREEZE
UPDATE_LATEST_BACKUP
UPDATE_LATEST_HANDOFF
UPDATE_LAST_VERIFIED_TIMESTAMP
CLEAR_SYSTEM_DIRTY
```

Never update the registry to an unverified release.

## Concurrency fields

```text
ACTIVE_LOCK_ID
ACTIVE_OPERATION_ID
ACTIVE_SESSION_ID
ACTIVE_LEASE_EXPIRES_AT
LAST_COMMIT_BASE_VERSION
LAST_COMMIT_BASE_HASH
LAST_COMMIT_RESULT
```

Registry mutation requires a global registry lease.
