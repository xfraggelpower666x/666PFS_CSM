# STORAGE GUARD INTEGRATION PATCH
## Parent: UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR v3.1.0

```text
ASSEMBLY_ID = USBO-3.1.0-PSG-1.0.0
PARENT_SYSTEM_ID = USBO-CORE-001
PARENT_VERSION = 3.1.0
MODULE_ID = PROMPT-STORAGE-GUARD-001
MODULE_VERSION = 1.1.0
INTEGRATION_MODE = ADDITIVE_HARDLOCK
PARENT_VERSION_MUTATION = FALSE
```

## Required loader insertion points

### Boot phase

```text
CONNECTOR DETECTED
→ ACTIVE PROFILE CHECK
→ STORAGE CLASSIFICATION
→ STORAGE IDENTITY GUARD
→ TARGET ROUTE RESOLUTION
```

### Lifecycle persistence phase

```text
LOCAL FREEZE
→ LOCAL BACKUP
→ STORAGE IDENTITY PREFLIGHT
→ READ REMOTE STATE
→ COMPARE
→ AUTHORIZE OR BLOCK
→ WRITE
→ READBACK
→ VERIFY COMMIT
```

### Technical artifact phase

The same guard applies to manifests, hashes, audit files, freeze files,
handoffs, recovery files, registry entries, pointers, catalogs, copies,
moves, renames, permissions, archives, and deletions.


## Corrected actor-to-target route

```text
AUTHORIZED_ACTORS =
  fraggelpower666@googlemail.com
  fraggelpower666@gmail.com

REQUIRED_TARGET_OWNER = dirk.meereis@icloud.com
CANONICAL_ROOT_ID = 1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3
```

The connector identity and target owner are separate authorization dimensions.
