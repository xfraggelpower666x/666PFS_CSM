# PERSISTENT STATE MANAGER
## UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR v3.1.0

**Created UTC:** `2026-07-12T19:21:14Z`

## Canonical behavior

```text
CANONICAL_DRIVE_MODE = PRIMARY_STORAGE
READ_BEFORE_WRITE = REQUIRED
APPEND_ONLY_RELEASES = TRUE
CURRENT_POINTER_UPDATE = VERIFIED_ONLY
NO_DUPLICATE_CANONICAL_STATE = TRUE
```

## Runtime identity rule

The connected Google account must be checked at runtime. Folder ownership and connector identity are distinct.

```text
FOLDER_OWNER_REFERENCE = dirk.meereis@icloud.com
CONNECTOR_IDENTITY = RUNTIME_VERIFIED
```

## Commit gate

```text
LOCAL_BACKUP_VERIFIED
→ DRIVE_UPLOAD
→ METADATA_READBACK
→ PARENT_FOLDER_VERIFIED
→ SIZE_OR_CONTENT_VERIFIED
→ CURRENT_POINTER_UPDATED
→ CATALOG_UPDATED
→ PERSISTENT_DRIVE_COMMIT_VERIFIED
```

## Conflict gate

```text
CHAT_STATE != DRIVE_STATE
→ DIVERGENCE_REPORT
→ NO_SILENT_OVERWRITE
→ USER_DECISION_IF_BLOCKING
```

## Recovery

If auto-upload fails after bounded retry:

```text
MANUAL_RESCUE_REQUIRED
```

The local package remains canonical candidate state, but not committed state.


## Prompt-system storage identity precondition

Before any persistent Drive commit for `ADDITIONAL_PROMPT_SYSTEM`:

```text
ACTIVE_CONNECTOR_PROFILE_CHECK = REQUIRED
APPROVED_WRITE_IDENTITY = dirk.meereis@icloud.com
EXACT_IDENTITY_MATCH = REQUIRED
```

A verified target folder and write permission are insufficient when the active
connector identity is not approved.

```text
IDENTITY_MISMATCH
→ REMOTE_COMMIT_BLOCKED
→ SYSTEM_DIRTY_RETAINED
→ LOCAL_BACKUP_RETAINED
→ NO_FALLBACK_ACCOUNT
```

## Cross-chat coordination gate

No persistent commit may begin without:

```text
CANONICAL_TARGET_OWNER = dirk.meereis@icloud.com
CANONICAL_ROOT_ID = 1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3
PROJECT_WRITE_LEASE = ACQUIRED
LOCK_WINNER_CONFIRMED_TWICE
BASE_STATE_MATCH = TRUE
```

Shared registry, catalog, and pointer mutations require separate shared-resource
leases. Lock uncertainty blocks the write.
