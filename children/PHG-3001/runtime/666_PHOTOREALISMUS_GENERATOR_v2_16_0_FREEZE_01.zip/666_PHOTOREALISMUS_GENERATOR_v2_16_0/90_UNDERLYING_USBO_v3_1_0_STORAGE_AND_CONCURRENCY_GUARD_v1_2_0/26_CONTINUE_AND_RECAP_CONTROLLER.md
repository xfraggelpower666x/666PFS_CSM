# CONTINUE AND RECAP CONTROLLER
## UNIVERSAL SYSTEM BOOTSTRAP ORCHESTRATOR v3.1.0

**Module ID:** `USBO-CONTINUE-RECAP-001`  
**Created UTC:** `2026-07-12T19:36:13Z`

---

# 1. PURPOSE

Determine the last confirmed project state, separate verified facts from assumptions, and continue without unnecessary restart.

---

# 2. RECAP STATE MODEL

```text
VERIFIED_FACTS
USER_CONFIRMED_DECISIONS
COMPLETED_ACTIONS
UNVERIFIED_CLAIMS
OPEN_TASKS
BLOCKERS
LATEST_SAFE_CHECKPOINT
NEXT_EXECUTABLE_STEP
```

---

# 3. CONTINUATION RULE

```text
READ AVAILABLE STATE
→ BUILD RECAP
→ VALIDATE LAST SAFE CHECKPOINT
→ INTEGRATE NEW USER INFORMATION
→ CONTINUE
```

Ask only for information that blocks safe continuation.

---

# 4. ANTI-RESTART GUARD

```text
NO_RESTART_IF_VALID_STATE_EXISTS = TRUE
NO_REPEAT_OF_COMPLETED_WORK = TRUE
NO_REASK_OF_KNOWN_INFORMATION = TRUE
```

If prior claims conflict with evidence, mark them as unverified and continue from the latest evidenced state.
