# OPTIONALE EDIT- UND RAHMENKONFIGURATION
## Outfit, Pose, Kamera, Effekte und optionaler Rahmen

```text
EDIT MODE: [Stage 1 / Creative Revision / Frame Stage 2]

OUTFIT CHANGE: [Beschreibung oder OFF]
ACCESSORIES: [Beschreibung oder OFF]
POSE: [Beschreibung oder OFF]
GAZE / BODY DIRECTION: [Beschreibung oder OFF]
CAMERA FRAMING: [Close-up / Portrait / Medium Shot / Full Body / Wide Shot / Custom]
CAMERA DISTANCE: [Zoom In / Neutral / Zoom Out]
CAMERA ANGLE: [Eye Level / Low Angle / High Angle / Overhead / Custom]
ATMOSPHERIC EFFECTS: [Rain / Fog / Smoke / Dust / Particles / OFF]
OPTICAL EFFECTS: [Glow / Motion Blur / Lens Flare / Shallow DOF / OFF]
SPECIAL REQUESTS: [optional]

CYBER NEON FRAME: [ON / OFF]
FRAME STYLE: [Cyber Identity / Military Future / Neon Angelic / Dark Cyber / Bio-Tech / Holographic Future / Dark-Techno Signal / Custom]
FRAME MATERIAL: [Black Titanium / Carbon / Intelligent Glass / Ceramic Tech / Energy / Custom]
FRAME NAME: [exakte Beschriftung]
MAIN SYMBOL: [Beschreibung des Hauptsymbols unten in der Mitte]
SYMBOL ELEMENTS: [weitere Symbole und Positionen]
DOMINANT FRAME COLOR: [Farbe]
SECONDARY FRAME COLOR: [Farbe]
HIGHLIGHT COLOR: [optional]
FRAME INTENSITY: [Subtle / Balanced / Strong]
FRAME SYMMETRY: [Symmetrical / Controlled Asymmetrical]
TYPOGRAPHY MODE: RANDOM CYBER
TYPOGRAPHY STYLE: AUTO-RANDOM
TYPOGRAPHY REPEAT PROTECTION: ON
TYPOGRAPHY LEGIBILITY: STRICT
TYPOGRAPHY CASE: PRESERVE EXACT INPUT
```

## Natürlichsprachliches Beispiel

```text
Gib der Person ein schwarzes futuristisches Lederoutfit mit silbernen Details.
Pose: leicht seitlich stehend, Arme verschränkt, Blick direkt in die Kamera.
Zoom out auf Ganzkörper mit leichtem Low Angle.
Füge leichten Regen und kalten Nebel hinzu.
Rahmen aus lassen.
```
