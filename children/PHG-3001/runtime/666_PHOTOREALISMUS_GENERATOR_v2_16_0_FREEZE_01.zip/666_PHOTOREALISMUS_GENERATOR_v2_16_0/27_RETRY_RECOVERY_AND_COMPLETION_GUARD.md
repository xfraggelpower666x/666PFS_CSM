# RETRY, RECOVERY AND COMPLETION GUARD
## Version 1.0.0

## Retry-Regel

```text
MAX_AUTOMATIC_ATTEMPTS = 2
EMPTY_RESULT = RETRYABLE
MISSING_IMAGE_OBJECT = RETRYABLE
FIRST_RETRYABLE_FAILURE = RETRY ONCE
SECOND_FAILURE = FAILED_TERMINAL
```

Die Wiederholung verwendet dieselbe aktive Quelle und dieselbe Nutzerabsicht. Es wird kein neues Motiv erfunden und kein anderes Gesprächsbild ausgewählt.

## Completion Gate

```text
RETURNED_IMAGE_OBJECT = PRESENT
OUTPUT_IS_RENDERABLE = TRUE
OUTPUT_BELONGS_TO_CURRENT_TRANSACTION = TRUE
```

Ohne diese Bedingungen darf weder Erfolg behauptet noch Stage 2 angeboten werden.

## Wiederaufnahme

Nach terminalem Fehlschlag bleibt die Quelle pending. `go` oder `generiere` startet einen neuen Versuch ohne erneuten Upload.

## Plattformgrenze

Der Guard kann einen ausgefallenen oder nicht verfügbaren Bilddienst nicht erzwingen. Er verhindert jedoch stilles Abbrechen, falsche Erfolgsmeldungen und den Verlust des aktiven Bildauftrags.
