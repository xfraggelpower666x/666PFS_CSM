# ADDON — CYBER HOLO LASER LOVE / BIRTHDAY FRAME PRESET FAMILY

**VERSION=1.0.0**
**DATE=2026-08-14**
**SCOPE=PHOTOREALISTIC\_GENERATOR\_PRESET\_ADDON**
**PARENT\_HANDOFF=PHOTOREALISTIC IMAGE GENERATOR PRESET EXPANSION v1.0.0**
**STATUS=VERIFIZIERT\_FROM\_CHAT\_ITERATIONS**
**ADD\_ONLY=TRUE**
**EXISTING\_PRESETS\_UNCHANGED=TRUE**

\==================================================

## ZWECK

Dieses Addon erweitert den bestehenden Photorealistic Generator um eine kontrollierte Cyber-Holo-Laser-Romantik-Preset-Familie.

Die Presets basieren auf den im Chat erfolgreich entwickelten Bildvarianten mit:

- photorealistischer Referenzperson
- futuristischem Cyber-Outfit
- Cyberpunk-Umgebung
- holografischem Herz als zentrales Objekt
- Umarmung des Herzobjekts
- exakt definierter Geburtstags-Inschrift
- vollständigem Neon-Laser-Stacheldraht-Rahmen
- gezielten LOVE-Symbolen
- vier farblich definierten Eckherzen
- unterem `I LOVE YOU`
- geflügeltem Herzsymbol
- kontrollierter Dekorationsdichte

Ziel ist ausdrücklich **nicht**, möglichst viele Neonobjekte zu erzeugen.

Ziel ist:

`SUBJECT_FIRST + HERO_HEART_SECOND + FRAME_THIRD + MINIMAL_SUPPORTING_SYMBOLS`

\==================================================

## GLOBAL CYBER LOVE LOCK

```
CYBER_LOVE_ADDON_ENABLED=TRUE

REFERENCE_IMAGE_LOCK=HIGH
CHARACTER_LOCK=HIGH
FACE_IDENTITY_LOCK=HIGH
POSE_INTENT_LOCK=HIGH

PHOTOREALISM_PRIORITY=MAX
HUMAN_PHOTOREALISM=STRICT
ENVIRONMENT_STYLE=CYBERPUNK_HOLOGRAPHIC
DECORATIVE_STYLE=NEON_LASER_HOLO

CGI_HUMAN_LOOK=FORBIDDEN
CARTOON_LOOK=FORBIDDEN
GAME_CHARACTER_LOOK=FORBIDDEN
PLASTIC_SKIN=FORBIDDEN

```

\==================================================

## REFERENCE PERSON TRANSFORMATION RULE

Wenn eine reale Person als Referenzbild vorhanden ist, darf sie für dieses Preset ein neues Cyber-Outfit und eine neue Cyberpunk-Umgebung erhalten.

Dabei gilt:

```
FACE_IDENTITY=KEEP
HAIR_IDENTITY=KEEP_AS_CLOSE_AS_POSSIBLE
BEARD_IDENTITY=KEEP_AS_CLOSE_AS_POSSIBLE
AGE_APPEARANCE=KEEP
SKIN_CHARACTERISTICS=KEEP
BODY_PROPORTIONS=KEEP

OUTFIT_LOCK=CONDITIONAL
BACKGROUND_LOCK=OFF_IF_CYBER_TRANSFORMATION_REQUESTED

```

Das bedeutet:

Bestehendes `OUTFIT_LOCK=ON` aus dem Parent-System bleibt Standard.

Dieses Addon darf den Lock nur bei explizitem Cyber-Outfit-Wunsch kontrolliert überschreiben:

```
IF USER_REQUESTS_CYBER_OUTFIT:
    OUTFIT_LOCK=CONTROLLED_REPLACE
ELSE:
    OUTFIT_LOCK=ON

```

Dasselbe gilt für die Umgebung:

```
IF USER_REQUESTS_CYBER_ENVIRONMENT:
    BACKGROUND_LOCK=CONTROLLED_REPLACE
ELSE:
    BACKGROUND_LOCK=ON

```

\==================================================

## HERO OBJECT — HOLOGRAPHIC LOVE HEART

```
HERO_OBJECT=HOLOGRAPHIC_HEART
HERO_OBJECT_ROLE=PRIMARY_EMOTIONAL_OBJECT
HERO_OBJECT_POSITION=CENTER_CHEST_AREA
HERO_OBJECT_INTERACTION=EMBRACED_BY_SUBJECT

HEART_RENDER_STYLE=CYBER_HOLOGRAM
HEART_MATERIAL=TRANSLUCENT_ENERGY_GRID
HEART_DEPTH=VISIBLE_3D_VOLUME
HEART_GLOW=STRONG_BUT_CONTROLLED
HEART_OCCLUSION=ALLOW_ARMS_OVER_HEART
FACE_OCCLUSION=FORBIDDEN

```

Die Person soll das Herz sichtbar und glaubwürdig umarmen.

Nicht erlaubt:

- Herz schwebt ohne Körperinteraktion
- Hände verlaufen durch das Herz
- Arme verschwinden
- Herz verdeckt das Gesicht
- Herz wird zu einer flachen Texttafel
- Herz wird durch weitere Symbole überlagert

\==================================================

## TEXT ON HERO HEART

Standard für die englische Variante:

```
HERO_HEART_TEXT="HAPPY BIRTHDAY MY ANGEL!"
TEXT_LANGUAGE=ENGLISH
TEXT_EXACTNESS=STRICT
TEXT_REWRITE=FORBIDDEN
TEXT_SYNONYM_REPLACEMENT=FORBIDDEN
TEXT_AUTO_CORRECTION=FORBIDDEN

```

Alternative explizit angeforderte deutsche Variante:

```
HERO_HEART_TEXT="HAPPY BIRTHDAY MEIN ENGEL!"

```

Case darf abhängig vom gewünschten visuellen Stil entweder exakt vorgegeben oder als Script-Schrift dargestellt werden.

Textinhalt darf dabei nicht verändert werden.

\==================================================

## HERO HEART COLOR PROFILE

```
HERO_HEART_COLOR_MODE=GRADIENT

PRIMARY_COLOR=NEON_PURPLE
SECONDARY_COLOR=NEON_PINK

EFFECTS=
LASER_EDGE,
HOLOGRAPHIC_GRID,
SOFT_BLOOM,
ENERGY_GLOW,
SUBTLE_PARTICLE_SPARKS

```

Empfohlener Verlauf:

```
UPPER_LEFT=ELECTRIC_PURPLE
CENTER=NEON_MAGENTA
LOWER_RIGHT=HOT_PINK

```

Kein Weiß-Ausfressen des Textes.

\==================================================

## CYBER HOLO BARBED WIRE FRAME

```
FRAME_PRESET=CYBER_HOLO_NEON_PURPLE_BARBED_WIRE

FRAME_ENABLED=TRUE
FRAME_FULL_VISIBILITY=REQUIRED
FRAME_SAFE_MARGIN=5_PERCENT
FRAME_EDGE_PADDING=REQUIRED

FRAME_COLOR=NEON_PURPLE
FRAME_SECONDARY_GLOW=PINK_VIOLET
FRAME_STYLE=LASER_HOLOGRAPHIC_BARBED_WIRE
FRAME_STRUCTURE=CONTINUOUS_ALL_FOUR_SIDES

FRAME_DEPTH=SLIGHT_FOREGROUND
FRAME_DENSITY=MEDIUM
FRAME_BRIGHTNESS=HIGH
FRAME_THICKNESS=MEDIUM

```

Pflicht:

> complete purple holographic laser barbed-wire frame fully visible on all four sides, no cropping, no missing corners, no frame section touching or hiding the subject

\==================================================

## FOUR CORNER HEARTS

Exakt vier primäre Eckherzen:

```
CORNER_HEART_COUNT=4

TOP_LEFT=RED_BLUE_LASER_HOLO_GRADIENT
TOP_RIGHT=RED_BLUE_LASER_HOLO_GRADIENT
BOTTOM_LEFT=RED_BLUE_LASER_HOLO_GRADIENT
BOTTOM_RIGHT=RED_BLUE_LASER_HOLO_GRADIENT

CORNER_HEART_STYLE=HOLOGRAPHIC_WIREFRAME
CORNER_HEART_SIZE=SMALL_MEDIUM
CORNER_HEART_PRIORITY=SECONDARY

```

Farbverlauf:

```
HEART_TOP=LASER_RED
HEART_BOTTOM=ELECTRIC_BLUE
TRANSITION=SMOOTH_HOLOGRAPHIC_GRADIENT

```

Die vier Eckherzen sollen:

- klar sichtbar
- gleichwertig
- nicht übergroß
- nicht mit dem zentralen Herz konkurrierend
- innerhalb des Safe-Margins positioniert sein

\==================================================

## LOVE SYMBOLS

```
LOVE_SYMBOL_MODE=MINIMAL
LOVE_SYMBOL_COLOR=NEON_PINK
LOVE_SYMBOL_RENDER=LASER_HOLOGRAM
LOVE_SYMBOL_DENSITY=LOW

```

Erlaubte zusätzliche LOVE-Symbole:

- maximal 1–3
- klein bis mittel
- bevorzugt im Hintergrund
- bevorzugt als Hologramm-Signage
- keine Überlagerung von Gesicht, Händen oder Haupttext

Beispiele:

```
LOVE
HEART_SYMBOL
SUBTLE_HOLO_LOVE_SIGN

```

Nicht erlaubt:

```
DOZENS_OF_HEARTS
RANDOM_LOVE_TEXT_EVERYWHERE
MULTIPLE_LARGE_SIGNS
DUPLICATED_WINGED_HEARTS

```

\==================================================

## LOWER LOVE ZONE

```
LOWER_TEXT="I LOVE YOU"
LOWER_TEXT_POSITION=BOTTOM_CENTER
LOWER_TEXT_COLOR_MODE=PINK_PURPLE_GRADIENT
LOWER_TEXT_STYLE=NEON_LASER_SCRIPT
LOWER_TEXT_EXACTNESS=STRICT

```

Darunter oder integriert:

```
LOWER_SYMBOL=WINGED_HEART
WINGED_HEART_COLOR_MODE=PINK_PURPLE_GRADIENT
WINGED_HEART_EFFECT=LASER_NEON_HOLOGRAM
WINGED_HEART_CENTERED=TRUE

```

Optional:

```
EKG_LINE_INSIDE_HEART=ALLOWED

```

Das Symbol bleibt sekundär zum Text.

\==================================================

## DECORATION BUDGET

Wichtige neue Regel aus den Iterationen:

```
OVERDECORATION_GUARD=STRICT
DECORATION_BUDGET=LIMITED

```

Prioritätsreihenfolge:

```
P1=SUBJECT
P2=HERO_HEART
P3=HERO_TEXT
P4=BARBED_WIRE_FRAME
P5=I_LOVE_YOU
P6=WINGED_HEART
P7=FOUR_CORNER_HEARTS
P8=BACKGROUND_LOVE_SYMBOLS
P9=LASERS_AND_PARTICLES

```

Wenn visuelle Überladung entsteht, zuerst reduzieren:

```
BACKGROUND_SYMBOLS
EXTRA_HEARTS
EXTRA_HOLOGRAPHIC_SIGNS
PARTICLES
SECONDARY_LASERS

```

Niemals zuerst reduzieren:

```
SUBJECT
HERO_HEART
MAIN_TEXT
FRAME
I_LOVE_YOU
FOUR_CORNER_HEARTS

```

\==================================================

## SYMBOL CLEAR ZONES

```
FACE_CLEAR_ZONE=MANDATORY
HANDS_CLEAR_ZONE=MANDATORY
HERO_TEXT_CLEAR_ZONE=MANDATORY
CHEST_HEART_CLEAR_ZONE=MANDATORY
LOWER_TEXT_CLEAR_ZONE=MANDATORY

```

Keine dekorativen Symbole innerhalb dieser Zonen.

\==================================================

## CYBER ENVIRONMENT

```
ENVIRONMENT_PRESET=ROMANTIC_NEON_CYBER_CITY
TIME=NIGHT

PRIMARY_ENVIRONMENT_COLORS=
PURPLE,
MAGENTA,
BLUE,
CYAN

ENVIRONMENT_ELEMENTS=
FUTURISTIC_SKYSCRAPERS,
RAIN_WET_STREET,
NEON_REFLECTIONS,
SUBTLE_LASER_BEAMS,
HOLOGRAPHIC_SIGNAGE

```

Optional:

```
MOON=ALLOWED
LIGHT_RAIN=ALLOWED
FOG=SUBTLE
SMOKE=SUBTLE

```

Nicht erwünscht:

```
VISUAL_CHAOS
TOO_MANY_SIGNS
CROWDS
EXTRA_PEOPLE
VEHICLES_BLOCKING_SUBJECT
EXTREME_FOG

```

\==================================================

## CYBER OUTFIT

```
OUTFIT_PRESET=ROMANTIC_CYBER_TECH_ARMOR

STYLE=
BLACK_TECHWEAR,
FUTURISTIC_LEATHER,
ARMOR_PANELING,
NEON_LIGHT_CHANNELS,
CYBER_GLOVES

OUTFIT_GLOW_COLOR=
PURPLE,
PINK,
OPTIONAL_BLUE

OUTFIT_DETAIL=HIGH
OUTFIT_PHYSICS=REALISTIC

```

Die Kleidung muss wie echte tragbare Kleidung wirken.

Nicht:

- Plastikanzug
- Superheldenkostüm
- Fantasy-Rüstung ohne Materiallogik
- massiver Mecha-Anzug
- Cartoon-Techwear

\==================================================

## PRESET\_06

```
PRESET_06=CYBER_BIRTHDAY_PURPLE_PINK_LOVE

SCENE_STYLE=PHOTOREALISTIC_CINEMATIC
SUBJECT_STYLE=REFERENCE_LOCKED_PHOTOREALISTIC
OUTFIT_PRESET=ROMANTIC_CYBER_TECH_ARMOR
BACKGROUND_PRESET=ROMANTIC_NEON_CYBER_CITY

HERO_OBJECT=HOLOGRAPHIC_HEART
HERO_HEART_TEXT="HAPPY BIRTHDAY MY ANGEL!"
HERO_HEART_COLORS=NEON_PURPLE,NEON_PINK

FRAME_PRESET=CYBER_HOLO_NEON_PURPLE_BARBED_WIRE
FRAME_SAFE_MARGIN=5_PERCENT

CORNER_HEART_COUNT=4
CORNER_HEART_COLORS=LASER_RED,ELECTRIC_BLUE

LOVE_SYMBOL_COLOR=NEON_PINK
LOVE_SYMBOL_DENSITY=LOW

LOWER_TEXT="I LOVE YOU"
LOWER_TEXT_COLORS=NEON_PINK,NEON_PURPLE
LOWER_SYMBOL=WINGED_HEART
LOWER_SYMBOL_COLORS=NEON_PINK,NEON_PURPLE

DECORATION_DENSITY=MEDIUM_LOW
SUBJECT_CLEAR_ZONE=STRICT

```

\==================================================

## PRESET\_07

```
PRESET_07=CYBER_BIRTHDAY_ELECTRIC_BLUE

SCENE_STYLE=PHOTOREALISTIC_CINEMATIC
SUBJECT_STYLE=REFERENCE_LOCKED_PHOTOREALISTIC

HERO_OBJECT=HOLOGRAPHIC_HEART
HERO_HEART_TEXT="HAPPY BIRTHDAY MY ANGEL!"
HERO_HEART_COLORS=ELECTRIC_BLUE,CYAN

FRAME_PRESET=CYBER_HOLO_ELECTRIC_BLUE_BARBED_WIRE

LOVE_SYMBOL_COLOR=ELECTRIC_BLUE

LOWER_TEXT="I LOVE YOU"
LOWER_TEXT_COLOR=ELECTRIC_BLUE
LOWER_SYMBOL=WINGED_HEART

CORNER_HEART_COLOR=ELECTRIC_BLUE

ENVIRONMENT_COLORS=
BLUE,
CYAN,
SUBTLE_PURPLE

```

Dieses Preset bildet die frühe erfolgreich erzeugte komplett blaue Cyber-Love-Variante ab.

\==================================================

## PRESET\_08

```
PRESET_08=CYBER_BIRTHDAY_HYBRID_BLUE_PURPLE_PINK

HERO_HEART_TEXT="HAPPY BIRTHDAY MY ANGEL!"

HERO_HEART_COLORS=
PURPLE,
PINK

FRAME_COLOR=NEON_PURPLE

CORNER_HEART_COLORS=
RED,
BLUE

BACKGROUND_LOVE_COLOR=
PINK

LOWER_TEXT_COLORS=
PINK,
PURPLE

WINGED_HEART_COLORS=
PINK,
PURPLE

ENVIRONMENT_ACCENTS=
BLUE,
PURPLE,
MAGENTA,
CYAN

```

Dieses Preset ist die bevorzugte Kombination aus den beiden entwickelten Hauptvarianten.

\==================================================

## CAUSAL COLOR ROUTING

Farbwünsche sollen nicht global blind angewendet werden.

Stattdessen:

```
COLOR_TARGET_ROUTING=ENABLED

```

Beispiel:

```
"purple barbed wire"
→ FRAME only

"pink LOVE symbols"
→ LOVE_SYMBOL layer only

"red blue hearts in the corners"
→ CORNER_HEART layer only

"pink purple winged heart"
→ LOWER_SYMBOL layer only

```

Damit wird verhindert, dass ein einzelner Farbwunsch versehentlich das komplette Bild umfärbt.

\==================================================

## LANGUAGE ROUTING

```
TEXT_LANGUAGE_ROUTING=STRICT

```

Wenn Nutzer schreibt:

```
TEXT ONLY ENGLISH

```

dann gilt:

```
ALL_VISIBLE_TEXT_LANGUAGE=ENGLISH
GERMAN_TEXT_RENDER=FORBIDDEN

```

Erlaubt:

```
HAPPY BIRTHDAY MY ANGEL!
LOVE
LOVE IS LIGHT
LOVE IS YOU
I LOVE YOU

```

Wenn deutsche Hauptinschrift ausdrücklich verlangt wird:

```
HAPPY BIRTHDAY MEIN ENGEL!

```

bleiben alle anderen Texte unverändert entsprechend Nutzerwunsch.

\==================================================

## REFERENCE COMPOSITION MODE

Wenn bereits ein vorheriges generiertes Cyber-Bild als Referenz hochgeladen wird:

```
REFERENCE_MODE=EDIT_NOT_REBUILD

```

Pflicht:

- Person möglichst exakt erhalten
- Körperposition erhalten
- Herzposition erhalten
- Umarmung erhalten
- vorhandene gute Komposition erhalten
- nur angeforderte Farben, Texte und Symbol-Layer verändern

Kein unnötiges komplettes Redesign.

\==================================================

## FORCE / EXACT INSTRUCTION MODE

Aus den Iterationen ergibt sich zusätzlich:

```
FORCE_EXACT_REQUEST_MODE=SUPPORTED

```

Wenn Nutzer signalisiert, dass die bestehende Komposition bereits akzeptiert ist und lediglich seine genaue Änderungsanweisung umgesetzt werden soll:

```
COMPOSITION_REDESIGN=FORBIDDEN
CREATIVE_REINTERPRETATION=MINIMAL
USER_LAYER_CHANGES=HIGHEST_PRIORITY

```

Beispiel:

```
"Das ist so in Ordnung, du musst nur meine Anweisung genau nach meinen Wünschen erfüllen."

```

führt zu:

```
KEEP_COMPOSITION=TRUE
CHANGE_ONLY_REQUESTED_LAYERS=TRUE

```

\==================================================

## FAILURE MODES ADDON

```
FAIL_08=TOO_MANY_SYMBOLS
FIX=DECORATION_BUDGET + LOVE_SYMBOL_DENSITY_LOW

FAIL_09=WRONG_COLOR_TARGET
FIX=CAUSAL_COLOR_ROUTING

FAIL_10=GERMAN_TEXT_REMAINS_IN_ENGLISH_MODE
FIX=ALL_VISIBLE_TEXT_LANGUAGE_ENGLISH

FAIL_11=HERO_HEART_NOT_EMBRACED
FIX=HERO_OBJECT_INTERACTION_EMBRACED_BY_SUBJECT

FAIL_12=CORNER_HEARTS_WRONG_COUNT
FIX=CORNER_HEART_COUNT_EXACT_4

FAIL_13=CORNER_HEART_WRONG_GRADIENT
FIX=RED_BLUE_LASER_HOLO_GRADIENT

FAIL_14=FRAME_COLOR_DRIFT
FIX=FRAME_COLOR_TARGET_LOCK

FAIL_15=WINGED_HEART_WRONG_COLOR
FIX=LOWER_SYMBOL_COLOR_TARGET_LOCK

FAIL_16=UNREQUESTED_COMPOSITION_REBUILD
FIX=REFERENCE_MODE_EDIT_NOT_REBUILD

FAIL_17=CYBER_OUTFIT_LOOKS_CGI
FIX=REALISTIC_MATERIAL_RESPONSE + HUMAN_PHOTOREALISM_STRICT

FAIL_18=MAIN_HEART_COMPETES_WITH_DECORATION
FIX=HERO_OBJECT_VISUAL_PRIORITY

```

\==================================================

## EXTENDED PRE-RENDER CHECK

```
[ ] reference image loaded
[ ] accepted composition detected
[ ] identity lock active
[ ] face lock active
[ ] outfit replace permission resolved
[ ] environment replace permission resolved
[ ] hero heart enabled
[ ] hero heart interaction = embrace
[ ] hero heart text exact
[ ] text language resolved
[ ] frame color routed correctly
[ ] full-frame safe margin active
[ ] exactly four corner hearts configured
[ ] corner heart red-blue gradient configured
[ ] LOVE symbol density low
[ ] lower I LOVE YOU configured
[ ] winged heart configured
[ ] lower color gradient correct
[ ] decoration budget active
[ ] face clear zone active
[ ] hand clear zone active
[ ] text clear zone active

```

\==================================================

## EXTENDED POST-RENDER CHECK

```
[ ] person remains recognizable as reference
[ ] skin remains photographic
[ ] hair remains realistic
[ ] cyber outfit physically plausible
[ ] hero heart clearly hugged
[ ] HAPPY BIRTHDAY MY ANGEL! exact
[ ] no accidental German text in English mode
[ ] heart text fully visible
[ ] purple/pink heart gradient correct
[ ] frame completely visible
[ ] frame is purple holographic laser barbed wire
[ ] exactly 4 corner hearts visible
[ ] each corner heart has red-blue gradient
[ ] I LOVE YOU visible in lower zone
[ ] winged heart visible
[ ] lower motif pink-purple
[ ] LOVE support symbols pink
[ ] no excessive heart duplication
[ ] no excessive LOVE duplication
[ ] no clutter over face
[ ] no clutter over hands
[ ] no clutter over main text
[ ] no extra people
[ ] no duplicated limbs
[ ] hands anatomically plausible
[ ] composition not unnecessarily redesigned

```

\==================================================

## NEW PARAMETERS

```
CYBER_LOVE_ADDON_ENABLED

REFERENCE_MODE
KEEP_COMPOSITION
CHANGE_ONLY_REQUESTED_LAYERS

HERO_OBJECT
HERO_OBJECT_INTERACTION
HERO_HEART_TEXT
HERO_HEART_COLOR_MODE
HERO_HEART_PRIMARY_COLOR
HERO_HEART_SECONDARY_COLOR

CYBER_OUTFIT_ENABLED
CYBER_OUTFIT_PRESET

CYBER_ENVIRONMENT_ENABLED
CYBER_ENVIRONMENT_PRESET

FRAME_STYLE
FRAME_COLOR_TARGET_LOCK

CORNER_HEART_COUNT
CORNER_HEART_PRIMARY_COLOR
CORNER_HEART_SECONDARY_COLOR

LOVE_SYMBOL_DENSITY
LOVE_SYMBOL_COLOR

LOWER_TEXT
LOWER_TEXT_COLOR_MODE
LOWER_SYMBOL
LOWER_SYMBOL_COLOR_MODE

DECORATION_BUDGET
COLOR_TARGET_ROUTING
FORCE_EXACT_REQUEST_MODE

```

\==================================================

## PIPELINE EXTENSION

Bestehende Pipeline:

```
REFERENCE LOCK
→ REALISM LOCK
→ SUBJECT LOCK
→ PRESET
→ TEXT LAYOUT
→ ASSET MAPPING
→ SAFE FRAME
→ NEGATIVE GUARDS
→ VALIDATION

```

Erweiterte Pipeline mit diesem Addon:

```
REFERENCE LOCK
→ COMPOSITION PRESERVATION CHECK
→ REALISM LOCK
→ SUBJECT IDENTITY LOCK
→ OUTFIT/BACKGROUND CHANGE PERMISSION
→ CYBER SCENE TRANSFORMATION
→ HERO HEART
→ HERO TEXT
→ COLOR TARGET ROUTING
→ BARBED WIRE FRAME
→ EXACT FOUR CORNER HEARTS
→ LOWER LOVE ZONE
→ MINIMAL LOVE SYMBOLS
→ DECORATION BUDGET
→ SAFE AREA
→ NEGATIVE GUARDS
→ TEXT LANGUAGE VALIDATION
→ VISUAL DENSITY VALIDATION
→ FINAL REFERENCE DRIFT CHECK

```

\==================================================

## CORE PRINCIPLE

```
KEEP THE HUMAN REAL.
MAKE THE WORLD CYBER.
MAKE THE LOVE HOLOGRAPHIC.
MAKE THE TEXT EXACT.
KEEP THE FRAME COMPLETE.
KEEP THE SYMBOLS CONTROLLED.

```

Das Preset darf spektakulär wirken, ohne die Person oder die emotionale Hauptaussage unter Neon-Dekoration zu begraben.

**END\_OF\_ADDON**