# CROSS-CHAT CONCURRENT WRITE COORDINATION GUARD
## Drive-Native Distributed Lease and Optimistic Concurrency Control

```text
MODULE_ID = PROMPT-WRITE-COORDINATION-GUARD-001
MODULE_VERSION = 1.0.0
PARENT_STORAGE_GUARD_VERSION = 1.2.0
PARENT_BOOTSTRAP_VERSION = 3.1.0
MODULE_STATUS = CANONICAL_HARDLOCK
LOAD_PHASE = BEFORE_REMOTE_STATE_MUTATION
FAILURE_MODE = FAIL_CLOSED
```

---

# 1. PURPOSE

Prevent two chats, agents, sessions, or processes from writing to the same
system branch, release pointer, registry record, catalog, or shared artifact
at the same time.

The coordination guard is mandatory even when both writers use an approved
connector and the same authorized target Drive.

```text
AUTHORIZED_ROUTE != WRITE_SLOT_AVAILABLE
```

A valid storage route grants permission to attempt lock acquisition.
It does not grant permission to write immediately.

---

# 2. SINGLE WRITING DRIVE HARDLOCK

For `ADDITIONAL_PROMPT_SYSTEM`:

```text
ONLY_WRITING_DRIVE_OWNER = dirk.meereis@icloud.com
ONLY_CANONICAL_ROOT_NAME = Chat GPT Systeme
ONLY_CANONICAL_ROOT_ID = 1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3
```

Allowed acting connectors:

```text
fraggelpower666@googlemail.com
fraggelpower666@gmail.com
```

The connector may write only through granted permission into the verified
target owned by `dirk.meereis@icloud.com`.

No additional prompt-system artifact may be written to:

```text
FragglePower-owned Drive
LYVRA / LÜVRA / LIBRA Drive
dirk.meereis@gmail.com-owned Drive
connector My Drive root
unverified shared folder
newly created parallel root
```

Subfolders are allowed only when their ancestor chain resolves to the canonical
root ID `1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3`.

---

# 3. LOCK SCOPE

A lock is acquired for the smallest safe resource scope.

```text
PROJECT_BRANCH_LOCK =
  SYSTEM_ID + TARGET_BRANCH_ID

GLOBAL_REGISTRY_LOCK =
  CANONICAL_ROOT_ID + REGISTRY_RESOURCE_KEY

GLOBAL_CATALOG_LOCK =
  CANONICAL_ROOT_ID + CATALOG_RESOURCE_KEY

RELEASE_POINTER_LOCK =
  SYSTEM_ID + POINTER_RESOURCE_KEY
```

Two independent systems may write concurrently only when:

```text
SYSTEM_ID differs
AND target branches differ
AND no shared registry/catalog/pointer resource is being changed
```

Writes to shared resources require their own global lock.

---

# 4. LOCK RECORD

Each contender creates a unique candidate lease record:

```json
{
  "schema": "USBO_WRITE_LEASE_V1",
  "lock_id": "UUID",
  "resource_key": "SYSTEM_ID::TARGET_BRANCH_ID",
  "system_id": "SYSTEM_ID",
  "target_root_id": "1anVKY6tadkkn22zxvwlSgV_4o0r3IpM3",
  "target_owner": "dirk.meereis@icloud.com",
  "target_branch_id": "FOLDER_ID",
  "actor_email": "ACTIVE_CONNECTOR_EMAIL",
  "session_id": "CHAT_OR_SESSION_IDENTIFIER",
  "operation_id": "UUID",
  "operation_type": "UPLOAD|UPDATE|POINTER|REGISTRY|CATALOG|DELETE",
  "base_version": "EXPECTED_REMOTE_VERSION",
  "base_hash": "EXPECTED_REMOTE_HASH",
  "base_modified_time": "EXPECTED_REMOTE_MODIFIED_TIME",
  "created_at_utc": "ISO-8601",
  "heartbeat_at_utc": "ISO-8601",
  "expires_at_utc": "ISO-8601",
  "state": "CANDIDATE|ACTIVE|COMMITTING|RELEASED|FAILED|STALE"
}
```

No secret, token, or private message content may be written into the lock.

---

# 5. DEFAULT LEASE PARAMETERS

```text
LEASE_DURATION = 15 MINUTES
HEARTBEAT_INTERVAL = 5 MINUTES
SETTLE_WINDOW = 5 SECONDS
LOCK_CONFIRMATION_READS = 2
LOCK_CONFIRMATION_INTERVAL = 2 SECONDS
MAX_CLOCK_SKEW_TOLERANCE = 60 SECONDS
```

These values may be tightened, but not silently weakened.

Long-running operations must renew the heartbeat before the remaining lease
time drops below two heartbeat intervals.

---

# 6. DRIVE-NATIVE DETERMINISTIC LOCK ELECTION

Google Drive file creation is not a transactional compare-and-set operation.
Therefore the guard must not assume that creating one lock file automatically
means ownership.

Required protocol:

```text
1. VERIFY ACTOR-TO-TARGET ROUTE.
2. READ ALL ACTIVE LOCK CANDIDATES FOR RESOURCE_KEY.
3. CREATE UNIQUE CANDIDATE LEASE.
4. WAIT SETTLE_WINDOW.
5. READ ALL ACTIVE CANDIDATES AGAIN.
6. DISCARD EXPIRED OR INVALID CANDIDATES.
7. ELECT WINNER DETERMINISTICALLY:
   lowest (created_at_utc, lock_id) wins.
8. READ LOCK SET AGAIN after confirmation interval.
9. REQUIRE same winner in two consecutive complete reads.
10. REQUIRE own lock_id == elected winner.
11. MARK own lease ACTIVE.
12. READ BACK ACTIVE LEASE.
13. ONLY THEN ALLOW REMOTE MUTATION.
```

If candidate listing is partial, unavailable, ambiguous, or changes during
confirmation:

```text
LOCK_CERTAINTY = FALSE
REMOTE_WRITE = BLOCKED
```

---

# 7. LOCK ACQUISITION RESULT

```text
LOCK_ACQUIRED
LOCK_HELD_BY_OTHER
LOCK_STATE_UNCERTAIN
LOCK_BACKEND_UNAVAILABLE
STALE_LOCK_REQUIRES_RECOVERY
```

Only `LOCK_ACQUIRED` permits a remote mutation.

Required block report when another writer owns the lock:

```text
BLOCKED: Another chat, session, agent, or process currently holds the
write lease for this system resource.

No remote write was executed.
The local work remains preserved.
Retry only after the active lease is released or expires and recovery checks
confirm that no incomplete commit exists.
```

---

# 8. HEARTBEAT

During a write transaction:

```text
ACTIVE LEASE
→ HEARTBEAT UPDATE
→ READBACK
→ VERIFY lock_id, resource_key, actor, session, expiry
```

Heartbeat failure:

```text
LEASE_HEARTBEAT_UNVERIFIED
→ STOP NEW MUTATIONS
→ DO NOT UPDATE POINTERS
→ MARK COMMIT INCOMPLETE LOCALLY
→ REQUIRE REMOTE STATE INSPECTION
```

---

# 9. OPTIMISTIC CONCURRENCY CHECK

The lease is necessary but not sufficient.

Immediately before each destructive or state-advancing mutation, re-read:

```text
REMOTE_VERSION
REMOTE_HASH
REMOTE_MODIFIED_TIME
CURRENT_POINTER
REGISTRY_REVISION
CATALOG_REVISION
TARGET_PARENT_ID
```

Compare against the values captured when the lock was acquired.

```text
BASE_STATE_MATCH = REQUIRED
```

Any drift means another change occurred or the assumed base is stale:

```text
REMOTE_STATE_DRIFT
→ ABORT WRITE
→ DO NOT OVERWRITE
→ PRESERVE LOCAL PACKAGE
→ CREATE DIVERGENCE REPORT
```

---

# 10. TWO-PHASE COMMIT

Use a staged commit:

```text
PHASE 1 — PREPARE
- acquire lock
- verify route
- verify base state
- upload immutable release artifacts to staging/release branch
- read back every artifact
- verify names, IDs, sizes, hashes where available

PHASE 2 — COMMIT
- heartbeat
- re-read lock set
- confirm sole elected winner
- re-read base state
- update release pointer
- update registry
- update catalog
- read back pointer, registry, and catalog
- mark DRIVE_COMMIT VERIFIED
```

Never update the current pointer before immutable artifacts are verified.

---

# 11. LOCK RELEASE

Successful release:

```text
DRIVE_COMMIT = VERIFIED
→ MARK LEASE RELEASED
→ READ BACK RELEASED STATE
→ DELETE OR ARCHIVE LEASE ACCORDING TO RETENTION POLICY
```

Failed operation:

```text
STATE = FAILED
RECOVERY_REQUIRED = TRUE
LEASE remains visible until expiry or explicit recovery
```

Do not silently delete evidence of an interrupted commit.

---

# 12. STALE LOCK RECOVERY

A lock is not considered safely stale merely because its timestamp expired.

Required recovery checks:

```text
1. Verify lease expiry plus clock-skew tolerance.
2. Verify no recent heartbeat.
3. Inspect staging and release artifacts.
4. Inspect current pointer.
5. Inspect registry and catalog.
6. Detect partial commit.
7. Produce recovery decision.
```

Outcomes:

```text
SAFE_TO_RECLAIM
PARTIAL_COMMIT_REQUIRES_REPAIR
LOCK_OWNER_STILL_ACTIVE
STATE_UNCERTAIN
```

Only `SAFE_TO_RECLAIM` permits a new election.

---

# 13. SESSION AND OPERATION IDENTITY

Every write attempt must have:

```text
SESSION_ID = stable identifier for the current chat or execution session
OPERATION_ID = unique identifier for one write transaction
LOCK_ID = unique identifier for one lease candidate
```

A session must never reuse a completed or failed `OPERATION_ID`.

---

# 14. SHARED RESOURCE SERIALIZATION

Even when two chats modify different systems, these shared resources must be
serialized:

```text
GLOBAL_PROJECT_REGISTRY
GLOBAL_SYSTEM_CATALOG
GLOBAL_RELEASE_INDEX
GLOBAL_BACKUP_INDEX
GLOBAL_RECOVERY_INDEX
```

A project-specific release may be prepared concurrently, but shared-index
updates require a separate global lock.

---

# 15. WRITE DECISION MATRIX

| Route valid | Lock acquired | Base state matches | Decision |
|---|---|---|---|
| No | Any | Any | BLOCK |
| Yes | No | Any | BLOCK |
| Yes | Uncertain | Any | BLOCK |
| Yes | Yes | No | BLOCK + divergence report |
| Yes | Yes | Yes | WRITE MAY PROCEED |

---

# 16. ACCEPTANCE TESTS

```text
TEST A — no existing lock
EXPECTED = candidate election succeeds, one winner

TEST B — another chat has active lock
EXPECTED = second chat blocked

TEST C — two candidates created nearly simultaneously
EXPECTED = deterministic winner; loser blocked

TEST D — lock listing incomplete
EXPECTED = fail closed

TEST E — active lease heartbeat stops
EXPECTED = no immediate takeover; stale recovery required

TEST F — base state changes after lock acquisition
EXPECTED = write aborted

TEST G — artifacts verified but pointer update not yet committed
EXPECTED = lease remains COMMITTING; second writer blocked

TEST H — pointer and registry readback match
EXPECTED = DRIVE_COMMIT VERIFIED, lease released

TEST I — different systems, different branches
EXPECTED = project releases may prepare concurrently

TEST J — both operations need global registry update
EXPECTED = registry updates serialized
```

---

# 17. HARD COMPLETION RULE

```text
SYSTEM_COMPLETION = VERIFIED
```

requires:

```text
AUTHORIZED_TARGET_DRIVE = TRUE
PROJECT_LOCK_ACQUIRED = TRUE
SHARED_RESOURCE_LOCKS_ACQUIRED_WHEN_REQUIRED = TRUE
BASE_STATE_MATCH = TRUE
POST_WRITE_READBACK = TRUE
POINTER_AND_REGISTRY_READBACK = TRUE
LEASE_RELEASE_VERIFIED = TRUE
```
