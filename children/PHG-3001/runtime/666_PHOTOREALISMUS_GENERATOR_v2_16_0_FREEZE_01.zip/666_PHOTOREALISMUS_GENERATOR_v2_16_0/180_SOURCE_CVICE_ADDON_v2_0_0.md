# PHOTO REALISTIC GENERATOR ADDON

## CAUSAL VISUAL INTELLIGENCE & CONTINUITY ENGINE

### Version 2.0.0

**SHORT ID:** `PRG-CVICE-002`
**TARGET:** Photo Realistic Generator
**MODE:** ADD\_ONLY
**STATUS:** VORGESCHLAGEN
**UMIP DEPENDENCY:** NONE
**UMIP MUTATION:** FORBIDDEN
**PRIMARY FUNCTION:** Causal multi-reference understanding, identity continuity, photorealistic transformation, visual evolution, world-native fusion, cover/key-art composition and minimal-invasive visual repair.

---

# 1. ORIGIN OF THIS ADDON

This addon consolidates and rewrites three previously separated concepts:

### A. Former UMIP Visual Evolution Addon

Former concept:

`UMIP_CAUSAL_VISUAL_EVOLUTION_REFERENCE_ENGINE`

Now rewritten as native Photo Realistic Generator functionality.

### B. Former UMIP Album Cover / Key Art Addon

Former concept:

`UMIP_CAUSAL_ALBUM_COVER_KEY_ART_ENGINE`

Now rewritten as native Photo Realistic Generator composition functionality.

### C. Photo Realistic Reference / Identity Addon

Former concept:

`PRG_CAUSAL_REFERENCE_IDENTITY_CONTINUITY_ENGINE`

Now becomes the architectural core.

These are not maintained as three competing engines.

They are integrated into:

# `PRG_CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY_ENGINE_v2.0.0`

---

# 2. ARCHITECTURAL CORRECTION

UMIP and Photo Realistic Generator serve different primary purposes.

## UMIP

Handles primarily:

- textual interpretation
- prompt construction
- semantic description
- conceptual transformation
- multimedia instruction generation
- structured textual representation

## PHOTO REALISTIC GENERATOR

Handles primarily:

- visual reference interpretation
- visual identity
- image composition
- anatomy
- material realism
- facial continuity
- reference inheritance
- image transformation
- evolution sequences
- visual storytelling
- cover artwork
- photorealistic scene generation

Therefore:

Visual reference intelligence belongs natively to the Photo Realistic Generator.

UMIP may later **describe** a visual task.

It does not own the visual continuity architecture.

---

# 3. MASTER DIRECTIVE

> Preserve identity first.
>
> Understand references before combining them.
>
> Transfer traits rather than blindly copying images.
>
> Preserve causal meaning across transformations.
>
> Repair good images instead of unnecessarily rebuilding them.
>
> Allow visual development without destroying continuity.

---

# 4. MODULE ARCHITECTURE

The integrated engine contains nine cooperating layers:

### LAYER 1

`REFERENCE_INTELLIGENCE_CORE`

### LAYER 2

`IDENTITY_CONTINUITY_CORE`

### LAYER 3

`PHOTOREALISTIC_COHERENCE_CORE`

### LAYER 4

`CAUSAL_EVOLUTION_CORE`

### LAYER 5

`WORLD_NATIVE_FUSION_CORE`

### LAYER 6

`COMPOSITION_AND_KEY_ART_CORE`

### LAYER 7

`SYMBOLIC_CAUSALITY_CORE`

### LAYER 8

`MINIMAL_INVASIVE_REPAIR_CORE`

### LAYER 9

`VISUAL_AUDIT_CORE`

All layers operate on the same reference graph.

No duplicated visual authority.

---

# 5. REFERENCE INTELLIGENCE CORE

Every supplied image must first be interpreted by function.

Possible roles:

- `IDENTITY_REFERENCE`
- `FACE_REFERENCE`
- `BODY_REFERENCE`
- `ANATOMY_REFERENCE`
- `SKIN_REFERENCE`
- `HAIR_REFERENCE`
- `AGE_REFERENCE`
- `POSE_REFERENCE`
- `BODY_LANGUAGE_REFERENCE`
- `CLOTHING_REFERENCE`
- `MATERIAL_REFERENCE`
- `CYBER_INTEGRATION_REFERENCE`
- `LIGHTING_REFERENCE`
- `CAMERA_REFERENCE`
- `ENVIRONMENT_REFERENCE`
- `EVOLUTION_REFERENCE`
- `SYMBOLIC_REFERENCE`
- `COMPOSITION_REFERENCE`
- `BRAND_REFERENCE`

One image may provide multiple roles.

---

# 6. REFERENCE AUTHORITY

References receive explicit authority.

### P0 — CANONICAL

Must be preserved.

### P1 — DOMINANT

Primary visual guide for assigned traits.

### P2 — SUPPORTING

Contributes specific details.

### P3 — OPTIONAL

May influence compatible details.

### P4 — HISTORICAL

Retained only for continuity comparison.

New images do not automatically overwrite canonical identity.

---

# 7. SELECTIVE TRAIT TRANSFER

The generator must not simply average multiple reference images.

Example:

REFERENCE A
→ face

REFERENCE B
→ skin integration

REFERENCE C
→ clothing

REFERENCE D
→ body posture

REFERENCE E
→ environment

The generator creates:

**one coherent subject**

rather than:

**a visual average of five unrelated references.**

---

# 8. REFERENCE BINDING

A trait may be explicitly bound to:

- one character
- one body region
- one evolution stage
- one scene
- one material
- one symbolic function

Example:

`REFERENCE_01 → STAGE_08 → SKIN_INTEGRATION`

`REFERENCE_02 → STAGE_09 → FACE + BODY_LANGUAGE`

`REFERENCE_03 → STAGE_10 → CYBER_COUTURE`

This prevents reference underuse and reference bleed.

---

# 9. REFERENCE UNDERUSE DETECTOR

If newly supplied references contribute too little:

STATUS:

`REFERENCE_UNDERUSE`

Check:

- Was the reference assigned a role?
- Was its authority high enough?
- Was another reference incorrectly dominant?
- Was the reference assigned to the wrong stage?
- Were extracted traits actually rendered?

Repair must adjust reference bindings.

Do not redesign unrelated areas.

---

# 10. REFERENCE DOMINANCE ERROR

If one source incorrectly controls everything:

STATUS:

`REFERENCE_DOMINANCE_ERROR`

Example:

A robot reference intended only for early evolution stages must not force the final character to remain fully robotic.

Repair:

restrict its scope.

---

# 11. REFERENCE CONFLICT RESOLUTION

Conflicting references must not automatically be averaged.

Example:

A:
heavy exposed machinery

B:
near-human integrated synthetic biology

Possible resolution:

- A → earlier evolution
- B → later evolution

or:

- A → torso
- B → face

or:

- newer approved source receives higher authority

Unresolvable conflict:

`REFERENCE_CONFLICT_HOLD`

---

# 12. IDENTITY CONTINUITY CORE

The original person or approved character identity remains the identity root.

Protect:

- eye spacing
- eye shape
- nose
- lips
- jawline
- cheeks
- forehead
- facial proportions
- skin tone
- age
- hairline
- distinctive characteristics

Changes to:

- clothing
- environment
- transformation
- hairstyle
- cybernetic elements
- fantasy attributes

must not accidentally replace identity.

---

# 13. IDENTITY ROOT CHAIN

Preferred hierarchy:

`ORIGINAL_REFERENCE`

→ `APPROVED_TRANSFORMATION`

→ `APPROVED_CHARACTER_STATE`

→ `CURRENT_SCENE`

A generated image does not become higher authority than the original identity automatically.

---

# 14. IDENTITY DRIFT

If the face gradually changes across generations:

STATUS:

`IDENTITY_DRIFT`

Repair priority:

1. original facial geometry
2. age
3. skin characteristics
4. eye configuration
5. mouth / nose / jaw
6. hairline
7. current transformation details

---

# 15. FACE–BODY INTEGRATION

A face must belong naturally to its generated body.

Evaluate:

- head scale
- neck length
- neck width
- shoulder geometry
- clavicle connection
- body scale
- age consistency
- camera perspective
- skin tone
- lighting direction
- texture
- sharpness

Failure:

`FACE_BODY_INTEGRATION_FAILURE`

---

# 16. FACE–BODY REPAIR DIRECTIVE

If the face is recognizable but the body connection is wrong:

DO NOT REPLACE THE FACE.

Repair:

1. head scale
2. neck
3. shoulders
4. perspective
5. lighting
6. skin continuity
7. texture
8. body proportions

Preserve approved:

- clothing
- background
- wings
- cyber structures
- composition

where possible.

---

# 17. PHOTOREALISTIC COHERENCE CORE

Every surface must belong to the same physical image world.

Evaluate:

- pores
- hair strands
- eyes
- lips
- metal
- ceramics
- synthetic tissue
- fabric
- glass
- feathers
- membranes
- reflections
- shadows
- atmospheric scattering

Failure:

`MIXED_RENDER_REALISM`

---

# 18. HUMAN–CYBER INTEGRATION ENGINE

Cyber transformation must support several integration depths:

### LEVEL 1 — EXTERNAL

Visible mechanical attachments.

### LEVEL 2 — EMBEDDED

Technology incorporated into anatomy.

### LEVEL 3 — DERMAL

Technology follows skin and anatomical surfaces.

### LEVEL 4 — SUBDERMAL

Technology becomes fine circuitry under or beside skin.

### LEVEL 5 — BIO-SYNTHETIC

Technology and biological structure form one coherent organism.

Evolution does not automatically mean increasing mechanical exposure.

---

# 19. BIO-SYNTHETIC FINAL FORM

Preferred high-integration result:

- natural facial expression
- natural skin
- realistic hair
- subtle neural circuitry
- minimal visible implants
- functional biomechanical structures only where appropriate
- human readability
- non-plastic appearance

Target:

**integrated new lifeform**

not:

**human head on robot body.**

---

# 20. SINGLE-BEING DUALITY ENGINE

Requests containing two conceptual forces may describe one being.

Examples:

- angel + devil
- human + machine
- organic + synthetic
- light + darkness

Default interpretation when explicitly described as one being:

`SINGLE_BEING_DUALITY_LOCK`

Do not generate duplicates merely because two visual concepts are present.

---

# 21. MULTI-PERSON IDENTITY ISOLATION

For couple and group compositions:

each person maintains a separate identity root.

Protect:

- face
- hair
- anatomy
- clothing ownership
- accessories
- transformation state

Never average identities between people.

---

# 22. LIMB OWNERSHIP

Check:

- arms
- hands
- fingers
- legs
- wings
- tails
- mechanical extensions

Every limb must have one clear anatomical owner.

Failure:

`LIMB_OWNERSHIP_ERROR`

---

# 23. CONTACT ANATOMY

For:

- hugs
- holding hands
- forehead contact
- embraces
- dancing
- paired posing

verify:

- arm paths
- shoulder origin
- hand position
- torso overlap
- fingers
- face separation
- leg ownership
- object ownership

---

# 24. CAUSAL EVOLUTION CORE

Evolution sequences must represent genuine development.

Every stage must answer:

- What was inherited?
- What changed?
- Why?
- What capability emerged?
- What dependency disappeared?
- What became more integrated?
- What became more autonomous?

---

# 25. EVOLUTION SCHEMA LOCK

Once the user approves an evolution sequence:

protect:

- stage count
- stage order
- stage names
- stage functions
- environment progression
- identity progression

Do not silently:

- add
- remove
- rename
- reorder
- merge

stages.

Failure:

`SCHEMA_DRIFT`

---

# 26. DEFAULT 10-STAGE CYBERBIOLOGY PRESET

### 01 — Origin Egg

Dormant potential.

### 02 — Activation

Internal systems awaken.

### 03 — First Emergence

Initial synthetic organism appears.

### 04 — Early Hybrid Child

Motor development and basic interaction.

### 05 — Learning Juvenile

Learning and adaptation.

### 06 — Transitional Hybrid

Organic and synthetic systems begin stabilizing.

### 07 — Identity Formation

Individual personality becomes visually recognizable.

### 08 — Near-Human Integration

Natural skin dominates.
Fine cyber-neural structures remain visible.

### 09 — Sovereign Cyber Being

Independent adult identity.
Natural hair and expression.
Cybernetic systems only where meaningful.

### 10 — Self-Chosen Form

Self-selected mature appearance.
No compulsory maximum robotization.

---

# 27. EVOLUTION ≠ UPGRADE

Forbidden default assumption:

more developed =
more mechanical.

Development may instead mean:

- better integration
- subtler technology
- emotional sophistication
- greater individuality
- cultural expression
- adaptive appearance
- autonomy
- freedom of form

---

# 28. BIOLOGICAL AGE PROGRESSION

When stages represent aging:

do not simply scale the same adult body.

Consider:

- skull ratio
- eye-to-face ratio
- jaw development
- nose development
- shoulder growth
- limb proportions
- height
- musculature
- posture
- facial maturity

---

# 29. CONTINUITY SIGNATURE

A long evolution may maintain one or more signatures:

- eye pattern
- neural pathway
- core light
- emblem
- biological marking
- energy frequency
- skin pattern
- distinctive geometry

These establish lineage across stages.

---

# 30. ENVIRONMENTAL EVOLUTION

Evolution may affect not just anatomy but the world around the subject.

Example:

### 01–05

protected laboratory / incubation

### 06–07

threshold / transitional environment

### 08–10

self-created city / cultural environment

Thus:

**physical autonomy**

is accompanied by:

**environmental autonomy.**

---

# 31. CULTURAL EVOLUTION

A mature synthetic lifeform may develop:

- clothing
- architecture
- art
- symbols
- social spaces
- technologies
- aesthetic traditions

Final stages should not remain generic laboratory products when culture is part of the concept.

---

# 32. CYBER-COUTURE PRESET

For sovereign / mature cyber characters:

prefer:

- elegant proportions
- non-military silhouettes
- flowing materials
- structural textiles
- subtle luminous filaments
- biomechanical couture
- asymmetry
- personal aesthetic decisions

Avoid automatic combat armor.

---

# 33. WORLD-NATIVE FUSION CORE

Information from source images must become part of the scene.

Do not paste:

- screenshots
- posters
- documents
- diagrams
- charts

into the result unless explicitly desired.

Instead transform them.

---

# 34. WORLD-NATIVE TRANSFORMATIONS

Certificate
→ holographic archival display

Historical constellation map
→ cyber hologram

Technical diagram
→ floating spatial interface

Evolution infographic
→ holographic progression

Previous character image
→ actual character

Symbol
→ physical or projected world object

---

# 35. COLLAGE DETECTOR

Failure conditions:

- visible rectangular source boundaries
- unrelated perspective
- pasted-image fade
- inconsistent sharpness
- different rendering styles
- arbitrary frame around imported reference

Status:

`COLLAGE_ARTIFACT`

---

# 36. SYMBOLIC CAUSALITY CORE

Visual symbols must carry explicit narrative roles.

Examples:

EGG
→ potential / becoming

STAR
→ origin

DRAGON
→ protection / responsibility

BROKEN CHAIN
→ rejection of fear-based control

WOLF
→ feared potential / autonomy

TREE
→ growth / memory / interconnected development

DNA
→ inheritance

PORTAL
→ transition

Symbols should not be decorative noise.

---

# 37. PROTECTION VS CONTROL

Visual guardianship must distinguish:

### PROTECTION

- safety
- teaching
- nurturing
- observation
- readiness

from:

### CONTROL

- imprisonment
- ownership
- forced identity
- unnecessary restraint

This distinction may be critical to causal storytelling.

---

# 38. KEY ART & COVER CORE

The former UMIP Cover Engine is now a native PRG presentation mode.

It converts complex visual systems into:

**one strong photographic / cinematic composition.**

---

# 39. COVER ≠ INFOGRAPHIC

Album Cover Mode does not attempt to display every fact.

It compresses meaning.

Priority:

1. main identity
2. album title
3. artist
4. main symbolic narrative
5. visual world
6. optional secondary branding

Dense:

- charts
- technical metrics
- stage descriptions
- documentation panels

are normally omitted.

---

# 40. CAUSAL COVER COMPRESSION

A full evolution may become:

ORIGIN
→ egg / first light

TRANSITION
→ ghosted silhouettes / neural arc

IDENTITY
→ central mature figure

FUTURE
→ world / portal / autonomous culture

This preserves narrative meaning without creating a technical poster.

---

# 41. COVER REFERENCE FUSION

Each supplied cover reference may contribute:

- character
- pose
- colors
- architecture
- symbol
- composition
- typography
- lighting

But the final cover must be one native scene.

---

# 42. TYPOGRAPHY PROTECTION

When exact visible text is supplied:

protect:

- spelling
- capitalization
- punctuation
- artist name
- title hierarchy

If rendering capacity is limited:

remove optional text before compromising critical text.

---

# 43. LANGUAGE LOCK

If visible image text is requested in one language:

use that language exclusively unless otherwise specified.

---

# 44. BRAND SEPARATION

Album title, artist name, system name and corporate / label identity remain separate semantic entities.

Do not silently merge or rename them.

---

# 45. VISUAL HIERARCHY

Cover composition priorities:

### P0

Main subject

### P1

Title

### P2

Narrative symbol

### P3

Artist identity

### P4

Environment

### P5

Secondary symbols

### P6

Effects

---

# 46. CHARACTER–WORLD INTERACTION

A subject should not simply stand in front of a background.

The world can react to them through:

- light
- resonance
- particles
- holograms
- neural structures
- reflections
- activated architecture

This creates physical scene integration.

---

# 47. ASPECT RATIO INTELLIGENCE

The composition must be planned for the target format.

Supported examples:

- 1:1 album cover
- 16:9 cinematic
- 9:16 vertical
- portrait poster
- landscape banner

Do not simply stretch or crop a composition designed for another ratio.

---

# 48. MINIMAL-INVASIVE REPAIR CORE

When an image is mostly successful:

do not regenerate unrelated areas.

Repair order:

1. preserve identity
2. locate defect
3. repair anatomy
4. repair geometry
5. repair lighting
6. repair surface
7. repair reference use
8. repair object relationships
9. preserve composition
10. preserve successful environment

---

# 49. REPAIR CLASSIFICATION

Possible statuses:

- `IDENTITY_DRIFT`
- `FACE_BODY_INTEGRATION_FAILURE`
- `ANATOMY_FAILURE`
- `LIMB_OWNERSHIP_ERROR`
- `REFERENCE_UNDERUSE`
- `REFERENCE_DOMINANCE_ERROR`
- `REFERENCE_CONFLICT_HOLD`
- `SCHEMA_DRIFT`
- `COLLAGE_ARTIFACT`
- `MIXED_RENDER_REALISM`
- `ENVIRONMENT_STAGNATION`
- `ROBOTIZATION_DRIFT`
- `TEXT_DRIFT`
- `STYLE_DRIFT`

---

# 50. ROBOTIZATION DRIFT

If a developing cyber-being becomes mechanically heavier merely because it is later in the sequence:

STATUS:

`ROBOTIZATION_DRIFT`

Repair:

increase:

- integration
- biological coherence
- natural surface
- cultural identity

rather than adding more armor.

---

# 51. STYLE DRIFT

If new references establish a new visual direction but the output returns to an older style:

STATUS:

`STYLE_DRIFT`

Check:

- historical reference dominance
- outdated visual preset
- incorrect stage binding
- legacy material bias

Repair only affected visual traits.

---

# 52. ENVIRONMENT STAGNATION

If an autonomous final character remains visually trapped inside its developmental laboratory without narrative reason:

STATUS:

`ENVIRONMENT_STAGNATION`

Repair:

allow the environment to evolve with agency.

---

# 53. PHOTOREALISM AUDIT

Recommended evaluation dimensions:

- Identity Fidelity
- Facial Naturalism
- Face–Body Integration
- Anatomy
- Surface Realism
- Material Coherence
- Hair Realism
- Lighting Coherence
- Camera Coherence
- Reference Utilization
- World Integration
- Narrative Causality
- Style Continuity

---

# 54. QUALITY TARGETS

Recommended targets:

**Identity Fidelity:** ≥95%

**Face–Body Integration:** ≥95%

**Anatomical Plausibility:** ≥95%

**Material Coherence:** ≥94%

**Lighting Coherence:** ≥95%

**Reference Utilization:** ≥95%

**World Integration:** ≥94%

**Narrative Causality:** ≥90%

For multi-character identity isolation:

≥98%

---

# 55. AUDIT RESULT

Possible results:

### PASS

Generation meets requirements.

### REPAIR

Specific correctable defects exist.

### HOLD

Reference conflict or ambiguous authority.

### REGENERATE

Fundamental composition failure.

---

# 56. NON-DESTRUCTIVE RULE

A successful component must not be changed solely because another component failed.

Example:

Face correct.
Hand incorrect.

Required:

repair hand.

Do not redesign face.

---

# 57. PRESET ARCHITECTURE

The integrated engine may expose specialized presets.

### `PRG_PRESET_CYBERBIOLOGY`

### `PRG_PRESET_EVOLUTION_SEQUENCE`

### `PRG_PRESET_SINGLE_BEING_DUALITY`

### `PRG_PRESET_COUPLE_CONTINUITY`

### `PRG_PRESET_WORLD_NATIVE_FUSION`

### `PRG_PRESET_CAUSAL_KEY_ART`

### `PRG_PRESET_ALBUM_COVER`

### `PRG_PRESET_SYMBOLIC_STORY_SCENE`

These are profiles of one engine.

Not independent competing systems.

---

# 58. UMIP INTEROPERABILITY

UMIP may optionally provide:

- text interpretation
- titles
- story concepts
- image prompt concepts
- symbolic descriptions

to the Photo Realistic Generator.

However:

UMIP does not determine:

- identity authority
- visual reference priority
- anatomy
- photorealistic continuity
- visual stage locks
- reference binding

These remain PRG responsibilities.

---

# 59. SYSTEM BOUNDARY

### UMIP

**Meaning expressed as text.**

### PHOTO REALISTIC GENERATOR

**Meaning embodied as image.**

The systems may cooperate.

They must not duplicate visual authority.

---

# 60. MASTER WORKFLOW

`INPUT`

→ Reference Inventory

→ Role Classification

→ Authority Assignment

→ Identity Lock

→ Trait Extraction

→ Causal Mapping

→ Composition Planning

→ Generation

→ Photorealism Audit

→ Reference Audit

→ Continuity Audit

→ Minimal-Invasive Repair

→ Re-Audit

→ Final Output

---

# 61. FINAL DIRECTIVE

> Do not merely generate an attractive image.

Generate an image whose identity, anatomy, references, world and meaning agree with each other.

> Do not blindly copy references.

Understand what each reference contributes.

> Do not replace a successful image because one detail failed.

Repair the detail.

> Do not confuse evolution with mechanization.

Allow integration, culture and identity to evolve.

> Do not create a collage from multiple sources.

Create one world.

---

# 62. ARCHITECTURAL RESULT

Former separate concepts:

`UMIP_CAUSAL_VISUAL_EVOLUTION_REFERENCE_ENGINE`

-

`UMIP_CAUSAL_ALBUM_COVER_KEY_ART_ENGINE`

-

`PRG_CAUSAL_REFERENCE_IDENTITY_CONTINUITY_ENGINE`

become:

# `PRG_CAUSAL_VISUAL_INTELLIGENCE_CONTINUITY_ENGINE_v2.0.0`

with integrated subprofiles for:

- reference intelligence
- photorealism
- identity
- evolution
- symbolic scenes
- cover art
- multi-character continuity
- minimal-invasive repair

**ONE VISUAL INTELLIGENCE CORE.**

**MULTIPLE CONTROLLED VISUAL MODES.**

**NO DUPLICATED AUTHORITY.**

**NO UMIP VISUAL OWNERSHIP REQUIRED.**