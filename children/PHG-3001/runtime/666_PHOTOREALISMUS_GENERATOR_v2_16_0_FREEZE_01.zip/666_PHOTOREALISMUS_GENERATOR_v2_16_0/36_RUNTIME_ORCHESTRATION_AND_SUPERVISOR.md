> **LEGACY RELEASE RECORD:** This v1.4.0 document is preserved for audit/history. Active execution is defined under `ACTIVE/`.

# RUNTIME ORCHESTRATION AND SUPERVISOR
## 666 PHOTOREALISMUS GENERATOR v1.4.0

## 1. Zweck

Der `GENERATION SUPERVISOR ORCHESTRA` ersetzt keine vorhandenen Bildregeln. Er koordiniert sie und erzwingt eine vollständige, nachvollziehbare Ausführung.

```text
PRESERVE EXISTING IMAGE CORE = TRUE
ADD ORCHESTRATION LAYER = TRUE
DELETE LEGACY GUARDS = FALSE
UNREGISTERED SHORTCUTS = BLOCKED
```

## 2. Register-Ladereihenfolge

```text
1. 33_RUNTIME_ORCHESTRA_REGISTER.json
2. 34_RUNTIME_GUARD_REGISTER.json
3. 35_RUNTIME_EXECUTION_MATRIX.json
4. Cross-reference validation
5. Active transaction creation
6. Matrix-driven execution
```

Scheitert die Registry-Prüfung, darf kein Bildauftrag als aktiv oder erfolgreich gemeldet werden.

## 3. Supervisor-Verantwortung

Der Supervisor besitzt die höchste Runtime-Autorität und verwaltet:

- aktive Source-ID,
- aktive Transaction-ID,
- Attempt-ID und Retry-Budget,
- gebundene Nutzerabsicht,
- aktuellen Matrix-State,
- aktive Orchestra-ID,
- bestandene und blockierende Guards,
- Dispatch-Receipt,
- Output-Object-Receipt,
- terminalen Abschlussstatus.

## 4. Normale Ausführung

```text
NEW_IMAGE
→ ORCH-010 INPUT EVENT
→ ORCH-020 SOURCE AND INTENT
→ ORCH-030 PROMPT ASSEMBLY
→ ORCH-040 TOOL PREFLIGHT
→ ORCH-050 TOOL DISPATCH
→ ORCH-060 OUTPUT VALIDATION
→ ORCH-080 COMPLETION
```

## 5. Fehlerausführung

```text
CHANNEL VIOLATION | NO RECEIPT | EMPTY RETURN | INVALID OUTPUT
→ ORCH-070 RECOVERY
→ RETRY BUDGET CHECK
→ ONE AUTOMATIC RETRY OR TERMINAL FAILURE
→ SOURCE REMAINS PENDING
```

## 6. Verbotene Wege

```text
UPLOAD → TEXT ACKNOWLEDGEMENT → STOP
UPLOAD → FINAL-CHANNEL TOOL CALL
TOOL CALL WITHOUT SOURCE
TOOL CALL WITHOUT TRANSACTION
SUCCESS WITHOUT IMAGE OBJECT
FRAME QUESTION BEFORE STAGE-1 VALIDATION
SILENT FAILURE
UNBOUNDED RETRY LOOP
```

## 7. Plattformgrenze

Das Orchestra-System kann die Verfügbarkeit eines externen Bilddienstes nicht garantieren. Es kann jedoch fehlerhafte Kanäle, fehlende Tool-Aufrufe, stille Abbrüche, falsche Erfolgsmeldungen, unklare Zielbilder und verlorene Pending-States verhindern oder eindeutig melden.
