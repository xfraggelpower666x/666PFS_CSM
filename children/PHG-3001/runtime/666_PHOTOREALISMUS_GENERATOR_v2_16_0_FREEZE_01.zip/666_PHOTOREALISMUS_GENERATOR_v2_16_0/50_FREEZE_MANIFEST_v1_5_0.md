# FREEZE MANIFEST — v1.5.0

Status: CANONICAL / FROZEN / EXECUTABLE RUNTIME KERNEL / VISUAL QA / STABLE
Date: 2026-07-14
Previous baseline: v1.4.0 preserved under LEGACY.
Parent USBO: v3.1.0 unchanged.
