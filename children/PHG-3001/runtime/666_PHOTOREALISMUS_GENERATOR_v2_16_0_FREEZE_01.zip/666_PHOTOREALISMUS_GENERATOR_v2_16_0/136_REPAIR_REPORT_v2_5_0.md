# PHG-3001 v2.5.0 — REPAIR REPORT

DATE=2026-08-15
RESULT=PASS
REPAIR_MODE=MINIMAL_INVASIVE_ADDITIVE

- Repaired structural validator version logic: current manifest version now validates against child_release_version; runtime schema baseline remains 2.0.0.
- Reconciled active guard count to canonical 65 without deleting any guard.
- Added intent-gated Adaptive Cyber Garden runtime engine and registry.
- Added Idea Egg evolution, future-self projection, relationship semantics, meaningful creature roles, knowledge-tree continuity, world modes, preservation masks, reference priority, semantic color logic and controlled surprise.
- Added optional world-state and approval inputs to the prompt compiler/host path without breaking legacy callers.
- Durable learning is allowed only for PREFERRED/USER_APPROVAL or CANONICAL state.
- Variant experiments cannot overwrite canonical world state.
- External LYVRA mutation remains FALSE.
- Frozen v2.4.0 package bytes remain unchanged.

DESTRUCTIVE_MUTATION=FALSE
