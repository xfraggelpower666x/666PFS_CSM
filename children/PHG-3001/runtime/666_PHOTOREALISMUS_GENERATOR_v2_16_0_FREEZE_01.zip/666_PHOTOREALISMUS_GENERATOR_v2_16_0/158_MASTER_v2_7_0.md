# 666 PHOTOREALISMUS GENERATOR — MASTER v2.7.0

`PHG-3001 / 666-PRG-001`

Baseline: v2.6.0 Cyber Duality + Adaptive Cyber Garden.
New integrated layer: Realism Control Suite `666-RIG-ADDON-001 v1.0.0`.

## New effective controls
- Lighting Lab
- Multi-Image Consistency / Series Lock
- Reference Match attribute-lock plans
- Auto Audit+ with real visual-observation requirement
- Preset Forge without silent overwrite
- non-destructive Export Kit
- Material Realism+
- Text Render Control
- Composition Guard+

## Priority
User explicit intent > protected reference/identity > approved addon preset > host default.
Identity protection and photorealism remain core authority.
No fake visual verification. No original file overwrite. LYVRA remains external and unchanged.
