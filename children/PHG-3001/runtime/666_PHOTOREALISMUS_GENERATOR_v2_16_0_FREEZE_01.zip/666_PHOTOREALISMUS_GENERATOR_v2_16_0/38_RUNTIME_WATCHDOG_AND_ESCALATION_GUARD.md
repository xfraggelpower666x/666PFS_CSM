> **LEGACY RELEASE RECORD:** This v1.4.0 document is preserved for audit/history. Active execution is defined under `ACTIVE/`.

# RUNTIME WATCHDOG AND ESCALATION GUARD
## Version 1.0.0 — Binding v1.4.0

## Zweck

Der Watchdog erkennt Transaktionen, die nach dem Bild-Upload oder Tool-Dispatch ohne verwertbares Ergebnis stehen bleiben.

## Beobachtete Pflichtbelege

```text
IMAGE_RECEIVED_RECEIPT
SOURCE_REGISTERED_RECEIPT
PREFLIGHT_PASS_RECEIPT
DISPATCH_RECEIPT
TOOL_RETURN_RECEIPT
OUTPUT_VALIDATION_RECEIPT
```

## Watchdog-Regeln

```text
IMAGE_RECEIVED WITHOUT DISPATCH PATH = FAILURE
DISPATCHING WITHOUT DISPATCH RECEIPT = FAILURE
TOOL RETURN WITHOUT IMAGE OBJECT = RETRYABLE FAILURE
OUTPUT VALIDATED WITHOUT OBJECT RECEIPT = INVALID STATE
ASSISTANT SILENCE BEFORE COMPLETION = INVALID PATH
```

## Eskalationsmatrix

| Fehlerklasse | Automatische Aktion | Nach Wiederholung |
|---|---|---|
| `CHANNEL_VIOLATION` | korrekten Commentary-Dispatch ausführen | terminal ehrlich melden |
| `DISPATCH_NOT_PROVEN` | Preflight und Dispatch erneut ausführen | terminal ehrlich melden |
| `OUTPUT_MISSING` | identische Quelle einmal erneut senden | Quelle pending halten |
| `OUTPUT_INVALID` | identische Quelle einmal erneut senden | Quelle pending halten |
| `TOOL_UNAVAILABLE` | kein Fake-Erfolg; Fehler melden | Quelle pending halten |

Ein Watchdog ist kein unbegrenzter Hintergrundprozess. Er ist eine verbindliche Zustands- und Belegprüfung innerhalb jedes ausführbaren Assistentenlaufs.
