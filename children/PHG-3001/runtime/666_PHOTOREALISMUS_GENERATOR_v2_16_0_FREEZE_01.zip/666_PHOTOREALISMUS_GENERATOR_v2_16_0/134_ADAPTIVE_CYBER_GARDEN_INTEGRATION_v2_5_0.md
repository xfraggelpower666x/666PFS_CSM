# PHG-3001 v2.5.0 — Adaptive Cyber Garden Integration

SYSTEM_ID=666-PRG-001
ENTRY_ID=PHG-3001
BASELINE=2.4.0
TARGET=2.5.0
ADDON_ID=PG-ACGIE-001
MODE=ADD_ONLY / NON_DESTRUCTIVE

## Integration decisions
- The v2.4.0 freeze is historical and remains unchanged.
- The new addon is integrated only into v2.5.0.
- Activation is explicit/semantic Cyber-Garden intent only; unrelated photorealistic jobs remain unchanged.
- Protected identity and reference priority remain above world evolution.
- Persistent learning is host-controlled: only USER_APPROVAL or explicit CANONICAL status may create durable preference changes.
- Variants branch from canonical state and do not overwrite it.
- External LYVRA is not mutated; LYVRA may appear only as requested visual/world context.
- Non-destructive evolution order is KEEP -> EXTEND -> INTEGRATE -> REBALANCE.

## Runtime additions
- ACTIVE/47_CYBER_GARDEN_ENGINE.py
- ACTIVE/48_CYBER_GARDEN_REGISTRY.json
- ACTIVE/49_RUN_CYBER_GARDEN_TESTS.py
- Prompt compiler integration with optional world-state and approval inputs.

## Baseline repair included
The inherited v2.4.0 structural validator incorrectly hard-coded ACTIVE manifest version 2.0.0 and the active manifest reported 73 guards while the canonical guard register and handler registry each contain 65. v2.5.0 repairs the validator to compare current manifest version with child_release_version while keeping runtime schema baseline 2.0.0, and corrects registered_guards to 65. No historical v2.4.0 bytes are changed.
