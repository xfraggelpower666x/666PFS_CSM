# REALISM CONTROL ADDON — SOURCE PACKAGE RECORD

- Addon ID: `666-RIG-ADDON-001`
- Version: `1.0.0`
- Source package: `666_PHOTOREALISMUS_GENERATOR_v2_4_0_PLUS_REALISM_CONTROL_ADDON_v1_0_0_TESTED.zip`
- Source SHA-256: `74ddc3bb10362e4781f1bcb600ded3e4aed2f419d3a6637e3622a4088d41c55a`
- Source ZIP entries: `279`
- Source host baseline: `PHG v2.4.0`
- Integration target: `PHG v2.7.0` derived from active `v2.6.0`
- Policy: `DELTA_EXTRACTION_ONLY / NO_DOWNGRADE / ADD_ONLY`

The source package's old v2.4 host files are not authoritative for v2.7.0. Only the Realism Control Suite, its registry, bridge logic and supported compiler integration semantics are imported.
