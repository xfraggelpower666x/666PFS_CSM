# PHG-3001 v2.2.0 — Aspect Ratio & Broadcast Preset

SYSTEM_ID=666-PRG-001
ENTRY_ID=PHG-3001
VERSION=2.2.0
BASELINE=2.0.0
PRESERVED_EXTENSION=PHLF-CYBER-v1.2.0
PRESERVED_EXTENSION=FRAME_MODES-v1.0.0

## Aspect-Ratio-Router

Unterstützte Mindestwerte: `1:1`, `4:3`, `3:4`, `16:9`, `9:16`.

Eine ausdrücklich vom Benutzer genannte Ratio hat immer Vorrang vor automatisch abgeleiteten oder Preset-Defaults. Ein gewöhnliches Landschaftsmotiv aktiviert deshalb nicht versehentlich den 16:9-Modus; dafür ist eine Formatabsicht erforderlich.

## Broadcast-Preset

PRESET_ID=PRESET_LYVRA_CYBER_HOLO_BROADCAST_16_9
DEFAULT_ASPECT_RATIO=16:9
DEFAULT_OUTPUT_VARIANTS=5
FRAME_MODE=FRAME_MODE_CYBER_HOLO
VISIBLE_TEXT=666SOUNDsDESIGn L.Y.V.R.A. WEBRADIO & BROADCASTER
AI_SYMBOL_LAYER=TRUE
HOLOGRAPHIC_MODE=TRUE
CYBER_UI=TRUE

LYVRA_ROLE=VISUAL_BRANDING_CONTEXT_ONLY
EXTERNAL_LYVRA_SYSTEM_MUTATION=FALSE
