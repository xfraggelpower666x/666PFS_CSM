# RELEASE HANDOFF — v1.5.2

## Startreihenfolge

```bash
python3 ACTIVE/25_CANONICAL_RESOLVER.py
python3 ACTIVE/12_VALIDATE_ACTIVE_RUNTIME.py
python3 ACTIVE/16_RUN_ACCEPTANCE_TESTS.py
python3 ACTIVE/21_RUN_HARDLOCK_TESTS.py
python3 ACTIVE/23_RUN_REPAIR_REGRESSION_TESTS.py
python3 66_FULL_SYSTEM_AUDIT.py
python3 32_VERIFY_PACKAGE.py
```

## Aktive Einstiegspunkte

- Runtime: `ACTIVE/11_RUNTIME_KERNEL.py`
- Host-Turn: `ACTIVE/19_HOST_TURN_EXECUTOR.py`
- Persistenz: `ACTIVE/22_RUNTIME_STORE.py`
- Canonical Resolver: `ACTIVE/25_CANONICAL_RESOLVER.py`

## Versionsregel

`v1.5.2` ist der einzige automatisch aktive Stand. `v1.5.1`, `v1.5.0` und `v1.4.0` bleiben Historie/Fallback und dürfen nicht ungefragt geladen werden.
