# 666 PHOTOREALISMUS GENERATOR — MASTER v2.6.0

SYSTEM_ID=666-PRG-001
ENTRY_ID=PHG-3001
VERSION=2.6.0
BASELINE=2.5.0
STATUS=FROZEN_LOCAL_VERIFIED_PENDING_REMOTE_PUBLICATION
UPDATE_CLASS=CONTROLLED_ADDITIVE_CYBER_DUALITY_CHARACTER_COUPLE_ENGINE
ADDON_ID=PG-CDCCE-001

## New active capability
Cyber Duality Character & Couple Engine: one-being angel/devil hybrid hardlock by default, explicit multi-person override, protected couple identities, face-body naturalism hardlock, wing/halo/horn anatomical logic, photorealism-first transformation, contact anatomy protection, and minimal-invasive face/body repair.

IDENTITY_PROTECTION=HARD
FACE_BODY_NATURALISM=HARD
PHOTOREALISM_PRIORITY=MAX
UNRELATED_IMAGE_INJECTION=FORBIDDEN
DEFAULT_DUALITY_PERSON_COUNT=ONE
EXPLICIT_MULTI_PERSON_OVERRIDE=TRUE
EXTERNAL_LYVRA_MUTATION=FALSE
