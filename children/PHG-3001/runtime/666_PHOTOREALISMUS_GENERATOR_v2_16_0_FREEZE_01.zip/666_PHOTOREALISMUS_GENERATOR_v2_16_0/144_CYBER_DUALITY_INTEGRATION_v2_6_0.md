# PHG-3001 v2.6.0 — Cyber Duality Character & Couple Integration

SYSTEM_ID=666-PRG-001
ENTRY_ID=PHG-3001
BASELINE=2.5.0
TARGET=2.6.0
ADDON_ID=PG-CDCCE-001
MODE=ADD_ONLY / NON_DESTRUCTIVE

## Runtime decisions
- Duality activates only from explicit/semantic angel+demon duality intent.
- Default: ONE PERSON -> ONE BODY -> ONE IDENTITY -> TWO VISUAL ENERGIES.
- Explicit couple/two-person intent overrides the single-being default and protects both identities independently.
- Identity, face/body naturalism, anatomy and requested person count outrank duality styling.
- Human -> Enhanced Human -> Cyber Hybrid is default; full robot requires explicit instruction.
- Duality uses interwoven shared architecture, not a crude center split.
- No random text/logos/glyphs.
- Face/body mismatch triggers minimal-invasive reconstruction around the protected face.
- Ordinary images and Cyber Garden behavior remain unaffected when duality is inactive.
- External LYVRA is not mutated.
