# BOOTSTRAP COMPATIBILITY HANDOFF
## 666 PHOTOREALISMUS GENERATOR v1.5.4

Parent bleibt `USBO v3.1.0`. Der Child-Stand v1.5.4 besitzt für Runtime-, Host-Turn-, Trigger-, Receipt- und Canonical-Resolution-Regeln Vorrang vor historischen Parent- oder Legacy-Regeln.

Verbindlich:

- ausschließlich `ACTIVE/` automatisch laden;
- `LEGACY/` nur ausdrücklich und read-only öffnen;
- unbekannte State/Event-Pfade verweigern;
- Bildwerkzeug nur in `commentary` aufrufen;
- keine Text-Erfolgsmeldung ohne Bildobjekt;
- Ganzphrasenprüfung für Control-Trigger;
- kreative Folgeanweisung mit vorhandener Quelle erneut ausführen;
- Remote-Schreibregeln nur über tatsächlich verfügbare Connector-Funktionen anwenden;
- Secrets, Tokens und Zugangsdaten niemals in Paketdateien protokollieren.

## PHG-3001 Child Release v2.2.0

- `SYSTEM_ID=666-PRG-001` und `ENTRY_ID=PHG-3001` bleiben unverändert.
- v2.2.0 ist ein vollständiger Child-Freeze auf Basis v2.0.0 plus FRAME_MODES v1.0.0.
- Der neue Aspect-Ratio-Router und das Broadcast-Preset werden ausschließlich aus `ACTIVE/` geladen.
- Explizite Seitenverhältnisse überschreiben alle Format-Defaults.
- Das externe LYVRA-System bleibt unverändert; der Name erscheint nur als Bild-/Branding-Preset.
