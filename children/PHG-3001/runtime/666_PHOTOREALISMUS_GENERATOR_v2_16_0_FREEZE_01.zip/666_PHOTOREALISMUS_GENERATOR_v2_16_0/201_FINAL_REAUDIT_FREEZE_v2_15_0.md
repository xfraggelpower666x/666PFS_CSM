# PHG v2.15.0 — Final Re-Audit and Freeze

Final gates: canonical runtime regression, portable governance tests, American-English current user-surface scan, version parity, menu ID parity, trigger parity, capability-class parity, and ZIP integrity.

Portable scope is the full execution runtime plus current user documentation. Historical archival ledgers remain in the canonical systems backup and are intentionally not shipped in the portable edition; this prevents legacy-language history from violating the en-US portability contract while preserving full runtime capability.
