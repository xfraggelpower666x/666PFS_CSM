# PHG v2.14.0 — Guided Interaction Integration

## New interface contract
PHG owns exactly two prefixed interface triggers:
- `PHG SYSTEMSTART`
- `PHG HELP`

The actual image control remains prefix-free. Users select modes by canonical name, menu number, compatible combinations, or semantic natural language.

## Mode selection behavior
Bare selection is control-plane input, not image generation. It returns mode explanation, limitations, recommended companion modes, and at least three copy-ready prompts. A substantive image instruction is required before image dispatch.

## Key repair learned from live use
`LOVE_FRAME_ELECTRIC_BLUE` is a style/frame preset. It must not silently imply photorealistic reconstruction, identity/reference preservation, or exact text. Guidance therefore recommends `CORE_PHOTOREALISM + REALISM_CONTROL + IDENTITY_PRESERVATION + REFERENCE_PRESERVATION` when those goals are relevant.

## New active modules
- `ACTIVE/78_PHG_INTERACTION_REGISTRY.json`
- `ACTIVE/79_PHG_INTERACTION_ENGINE.py`
- `ACTIVE/80_RUN_PHG_INTERACTION_TESTS.py`

## Modified active modules
- `ACTIVE/00_ACTIVE_MANIFEST.json`
- `ACTIVE/17_CONTROL_TRIGGER_REGISTRY.json`
- `ACTIVE/75_MODE_MENU_REGISTRY.json`
- `ACTIVE/76_MODE_MENU_ENGINE.py`
- `ACTIVE/77_RUN_MODE_MENU_TESTS.py`

No external LYVRA mutation. Existing PHG modes and presets are preserved.
