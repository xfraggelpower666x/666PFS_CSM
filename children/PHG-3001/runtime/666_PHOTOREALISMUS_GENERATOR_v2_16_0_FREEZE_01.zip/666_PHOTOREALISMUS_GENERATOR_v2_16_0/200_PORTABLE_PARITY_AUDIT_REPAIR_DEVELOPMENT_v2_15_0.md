# PHG v2.15.0 — Audit / Repair / Improvement / Development

Pre-audit identified that v2.14.0 produced only a canonical system backup and had no mandatory portable parity contract.

Repair and development:
- Added PORTABLE_PARITY_REQUIRED governance.
- Added en-US portable sister-release requirement.
- Added dual-release lifecycle lockstep.
- Added feature/menu/trigger/prompt parity gates.
- Added fail-closed release completion gate.
- Defined portable as full execution runtime plus current user documentation, excluding historical archival ledgers so the portable package can remain entirely American English.
- Stable technical IDs are preserved unchanged.
