# FREEZE MANIFEST v1.6.0

Status: FROZEN

- Active runtime version: 1.6.0
- Previous frozen baseline: 1.5.4
- Extension focus: outfit / pose / camera reframing / effect directives
- Validation status: PASS
