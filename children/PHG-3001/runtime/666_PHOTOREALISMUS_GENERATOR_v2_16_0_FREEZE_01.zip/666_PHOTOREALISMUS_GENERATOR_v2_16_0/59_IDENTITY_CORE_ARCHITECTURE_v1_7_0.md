# IDENTITY CORE ARCHITECTURE v1.7.0

The uploaded source image is the canonical identity anchor. Each visible person receives a separate identity record. Protected traits remain locked; mutable traits may change only through explicit creative intent. High identity drift is vetoed unless the user explicitly requests an identity replacement.
