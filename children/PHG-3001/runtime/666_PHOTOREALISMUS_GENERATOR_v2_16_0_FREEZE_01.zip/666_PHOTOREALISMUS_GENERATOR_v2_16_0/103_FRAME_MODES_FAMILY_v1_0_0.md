# FRAME_MODES FAMILY v1.0.0 — PHG-3001 / 666-PRG-001

STATUS=LOCAL_FREEZE_READY_WRITE_BLOCKED

## Purpose
Automatically detect natural-language requests for a frame/border and route them into a coherent frame family without requiring internal mode names.

## Modes
- FRAME_MODE_NONE
- FRAME_MODE_CLEAN_BORDER
- FRAME_MODE_POSTER_EDGE
- FRAME_MODE_CYBER_HOLO
- FRAME_MODE_CYBER_LOVE_HOLO
- FRAME_MODE_ROMANTIC_NEON_SIGNATURE
- FRAME_MODE_TECHNO_POSTER
- FRAME_MODE_LUXURY_GLOW
- FRAME_MODE_DARK_ORNAMENT
- FRAME_MODE_CUSTOM

## Routing
Explicit user instructions > detected frame intent > scene context > closest family > fallback. Generic neutral frame requests resolve to CLEAN_BORDER; cyber context to CYBER_HOLO; cyber+romance/love context to CYBER_LOVE_HOLO.

## Preservation
Frames are additive outer layers. Identity, faces, eyes, main subject, pose, clothing, background, camera perspective and existing important text remain protected unless explicitly changed.

## Cyber Love preset
FRAME_MODE_CYBER_LOVE_HOLO supports holographic border/UI, holographic barbed wire, love symbols, music/rose symbols and contextual signatures. Fraggle/Veluna exact signature is available when explicitly named: Fraggle [red holo heart] Veluna, names holo-neon blue, center heart red neon.
