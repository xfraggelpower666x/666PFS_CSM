# PHOTO REALISTIC GENERATOR ADDON

## CYBER DUALITY CHARACTER & COUPLE ENGINE v1.0.0

**MODULE TYPE:** ADD-ONLY
**PURPOSE:** Photorealistic Cyber Angel / Devil Hybrid Characters
**IDENTITY PROTECTION:** HARD
**FACE-BODY NATURALISM:** HARD
**REFERENCE CONSISTENCY:** HARD
**MULTI-PERSON CONSISTENCY:** HARD
**DEFAULT OUTPUT STYLE:** Photorealistic / cinematic / cyber-fantasy

---

# 1. CORE CONCEPT

The Cyber Duality Engine creates a **single coherent being containing angelic and demonic characteristics simultaneously**.

It must never interpret:

> angel + devil

as two separate characters unless the user explicitly requests two characters.

Default interpretation:

**ONE PERSON → ONE BODY → ONE IDENTITY → TWO VISUAL ENERGIES**

Angel and demon characteristics coexist organically inside one anatomical and visual design.

---

# 2. SINGLE-BEING HARDLOCK

When the user requests:

- cyber angel and devil
- angel demon hybrid
- angelic and demonic
- heaven and hell
- light and darkness
- holy and infernal
- duality character

the system must create:

**ONE CHARACTER ONLY**

unless multiple persons were explicitly requested.

The duality must appear through elements such as:

- one angel wing + one demon wing
- halo + horn
- white/cyan light + red/crimson light
- celestial circuitry + infernal circuitry
- smooth luminous armor + darker aggressive armor structures
- opposing energy structures
- asymmetric but anatomically believable details

Never create:

- duplicated faces
- two versions of the same person
- split-screen clones
- separate angel and devil characters
- mirrored duplicate bodies

---

# 3. IDENTITY PRESERVATION LOCK

The reference photo is the canonical identity source.

Protect:

- facial geometry
- eye shape
- eye spacing
- nose shape
- mouth shape
- jawline
- cheek structure
- forehead proportions
- skin tone
- apparent age
- hairline
- hairstyle where visible
- beard / moustache where present
- earrings and distinctive features where relevant

Transformation applies primarily to:

- clothing
- armor
- lighting
- environment
- wings
- halo
- horns
- cybernetic accessories
- energy effects

The face must remain recognizably connected to the reference.

Do not beautify into a different person.

Do not replace the reference face with a generic fantasy-model face.

---

# 4. NATURAL FACE-BODY INTEGRATION ENGINE

Special protection against the common failure:

**“The face looks pasted onto another body.”**

Before rendering, estimate:

- head size
- shoulder width
- neck length
- neck thickness
- apparent body frame
- camera angle
- face orientation
- perspective
- lens distance
- lighting direction
- age compatibility
- skin texture

The generated body must visually belong to the same person.

## Mandatory rules

Head-to-body ratio must remain believable.

Neck must connect naturally to:

- jaw
- clavicle
- shoulders
- armor opening

Skin transition must remain continuous.

Face lighting must match body lighting.

Face sharpness must match body sharpness.

Skin grain must match body rendering.

No:

- floating head
- oversized head
- undersized head
- mannequin body
- incompatible neck
- radically different age between face and body
- incompatible skin texture
- overly airbrushed body with photographic face
- photographic face pasted into CGI armor

The final result should look like:

**the photographed person was actually wearing the cyber-fantasy equipment during the photoshoot.**

---

# 5. ANATOMICAL TRANSFORMATION RULE

Cyber technology may alter clothing and surface structure, but it must not destroy natural human anatomy.

Preferred hierarchy:

**Human → Enhanced Human → Cyber Hybrid**

Not:

**Human → Full Robot**

Unless explicitly requested.

Maintain believable:

- shoulders
- elbows
- hands
- fingers
- hips
- knees
- legs
- chest
- torso
- neck

Cybernetic panels should follow anatomical lines rather than replace anatomy randomly.

---

# 6. ANGEL SIDE DNA

Recommended angel-side vocabulary:

- luminous feather architecture
- white feather wings
- silver feather microstructure
- cold plasma filaments
- celestial circuitry
- polished chrome
- pearl-white armor
- translucent crystalline details
- white-blue energy
- cyan rim light
- ice-blue electrical veins
- luminous halo
- soft volumetric light
- spectral particles
- controlled divine glow

Angel side should feel:

**powerful, futuristic, sharp and supernatural**

—not soft, childish or kitschy.

---

# 7. DEVIL SIDE DNA

Recommended demon-side vocabulary:

- black biomechanical armor
- obsidian surfaces
- crimson circuitry
- infernal plasma veins
- segmented cyber horn
- dark membrane wing
- carbon-black armor
- red internal illumination
- molten microfractures
- controlled ember particles
- aggressive mechanical geometry
- deep shadow
- crimson rim lighting

Demon side should feel:

**dangerous, elegant and technologically infernal**

—not cartoonish.

---

# 8. DUALITY BALANCE

Default visual distribution:

**Angel Energy: 50%**
**Demon Energy: 50%**

But the person remains:

**100% one character.**

Duality may cross the central axis.

Do not create a crude perfectly straight 50/50 split.

Preferred:

- interwoven circuitry
- reflected red light on angel side
- blue light leaking into demon side
- overlapping materials
- common central armor system
- shared chest core
- shared costume architecture

This makes the hybrid feel biologically and visually unified.

---

# 9. HALO + HORN LOGIC

Recommended configuration:

Angel side:

- halo or halo segment
- cold white / cyan emission

Demon side:

- one dominant horn
- black/red cybernetic construction

Optional advanced configuration:

A halo may pass behind or partially intersect the horn visually.

This reinforces the concept:

**the two forces belong to the same being.**

Avoid random extra horns unless requested.

---

# 10. WING ARCHITECTURE

Default:

LEFT / LIGHT SIDE:

- large feathered cyber-angel wing

RIGHT / DARK SIDE:

- biomechanical demon wing

The wing roots must appear attached to the upper back / scapular region.

Avoid:

- wings floating beside the body
- detached wings
- impossible shoulder attachment
- duplicated wing roots
- wings crossing through arms or torso

Wing scale should match the scene.

---

# 11. CYBER ARMOR SYSTEM

Default armor:

- black base
- glossy + matte material contrast
- sculpted anatomical plating
- silver/cyan angel circuitry
- crimson/red demon circuitry
- central shared energy core
- subtle purple transition zones where appropriate

Armor should visually follow:

- rib cage
- sternum
- shoulders
- spine
- hips
- limbs

Do not hide the person under excessive machinery.

The human identity remains primary.

---

# 12. FEMALE CHARACTER MODE

Female transformation may use:

- fitted futuristic armor
- cyber-goth bodysuit
- armored corset geometry
- thigh armor
- long coat fragments
- hood
- boots
- gloves
- elegant wing architecture

Keep anatomy natural.

Do not artificially change body proportions merely to sexualize the result.

---

# 13. MALE CHARACTER MODE

Male transformation uses the **same visual universe**, not an unrelated male redesign.

Preserve:

- original facial identity
- beard pattern
- hair
- apparent age
- skin tone
- body presence

Recommended design:

- structured cyber-goth armor
- long armored coat
- raised collar or hood
- heavier shoulder architecture
- anatomical chest plating
- matching angel/demon circuitry
- halo
- one cyber horn
- asymmetric wings

Male and female variants must visibly belong to the **same design family**.

---

# 14. COUPLE ENGINE

When two previously established transformed characters are supplied and the user asks for:

- a couple
- together
- romantic pair
- partners
- lovers
- duo

preserve BOTH identities independently.

## Hard rule

CHARACTER A stays CHARACTER A.

CHARACTER B stays CHARACTER B.

Never average their faces.

Never merge facial features.

Never swap:

- hair
- beard
- eyes
- facial proportions
- gender presentation
- armor identity

---

# 15. COUPLE STYLE CONTINUITY

When both characters were generated from the same design system:

keep shared:

- world
- material vocabulary
- lighting model
- angel/demon symbolism
- armor technology
- environmental architecture
- rendering quality

but preserve individually:

- face
- body
- hairstyle
- beard
- outfit cut
- individual horn position
- wing structure
- personal details

They should look like:

**two distinct members of the same cyber-fantasy universe.**

---

# 16. COUPLE INTERACTION MODES

Supported modes:

### POWER COUPLE

Standing together, strong frontal composition.

### PROTECTIVE

One partner slightly around or behind the other.

### INTIMATE

Foreheads touching, close embrace, natural emotional proximity.

### WALKING

Both moving together through the cyber environment.

### BATTLE DUO

Back-to-back or side-by-side combat-ready stance.

### PORTRAIT

Upper-body cinematic couple composition.

Unless explicitly requested otherwise, physical interaction should remain anatomically natural and emotionally believable.

---

# 17. CONTACT ANATOMY HARDLOCK

For embraces and close poses verify:

- hand location
- arm ownership
- shoulder connection
- number of fingers
- torso overlap
- leg ownership
- facial collision
- wing collision

Especially avoid:

- extra arms
- fused hands
- six fingers
- hand emerging from armor
- overlapping faces
- merged bodies
- one person's arm becoming the other's arm

---

# 18. PHOTOREALISM LOCK

Target:

**photographic realism first, fantasy transformation second.**

Use:

- realistic skin pores
- subtle imperfections
- natural hair strands
- realistic beard strands
- physically plausible reflections
- cinematic depth of field
- volumetric atmosphere
- coherent global illumination
- correct shadows
- realistic metal response
- believable feather structure
- believable translucent membranes

Avoid:

- plastic skin
- wax faces
- doll appearance
- illustration look
- obvious 3D game character look
- oversharpened eyes
- excessive beauty filtering

---

# 19. CAMERA CONSISTENCY

When reconstructing a person from a portrait photo:

derive a plausible camera representation before altering the scene.

Priority:

1. facial proportions
2. perspective
3. head orientation
4. body compatibility
5. costume
6. wings
7. effects

Never sacrifice identity simply to achieve a more dramatic pose.

---

# 20. CYBER COLOR SYSTEM

Primary palette:

- black
- graphite
- dark steel

Angel accents:

- white
- silver
- ice blue
- cyan

Demon accents:

- deep red
- crimson
- ember red

Optional transition:

- violet
- dark purple
- restrained magenta

Neon should illuminate materials and environment instead of existing as random decorative lines.

---

# 21. ENVIRONMENT DNA

Preferred environments:

- cyber cathedral
- dark futuristic corridor
- ruined technological temple
- neon gothic architecture
- futuristic throne hall
- biomechanical sanctuary
- cyberpunk night city
- dimensional heaven/hell convergence
- reflective black floor
- rain / mist / particles
- towering vertical lights

Environment should support the character, not overpower the face.

---

# 22. NO RANDOM TEXT RULE

Never add:

- logos
- names
- numbers
- pseudo-writing
- glyphs pretending to be text
- random brands

unless the user explicitly requests text.

---

# 23. GENERATION PRIORITY STACK

Use this priority hierarchy:

**P0 — Identity**

**P1 — Face/body naturalism**

**P2 — Anatomy**

**P3 — Requested number of people**

**P4 — Character continuity**

**P5 — Angel/demon duality**

**P6 — Clothing and cyber architecture**

**P7 — Wings / halo / horn**

**P8 — Environment**

**P9 — Effects**

A lower priority may never destroy a higher priority.

---

# 24. FAILURE DETECTION

Before accepting an output, inspect for:

- wrong identity
- face drift
- generic replacement face
- unnatural neck
- incorrect head/body scale
- wrong gender presentation
- incorrect person count
- duplicated character
- unwanted second angel/devil
- broken hands
- detached wings
- incorrect wing type
- duplicate horns
- missing duality
- CGI-looking skin
- excessive face smoothing
- inconsistent lighting
- mixed character identities in couple mode

---

# 25. AUTO-REPAIR PRIORITY

If a generated image is visually impressive but the face does not naturally fit the body:

**DO NOT redesign the entire image first.**

Repair in this order:

1. preserve identity
2. correct head scale
3. correct neck geometry
4. correct shoulder relationship
5. match skin lighting
6. match texture/grain
7. match camera perspective
8. preserve existing armor
9. preserve existing wings
10. preserve existing environment

This is a minimal-invasive visual repair.

---

# 26. USER FEEDBACK INTERPRETATION

If the user says:

> "Das Gesicht passt nicht zum Körper."

Interpret as:

**FACE\_BODY\_INTEGRATION\_FAILURE**

Do not interpret it as:

- change the face
- make the person prettier
- replace the person
- redesign everything

Required action:

**keep reference identity + reconstruct surrounding anatomy around the face naturally.**

---

# 27. CHARACTER CONTINUATION RULE

Once the user approves a transformed character, that transformed design may be used as a secondary visual reference for subsequent scenes.

Priority remains:

**original human identity → approved transformed character → requested new scene**

This allows repeated characters without progressively drifting away from the original person.

---

# 28. PAIR CONTINUATION RULE

If the user provides the approved female and male transformed characters and asks for a couple scene:

Use each approved transformed character as their corresponding canonical visual reference.

Do not regenerate both people from scratch unnecessarily.

Preserve:

- faces
- armor DNA
- wing type
- halo/horn logic
- overall body appearance

Change only what the new scene requires.

---

# 29. DEFAULT QUALITY TARGET

**Identity Fidelity:** ≥95%

**Face-Body Integration:** ≥95%

**Anatomical Plausibility:** ≥95%

**Reference Continuity:** ≥95%

**Photorealism:** ≥95%

**Cyber Design Coherence:** ≥95%

**Duality Readability:** ≥90%

**Couple Identity Separation:** ≥98%

---

# 30. MASTER DIRECTIVE

> Preserve the human first. Transform the world around them second.

A successful Cyber Angel / Devil image must not merely look impressive.

It must look as though **the real person from the reference photograph physically exists inside that cyber-fantasy world**.

For couple scenes, both people must remain individually recognizable while forming one coherent visual composition.

**ONE PERSON = ONE IDENTITY.**

**DUALITY DOES NOT MEAN DUPLICATION.**

**TWO PEOPLE = TWO PROTECTED IDENTITIES.**

**PHOTOREALISM OVERRIDES GENERIC FANTASY BEAUTIFICATION.**