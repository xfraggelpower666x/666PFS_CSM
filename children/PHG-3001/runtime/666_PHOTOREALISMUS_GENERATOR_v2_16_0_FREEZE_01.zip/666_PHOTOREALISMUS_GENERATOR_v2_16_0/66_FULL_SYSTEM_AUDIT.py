#!/usr/bin/env python3
"""Run the complete v1.5.4 package, runtime, deep regression and drift audit."""
from pathlib import Path
import hashlib, json, py_compile, subprocess, sys
ROOT=Path(__file__).resolve().parent
errors=[]; results=[]
for path in sorted(ROOT.rglob("*.json")):
    try: json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc: errors.append(f"JSON_PARSE:{path.relative_to(ROOT)}:{exc}")
for path in sorted(ROOT.rglob("*.py")):
    if "__pycache__" in path.parts: continue
    try: py_compile.compile(str(path),doraise=True)
    except Exception as exc: errors.append(f"PY_COMPILE:{path.relative_to(ROOT)}:{exc}")
mirrors={"26_GENERATION_RUNTIME_STATE_SCHEMA.json":"ACTIVE/01_CANONICAL_STATE_MODEL.json","33_RUNTIME_ORCHESTRA_REGISTER.json":"ACTIVE/03_ORCHESTRA_REGISTER.json","34_RUNTIME_GUARD_REGISTER.json":"ACTIVE/04_GUARD_REGISTER.json","35_RUNTIME_EXECUTION_MATRIX.json":"ACTIVE/05_EXECUTION_MATRIX.json"}
for mirror,canonical in mirrors.items():
    if hashlib.sha256((ROOT/mirror).read_bytes()).hexdigest()!=hashlib.sha256((ROOT/canonical).read_bytes()).hexdigest(): errors.append(f"MIRROR_DRIFT:{mirror}:{canonical}")
commands=[[sys.executable,"ACTIVE/25_CANONICAL_RESOLVER.py"],[sys.executable,"44_VALIDATE_RUNTIME_REGISTRY.py"],[sys.executable,"ACTIVE/30_RUN_V154_ACCEPTANCE_TESTS.py"],[sys.executable,"ACTIVE/37_RUN_PHLF_EXTENSION_TESTS.py"],[sys.executable,"ACTIVE/39_RUN_FRAME_MODES_TESTS.py"],[sys.executable,"ACTIVE/41_RUN_ASPECT_RATIO_TESTS.py"],[sys.executable,"32_VERIFY_PACKAGE.py"]]
for command in commands:
    proc=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
    output=(proc.stdout+proc.stderr).strip(); results.append(output)
    if proc.returncode!=0: errors.append(f"COMMAND_FAIL:{' '.join(command)}:{output}")
if errors:
    print("FULL SYSTEM AUDIT = FAIL"); print("\n".join(errors)); sys.exit(1)
print("FULL SYSTEM AUDIT = PASS")
for result in results:
    if result: print(result)
