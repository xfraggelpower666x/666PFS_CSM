# LEAN PHOTOREAL RECONSTRUCTION PATCH v1.9.0

Removed excessive creative-prompt duplication and introduced a dedicated CGI/3D-to-photoreal reconstruction path.

## Removed from mandatory creative prompt
- duplicated IDENTITY_CORE_LOCK block
- unconditional FRAMELESS_STAGE1 block
- unconditional NO_UNAUTHORIZED_TEXT block
- oversized anatomy wording
- redundant environment/material blocks when not directly requested

## Added
- CGI_TO_PHOTOREAL_RECONSTRUCTION profile
- maximum four creative prompt blocks
- minimal identity anchor
- full visual reconstruction permission for skin, hair, anatomy, materials, light, depth and reflections
- post-result identity drift control instead of pre-generation overblocking
