# PHG-3001 v2.6.0 — REPAIR LEDGER

- Added ACTIVE/50_CYBER_DUALITY_ENGINE.py with semantic activation and explicit-multi override.
- Added ACTIVE/51_CYBER_DUALITY_REGISTRY.json.
- Added ACTIVE/52_RUN_CYBER_DUALITY_TESTS.py.
- Integrated a dedicated CYBER_DUALITY_CHARACTER_COUPLE prompt module.
- Added unconditional active duality directive after normal prompt-block budgeting so safety/identity constraints cannot be truncated by the compact module budget.
- Enforced ONE PERSON ONLY for non-multi duality intent.
- Enforced TWO PROTECTED IDENTITIES for explicit couple/two-person intent.
- Added FACE_BODY_INTEGRATION_REPAIR order preserving face identity before armor/wings/environment changes.
- Preserved existing Cyber Garden, preset, frame, aspect-ratio, PHLF and baseline behavior.
- External LYVRA mutation remains FALSE.

REPAIR_RESULT=IMPLEMENTED
