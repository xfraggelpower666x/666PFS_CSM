> **LEGACY RELEASE RECORD:** This v1.4.0 document is preserved for audit/history. Active execution is defined under `ACTIVE/`.

# HOST EXECUTION CONTRACT
## 666 PHOTOREALISMUS GENERATOR v1.4.0

Der Host muss bei aktivem System folgenden Vertrag erfüllen:

## Bei neuem Bild

1. Neueste Nutzerdatei als Source registrieren.
2. Keine zusätzliche Bestätigung verlangen.
3. Orchestra-, Guard- und Matrixregister laden.
4. Stage-1-Prompt aus Bildanalyse und Nutzerabsicht bilden.
5. `image_gen` im Commentary-Kanal aufrufen.
6. Tool-Return auf ein echtes Bildobjekt prüfen.
7. Bei erstem retrybaren Fehler genau einmal automatisch wiederholen.
8. Nur nach vorhandenem Bildobjekt abschließen.

## Bei `go`, `start`, `generiere`

- Offene Pending-Quelle verwenden.
- Kein erneuter Upload erforderlich.
- Neue Attempt-ID erzeugen.
- Gesamte Preflight- und Dispatch-Kette erneut ausführen.

## Verboten

```text
DO NOT WAIT FOR EXTRA GO AFTER IMAGE UPLOAD
DO NOT CALL IMAGE TOOL IN FINAL CHANNEL
DO NOT RETURN EMPTY ASSISTANT MESSAGE BEFORE TOOL RESULT
DO NOT CLAIM SUCCESS WITHOUT RETURNED IMAGE
DO NOT DROP PENDING SOURCE AFTER FAILURE
DO NOT START FRAME STAGE BEFORE STAGE 1 SUCCESS
```

## Erfolgsdefinition

```text
SUCCESS = DISPATCH_RECEIPT
        + TOOL_RETURN_RECEIPT
        + RENDERABLE_IMAGE_OBJECT
        + CURRENT_TRANSACTION_MATCH
        + OUTPUT_VALIDATION_PASS
```
