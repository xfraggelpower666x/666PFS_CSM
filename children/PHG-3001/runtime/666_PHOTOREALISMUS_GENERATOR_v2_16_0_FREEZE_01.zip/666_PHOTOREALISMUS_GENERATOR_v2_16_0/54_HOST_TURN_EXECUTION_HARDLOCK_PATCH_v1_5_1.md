# HOST TURN EXECUTION HARDLOCK PATCH v1.5.1

Implemented non-destructively on v1.5.0.

- Image-only upload triggers atomic source → prompt → preflight → commentary dispatch.
- `render`, `go`, `generiere`, `again`, `nochmal`, `erneut` are control triggers.
- Control triggers are never copied into image prompt content.
- `hardlock erstellen`, guard, orchestra, matrix and repair commands route to system maintenance and cannot become generated poster content.
- No status-only response before mandatory tool dispatch.
- No final response before image result.
- Successful image turn contains image only.
