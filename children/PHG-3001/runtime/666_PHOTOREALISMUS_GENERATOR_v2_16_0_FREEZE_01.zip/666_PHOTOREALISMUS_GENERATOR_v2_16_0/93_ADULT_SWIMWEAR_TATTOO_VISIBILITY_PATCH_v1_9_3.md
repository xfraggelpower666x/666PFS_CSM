# ADULT / SWIMWEAR / TATTOO VISIBILITY PATCH v1.9.3

Integrated a compact policy-aware normalization layer for non-explicit adult skin, swimwear and tattoo visibility.

## Core rules

- Visible skin is not sexual by default.
- Male bare torso is allowed for tattoos, swimming, heat, summer, sport and body-art visibility.
- Female subjects must use bikini, swimsuit, opaque bodywear, crop/bodywear, shorts, underwear or comparable coverage when skin visibility is relevant.
- Upper body and lower body use the same rule: non-explicit visibility is allowed when intimate areas remain covered.
- Kissing and embrace are romantic affection by default, not automatic sexual activity.
- Explicit sexual acts, exposed genitals and pornographic staging remain blocked.

## Integrated files

- ACTIVE/35_ADULT_SWIMWEAR_TATTOO_VISIBILITY_POLICY.py
- ACTIVE/33_CHARACTER_TRANSFORMATION_DIRECTOR.py
- ACTIVE/26_PROMPT_COMPILER.py
- ACTIVE/09_PROMPT_MODULE_REGISTRY.json
- ACTIVE/34_CREATIVE_RUNTIME_PROFILES.json
