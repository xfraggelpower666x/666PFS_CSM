# PHG-3001 v2.9.0 CYBER LOVE FRAME INTEGRATION

ADDON_ID=PRG-ADDON-CYBER-LOVE-FRAME-001
VERSION=1.0.0
MODE=ADD_ONLY
BASE_FRAME_MODE=FRAME_MODE_CYBER_LOVE_HOLO

## Added runtime
- ACTIVE/60_CYBER_LOVE_FRAME_ADDON.py
- ACTIVE/61_RUN_CYBER_LOVE_FRAME_TESTS.py
- ACTIVE/62_CYBER_LOVE_FRAME_REGISTRY.json

## Additive bindings
- ACTIVE/26_PROMPT_COMPILER.py
- ACTIVE/09_PROMPT_MODULE_REGISTRY.json
- ACTIVE/00_ACTIVE_MANIFEST.json

## Preserved
- all existing frame modes
- PRESET_09 dance family
- Cyber Morning IHC
- Cyber Garden
- Cyber Duality
- Realism Control
- identity/reference hierarchy
- external LYVRA state

## Runtime semantics
Explicit user instruction remains highest. The addon activates only for explicit or strict semantic cyber-love-frame intent. Default frame text is I LOVE YOU / ENDLESS only when the addon is active and the relevant user text slot is not explicitly overridden. Frame construction remains physical, photorealistic, 4-sided, outward-extension preferred, with 6–12% recommended occupancy and 15% normal maximum.
