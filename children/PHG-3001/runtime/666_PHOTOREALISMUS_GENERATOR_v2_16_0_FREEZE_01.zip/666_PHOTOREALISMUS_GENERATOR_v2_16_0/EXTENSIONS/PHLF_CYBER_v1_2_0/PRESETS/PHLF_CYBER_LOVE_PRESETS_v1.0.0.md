# PHLF-CYBER-LOVE PRESETS v1.0.0

## Visual DNA

- Neon Black
- Neon Pink
- Neon Purple
- Neon Blue
- Lightning
- Glowing music notes
- Massive neon-glass heart
- Barbed-wire heart frame
- Clearly adult embracing couple
- Optional neon city, rain, wet asphalt and reflections
- Optional text: `love you over all`

## 1. Neon Glass Embrace

```text
Create a photorealistic cyber-romantic image of two clearly adult consenting partners, both age 25 or older, embracing closely inside a massive glowing neon-glass heart.

Use neon black, pink, purple, and blue. Surround the heart with controlled lightning arcs, glowing music notes, and a barbed-wire heart frame.

Place them in a rainy futuristic neon city with wet asphalt and cinematic reflections.

Romantic, emotionally intense, and non-explicit.
```

## 2. Love You Over All Poster

```text
Create a photorealistic cyber-love poster with two clearly adult partners embracing inside a massive neon-glass heart wrapped by a barbed-wire heart frame.

Integrate glowing music notes and electric blue-violet lightning.

Render the text "love you over all" as readable real neon-glass tubing with coherent reflections and soft light spill.

Use a futuristic rainy city background.
```

## 3. Gentle Kiss in the Heart

```text
Create a photorealistic image of two clearly adult consenting partners sharing a gentle natural kiss inside a glowing pink-purple-blue neon-glass heart.

Add a barbed-wire heart outline, subtle music notes, electric arcs, mist, and a dark futuristic city background.

Preserve realistic facial contact, hands, anatomy, and emotional closeness.

Non-explicit.
```

## 4. Cyber-Love Framework Sheet

```text
Create a premium visual style-guide sheet for a cyber-love design system.

Display separate photorealistic reference sections for:
- neon-glass heart
- barbed-wire heart frame
- neon pink, purple, blue, and black palette
- lightning
- music notes
- embracing adult couple
- rainy neon-city background
- neon-glass text "love you over all"

Use clean hierarchy and readable labels.
```

## 5. Protective Heart

```text
Create a photorealistic cyber-love image where a massive neon-glass heart forms a protective luminous structure around two clearly adult partners embracing.

The barbed wire remains outside the heart as a protective boundary rather than touching the couple.

Use music-note light trails, violet-blue lightning, rain, mist, and wet city reflections.

Emotional, protective, and non-explicit.
```
