# PHLF-CYBER PRESETS v1.2.0

## 1. Cyber Streetwear Portrait

```text
Apply PHLF-CYBER v1.2.0.

Create a photorealistic portrait of a clearly adult woman, age 25 or older, wearing dark cyber streetwear with matte structured fabric, subtle reflective panels, a refined utility belt, and minimal metallic accessories.

Use sleek black hair with subtle violet-blue streaks, medium almond black-chrome nails, metallic eyeliner, and realistic skin texture.

Place her in a rainy neon alley with wet asphalt, cyan-magenta reflections, atmospheric mist, and a natural 50mm portrait perspective.

Non-explicit. No unrelated changes.
```

## 2. Cyber Man Pool Portrait

```text
Create a photorealistic lifestyle image of a clearly adult man, age 25 or older, standing beside a futuristic rooftop pool.

He wears ordinary opaque dark swimming trunks and no shirt, appropriate for the pool environment.

Use natural adult anatomy, realistic skin, body hair, subtle water droplets, believable fabric, neon-blue pool light, violet city reflections, and a distant skyline.

Non-explicit, natural, and context-appropriate.
```

## 3. Cyber Bikini Pool Fashion

```text
Create a professional photorealistic poolside fashion image of a clearly adult woman, age 25 or older.

She wears a normal opaque black cyber-inspired bikini with metallic violet trim and realistic garment construction.

Use sleek black hair, glossy black chrome nails, minimal rings, and subtle futuristic makeup.

Place her at a luxury rooftop pool with neon-blue and purple reflections, glass architecture, and cinematic night lighting.

No transparent exposure, pornographic posing, exaggerated anatomy, or unintended clothing displacement.
```

## 4. Cyber Tattoo Transformation

```text
Use the uploaded image as the locked base image.

Preserve the same person, face, apparent adult age, body proportions, pose, camera perspective, framing, and lighting.

Add fully healed cyber-organic blackwork tattoos to suitable visible skin, a refined dark-techwear outfit, subtle metallic accessories, and black chrome nails.

Place the subject in a realistic neon-lit industrial corridor only if a background change is explicitly requested.

Change only the named elements.
```

## 5. Techno Club Portrait

```text
Create a photorealistic portrait of a clearly adult person, age 25 or older, in an underground dark-techno club.

Use wearable black clubwear with technical fabric, subtle reflective seams, sleek hair, controlled cyber makeup, and realistic nails.

Use LED strips, haze, directional violet-blue light, and a natural cinematic camera perspective.

Fashion-oriented, mature, and non-explicit.
```

## 6. Cyber Couple Embrace

```text
Create a photorealistic image of two clearly adult consenting partners, both age 25 or older, embracing naturally in a rainy neon city at night.

Dress them in coordinated dark cyber streetwear.

Preserve natural hand placement, anatomically correct contact, individual facial identities, realistic clothing folds, wet pavement reflections, and cinematic blue-magenta light.

Romantic and non-explicit.
```

## 7. Cyber Couple Gentle Kiss

```text
Create a photorealistic image of two clearly adult consenting partners, both age 25 or older, sharing a gentle natural romantic kiss.

Use believable facial alignment, natural hand placement, elegant cyber fashion, soft rain, neon reflections, and atmospheric city light.

Emotionally intimate but non-explicit.
```

## 8. Cyber Beauty Close-up

```text
Create a photorealistic beauty close-up of a clearly adult woman, age 25 or older.

Use metallic eyeliner, glossy neutral lips, subtle holographic highlight, realistic skin pores, sleek dark hair, and black chrome nails near the face.

Use a soft violet-blue neon spill and a blurred cyber background.

Preserve facial identity and natural proportions.
```

## 9. Cyber Resort Couple

```text
Create a photorealistic lifestyle image of two clearly adult partners at a futuristic luxury resort.

Use elegant context-appropriate resortwear or opaque swimwear, subtle cyber design accents, relaxed body language, realistic water reflections, and refined neon architecture.

They may hold hands or embrace gently.

Non-explicit and natural.
```

## 10. Dark Cyber Full-Body Fashion

```text
Create a full-body photorealistic fashion image of a clearly adult person, age 25 or older.

Use a dark structured cyber outfit with matte fabric, metallic trims, realistic footwear, sleek hair, and refined nail design.

Place the subject in a glass-and-metal corridor with violet edge lighting.

Preserve correct full-body anatomy, feet, hands, proportions, and perspective.
```

## 11. Cyber Hair Redesign Edit

```text
Use the uploaded image as the locked base.

Change only the hairstyle and hair color.

Create a plausible sleek asymmetrical cyber hairstyle with black roots and controlled violet-blue accent streaks.

Preserve the same face, hairline, identity, age impression, body, pose, clothing, background, lighting, and camera perspective.

No other changes.
```

## 12. Cyber Nail Design Edit

```text
Use the uploaded image as the locked base.

Change only the visible fingernails to a realistic medium-length almond-shaped black chrome manicure with subtle violet edge accents.

Preserve hands, fingers, skin folds, jewelry, pose, identity, clothing, background, and lighting.

Correct finger count and anatomically accurate nails are mandatory.
```
