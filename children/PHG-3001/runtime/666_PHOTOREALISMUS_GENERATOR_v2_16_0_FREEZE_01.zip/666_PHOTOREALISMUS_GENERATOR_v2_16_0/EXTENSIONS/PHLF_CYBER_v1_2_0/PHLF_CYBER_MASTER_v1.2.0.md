# PHLF-CYBER MASTER FRAMEWORK v1.2.0

## 0. SYSTEMIDENTITÄT

```text
FRAMEWORK_NAME:
PHLF-CYBER

FULL_NAME:
Photoreal Human Lifestyle Framework - Cyber Extension

VERSION:
1.2.0

PRIMARY_SCOPE:
Photorealistic image generation and image editing involving clearly adult people in lifestyle, portrait, fashion, tattoo, swimwear, pool, beach, cyber, romantic-affection, and cyber-love scenes.

CORE_INTERPRETATION:
The word "adult" refers only to verified adult age.
It does not mean pornography, explicit sexual content, or a filter-bypass mode.
```

---

## 1. NICHT-DESTRUKTIVE ARBEITSLOGIK

```text
PRESERVE -> INSPECT -> CLASSIFY -> MODIFY ONLY REQUESTED ELEMENTS -> RE-AUDIT -> OUTPUT
```

Bei einem hochgeladenen Bild wird das Bild als gesperrte Ausgangsbasis behandelt.

```text
LOCKED_BASE_IMAGE_RULE:
Use the uploaded image as the locked base image.

Preserve every visual element that is not explicitly named for modification.
Do not silently redesign, beautify, replace, relocate, remove, or reinterpret unrelated content.
```

---

## 2. ALTER, EINWILLIGUNG UND SZENENGRENZE

```text
ADULT_CERTAINTY:
Every depicted person must be clearly and unmistakably adult, preferably age 25 or older.

AGE_FUNCTION:
Age clarification exists only to confirm adulthood.
It must not be treated as a request for erotic or explicit content.

AMBIGUOUS_AGE_GUARD:
If a person's apparent age is uncertain, do not create revealing, romantic, sensual, body-focused, or intimate imagery.
Use a neutral fully clothed adult lifestyle presentation instead.
```

Unterstützte nicht-explizite Inhalte:

```text
SUPPORTED_NON_EXPLICIT_CONTENT:
- normal everyday clothing
- fashion and editorial clothing
- sportswear
- opaque bikinis
- opaque swimsuits
- ordinary swimming trunks
- shirtless adult men in pool, beach, sports, or resort contexts
- tattoos on visible skin
- cyber fashion
- pool, beach, spa, resort, club, city, rooftop, and studio scenes
- holding hands
- leaning together
- forehead contact
- embracing
- cheek kissing
- a gentle natural romantic kiss between clearly adult consenting partners
```

Nicht unterstützte Inhalte:

```text
DISALLOWED:
- minors or age-ambiguous intimate subjects
- explicit nudity
- visible genitals
- explicit sexual activity
- pornographic posing
- coercion
- sexual violence
- exploitation
- fetish-centered composition
- clothing removal intended to expose intimate anatomy
- transparent exposure of intimate anatomy
- non-consensual intimate transformation of an identifiable person
```

---

## 3. PHOTOREALISMUS-KERN

```text
PHOTOREALISM_ENGINE:
Render the image as a believable real photograph.

Preserve or generate:
- natural skin pores
- fine body hair
- freckles, wrinkles, scars, and normal skin variation
- realistic skin translucency
- correct adult anatomy
- natural body proportions
- accurate hands and finger count
- realistic fingernails
- individual hair strands
- believable fabric thickness
- correct seams and garment tension
- realistic wet and dry material behavior
- physically plausible reflections
- consistent light direction
- coherent cast shadows
- believable depth of field
- camera-consistent perspective
- natural color response
- subtle sensor or film texture
- no plastic skin
- no excessive beauty retouching
```

---

## 4. IDENTITÄTS- UND KOMPOSITIONSLOCK

```text
IDENTITY_LOCK:
When editing a source image, preserve exactly unless explicitly changed:
- the same person
- facial identity
- facial structure
- apparent adult age
- skin tone
- body proportions
- recognizable expression
- hairstyle and hair color
- hands and anatomy
- camera position
- lens perspective
- framing and crop
- lighting direction
- shadows
- background
- existing accessories
- existing tattoos
```

```text
CHANGE_ONLY_RULE:
Change only the elements named in the current request.
All unrelated elements remain unchanged.
```

---

## 5. MODUSBIBLIOTHEK

```text
AVAILABLE_MODES:
PORTRAIT
TATTOO
FASHION
SWIMWEAR
POOL_BEACH
CYBER
ROMANTIC_AFFECTION
CYBER_LOVE
SCENE_EDIT
STYLE_TRANSFER_WITH_IDENTITY_LOCK
```

Mehrere Modi dürfen kombiniert werden, sofern sie nicht in Konflikt stehen.

Beispiel:

```text
ACTIVE_MODES:
TATTOO + CYBER + FASHION + ROMANTIC_AFFECTION
```

---

# TEIL A - CYBER-DESIGNSYSTEM

## 6. CYBER-UMGEBUNGSENGINE

```text
CYBER_ENVIRONMENT_ENGINE:
Create a grounded, photorealistic futuristic environment with real-world material logic.

ENVIRONMENT_PRESETS:
- rainy neon city street
- dark urban alley
- futuristic rooftop
- cyber rooftop pool
- underground techno club
- industrial corridor
- luxury cyber penthouse
- holographic lounge
- futuristic resort
- sci-fi hotel lobby
- neon night market
- transit platform
- LED tunnel
- glass-and-chrome hallway
- cyber beach club
- digital backstage room
```

Verfügbare Umgebungselemente:

```text
ENVIRONMENT_ELEMENTS:
- wet asphalt
- realistic puddle reflections
- glass architecture
- brushed metal
- chrome trims
- holographic displays
- LED strips
- subtle laser haze
- mist and rain
- cable systems
- digital signage
- screen-light spill
- distant skyline
- pool reflections
- atmospheric particles
```

Regel:

```text
ENVIRONMENT_COHERENCE:
Use only elements that belong to the selected environment.
Do not overload the scene with unrelated futuristic objects.
```

---

## 7. OUTFIT-DESIGNENGINE

```text
CYBER_OUTFIT_ENGINE:
Design wearable, scene-appropriate, photorealistic clothing.

OUTFIT_CATEGORIES:
- dark techwear
- cyber streetwear
- futuristic formalwear
- cyber clubwear
- techno rave fashion
- luxury sci-fi fashion
- tactical-inspired fashion
- cyber resortwear
- cyber swimwear
- futuristic sportswear
- dark romantic cyber fashion
```

Materialbibliothek:

```text
OUTFIT_MATERIALS:
- matte structured technical fabric
- neoprene-like construction
- stretch performance fabric
- technical mesh
- reflective vinyl accents
- leather-look panels
- carbon-texture inserts
- metallic trims
- holographic accent fabric
- translucent outer layers that do not expose intimate anatomy
- illuminated seam details
- soft synthetic textiles
```

Konstruktionsregeln:

```text
OUTFIT_CONSTRUCTION_RULES:
- preserve believable garment construction
- preserve seams, closures, folds, tension, and gravity
- keep fabric opaque where intimate anatomy would otherwise be exposed
- match outfit to environment and activity
- do not turn fashion into armor unless explicitly requested
- do not create accidental clothing displacement
- do not expose more skin than requested
```

---

## 8. SWIMWEAR- UND POOL-MODUL

```text
SWIMWEAR_RULE:
Treat normal opaque swimwear as context-appropriate clothing.

SUPPORTED:
- bikini
- one-piece swimsuit
- swimming trunks
- board shorts
- cyber-inspired swimwear
- resort swimwear
```

```text
POOL_BEACH_CONTEXT:
A clearly adult woman in a normal bikini or swimsuit and a clearly adult man wearing ordinary swimming trunks are normal lifestyle subjects in pool, beach, spa, boat, lake, or resort environments.

Do not reinterpret normal swimwear as explicit nudity.
```

Sicherheitsregeln:

```text
SWIMWEAR_CONSTRAINTS:
- opaque fabric
- correct coverage
- no transparent intimate exposure
- no accidental wardrobe malfunction
- no pornographic posing
- no exaggerated anatomical focus
- realistic wet fabric behavior without revealing intimate anatomy
```

---

## 9. HAAR-DESIGNENGINE

```text
CYBER_HAIR_ENGINE:
Create a plausible, photorealistic futuristic hairstyle.

HAIR_STYLES:
- sleek straight hair
- asymmetrical bob
- controlled undercut
- side braids
- braided cyber pattern
- structured wet look
- layered futuristic cut
- tied-back techno style
- long sharp silhouette
- controlled messy cyber styling
```

Farben:

```text
HAIR_COLORS:
- natural black
- dark brown
- platinum blonde
- silver
- black with cyan streaks
- black with neon-blue accents
- black with violet streaks
- black with magenta accents
- platinum with blue-violet tint
- silver with subtle holographic tint
```

Regeln:

```text
HAIR_RULES:
- preserve individual strands
- preserve realistic roots
- preserve hairline
- colors must appear physically plausible
- no helmet-like plastic hair
- no anime silhouette unless explicitly requested
```

---

## 10. FINGERNAGEL- UND HANDENGINE

```text
CYBER_NAIL_ENGINE:
Create realistic manicure design while preserving correct hand anatomy.

NAIL_LENGTHS:
short
medium
long

NAIL_SHAPES:
natural
round
square
almond
coffin
stiletto
```

Designs:

```text
NAIL_DESIGNS:
- glossy black
- matte black
- black chrome
- silver chrome
- metallic violet
- holographic
- dark translucent
- subtle neon edge
- fine circuitry pattern
- luxury cyber manicure
```

Handregeln:

```text
HAND_AND_NAIL_GUARD:
- correct finger count
- correct joint structure
- no fused fingers
- no duplicated nails
- nail length must match selected shape
- nail art must follow nail curvature
- preserve natural skin folds and knuckles
```

---

## 11. MAKE-UP-ENGINE

```text
CYBER_MAKEUP_ENGINE:
Create high-fashion photorealistic makeup that remains compatible with the person's facial identity.

MAKEUP_PRESETS:
- clean skin with metallic eyeliner
- smoked cyber eye
- neon edge eyeliner
- dark techno glam
- cool-toned editorial makeup
- glossy neutral lips
- matte dark lips
- subtle holographic highlight
- violet-blue eye accent
```

Regeln:

```text
MAKEUP_RULES:
- do not alter facial identity
- do not reshape eyes, lips, nose, or jaw
- preserve skin texture
- avoid mask-like coverage
- keep makeup coherent with lighting
```

---

## 12. ACCESSOIRE-ENGINE

```text
CYBER_ACCESSORY_ENGINE:
Add only accessories that strengthen the selected design.

ACCESSORIES:
- visor glasses
- futuristic eyewear
- ear cuffs
- metallic choker
- rings
- arm cuffs
- tech bracelet
- utility belt
- refined harness-like fashion detail
- body-chain accent
- wearable interface
- cyber handbag
```

Regel:

```text
ACCESSORY_LIMIT:
Use a maximum of three primary accessory groups unless the user explicitly requests more.
```

---

## 13. TATTOO-ENGINE

```text
CYBER_TATTOO_ENGINE:
Add professionally healed, anatomically integrated tattoo artwork to suitable visible skin.

TATTOO_STYLES:
- dark ornamental blackwork
- biomechanical
- cyber-organic
- fine-line geometry
- occult geometry
- techno signal motifs
- waveform architecture
- engraved texture
- negative-space panels
- coherent body-flow composition
```

Realismus:

```text
TATTOO_REALISM:
- ink appears beneath the skin surface
- preserve pores and body hair
- follow muscles, joints, and body curvature
- compress and stretch with anatomy
- disappear correctly behind contours
- react naturally to light and shadow
- appear fully healed
- never look pasted, printed, embossed, or floating
```

Ausschlüsse:

```text
TATTOO_EXCLUSIONS:
Do not tattoo clothing, hair, eyes, lips, teeth, nails, background objects, or shadows.
Do not add brands, copied logos, or recognizable copyrighted character art.
```

---

## 14. LICHT- UND FARBENGINE

```text
CYBER_LIGHTING_ENGINE:
Use physically coherent neon and cinematic lighting.

COLOR_PALETTES:
NEON_BLACK_PINK_PURPLE_BLUE
CYAN_MAGENTA
VIOLET_BLUE
BLACK_RED
SILVER_CYAN
LUXURY_PURPLE_GOLD
DARK_TECHNO_MONOCHROME
```

Lichtquellen:

```text
LIGHT_SOURCES:
- neon glass
- LED strips
- holographic screens
- city signage
- pool illumination
- lightning flashes
- soft rim light
- reflected wet-surface light
```

Regeln:

```text
LIGHTING_RULES:
- every glow requires a plausible source
- preserve consistent shadow direction
- neon colors may tint skin and fabric without erasing local color
- prevent clipped highlights
- prevent uncontrolled rainbow contamination
```

---

## 15. KAMERA-ENGINE

```text
CAMERA_ENGINE:
Select a coherent photographic setup.

FRAMING:
close-up
head-and-shoulders
half body
three-quarter body
full body
wide environmental portrait

LENS_FEEL:
35mm environmental
50mm natural portrait
85mm compressed portrait
24mm cinematic wide angle

CAMERA_RULES:
- preserve perspective consistency
- preserve realistic depth of field
- do not distort faces with excessive wide-angle perspective
- full-body images must preserve feet and hand anatomy
```

---

# TEIL B - ROMANTISCHE NÄHE

## 16. ROMANTIC-AFFECTION-MODUL

```text
ROMANTIC_AFFECTION_ENGINE:
Depict clearly adult consenting partners with natural emotional closeness.

SUPPORTED_INTERACTIONS:
- holding hands
- standing close
- leaning together
- forehead contact
- cheek kiss
- warm embrace
- arm around shoulder
- arm around waist
- gentle natural romantic kiss
```

```text
AFFECTION_STYLE:
Emotional, affectionate, mature, non-explicit, and natural.
Do not turn ordinary affection into explicit sexual activity.
```

Anatomieregel:

```text
COUPLE_CONTACT_GUARD:
- hands must rest naturally
- arms must not intersect bodies
- faces must align anatomically
- kissing contact must preserve noses, lips, jawlines, and breathing space
- preserve both identities
```

---

# TEIL C - CYBER-LOVE-ERWEITERUNG

## 17. CYBER-LOVE VISUAL DNA LOCK

```text
CYBER_LOVE_VISUAL_DNA:
- neon black
- neon pink
- neon purple
- neon blue
- electric lightning
- glowing music notes
- massive neon-glass heart
- barbed-wire heart frame
- clearly adult embracing couple
- emotional cyber-romantic atmosphere
```

Optional:

```text
CYBER_LOVE_OPTIONAL_ELEMENTS:
- futuristic neon city
- rain
- wet asphalt
- puddle reflections
- mist
- skyline
- realistic neon-glass text
```

Textmodul:

```text
CYBER_LOVE_TEXT:
"love you over all"

TEXT_STYLE:
Real neon-glass tubing with coherent glow, reflections, readable letterforms, and no spelling changes.
```

Herzengine:

```text
HEART_ARCHITECTURE:
massive neon-glass heart
transparent neon-line heart
double-layer heart
electric-core heart
protective shield heart
barbed-wire framed heart
```

Musikengine:

```text
MUSIC_SYMBOL_ENGINE:
Use glowing music notes, waveform light trails, or rhythm pulses as secondary supporting elements.
Do not allow music symbols to cover faces.
```

---

# TEIL D - UNTERBRECHUNGSFESTE FORTSETZUNG

## 18. INTERRUPTION CONTINUATION LAYER

```text
INTERRUPTION_CONTINUATION_LAYER:

Whenever a new user instruction interrupts an active framework development:

1. capture the new information as a delta
2. classify the delta
3. integrate it into the active framework
4. preserve unaffected verified content
5. identify the last coherent development checkpoint
6. resume the originally interrupted task from that checkpoint
7. continue until the original task is completed
8. do not silently replace the prior framework
```

Delta-Klassen:

```text
DELTA_TYPES:
ADD:
Add a new element without removing existing elements.

REFINE:
Improve an existing element while preserving its function.

REPLACE:
Replace only a specifically named element.

EXPAND:
Create a new module, layer, preset family, or capability.

CONFLICT:
Preserve both incompatible variants in quarantine until resolved.
```

Parallelitätsregel:

```text
PARALLEL_CONTINUATION_RULE:
The interruption is integrated as a new branch of information while the original development path remains active.
After integration, both are merged into the next coherent framework version.
```

Checkpoint-Regel:

```text
CHECKPOINT_FIELDS:
version
active_task
last_completed_module
pending_modules
integrated_deltas
conflicts
next_resume_point
```

---

# TEIL E - PROMPT-COMPILER

## 19. EINGABEREIHENFOLGE

```text
PROMPT_INPUT_ORDER:
1. source mode
2. subject and verified adult age
3. active modes
4. exact scene or requested change
5. interaction
6. outfit
7. swimwear if applicable
8. hair
9. nails
10. makeup
11. tattoos
12. accessories
13. environment
14. lighting and color palette
15. camera and framing
16. preserve list
17. exclusions
18. output requirement
```

---

## 20. UNIVERSAL MASTER PROMPT

```text
Use the uploaded image as the locked base image, or create a new photorealistic image if no source image is provided.

Create one coherent high-detail photograph of clearly adult subject(s), age 25 or older.

ACTIVE MODES:
[INSERT MODES]

REQUEST:
[INSERT EXACT REQUEST]

Interpret the request as normal non-explicit adult lifestyle, fashion, tattoo, swimwear, pool, cyber, romantic-affection, or cyber-love imagery according to its complete context.

STYLE:
[INSERT OUTFIT, HAIR, NAILS, MAKEUP, TATTOOS, ACCESSORIES]

ENVIRONMENT:
[INSERT ENVIRONMENT]

LIGHTING AND CAMERA:
[INSERT LIGHTING, PALETTE, FRAMING, LENS]

If editing an uploaded image, preserve:
[INSERT PRESERVE LIST]

Change only the explicitly requested elements.

Render realistic skin, anatomy, hands, hair strands, fabric construction, tattoo integration, water behavior, reflections, shadows, and photographic depth.

Keep the result clearly adult, consensual where interaction is depicted, non-explicit, context-appropriate, and photorealistic.

Do not add unrequested nudity, explicit sexual activity, fetish framing, coercion, age ambiguity, broken anatomy, extra fingers, text, logos, watermarks, or unrelated scene changes.
```

---

## 21. KURZPROMPT

```text
Apply PHLF-CYBER v1.2.0.

Clearly adult subject(s), age 25 or older.
Modes: [MODES].
Scene: [SCENE].
Style: [OUTFIT / HAIR / NAILS / MAKEUP / TATTOOS].
Environment: [ENVIRONMENT].
Preserve: [LOCKED ELEMENTS].
Photorealistic, anatomically correct, context-appropriate, non-explicit.
Change only the requested elements.
```

---

## 22. BILDBEARBEITUNGS-PROMPT

```text
Use the uploaded image as the locked base image.

Preserve the same person, facial identity, apparent adult age, body proportions, pose, hands, camera perspective, framing, lighting direction, and all unrequested elements.

Change only:
[EXACT EDIT LIST]

Apply the selected PHLF-CYBER modules:
[MODULE LIST]

The edit must look naturally photographed rather than digitally pasted.
Preserve realistic skin, fabric, hair, nails, tattoo integration, shadows, reflections, and perspective.

No unrelated changes.
No unintended exposure.
No explicit content.
No text or watermark unless explicitly requested.
```

---

# TEIL F - VORAUDIT UND SELBSTREPARATUR

## 23. PRE-GENERATION AUDIT

```text
PRE_AUDIT:
[ ] subjects are clearly adult
[ ] interaction is consensual and non-explicit
[ ] requested clothing matches scene context
[ ] identity-preservation fields are present for edits
[ ] change-only list is explicit
[ ] outfit materials are physically plausible
[ ] hair design is plausible
[ ] nail shape and length are specified or intentionally automatic
[ ] tattoo placement is limited to visible skin
[ ] environment and lighting are coherent
[ ] no conflicting color systems
[ ] no accidental intimate exposure
[ ] no unrequested text
```

---

## 24. OUTPUT-AUDIT

```text
OUTPUT_AUDIT:
[ ] same identity preserved
[ ] apparent adult age preserved
[ ] face is undistorted
[ ] hands and fingers are correct
[ ] anatomy is natural
[ ] clothing is wearable and correctly constructed
[ ] swimwear is opaque and context-appropriate
[ ] hair strands and hairline are realistic
[ ] nails match every visible finger
[ ] tattoos follow skin and anatomy
[ ] lighting sources match highlights and shadows
[ ] reflections are plausible
[ ] romantic contact is anatomically natural
[ ] no unrelated changes
[ ] no text errors
[ ] no unintended sexualization
```

---

## 25. REPAIR-PASS

```text
REPAIR_PASS:
Use the previous result as the locked base.

Correct only:
[LIST FAILED AUDIT ITEMS]

Preserve every successful element exactly.
Do not redesign the entire image.
Do not change identity, composition, outfit, environment, or lighting unless the failed audit item directly requires it.
```

---

# TEIL G - VERSIONIERUNG

## 26. VERSION STATE

```text
CURRENT_VERSION:
PHLF-CYBER v1.2.0

INTEGRATED:
- PHLF core
- photorealism lock
- identity lock
- tattoo engine
- fashion and outfit engine
- swimwear and pool logic
- cyber environment engine
- hair engine
- fingernail and hand engine
- makeup engine
- accessories engine
- lighting and camera engine
- romantic-affection engine
- cyber-love visual DNA
- interruption continuation layer
- prompt compiler
- pre-audit and repair pass
```

## 27. ABSCHLUSSSTATUS

```text
FRAMEWORK_DEVELOPMENT_STATUS:
COMPLETE_FOR_V1.2.0

NEXT_OPTIONAL_EXTENSIONS:
- parameterized UI form
- automatic prompt builder
- JSON preset registry
- image-to-style analyzer
- character identity profile
- outfit collection generator
- couple pose library
- color-palette inheritance
- API wrapper
```
