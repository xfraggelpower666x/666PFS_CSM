# CHANGELOG

## v1.2.0 - 2026-08-02

### Added
- vollständige Cyber-Umgebungsengine
- Outfit- und Materialengine
- Swimwear- und Poollogik
- Haar-Designengine
- Fingernagel- und Handengine
- Make-up-Engine
- Accessoire-Engine
- Tattoo-Engine
- Licht-, Farb- und Kameraengine
- Romantic-Affection-Modul
- Cyber-Love Visual DNA
- Interruption Continuation Layer
- Prompt-Compiler
- Pre-Audit, Output-Audit und minimalinvasiver Repair-Pass
- Preset-Bibliothek
- JSON-Eingabeschema

### Integrated interruption delta
Die Cyber-Love-Elemente wurden aufgenommen, ohne den ursprünglichen PHLF-CYBER-Ausbau abzubrechen:
- Neon-Glasherz
- Stacheldraht-Herzrahmen
- Musiknoten
- Blitze
- umarmtes erwachsenes Paar
- futuristische Neon-City
- Regen und nasser Asphalt
- Schriftzug `love you over all`

### Corrected workflow
Unterbrechungen führen nicht mehr zum Verlassen der ursprünglichen Entwicklungsaufgabe. Neue Informationen werden integriert; danach wird am letzten konsistenten Stand weitergeführt.

## v1.1.0
- Grundmodule für Cyber-Umgebung, Outfits, Haare, Nägel, Make-up, Accessoires und Tattoos konzipiert.

## v1.0.0
- PHLF-Kern für erwachsene, nicht-explizite Lifestyle-, Swimwear-, Tattoo- und romantische Szenen definiert.
