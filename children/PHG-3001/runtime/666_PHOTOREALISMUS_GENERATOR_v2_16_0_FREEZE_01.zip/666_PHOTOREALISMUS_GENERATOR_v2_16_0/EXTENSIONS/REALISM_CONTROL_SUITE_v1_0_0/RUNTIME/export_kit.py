#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json
try:
    from PIL import Image
except Exception:
    Image=None
ROOT=Path(__file__).resolve().parents[1]
REG=json.loads((ROOT/'REGISTRY'/'REALISM_CONTROL_REGISTRY.json').read_text(encoding='utf-8'))

def export_image(source, target_dir, profile='WEB_JPEG_2048'):
    if Image is None: raise RuntimeError('PILLOW_REQUIRED_FOR_EXPORT_KIT')
    src=Path(source); outdir=Path(target_dir)
    if not src.is_file(): raise FileNotFoundError(src)
    if profile not in REG['export_profiles']: raise ValueError('UNKNOWN_EXPORT_PROFILE:'+profile)
    cfg=REG['export_profiles'][profile]; outdir.mkdir(parents=True,exist_ok=True)
    img=Image.open(src).convert('RGB' if cfg['format']=='JPEG' else 'RGBA')
    if cfg.get('long_edge'):
        ratio=min(1.0,float(cfg['long_edge'])/max(img.size)); size=(max(1,round(img.width*ratio)),max(1,round(img.height*ratio)))
        if size!=img.size: img=img.resize(size,Image.Resampling.LANCZOS)
    elif cfg.get('width') and cfg.get('height'):
        # contain, no crop
        canvas=Image.new('RGB',(cfg['width'],cfg['height']),(0,0,0)); work=img.convert('RGB'); work.thumbnail((cfg['width'],cfg['height']),Image.Resampling.LANCZOS)
        x=(cfg['width']-work.width)//2; y=(cfg['height']-work.height)//2; canvas.paste(work,(x,y)); img=canvas
    ext='.jpg' if cfg['format']=='JPEG' else '.png'; out=outdir/(src.stem+'__'+profile+ext)
    if out.resolve()==src.resolve(): raise RuntimeError('ORIGINAL_OVERWRITE_FORBIDDEN')
    kw={'quality':cfg.get('quality',92),'optimize':True} if cfg['format']=='JPEG' else {'optimize':True}
    img.save(out,cfg['format'],**kw)
    return {'output':str(out),'profile':profile,'size':img.size,'original_untouched':True}
