#!/usr/bin/env python3
from __future__ import annotations

def build_reference_plan(*, identity=True, pose=True, outfit=True, composition=True, background=True, allowed_changes=None):
    allowed=set(allowed_changes or [])
    fields={'identity':identity,'pose':pose,'outfit':outfit,'composition':composition,'background':background}
    return {'locks':{k:('CHANGE_ALLOWED' if k in allowed else ('LOCK_MAX' if v else 'UNLOCKED')) for k,v in fields.items()},'comparison_method':'HOST_VISUAL_READBACK_REQUIRED','numeric_similarity_claim':'FORBIDDEN_WITHOUT_MEASUREMENT'}
