#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json

def build_series_lock(series_id:str, reference_ids:list[str], locked_attributes:list[str]|None=None)->dict:
    attrs=locked_attributes or ['identity','age_cues','facial_geometry','signature_hair','defining_marks','style_dna']
    refs=[str(x) for x in reference_ids if str(x).strip()]
    payload={'series_id':str(series_id),'reference_ids':refs,'locked_attributes':attrs,'mutation_policy':'EXPLICIT_FIELDS_ONLY'}
    payload['series_lock_hash']=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return payload
