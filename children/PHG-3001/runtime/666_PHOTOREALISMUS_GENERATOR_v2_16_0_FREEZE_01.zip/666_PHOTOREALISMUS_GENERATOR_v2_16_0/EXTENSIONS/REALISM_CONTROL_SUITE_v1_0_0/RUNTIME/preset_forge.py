#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json, re
ALLOWED={'name','description','lock_profile','modules','lighting','material_profiles','text_exactness','composition_policy','export_profile'}

def _id(name): return re.sub(r'[^A-Z0-9]+','_',name.upper()).strip('_')
def validate(p):
    if not isinstance(p,dict): raise ValueError('PRESET_NOT_OBJECT')
    extra=set(p)-ALLOWED
    if extra: raise ValueError('UNSUPPORTED_FIELDS:'+','.join(sorted(extra)))
    if not str(p.get('name','')).strip(): raise ValueError('PRESET_NAME_REQUIRED')
    return True

def save_preset(preset:dict, directory:str|Path)->Path:
    validate(preset); d=Path(directory); d.mkdir(parents=True,exist_ok=True)
    pid=_id(preset['name']); out=d/(pid+'.json')
    if out.exists(): raise FileExistsError('PRESET_EXISTS:'+str(out))
    payload={'preset_id':pid,'schema_version':'1.0.0',**preset}
    out.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return out
