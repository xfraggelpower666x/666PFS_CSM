#!/usr/bin/env python3
from __future__ import annotations
WEIGHTS={'identity':0.15,'photorealism':0.15,'anatomy':0.12,'composition':0.10,'lighting':0.08,'materials':0.08,'text':0.08,'reference_match':0.08,'series_consistency':0.08,'frame':0.04,'artifact_cleanup':0.04}

def audit_template(applicability=None):
    app=applicability or {}
    return {'status':'READBACK_PENDING','checks':{k:{'applicable':bool(app.get(k,True)),'score':None,'passed':None,'observation':None} for k in WEIGHTS},'note':'Scores and observations must come from actual host visual inspection; this module never invents them.'}

def evaluate(report:dict)->dict:
    checks=(report or {}).get('checks') or {}
    errors=[]; num=den=0.0; repairs=[]
    hard={'identity','anatomy','photorealism'}
    for k,w in WEIGHTS.items():
        c=checks.get(k)
        if not c: errors.append('MISSING:'+k); continue
        if not c.get('applicable',True): continue
        s=c.get('score'); p=c.get('passed'); obs=c.get('observation')
        if not isinstance(s,(int,float)) or not 0<=float(s)<=1: errors.append('INVALID_SCORE:'+k); continue
        if not isinstance(p,bool): errors.append('INVALID_PASS:'+k); continue
        if not isinstance(obs,str) or not obs.strip(): errors.append('MISSING_OBSERVATION:'+k); continue
        num+=w*float(s); den+=w
        if not p: repairs.append(k)
    score=(num/den) if den else 0.0
    hard_fail=[k for k in hard if checks.get(k,{}).get('applicable',True) and checks.get(k,{}).get('passed') is False]
    if errors: status='READBACK_INCOMPLETE'
    elif hard_fail or score<0.86: status='REPAIR_REQUIRED'
    else: status='PASS'
    return {'status':status,'weighted_score':round(score,4),'errors':errors,'repair_targets':repairs,'hard_failures':hard_fail,'verification':'HOST_OBSERVATION_BASED'}
