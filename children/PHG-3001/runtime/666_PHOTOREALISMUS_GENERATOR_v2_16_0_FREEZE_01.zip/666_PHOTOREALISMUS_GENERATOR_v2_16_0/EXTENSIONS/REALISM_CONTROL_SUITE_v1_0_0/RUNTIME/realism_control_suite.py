#!/usr/bin/env python3
"""666 Realism Control Suite v1.0.0 — additive orchestration layer.
Does not perform visual verification itself; host-observed evidence is required for audit claims.
"""
from __future__ import annotations
from pathlib import Path
import json, re, hashlib

ROOT=Path(__file__).resolve().parents[1]
REGISTRY=json.loads((ROOT/'REGISTRY'/'REALISM_CONTROL_REGISTRY.json').read_text(encoding='utf-8'))
PRESETS=json.loads((ROOT/'REGISTRY'/'REALISM_PRESET_REGISTRY.json').read_text(encoding='utf-8'))

def _n(v): return re.sub(r'\s+',' ',str(v or '').casefold()).strip()
def _has(text, terms):
    t=_n(text)
    return any(_n(x) in t for x in terms)
def _detect_preset(text):
    t=_n(text)
    for pid in PRESETS['presets']:
        if _n(pid.replace('_',' ')) in t or _n(pid) in t: return pid
    aliases={'portrait pro':'PORTRAIT_PRO','cyberpunk realism':'CYBERPUNK_REALISM','poster builder':'POSTER_BUILDER','consistency engine':'CONSISTENCY_ENGINE','reference match max':'REFERENCE_MATCH_MAX'}
    for a,p in aliases.items():
        if a in t:return p
    return None

def analyze(intent:str, source_traits:list[str]|None=None)->dict:
    text=(intent or '').strip(); traits=[str(x) for x in (source_traits or [])]
    if not text: raise ValueError('RIG_INTENT_EMPTY')
    combined=text+' '+' '.join(traits)
    preset_id=_detect_preset(text); preset=dict(PRESETS['presets'].get(preset_id,{})) if preset_id else {}
    selected=[]; bridges=[]; new=[]
    preset_modules=set(preset.get('modules',[]))
    for m in REGISTRY['modules']:
        hit=m['id'] in preset_modules or _has(combined,m.get('triggers',[]))
        if hit:
            selected.append(m['id'])
            if m['type'].startswith('BRIDGE') or m['type']=='NEW_BRIDGE': bridges.append({'module':m['id'],'maps_to':m.get('maps_to',[])})
            if m['type'].startswith('NEW'): new.append(m['id'])
    # Existing host capabilities are not duplicated into prompt unless explicitly requested.
    if _has(combined,['reference image','reference photo','referenzbild','referenzfoto','same image','source image']):
        for mid in ['RIG-02-IDENTITY_GUARD','RIG-08-COMPOSITION_GUARD','RIG-10-REFERENCE_MATCH']:
            if mid not in selected:selected.append(mid)
    if _has(combined,['series','image series','bildserie','multiple images','mehrere bilder']):
        if 'RIG-09-MULTI_IMAGE_CONSISTENCY' not in selected:selected.append('RIG-09-MULTI_IMAGE_CONSISTENCY')
    lighting=None
    lt=_n(combined)
    if 'neon' in lt or 'cyberpunk' in lt: lighting='CINEMATIC_NEON'
    elif 'studio' in lt: lighting='STUDIO_SOFT'
    elif 'low key' in lt or 'low-key' in lt: lighting='LOW_KEY_DRAMATIC'
    elif 'rim light' in lt or 'back light' in lt: lighting='RIM_SEPARATION'
    elif 'natural light' in lt or 'documentary' in lt: lighting='NATURAL_DOCUMENTARY'
    if preset.get('lighting'): lighting=preset['lighting']
    material=[]
    if _has(combined,['skin','haut']): material.append('HUMAN_SKIN')
    if _has(combined,['metal','metall','armor','rüstung']): material.append('METAL_HARD_SURFACE')
    if _has(combined,['glass','glas','hologram']): material.append('GLASS_OPTICS')
    if _has(combined,['fabric','cloth','clothing','stoff','kleidung']): material.append('FABRIC_TEXTILES')
    lock_profile=preset.get('lock_profile') or ('REFERENCE_MAX' if 'RIG-10-REFERENCE_MATCH' in selected else 'BALANCED')
    export_profile=None
    for name in REGISTRY['export_profiles']:
        if _n(name.replace('_',' ')) in lt or _n(name) in lt: export_profile=name
    active=bool(selected or preset_id or lighting or material or export_profile)
    report={
      'addon_id':REGISTRY['addon_id'],'version':REGISTRY['version'],'active':active,'preset_id':preset_id,
      'selected_modules':selected,'bridges':bridges,'new_modules':new,'lock_profile':lock_profile if active else None,
      'locks':dict(REGISTRY['lock_profiles'].get(lock_profile,{})) if active else {},
      'lighting_preset':lighting,'lighting_directive':REGISTRY['lighting_presets'].get(lighting) if lighting else None,
      'material_profiles':material,'material_directives':[REGISTRY['material_profiles'][m] for m in material],
      'multi_image_consistency':{'active':'RIG-09-MULTI_IMAGE_CONSISTENCY' in selected,'identity_anchor':'IMMUTABLE_PER_SERIES','style_anchor':'STABLE_UNLESS_EXPLICIT_OVERRIDE','scene_anchor':'PRESERVE_WHEN_REQUESTED'},
      'reference_match':{'active':'RIG-10-REFERENCE_MATCH' in selected,'method':'ATTRIBUTE_LOCK_PLAN_PLUS_HOST_VISUAL_READBACK','no_fake_similarity_score':True},
      'auto_audit':{'active':'RIG-11-AUTO_AUDIT_PLUS' in selected,'requires_host_observations':True},
      'preset_forge':{'active':'RIG-12-PRESET_FORGE' in selected,'explicit_user_override_wins':True},
      'export_profile':export_profile,
      'original_intent_hash':hashlib.sha256(text.encode()).hexdigest()
    }
    return report

def compact_directive(report:dict)->str:
    if not report.get('active'): return ''
    bits=[]
    ids=set(report.get('selected_modules',[]))
    # Host-core deduplication: a lone photorealism bridge adds no new instruction
    # because CORE_PHOTOREALISM already enforces the same anti-CGI behavior.
    # Keep the report active for routing/audit, but emit no redundant prompt block.
    if ids == {'RIG-01-PHOTOREALISM_LOCK'} and not report.get('lighting_directive') and not report.get('material_directives'):
        return ''
    if 'RIG-09-MULTI_IMAGE_CONSISTENCY' in ids:
        bits.append('For a multi-image series, keep the same character identity anchors, age cues, facial geometry, signature hair/features and requested style DNA stable across every image; change only explicitly variable scene attributes.')
    if 'RIG-10-REFERENCE_MATCH' in ids:
        bits.append('REFERENCE_MATCH=MAX: prioritize the supplied reference over generic beautification; preserve identity, pose, outfit, camera relationship, crop and background whenever those fields were not explicitly changed.')
    if report.get('lighting_directive'):
        bits.append('LIGHTING_LAB: '+report['lighting_directive']+'.')
    if report.get('material_directives'):
        bits.append('MATERIAL_REALISM_PLUS: '+'; '.join(report['material_directives'])+'.')
    if 'RIG-07-TEXT_RENDER_CONTROL' in ids:
        bits.append('TEXT_RENDER_CONTROL: visible requested wording is immutable content; no spelling changes, paraphrase, invented text or symbol-to-word substitution; keep text inside safe readable zones.')
    if 'RIG-08-COMPOSITION_GUARD' in ids:
        bits.append('COMPOSITION_GUARD: protect face, eyes, hands, defining tattoos and primary interaction zones from crop, text, frame and decorative occlusion.')
    if 'RIG-04-HANDS_ANATOMY_REPAIR' in ids:
        bits.append('HANDS_ANATOMY_REPAIR: prioritize correct finger count, joint direction, grasp/contact mechanics, limb continuity and physically plausible weight bearing.')
    if 'RIG-01-PHOTOREALISM_LOCK' in ids:
        bits.append('PHOTOREALISM_LOCK: no plastic skin, game-render sheen, illustration drift or synthetic beauty-filter smoothing.')
    return ' '.join(bits)
