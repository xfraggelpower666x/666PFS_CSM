from pathlib import Path
import importlib.util, tempfile, json, sys
R=Path(__file__).resolve().parents[1]/'RUNTIME'
def load(n):
 p=R/(n+'.py'); s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
suite=load('realism_control_suite'); audit=load('auto_audit'); multi=load('multi_image_consistency'); ref=load('reference_match')
checks=[]
def ok(x,m): checks.append((bool(x),m))
r=suite.analyze('Use the same reference image. Cyberpunk realism with cinematic neon lighting, exact text and image series consistency.', ['human','skin','metal'])
ok(r['active'],'active'); ok(r['lighting_preset']=='CINEMATIC_NEON','lighting'); ok('RIG-09-MULTI_IMAGE_CONSISTENCY' in r['selected_modules'],'multi'); ok('RIG-10-REFERENCE_MATCH' in r['selected_modules'],'ref')
s=multi.build_series_lock('S1',['A','B']); ok(len(s['series_lock_hash'])==64,'hash')
p=ref.build_reference_plan(allowed_changes=['outfit']); ok(p['locks']['outfit']=='CHANGE_ALLOWED' and p['locks']['identity']=='LOCK_MAX','ref plan')
t=audit.audit_template({'series_consistency':False}); ok(t['status']=='READBACK_PENDING','audit pending')
fail=[m for v,m in checks if not v]
if fail: print('TESTS FAIL',fail); sys.exit(1)
print(f'ADDON UNIT TESTS = PASS ({len(checks)}/{len(checks)})')
