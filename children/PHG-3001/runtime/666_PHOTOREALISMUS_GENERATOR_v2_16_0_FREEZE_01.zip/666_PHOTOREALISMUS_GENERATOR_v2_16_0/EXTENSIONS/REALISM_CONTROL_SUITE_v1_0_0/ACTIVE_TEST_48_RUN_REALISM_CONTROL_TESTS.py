#!/usr/bin/env python3
from pathlib import Path
import importlib.util, json, sys
R=Path(__file__).resolve().parent

def load(n,p):
    s=importlib.util.spec_from_file_location(n,R/p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load('addon','47_REALISM_CONTROL_ADDON.py')
C=load('compiler','26_PROMPT_COMPILER.py')
checks=[]
def ok(v,msg): checks.append((bool(v),msg))
r=A.analyze('Keep the same reference image and person. Cyberpunk realism, cinematic neon lighting, exact text, image series consistency.')
ok(r['active'],'addon active')
ok('RIG-09-MULTI_IMAGE_CONSISTENCY' in r['selected_modules'],'series module')
ok(r['lighting_preset']=='CINEMATIC_NEON','lighting route')
c=C.compile_prompt('Use the same reference image. Cyberpunk realism with cinematic neon lighting and series consistency.',source_traits=['human','reference image'])
ok('realism_control_report' in c,'compiler report')
ok('[REALISM_CONTROL_ADDON]' in c['compiled_prompt'],'compiler directive')
fail=[m for v,m in checks if not v]
if fail:
 print('REALISM CONTROL ADDON TESTS = FAIL'); print('\n'.join(fail)); sys.exit(1)
print(f'REALISM CONTROL ADDON TESTS = PASS ({len(checks)}/{len(checks)})')
