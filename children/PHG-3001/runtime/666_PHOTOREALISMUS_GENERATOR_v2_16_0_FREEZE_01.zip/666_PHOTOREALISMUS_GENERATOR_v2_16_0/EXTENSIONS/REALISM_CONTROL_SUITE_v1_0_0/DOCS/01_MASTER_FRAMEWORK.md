# REALISM CONTROL SUITE — MASTER FRAMEWORK v1.0.0

## Zweck
Das Add-on erweitert den bestehenden Generator um eine gemeinsame Kontrollschicht für Realismus, Referenztreue, Serienkonsistenz, Licht, Materialien, Typografie, Layout, Audit, Presets und Export. Es ist kein Ersatz für den vorhandenen Prompt Compiler und kein zweites Generatorsystem.

## Routing-Prinzip
`USER INTENT → HOST CORE ROUTING → REALISM CONTROL ANALYSIS → COMPACT ADDON DIRECTIVE → IMAGE TOOL → HOST VISUAL READBACK → AUTO AUDIT+ → OPTIONAL TARGETED REPAIR`

## Erhaltene Host-Funktionen
Photorealism, Identity, Pose, Outfit, Anatomy, Materials, Frame Modes, Narrative Typography, Aspect Ratio, Preset Expansion und Visual QA werden weiter durch den bestehenden Host ausgeführt. Das Add-on bindet diese Funktionen nur stärker zusammen.

## Neue Fähigkeiten
- **Lighting Lab:** deterministische Lichtprofile ohne CGI-Drift.
- **Multi-Image Consistency:** Serien-Lock für wiederkehrende Figuren und Style-DNA.
- **Reference Match:** expliziter Attribut-Lock-Plan; keine erfundenen Ähnlichkeitswerte.
- **Auto Audit+:** erweiterter QA-Aggregator auf Basis echter Host-Beobachtungen.
- **Preset Forge:** sichere Custom-Presets ohne Überschreiben vorhandener Presets.
- **Export Kit:** optionale lokale JPG/PNG-Derivate; Original bleibt unangetastet.

## Konfliktregeln
1. Explizite User-Anweisung.
2. Source-/Reference-Locks.
3. Add-on-Preset.
4. Host-Default.
5. Keine stille Ersetzung.

## Reference-Match Lock
`identity → pose → outfit → composition → background` werden nur dort gelockt, wo der Nutzer keine Änderung verlangt. Damit kann beispielsweise ein Outfit geändert werden, während Person, Pose und Kamera stabil bleiben.

## Serienlogik
Ein Series Lock besitzt eine ID, Referenz-IDs, gelockte Attribute und einen SHA-256-Lock-Hash. Er ist eine Konsistenzbeschreibung, kein versteckter Agent und keine zusätzliche Authority.
