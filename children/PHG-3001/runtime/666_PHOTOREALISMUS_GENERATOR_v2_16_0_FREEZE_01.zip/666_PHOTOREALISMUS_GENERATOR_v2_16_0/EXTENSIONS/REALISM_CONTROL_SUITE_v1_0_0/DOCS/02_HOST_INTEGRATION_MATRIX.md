# HOST-INTEGRATIONSMATRIX

| Add-on-Modul | Status | Bestehender Host-Bezug | Add-on-Mehrwert |
|---|---|---|---|
| Photorealism Lock | BRIDGE+ | CORE_PHOTOREALISM | Anti-CGI-Verstärkung bei explizitem Bedarf |
| Identity Guard | BRIDGE+ | IDENTITY_CORE / IDENTITY_PRESERVATION | Reference-Max Lock-Profil |
| Pose & Outfit Lock | BRIDGE+ | POSE_DIRECTION / OUTFIT_TRANSFORMATION | gemeinsamer Änderungs-/Erhaltungsplan |
| Hands & Anatomy Repair | BRIDGE+ | ANATOMY_PRECISION / Visual QA | dedizierte Kontakt-/Fingerpriorität |
| Lighting Lab | NEW | EFFECT_STYLING | reproduzierbare Lichtprofile |
| Material Realism+ | BRIDGE+ | MATERIAL_REALISM / REFLECTION_CONTROL | materialspezifische Mikroregeln |
| Text Render Control | BRIDGE+ | TEXT/NARRATIVE Engines | unveränderlicher Textinhalt |
| Composition Guard | BRIDGE+ | CONTENT_AWARE_COMPOSITION | Protected Zones |
| Multi-Image Consistency | NEW | — | Series Lock |
| Reference Match | NEW/BRIDGE | Reference Preservation | Feld-Lock-Plan, Host-Readback |
| Auto Audit+ | NEW | Visual QA | breiter QA-Aggregator |
| Preset Forge | NEW | Preset Expansion | sichere Custom Presets |
| Frame & Poster Layer | BRIDGE+ | Frame Modes / Typography | Poster-Orchestrierung |
| Export Kit | NEW LOCAL | — | nicht-destruktive Derivate |
