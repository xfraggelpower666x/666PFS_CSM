# Custom Presets
Preset Forge schreibt neue Presets nur hier oder in einen explizit angegebenen Zielordner. Vorhandene Preset-Dateien werden nicht überschrieben.
