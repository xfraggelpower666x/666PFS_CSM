# COMPLETE REPAIR LEDGER — v1.5.2

## Reparierte Defekte

1. **Root-Validator-Pfadfehler**  
   `44_VALIDATE_RUNTIME_REGISTRY.py` suchte Runtime-Dateien im Root statt unter `ACTIVE/`. Der Root-Validator delegiert nun eindeutig an den kanonischen ACTIVE-Validator.

2. **Unvollständige ausführbare Guard-Abdeckung**  
   In v1.5.1 waren 55 Guards registriert, der Kernel prüfte praktisch nur einen kleinen kritischen Teil. v1.5.2 ergänzt ausführbare Prüfungen für Tool-Verfügbarkeit, Runtime-State, Dispatch-Idempotenz, Receipt-Vollständigkeit, Output-Idempotenz, Prompt-Leerstand und Ownership.

3. **Teilstring-Fehlklassifikation**  
   Trigger wurden per beliebigem Substring erkannt. Dadurch konnte `logo` als `go` oder `guardian` als `guard` interpretiert werden. Erkennung erfolgt jetzt nur über vollständige führende Phrasen.

4. **Kreative Folgeanweisung nach COMPLETE**  
   Eine Anweisung wie `make it more photorealistic` konnte mit erhaltener Quelle in `NO_HOST_ACTION` enden. Jetzt wird eine neue Transaktion mit derselben Quelle und aktualisiertem Intent erzeugt.

5. **Tool-Verfügbarkeit nur dokumentiert**  
   `GRD-017` war nicht praktisch im Kernel durchgesetzt. v1.5.2 blockiert Preflight und Dispatch bei `tool_available = false`.

6. **Unvollständige Dispatch-Receipts**  
   Hostaktionen enthalten nun Transaktion, Attempt, Source-ID, Source-Hash, Prompt-Hash, Dispatch-Key, Kanal und ein unveränderliches Receipt-Objekt.

7. **State-/Manifest-Drift**  
   Root-Mirror-Register wurden mit `ACTIVE/` synchronisiert. Ein Canonical Resolver und Manifest-Count-Prüfungen verhindern stilles Zurückfallen auf Legacy.

8. **Nicht atomare optionale Persistenz**  
   `ACTIVE/22_RUNTIME_STORE.py` ergänzt lock-geschützte atomare Zustandswrites und JSONL-Journal-/Receipt-Appends.

## Erhaltene Strukturen

- komplette historische Dateien und Legacy-Baselines;
- Bildkern, Identitäts-, Anatomie-, Welt- und Frame-Regeln;
- Storage-/Concurrency-Unterstruktur;
- bisherige State-Matrix und bestehende Ereignisse;
- System-only Backup-Grenze ohne erzeugte Bilder.
