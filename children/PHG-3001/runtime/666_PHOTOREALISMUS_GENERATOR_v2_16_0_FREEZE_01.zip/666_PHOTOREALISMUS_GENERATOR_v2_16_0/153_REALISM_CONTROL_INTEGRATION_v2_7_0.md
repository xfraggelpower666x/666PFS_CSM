# REALISM CONTROL INTEGRATION — PHG v2.7.0

Integrated addon: `666-RIG-ADDON-001 v1.0.0`

Routing:
`USER INTENT → PHG CORE → REALISM CONTROL ANALYSIS → COMPACT DIRECTIVE → IMAGE TOOL → VISUAL READBACK → OPTIONAL AUDIT/REPAIR`

New/strengthened capabilities:
- Lighting Lab
- Multi-Image Consistency
- Reference Match attribute-lock plan
- Auto Audit+ requiring real host observations
- Preset Forge with no silent overwrite
- Export Kit with original overwrite forbidden
- Material Realism+
- Text Render Control
- Composition Guard+

Conflict order remains:
1. explicit user instruction
2. source/reference locks
3. addon preset
4. host default
5. no silent replacement

Realism Control is an orchestration layer, not a replacement generator and not an authority over identity locks.
