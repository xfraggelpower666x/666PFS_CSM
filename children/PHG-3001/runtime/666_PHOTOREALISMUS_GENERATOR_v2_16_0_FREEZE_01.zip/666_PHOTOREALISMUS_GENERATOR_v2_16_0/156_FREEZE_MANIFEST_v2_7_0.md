# PHG-3001 v2.7.0 FREEZE MANIFEST

Freeze ID: `666-PRG-001-v2.7.0-REALISM-CONTROL-FREEZE-01`
Status target: `LOCAL_FROZEN_VERIFIED_REALISM_CONTROL_INTEGRATED`
Baseline: `2.6.0`
Addon: `666-RIG-ADDON-001 v1.0.0`
Policy: `CONTROLLED_ADDITIVE / NO_DOWNGRADE / NO_PARENT_MUTATION`
LYVRA: `EXTERNAL_UNCHANGED`

Final ZIP hash/size/entry count are established after packaging and stored in the external release/system backup record; package-internal inventory is verified by `08_PACKAGE_MANIFEST.json` + `09_SHA256SUMS.txt`.
