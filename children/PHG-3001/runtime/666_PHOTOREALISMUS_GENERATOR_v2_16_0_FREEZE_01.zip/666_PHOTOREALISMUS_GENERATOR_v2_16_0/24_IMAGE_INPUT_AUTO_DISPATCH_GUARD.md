# IMAGE INPUT AUTO-DISPATCH GUARD
## Version 1.0.0

**Binding:** `666 PHOTOREALISMUS GENERATOR v1.3.0`

## Zweck

Verhindert, dass ein neu hochgeladenes Bild nur registriert, aber nicht verarbeitet wird.

```text
SYSTEM_ACTIVE + NEW_USABLE_IMAGE = IMMEDIATE_STAGE_1_DISPATCH
IMAGE_ONLY_MESSAGE = EXECUTABLE_REQUEST
NO_REDUNDANT_CONFIRMATION = TRUE
```

## Zielauswahl

```text
ACTIVE_SOURCE_IMAGE = NEWEST_USER_SUPPLIED_IMAGE
OLDER_UNPROCESSED_SOURCE = SUPERSEDED
EXPLICIT_REFERENCE = OVERRIDE
```

## Pflichtaktionen

1. Bild als aktive Quelle registrieren.
2. Silent Source Analysis durchführen.
3. Stage-1-Locks aktivieren.
4. Bildwerkzeug unmittelbar aufrufen.
5. Erst nach zurückgegebenem Bild abschließen.

## Blockierte Fehlverhalten

```text
UPLOAD ACKNOWLEDGED BUT NOT DISPATCHED
WAIT FOR GO AFTER NEW IMAGE
EMPTY ASSISTANT RESPONSE
TEXT-ONLY SUCCESS
REUSE OF WRONG PREVIOUS IMAGE
```
