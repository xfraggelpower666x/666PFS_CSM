# Runtime State

This directory contains templates only in the frozen package. Live journals and receipts are created at runtime and must not be embedded in system backups.
