# RELEASE HANDOFF v1.6.0

Active runtime is upgraded to v1.6.0 with edit-directive expansion. Start from 00_START_HERE.md and execute ACTIVE/25_CANONICAL_RESOLVER.py, ACTIVE/12_VALIDATE_ACTIVE_RUNTIME.py and ACTIVE/30_RUN_V154_ACCEPTANCE_TESTS.py.
