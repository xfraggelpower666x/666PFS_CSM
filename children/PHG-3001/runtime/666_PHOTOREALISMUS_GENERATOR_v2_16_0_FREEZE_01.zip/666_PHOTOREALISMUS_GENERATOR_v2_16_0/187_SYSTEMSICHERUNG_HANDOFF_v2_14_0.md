# PHG v2.14.0 — Systemsicherung / Handoff

Status: FROZEN VERIFIED

## Primary change
PHG now has a guided interaction layer. `PHG SYSTEMSTART` and `PHG HELP` are the only PHG-prefixed interface triggers. Normal mode/image control remains prefix-free.

## Critical behavior
- Bare mode selection = guidance + copy-ready prompt proposals; no image dispatch.
- Mode + substantive creative instruction = normal creative flow.
- Uploaded image + bare mode = guidance first, preventing accidental frame-only or premature rendering.
- Explicit mode IDs and menu numbers resolve for every registered menu mode.
- Style/frame modes declare their limitations and recommend photorealism/preservation companions when appropriate.
- Exact text should be locked with spelling and position.

## Live-use repair encoded
`LOVE_FRAME_ELECTRIC_BLUE` no longer implies that a frame alone performs a full photorealistic rebuild. Guidance recommends `CORE_PHOTOREALISM + REALISM_CONTROL + IDENTITY_PRESERVATION + REFERENCE_PRESERVATION` when the user wants realistic central models while preserving the source composition.

## Verification
Deep acceptance 54/54 PASS; menu 11/11 PASS; guided interaction 30/30 PASS; static JSON/Python audit PASS; LYVRA external mutation FALSE.
