# EDIT DIRECTIVE EXPANSION PATCH v1.6.0

Integrated first-class prompt support for outfit changes, pose control, camera reframing and visible effects while preserving the existing hardlocked photorealism runtime.
