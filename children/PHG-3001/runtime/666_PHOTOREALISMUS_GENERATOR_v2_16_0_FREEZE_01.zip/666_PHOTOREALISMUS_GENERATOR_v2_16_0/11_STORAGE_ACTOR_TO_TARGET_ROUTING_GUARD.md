# STORAGE ACTOR, TARGET AND CREATED-OBJECT OWNER ROUTING GUARD
## Canonical Repair v1.2.1

Historical v1.2.0 actor-to-target routing is superseded. The active uploader is an ownership dimension, not merely a technical actor.

## Authorization formula

```text
ACTIVE_CONNECTOR == dirk.meereis@icloud.com
AND TARGET_ROOT_OWNER == dirk.meereis@icloud.com
AND CREATED_OBJECT_OWNER == dirk.meereis@icloud.com
AND CANONICAL_ROOT_ID MATCHES
AND LEASE_LOCK ACQUIRED
= REMOTE WRITE MAY CONTINUE
```

Any FragglePower/Gmail/Googlemail/LYVRA connector may perform read-only inspection only. It may not create folders, upload files, update pointers, copy artifacts, rename, move, delete, or mutate metadata for additional prompt systems.

## Post-write verification

Read back every created object. Verify owner, parents, name, size, modification time and expected content identity. If the object owner is not the approved iCloud identity:

```text
DRIVE_COMMIT = INVALID
ROLLBACK_REQUIRED = TRUE
LOCAL_BACKUP = RETAINED
```
