# STABILITY ACCEPTANCE TESTS
## 666 PHOTOREALISMUS GENERATOR v1.3.0

| Test | Erwartung | Status |
|---|---|---|
| T01: Bild ohne Text hochladen | automatische Stage-1-Dispatch | PASS |
| T02: Bild plus Anweisung | Bild und Anweisung gemeinsam verwenden | PASS |
| T03: Neues Bild nach vorherigem Output | neuestes Nutzerbild wird aktive Quelle | PASS |
| T04: `go` bei pending Quelle | unmittelbare Wiederaufnahme | PASS |
| T05: erster Tool-Return ohne Bild | genau ein automatischer Retry | PASS |
| T06: zweiter Tool-Return ohne Bild | ehrliche Fehlermeldung, Quelle bleibt pending | PASS |
| T07: erfolgreicher Output | kein automatisches Duplikat | PASS |
| T08: reine Textbestätigung ohne Bild | als ungültig blockiert | PASS |
| T09: leere Antwort vor Output | als ungültig blockiert | PASS |
| T10: Rahmenfrage vor Stage-1-Output | blockiert | PASS |
| T11: mehrere Bilder im Kontext | neuestes Nutzerbild ist Default | PASS |
| T12: expliziter Verweis auf älteres Bild | Nutzerverweis überschreibt Default | PASS |

```text
ACCEPTANCE_VERDICT = PASS
TESTS_PASSED = 12/12
```
