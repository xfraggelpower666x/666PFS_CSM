> **LEGACY RELEASE RECORD:** This v1.4.0 document is preserved for audit/history. Active execution is defined under `ACTIVE/`.

# TOOL INVOCATION CHANNEL AND RECEIPT GUARD
## Version 1.0.0 — Binding v1.4.0

## Hardlock

```text
IMAGE_GENERATION_TOOL = image_gen
ALLOWED_TOOL_CALL_CHANNEL = commentary
FORBIDDEN_TOOL_CALL_CHANNEL = final
FINAL_RESPONSE_BEFORE_TOOL_RESULT = FORBIDDEN
```

Ein Bildauftrag darf nicht durch einen Tool-Aufruf im Final-Kanal ausgeführt werden. Der Host muss den Bildwerkzeugaufruf im Commentary-Kanal senden.

## Dispatch-Receipt

Vor oder zusammen mit dem Dispatch werden intern registriert:

```text
transaction_id
attempt_id
source_image_id
user_intent_hash
orchestra_id = ORCH-050
tool_name = image_gen
channel = commentary
dispatch_status = SENT
```

Nach dem Tool-Return:

```text
return_received = TRUE | FALSE
returned_image_object = PRESENT | MISSING
output_transaction_match = TRUE | FALSE
```

## Fehlerklassifikation

```text
CALL_IN_FINAL_CHANNEL = CHANNEL_VIOLATION
NO_DISPATCH_RECEIPT = DISPATCH_NOT_PROVEN
NO_TOOL_RETURN = OUTPUT_MISSING
TEXT_ONLY_RETURN = OUTPUT_MISSING
UNRELATED_IMAGE_RETURN = OUTPUT_INVALID
```

Keiner dieser Zustände darf als Erfolg ausgegeben werden.
