# PHG v2.15.0 — Portable Parity Integration

Status: INTEGRATED

PHG now requires a canonical frozen system backup and a feature-equivalent American-English portable sister release for every completed release. The portable edition is a complete execution runtime, not a Lite edition. Both variants must remain on the same version and lifecycle head. Technical IDs remain stable and are not translated.

## Release completion gate
A PHG release is incomplete if portable parity is not verified. Required parity covers runtime, capabilities, menu mode IDs, interface triggers, prompt-template behavior, security guards, repair head, and freeze stage.
