# 666 PHOTOREALISMUS GENERATOR — v2.0.0

**Status:** CANONICAL / FROZEN / CRASH-RECOVERABLE PERSISTENCE / RESULT-PATH REPAIR / EDIT-DIRECTIVE EXPANSION / STABLE

## Verbindlicher Start

1. `ACTIVE/13_BOOT_CAPSULE.md` lesen.
2. `python3 ACTIVE/25_CANONICAL_RESOLVER.py` ausführen.
3. `python3 ACTIVE/12_VALIDATE_ACTIVE_RUNTIME.py` ausführen.
4. `python3 ACTIVE/30_RUN_V154_ACCEPTANCE_TESTS.py` ausführen.
5. Host-Turns ausschließlich über `ACTIVE/19_HOST_TURN_EXECUTOR.py` routen.
6. Reale Toolresultate ausschließlich über `ACTIVE/28_HOST_RESULT_EXECUTOR.py` verarbeiten.
7. State, Journal und Receipts gemeinsam über `ACTIVE/22_RUNTIME_STORE.py` sichern.
8. Vor Freeze oder Deployment `python3 66_FULL_SYSTEM_AUDIT.py` ausführen.
9. Für v2.2.0 zusätzlich `python3 ACTIVE/41_RUN_ASPECT_RATIO_TESTS.py` ausführen.

## Aktive Hardlocks

- Bildwerkzeug ausschließlich im Kanal `commentary`.
- Fehlende Source-ID, ungültiger SHA-256 oder nicht vertrauenswürdige Hash-Provenienz: kein Dispatch.
- Fehlende Tool-Verfügbarkeitsbestätigung: kein Dispatch.
- Kein Output-ID/Hash: kein Erfolg.
- Unvollständige Transaction-/Attempt-/Source-/Prompt-Ownership: kein Erfolg.
- Kein vollständiger Visual-QA-Bericht: kein Abschluss.
- Kein Retry oder Targeted Repair ohne erneute Prompt-Compilation.
- Exakte Marken-, Namen- und Textschreibweise bleibt erhalten.

- Outfit-, Wardrobe- und Accessory-Wechsel sind jetzt als eigene Prompt-Module integriert.
- Posen, Kamera-Reframing (Zoom In/Out, Close-up, Wide Shot) und sichtbare Effekte werden modular erkannt und gebunden.
- Kreative Wörter wie Guard, Matrix oder Orchestra sind nicht automatisch Systemwartung.
- Doppelte Dispatches, stale Outputs und doppelte Outputs werden blockiert.
- Receipts sind schema-valid und journalgebunden.
- Runtime-Persistenz nutzt Revision/CAS, gehashte WAL-Generationen, Before-Images, Readback und automatisches Rollback/Finalize.
- Stage 2 darf nur als Child-Transaction eines validierten Stage-1-Outputs starten.
- `LEGACY/` bleibt lesbarer Fallback und darf niemals automatisch aktiv werden.

## Host-Grenze

Das Paket erzeugt eine verbindliche `CALL_IMAGE_TOOL`-Hostaktion und verarbeitet anschließend reale Toolresultate. Nur die Hostumgebung kann `image_gen` tatsächlich aufrufen und reale visuelle QA-Beobachtungen liefern. Eine reine Textbestätigung ersetzt keinen dieser Schritte.


## Creative Hot Path v2.0.0

Bildbearbeitungen laufen über den Character Transformation Director. Audit, Freeze, Backup, Hashing und Remote-Routing bleiben außerhalb des kreativen Prompts.

## v2.0.0 Host Channel & Status Query Repair
- final-channel dispatch is blocked before tool invocation
- status queries never trigger generation
- empty returns expose a visible pending-retry reason


## v2.0.0 ADULT / SWIMWEAR / TATTOO VISIBILITY MODE

- Non-explicit adult skin visibility is treated as normal human reality, not as automatic sexual content.
- Upper body and lower body use the same logic: visibility may be appropriate for summer, pool, beach, sport, tattoo, swimwear and body-art contexts.
- Male bare torso may be used to show tattoos.
- Female subjects may use bikini, swimsuit, crop/bodywear or other opaque coverage suitable for the scene.
- All intimate areas must remain covered by opaque swimwear, underwear, shorts, bikini, bodysuit or comparable clothing.
- Kissing and embrace are romantic affection by default, not automatic sex.
- Explicit sexual acts, exposed genitals or pornographic staging remain blocked.

## Child Release v2.2.0 — Aspect Ratio & Broadcast Preset

- `ACTIVE/40_ASPECT_RATIO_ENGINE.py` erkennt explizite Seitenverhältnisse und setzt Benutzerwerte vor Defaults.
- Unterstützt mindestens `1:1`, `4:3`, `3:4`, `16:9` und `9:16`.
- `PRESET_LYVRA_CYBER_HOLO_BROADCAST_16_9` ist als reiner visueller Branding-Kontext integriert.
- Exakter Standardtext: `666SOUNDsDESIGn L.Y.V.R.A. WEBRADIO & BROADCASTER`.
- Standardausgabe des Presets: fünf Varianten.
- Das externe LYVRA-System wird nicht geladen oder verändert.


## Child Release v2.12.0 — Cyber Neon Symbolic Composition

- `PRG-CNSC-ADDON-001 v1.0.0` is integrated ADD_ONLY via `ACTIVE/69_CYBER_NEON_SYMBOLIC_COMPOSITION_ADDON.py`.
- Preserves source-symbol topology and interweave continuity.
- Adds continuous material-aware PINK→MAGENTA→VIOLET→ELECTRIC_BLUE→CYAN color fusion and physically grounded neon/laser energy.
- Optional `RELATIONAL_NEON_HEART` preset is registered.
- Existing CVICE/reference identity authority is reused; no duplicate visual authority.
