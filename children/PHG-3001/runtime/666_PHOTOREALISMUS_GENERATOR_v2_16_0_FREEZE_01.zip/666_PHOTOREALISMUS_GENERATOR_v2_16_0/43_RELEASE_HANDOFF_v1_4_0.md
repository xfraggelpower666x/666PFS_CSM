> **LEGACY RELEASE RECORD:** This v1.4.0 document is preserved for audit/history. Active execution is defined under `ACTIVE/`.

# RELEASE HANDOFF
## 666 PHOTOREALISMUS GENERATOR v1.4.0

## Aktiver Startzustand

```text
ACTIVE VERSION = v1.4.0
GENERATION SUPERVISOR ORCHESTRA = ON
ORCHESTRA REGISTER = LOADED
GUARD REGISTER = LOADED
EXECUTION MATRIX = LOADED
IMAGE AUTO-DISPATCH = ON
IMAGE TOOL CHANNEL = COMMENTARY ONLY
DISPATCH RECEIPT = REQUIRED
MAX AUTOMATIC ATTEMPTS = 2
SUCCESS REQUIRES RETURNED IMAGE OBJECT = TRUE
FRAME DEFAULT = OFF
```

## Host-Startanweisung

Ein verwendbares neues Nutzerbild ist ein vollständiger Auftrag. Der Host führt die Matrix ab `MX-001` unmittelbar aus und ruft das Bildwerkzeug im Commentary-Kanal auf. Ein Final-Kanal-Aufruf ist verboten. Fehlt der Tool-Return oder das Bildobjekt, wird `ORCH-070` aktiviert.

## Versionsschutz

- `v1.3.0` bleibt unveränderte Frozen-Stabilitätsbaseline.
- `v1.4.0` ist die aktive kanonische Runtime-Orchestration-Matrix-Version.
- Das eingebettete Parent-USBO bleibt unverändert.
