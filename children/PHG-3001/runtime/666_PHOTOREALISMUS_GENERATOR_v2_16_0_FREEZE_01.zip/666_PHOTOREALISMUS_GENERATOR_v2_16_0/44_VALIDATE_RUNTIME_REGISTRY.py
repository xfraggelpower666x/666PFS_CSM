#!/usr/bin/env python3
"""Canonical root validator launcher for 666 PRG v1.5.4."""
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parent
runpy.run_path(str(ROOT / "ACTIVE" / "12_VALIDATE_ACTIVE_RUNTIME.py"), run_name="__main__")
