# 03 — IDENTITY-BOUND PROPERTY REGISTRY

## Zweck

Definiert, welche visuellen Eigenschaften einer Person gehören und deshalb mit ihr mitwandern müssen.

## Registry

```text
NAME
TYPOGRAPHY_COLOR
SIGNATURE_COLOR
RELATIONAL_COLOR_ROLE
FRAME_REGION_COLOR
PERSON_SYMBOL
PERSON_NAMEPLATE
PERSON_HUD_COLOR
PERSON_LIGHT_ACCENT
OPTIONAL_ORNAMENT_COLOR
```

## Nicht identity-bound

```text
CENTER_CONNECTOR
GLOBAL_CAPTION
GLOBAL_BACKGROUND
GLOBAL_SCENE_EVENT
```

## Grundsatz

```text
PROPERTY_OWNER = PERSON_ID
NOT SCREEN_SIDE
```

Wenn eine Person die Seite wechselt, bleibt der Property-Owner gleich.
Nur die Bildschirmposition ändert sich.
