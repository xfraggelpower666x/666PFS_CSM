# 04 — DYNAMIC SIDE REMAPPING ENGINE

## Kernidee

Seitenwechsel einer Person löst automatisches Umrouting aller identity-bound Eigenschaften aus.

## Ablauf

```text
DETECT PERSON SIDE
→ READ PROPERTY OWNERSHIP
→ MAP PERSON TO CURRENT SIDE
→ MOVE NAME / COLOR / FRAME REGION / SYMBOL
→ VERIFY NO SWAP
→ OUTPUT REMAPPED LAYOUT
```

## Beispiel

```text
PREVIOUS
LEFT  = AMARIS = BLUE
RIGHT = AMARIN = PINK

CURRENT
LEFT  = AMARIN = PINK
RIGHT = AMARIS = BLUE
```

## Ergebnis

- Namen folgen den Personen
- Farben folgen den Personen
- Frame-Hälften folgen den Personen
- Symbole / Nameplates folgen den Personen

Die Serie bleibt identisch, obwohl die Bildseiten wechseln.
