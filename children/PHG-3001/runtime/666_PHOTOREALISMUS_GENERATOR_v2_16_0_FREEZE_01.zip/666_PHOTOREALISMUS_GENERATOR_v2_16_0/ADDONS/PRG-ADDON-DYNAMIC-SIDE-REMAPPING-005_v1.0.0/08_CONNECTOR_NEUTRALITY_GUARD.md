# 08 — CONNECTOR NEUTRALITY GUARD

## Zweck

Schützt neutrale Verbindungselemente zwischen zwei personengebundenen Namensfeldern.

## Erlaubte neutrale Connectoren

```text
&
and
♡
∞
EMBLEM
```

## Regeln

- Connector darf mittig stehen.
- Connector gehört keiner Person.
- Connector darf neutral oder dual-color sein.
- Connector darf die Zuordnung links/rechts nicht stören.

## Audit

```text
CONNECTOR_CENTERED
CONNECTOR_NEUTRAL
NO_PERSON_OWNERSHIP_CONFLICT
NO_NAME_OVERWRITE
```
