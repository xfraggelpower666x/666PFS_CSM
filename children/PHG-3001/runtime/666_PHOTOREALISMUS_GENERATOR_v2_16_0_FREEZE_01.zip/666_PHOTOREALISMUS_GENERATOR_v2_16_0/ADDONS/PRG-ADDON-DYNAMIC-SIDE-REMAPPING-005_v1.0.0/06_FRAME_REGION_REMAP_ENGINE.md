# 06 — FRAME REGION REMAP ENGINE

## Zweck

Remappt farbige Frame-Hälften oder Frame-Regionen dynamisch entsprechend der Personenposition.

## Regel

```text
FRAME_REGION_COLOR_OWNER = PERSON_ID
```

Nicht:

```text
LEFT_ALWAYS_BLUE
RIGHT_ALWAYS_MAGENTA
```

## Beispiel

Wenn Person B nach links wandert, folgt ihr farblicher Frame-Bereich mit.

## Geltungsbereiche

```text
LEFT_FRAME_SECTION
RIGHT_FRAME_SECTION
LOWER_NAMEPLATE_AREA
SIDE_CARTOUCHES
EDGE_GLOW
ORNAMENT_ACCENTS
```

## Ziel

Die Frame-Semantik soll die Identitätslogik bestätigen, nicht sabotieren.
