# 02 — PERSON SIDE STATE ENGINE

## Aufgabe

Ermittelt die aktuelle Seitenlage jeder Person innerhalb der konkreten Bildkomposition.

## Kernfelder

```text
PERSON_A_CURRENT_SIDE = LEFT | RIGHT | CENTER-LEAN-LEFT | CENTER-LEAN-RIGHT
PERSON_B_CURRENT_SIDE = LEFT | RIGHT | CENTER-LEAN-LEFT | CENTER-LEAN-RIGHT
SIDE_CONFIDENCE       = LOW | MEDIUM | HIGH
VISIBLE_DOMINANCE     = PRIMARY | SECONDARY
```

## Regel

Die Seitenlage wird pro Bild neu bewertet.
Sie ist keine feste Serienkonstante.

```text
PERSON_SIDE_CHANGE
≠
IDENTITY_CHANGE
```

## Hinweis

Die Seitenlage dient als Routing-Input für Namen, Farben, Frame-Hälften und andere identity-bound Eigenschaften.
