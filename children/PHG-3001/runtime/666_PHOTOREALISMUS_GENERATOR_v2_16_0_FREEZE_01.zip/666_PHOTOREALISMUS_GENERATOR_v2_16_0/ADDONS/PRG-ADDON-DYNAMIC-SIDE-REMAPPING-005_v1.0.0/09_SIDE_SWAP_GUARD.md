# 09 — SIDE SWAP GUARD

## Zweck

Behandelt Seitenwechsel sauber als normale Variation statt als Fehler oder neue Identität.

## Regel

```text
SIDE_SWAP
→ REMAP NAME
→ REMAP COLOR
→ REMAP FRAME REGION
→ PRESERVE IDENTITY
→ PRESERVE RELATIONSHIP
```

## Verbotene Fehlinterpretationen

```text
PERSON_MOVED_RIGHT
→ NEW_PERSON

PERSON_MOVED_LEFT
→ COLOR_STAYS_OLD_SIDE

SIDE_SWAP
→ NAME_STAYS_OLD_SIDE
```

## Guard

```text
SIDE_SWAP_IS_ALLOWED = TRUE
BROKEN_SIDE_REMAP    = FORBIDDEN
```
