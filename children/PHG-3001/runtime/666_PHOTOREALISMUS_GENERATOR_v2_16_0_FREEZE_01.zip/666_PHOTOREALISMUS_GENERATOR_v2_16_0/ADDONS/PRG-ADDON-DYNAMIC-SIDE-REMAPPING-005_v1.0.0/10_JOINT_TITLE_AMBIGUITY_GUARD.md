# 10 — JOINT TITLE AMBIGUITY GUARD

## Problem

Ein gemeinsamer dekorativer Titel kann die Personenzuordnung verwässern.

## Regel

```text
CENTER_ONLY_JOINT_TITLE = FORBIDDEN
UNLESS_EXPLICITLY_APPROVED
```

## Bevorzugtes Layout

```text
LEFT_PERSON_NAME
+ CENTER_CONNECTOR
+ RIGHT_PERSON_NAME
```

## Nur mit Ausnahme

Ein gemeinsamer dekorativer Titel ist nur zulässig, wenn zusätzlich klare Sideplates, Nameplates oder andere eindeutige Bindungsmarker vorhanden sind.
