# 13 — LAYOUT CASES AND EXCEPTIONS

## Standardfall

```text
PERSON LEFT  → NAME LEFT
PERSON RIGHT → NAME RIGHT
```

## Enger Couple-Crop

Bei engem Crop:
- kleinere Nameplates
- untere Ecken
- Side-Cartouches
- Frame-Kartuschen

## Überkreuzte Komposition

Wenn Körper sich stark kreuzen:
- sichtbare Seitenlage bewerten
- notfalls Nameplates näher am jeweiligen Subjekt verankern
- Symmetrie unterordnen

## Dominante Center-Pose

Wenn eine Person fast mittig steht:
- Haupt-Seitentendenz ermitteln
- Lesbarkeit priorisieren
- Ambiguität vermeiden
