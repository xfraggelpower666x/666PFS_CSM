# 11 — IDENTITY PROPERTY GRAPH

## Schema

```text
PERSON_ID
│
├── NAME
├── COLOR
├── TYPOGRAPHY COLOR
├── FRAME REGION COLOR
├── PERSON SYMBOL
├── LIGHT ACCENT
└── OPTIONAL HUD COLOR
     │
     ↓
CURRENT SCREEN SIDE
```

## Grundsatz

Die Datenrichtung verläuft von Person zur Position.

Nicht:

```text
SCREEN_SIDE
→ PERSON_PROPERTY
```

## Nutzen

Das verhindert, dass visuelle Serienmarker an der falschen Ebene verankert werden.
