# 99 — CHANGELOG

## v1.0.0

Initiales fünftes Addon-Pack.

Neu:

- Person Side State Engine
- Identity-Bound Property Registry
- Dynamic Side Remapping Engine
- Color Person Binding
- Frame Region Remap Engine
- Name Side Binding Enforcer
- Connector Neutrality Guard
- Side Swap Guard
- Joint Title Ambiguity Guard
- Identity Property Graph
- Property Consistency Audit
- Repair Pass
- Integration Contract
- Test Plan
- Status / Handoff
