# 07 — NAME SIDE BINDING ENFORCER

## Verstärkung der Hard-Lock-Regel

```text
NAME_SIDE_BINDING = MANDATORY
NAME_PERSON_MATCH = HARD_LOCK
NAME_SWAP         = FORBIDDEN
```

## Erweiterung durch DSR-005

Name-Side-Binding wird nicht nur geprüft, sondern dynamisch aus dem Person-Side-State abgeleitet.

## Logik

```text
IF PERSON_A_CURRENT_SIDE = LEFT
THEN NAME_A_POSITION = LEFT

IF PERSON_A_CURRENT_SIDE = RIGHT
THEN NAME_A_POSITION = RIGHT
```

## Joint-Title-Default

Ein ungetrennter gemeinsamer Schriftzug ohne eindeutige Personenseiten-Zuordnung ist standardmäßig nicht zulässig.
