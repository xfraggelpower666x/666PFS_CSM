# 12 — PROPERTY CONSISTENCY AUDIT

## Audit-Gates

### Gate A — Side Detection
- Personen-Seitenlage korrekt erkannt

### Gate B — Name Binding
- Name links bei linker Person
- Name rechts bei rechter Person

### Gate C — Color Binding
- Personenfarbe stimmt
- kein Side-Stickiness-Fehler

### Gate D — Frame Binding
- Frame-Regionen korrekt remapped
- keine starre Left/Right-Fehlbindung

### Gate E — Connector
- neutral
- mittig
- nicht zuordnungsstörend

### Gate F — Identity Graph Integrity
- owner bleibt Person
- Mapping zur Seite korrekt

## Ergebnisstatus

```text
PASS
PASS_WITH_MINOR_REPAIR
REPAIR_REQUIRED
HOLD
REJECT
```
