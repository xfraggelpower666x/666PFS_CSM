# 05 — COLOR PERSON BINDING

## Problem

Serienfarblogik darf nicht fälschlich an Bildschirmseiten gebunden werden.

## Harte Trennung

```text
COLOR_PERSON_BINDING
≠
COLOR_SIDE_BINDING
```

## Beispiel

```text
AMARIS = BLUE
AMARIN = MAGENTA
```

Wenn Amaris von links nach rechts wechselt, dann muss Blau mit Amaris mitwechseln.

## Regel

```text
PERSON_COLOR_ROLE = LOCK | CONTROLLED_LOCK
```

## Audit

Prüfen:

```text
PERSON_COLOR_MATCH
NO_SIDE_STICKINESS
NO_ACCIDENTAL_COLOR_SWAP
COLOR_SERIES_CONSISTENCY
```
