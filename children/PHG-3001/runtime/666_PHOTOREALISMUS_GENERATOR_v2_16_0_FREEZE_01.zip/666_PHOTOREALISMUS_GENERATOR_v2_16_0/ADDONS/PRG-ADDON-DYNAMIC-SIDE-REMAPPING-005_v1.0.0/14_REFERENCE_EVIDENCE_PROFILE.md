# 14 — REFERENCE EVIDENCE PROFILE

## Beobachtete zusätzliche Evidenz

Die auslösende Referenz zeigt eine Paar-Szene mit vertauschten Bildseiten im Vergleich zu früheren Varianten.

Beobachtet:

```text
LEFT  = AMARIN = MAGENTA
RIGHT = AMARIS = BLUE
CENTER CONNECTOR = and
FRAME SIDE COLORS = REMAPPED CORRECTLY
```

## Hauptbeobachtungen

1. Name-Side-Binding muss dynamisch sein.
2. Personenfarben gehören zur Person, nicht zur Seite.
3. Frame-Hälften müssen mit Person-Ownership remapped werden.
4. Seitenwechsel ist normale Serienvariation.
5. Der Connector bleibt neutral.

## Status

```text
SOURCE_TYPE = USER_PROVIDED_VISUAL_REFERENCE
LEARNING_STATE = OBSERVED_EVIDENCE_SET
CANONICAL = FALSE
PERSISTENT_LEARNING = FALSE
```
