# REFERENCE ORIGIN

Concept derived from the current conversation's cybernetic lemur and cybernetic llama sequence:
1. Original cyber lemur reference.
2. Original lower-detail cyber llama reference.
3. Llama realism/detail enhancement.
4. Lemur/llama causal hybrid.
5. Duo composition.
6. Lemur riding cyber llama.

The images themselves are not embedded in this addon. The addon captures reusable visual logic,
not copyrighted pixel copies or a fixed character identity.
