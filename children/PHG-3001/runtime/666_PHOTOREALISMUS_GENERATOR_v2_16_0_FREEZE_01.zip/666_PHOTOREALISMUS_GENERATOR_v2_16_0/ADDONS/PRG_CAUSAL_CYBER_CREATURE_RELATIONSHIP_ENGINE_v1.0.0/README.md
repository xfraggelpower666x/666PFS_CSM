# PRG Causal Cyber Creature Relationship Engine v1.0.0

DFRAMEWORK-compatible add-only package for the Photo Realistic Generator.

## Purpose
Adds causal cyber-creature rendering logic derived from the lemur/llama visual sequence:
detail-level transfer, duo continuity, causal hybridization, rider/mount composition,
shared cybernetic design DNA and organic/mechanical realism.

## Integration
This package is deliberately standalone.

- ADD_ONLY = TRUE
- CORE_MUTATION = NONE
- EXISTING_MODULE_REPLACEMENT = NONE
- REFERENCE_LOSS = FORBIDDEN

The parent generator remains authoritative. Install/import this package only through the
generator's existing addon route. Do not replace parent modules with files from this ZIP.

## Contents
- addon/manifest.json
- addon/PRG_CCRE_ENGINE.md
- presets/creature_relationship_presets.json
- guards/CCRE_GUARDS.md
- tests/audit_spec.json
- docs/CHANGELOG.md
- references/REFERENCE_ORIGIN.md
- SHA256SUMS.txt
