# DFRAMEWORK ADDON
ADDON_ID=PRG-CCRE-001
ADDON_NAME=PRG_CAUSAL_CYBER_CREATURE_RELATIONSHIP_ENGINE
VERSION=1.0.0
TARGET=PHOTO_REALISTIC_GENERATOR
MODE=ADD_ONLY
CORE_MUTATION=NONE
EXISTING_MODULE_REPLACEMENT=NONE
REFERENCE_LOSS=FORBIDDEN

## MASTER DIRECTIVE
Preserve each reference identity before transformation.
Understand anatomy, material logic, detail level, pose, relationship and world lighting before composition.
Transfer traits causally; never create a simple collage.
Photorealistic and physical coherence outrank spectacle.

## PIPELINE
1 REFERENCE_ROLE_CLASSIFICATION
2 IDENTITY_AND_ANATOMY_EXTRACTION
3 MATERIAL_AND_TECH_DNA_EXTRACTION
4 DETAIL_LEVEL_NORMALIZATION
5 RELATIONSHIP_MODE_ROUTING
6 PHYSICAL_CONTACT_AND_SCALE_SOLVER
7 WORLD_LIGHT_COUPLING
8 MICRODETAIL_AND_MATERIAL_REALISM
9 ANATOMY_GUARD
10 ANTI_COLLAGE_ANTI_MORPH_GUARD
11 FINAL_VISUAL_AUDIT

## MODES

### DETAIL_LEVEL_TRANSFER
Use when one supplied creature/reference has a stronger realism/detail level.
Preserve the target creature's species, silhouette, face, proportions and distinguishing features.
Transfer only quality characteristics:
- material complexity
- micro-mechanics density
- realistic fur integration
- cable routing discipline
- surface wear
- optical complexity
- physically plausible joints
- lighting response
Do not transform the target into the source species.

### CREATURE_DUO_CONTINUITY
Keep both creatures individually recognizable.
They share one physical environment and compatible technological design language.
Do not fuse anatomy unless HYBRID_FUSION is explicitly requested.
Enforce coherent scale, ground contact, shadows, reflections, atmosphere and camera perspective.

### CAUSAL_HYBRID_FUSION
Create one new organism from multiple creature references.
Do not use left/right collage splitting.
Resolve:
- one coherent skeleton
- one locomotion model
- one head architecture
- coherent limb count
- coherent fur/skin/armor transitions
- inherited signature traits from each source
The result must read as a naturally designed third species.

### RIDER_MOUNT_RELATIONSHIP
Preserve rider and mount as separate identities.
Validate:
- plausible rider-to-mount scale
- seat/support region
- center of gravity
- leg placement
- hand/rein/control contact when present
- no body penetration
- no floating rider
- believable load response
- unobstructed mount anatomy
Cybernetic interfaces may connect both subjects but must remain mechanically plausible.

### SHARED_TECH_DNA
References may share:
- cyan/electric-blue illumination
- controlled amber/orange accents
- gunmetal/chrome/black structures
- circular optical/mechanical nodes
- exposed cable systems
- layered armor
- internal luminous conduits
Sharing design DNA must not erase individual identity.

### ORGANIC_MECHANICAL_BOUNDARY
Mechanics must appear structurally integrated.
Fur may emerge between panels and around mechanical anchors.
Cables must have plausible origins and destinations.
Armor must follow body topology.
No random glued-on components.
No arbitrary floating cables.

### WORLD_LIGHT_COUPLING
All subjects inherit the same:
- key light
- rim light
- environmental color spill
- fog interaction
- wet-surface reflection logic
- shadow direction
- atmospheric depth
Neon sources must illuminate nearby materials rather than act as flat painted color.

## OUTPUT PRIORITY
1 PHOTOREALISTIC_COHERENCE
2 REFERENCE_IDENTITY
3 ANATOMICAL_COHERENCE
4 PHYSICAL_RELATIONSHIP
5 NATURAL_TECH_INTEGRATION
6 LIGHTING_AND_REFLECTION
7 ATMOSPHERE
8 MICRODETAIL
9 SPECTACLE

## FAIL CONDITIONS
Reject or repair output logic when:
- duplicate or missing limbs
- broken hoof/paw/hand geometry
- accidental body fusion in duo mode
- floating rider
- impossible saddle/contact geometry
- inconsistent scale
- disconnected cables
- collage seams
- random logos or unintended text
- incompatible lighting
- synthetic plastic fur
- source identity collapse
