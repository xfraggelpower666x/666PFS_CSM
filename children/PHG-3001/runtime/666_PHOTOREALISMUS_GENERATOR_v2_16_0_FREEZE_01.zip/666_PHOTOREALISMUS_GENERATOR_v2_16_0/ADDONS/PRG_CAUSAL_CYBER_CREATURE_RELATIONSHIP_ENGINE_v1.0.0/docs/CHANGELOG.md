# CHANGELOG
## 1.0.0
- Initial DFRAMEWORK addon package.
- Added detail-level transfer.
- Added duo continuity.
- Added causal hybrid fusion.
- Added rider/mount relationship solver specification.
- Added shared tech DNA and organic/mechanical boundary logic.
- Added 16 guards and 14 audit tests.
- No parent/core files modified.
