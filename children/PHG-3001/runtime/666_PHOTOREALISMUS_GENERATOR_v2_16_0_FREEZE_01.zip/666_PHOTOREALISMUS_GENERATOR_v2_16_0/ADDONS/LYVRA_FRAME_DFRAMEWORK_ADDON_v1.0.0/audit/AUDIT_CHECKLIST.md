# AUDIT CHECKLIST — LYVRA FRAME DFRAMEWORK ADDON v1.0.0

- [ ] Quellbild bleibt vollständig erkennbar
- [ ] Gesichter/Hände/Primärmotive werden nicht verdeckt
- [ ] Rahmenraum wird bevorzugt nach außen erweitert
- [ ] violette LYVRA-Signatur bleibt dominant
- [ ] Gold ist struktureller Akzent, nicht Hauptfarbe
- [ ] Rahmen wirkt physisch integriert statt aufgeklebt
- [ ] Reflektionen und Lichtspill sind plausibel
- [ ] reale Menschen bleiben fotorealistisch
- [ ] keine CGI-/Anime-/Illustrationskonvertierung realer Personen
- [ ] keine zufälligen Wörter oder Logos
- [ ] Text nur bei expliziter Aktivierung
- [ ] Dual-World-Mittelachse wirkt verbindend, nicht wie Collage-Naht
- [ ] gleiche Identität bleibt bei Dual-World-Nutzung erkennbar
- [ ] keine Parent-Core-Mutation
- [ ] keine bestehenden Presets gelöscht oder ersetzt
- [ ] Dublettenfunktionen werden gemappt statt dupliziert
- [ ] Fehler werden layer-lokal repariert und erneut auditiert
