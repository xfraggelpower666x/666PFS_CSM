# LYVRA FRAME · DUAL WORLD VISUAL DNA ADDON

VERSION=1.0.0
ADDON_ID=PRG-ADDON-LYVRA-FRAME-DUALWORLD-001
DFRAMEWORK_ADDON=TRUE
TARGET_SYSTEM=666 PHOTOREALISMUS GENERATOR
TARGET_SYSTEM_ID=666-PRG-001
TARGET_ENTRY_ID=PHG-3001
TYPE=Visual Frame + Dual-World Composition Addon
MODE=ADDITIVE_ONLY
CORE_REPLACEMENT=FORBIDDEN
EXISTING_PHOTOREALISM_RULES=PRESERVE
EXISTING_PRESETS=PRESERVE
HOST_VERSION_POLICY=LATEST_ACTIVE_AT_INTEGRATION
HOST_RUNTIME_COMPATIBILITY=NOT_VERIFIED_IN_THIS_PACKAGE
REFERENCE_ROLE=STYLE_AND_COMPOSITION_ONLY
SOURCE_CHARACTER_CANON_MUTATION=FORBIDDEN

## 1. Zweck

Dieses Addon extrahiert die visuelle DNA des im Chat entwickelten LYVRA-Rahmens und der deutsch/amerikanischen Dual-World-Gegenüberstellung und macht sie als eigenständige, nicht-destruktive Erweiterung für den 666 Photorealismus Generator nutzbar.

Es erweitert ausschließlich:

- Rahmenarchitektur
- ornamentale Cyber-Fantasy-Details
- violett/goldene LYVRA-Lichtsignatur
- Dual-World-Komposition
- zentrale Baum-/Wurzel-/Resonanzsymbolik
- Safe-Area- und Outward-Canvas-Logik
- optionale Charakter-Gegenüberstellung

Es ersetzt keine bestehenden Generatorregeln, keine vorhandenen Presets und keine bestehende Charakteridentität.

Grundsatz:

SOURCE IMAGE ERHALTEN → IDENTITÄT SCHÜTZEN → SAFE AREA BERECHNEN → CANVAS NACH AUSSEN ERWEITERN → LYVRA-RAHMEN BAUEN → LICHT PHYSISCH INTEGRIEREN → OPTIONAL DUAL-WORLD STRUKTURIEREN → TEXT PRÜFEN → PHOTOREALISMUS PRÜFEN.

## 2. Referenzautorität

Die mitgelieferte Referenzgrafik dient nur als Stil- und Kompositionsbeispiel.

RUNTIME_USER_REFERENCE = PRIMARY_AUTHORITY
ADDON_REFERENCE = FRAME_STYLE_SECONDARY
FACE_IDENTITY_FROM_ADDON_REFERENCE = FORBIDDEN
CHARACTER_IDENTITY_FROM_ADDON_REFERENCE = FORBIDDEN
SOURCE_IMAGE_PRESERVATION = MAXIMUM

Wenn eine reale Person oder ein anderes Ausgangsbild geliefert wird, besitzt dieses Ausgangsbild Vorrang vor der mitgelieferten LYVRA-Referenz.

## 3. LYVRA Frame DNA

### 3.1 Farbsignatur

PRIMARY_COLORS:
- deep black
- midnight violet
- electric purple
- ultraviolet glow
- dark chrome

SECONDARY_COLORS:
- restrained antique gold
- warm bronze-gold
- subtle magenta
- controlled electric blue

COLOR_RULE:
VIOLET_DOMINANT + GOLD_STRUCTURAL_ACCENT + BLACK_NEGATIVE_SPACE.

Gold darf die violette LYVRA-Signatur nicht verdrängen.

### 3.2 Rahmenmaterialien

FRAME_MATERIALS:
- black titanium
- dark chrome
- polished obsidian-like metal
- violet emissive glass
- fiber-optic light channels
- translucent crystal
- restrained antique-gold filigree

Materialien müssen fotografisch plausibel reagieren:
- contact shadows
- reflections
- specular response
- roughness variation
- believable glow spill
- local occlusion

### 3.3 Strukturelle Motive

FRAME_MOTIFS:
- elegant cyber-circuit linework
- fine botanical filigree
- root and branch geometry
- tree-of-resonance emblem
- small crystals
- geometric sigils
- subtle stars / micro particles
- restrained holographic nodes

MOTIF_PRIORITY:
1. FRAME_STRUCTURE
2. LYVRA_TREE_RESONANCE
3. CYBER_LINEWORK
4. CRYSTAL_ACCENTS
5. MICRO_DECORATION

Keine dekorative Überladung vor dem Hauptmotiv.

## 4. Rahmenaufbau

### Top Rail
- schmale, mehrschichtige technische Rahmenarchitektur
- violette Lichtkanäle
- dünne Goldfiligranlinien
- zentraler LYVRA-Baum-/Blatt-/Resonanzknoten
- optionale Titelzone, standardmäßig leer

### Side Rails
- vertikale Cyber-Ornamentik
- kleine Sigils und Kristalle
- keine zufälligen UI-Wörter
- keine breiten Seitenmodule, die das Bild zusammendrücken

### Bottom Rail
- Wurzel-/Resonanzlinien
- zentraler Kristall- oder Baumknoten
- dünne Energiekanäle
- optionales Statement-Feld, standardmäßig leer

### Corners
- symmetrische oder leicht organisch asymmetrische Eckmodule
- crystal + filigree + circuit fusion
- keine riesigen Eckornamente

## 5. Safe Area / Canvas Expansion

SOURCE_CROP=FORBIDDEN_BY_DEFAULT
OUTWARD_CANVAS_EXPANSION=PREFERRED
FRAME_SAFE_MARGIN=5_PERCENT_MINIMUM
SUBJECT_CLEAR_ZONE=REQUIRED
FACE_CLEAR_ZONE=STRICT
TEXT_CLEAR_ZONE=CONDITIONAL

Reihenfolge:
1. Quellbildgrenzen analysieren
2. Gesichter und Primärmotive erkennen
3. negativen Raum bestimmen
4. erforderlichen Rahmenraum außerhalb des Bildes anlegen
5. nur falls technisch unvermeidbar minimal innen überlappen
6. niemals Gesichter, Hände oder zentrale Symbolik verdecken

## 6. Photorealismus-Regel

Die Referenzgrafik darf stilistisch illustrativ wirken. Dieses Addon darf diesen Illustrationslook NICHT auf reale Personen übertragen.

HUMAN_PHOTOREALISM=STRICT
NATURAL_SKIN_TEXTURE=REQUIRED
REALISTIC_HAIR=REQUIRED
ANATOMY_STABILITY=REQUIRED
PHYSICAL_LIGHT_INTERACTION=REQUIRED
PLASTIC_SKIN=FORBIDDEN
GAME_CHARACTER_LOOK=FORBIDDEN
CGI_FACE=FORBIDDEN
ANIME_LOOK=FORBIDDEN
PAINTERLY_FACE=FORBIDDEN

Frame und Umgebung dürfen stark stilisiert sein, Menschen bleiben nach Parent-Photorealismusregeln realistisch.

## 7. Dual-World Composition Engine

OPTIONAL_MODULE=LYVRA_DUAL_WORLD_COMPOSITOR

Verwendbar für Gegenüberstellungen von zwei Varianten derselben Identität oder zwei klar verwandten visuellen Welten.

### Left World Default
ROLE=ANALYTICAL_CYBER_WORLD
MOOD=precise|focused|controlled|technical|cool|sophisticated
ENVIRONMENT=futuristic cyber interior + purple city night
LIGHTING=violet_neon|low_key|high_contrast
MATERIALS=black_chrome|glass|holographic_interfaces

### Right World Default
ROLE=WARM_WONDERGARDEN_WORLD
MOOD=warm|open|imaginative|playful|heartfelt
ENVIRONMENT=enchanted garden + warm lanterns + purple flora
LIGHTING=warm_amber|soft_violet|natural_depth
MATERIALS=leather|aged_metal|paper|flowers|crystal

### Shared Identity Rule
SAME_CHARACTER_FEEL=REQUIRED_WHEN_REQUESTED
WORLD_DIFFERENCE=HIGH
FACE_IDENTITY_DRIFT=FORBIDDEN_WHEN_REFERENCE_PERSON_PRESENT
POSE_COPY=OPTIONAL
OUTFIT_VARIATION=ONLY_IF_USER_OR_PRESET_ALLOWS

Dualität bedeutet zwei Welten, nicht zwei zufällige Personen.

## 8. Center Divider / Resonance Axis

CENTER_DIVIDER=OPTIONAL
DIVIDER_STYLE=elegant_thin_violet_gold
CENTER_EMBLEM=LYVRA_TREE_RESONANCE
DIVIDER_MUST_NOT_SPLIT_FACES=TRUE
DIVIDER_MUST_NOT_LOOK_LIKE_COLLAGE_SEAM=TRUE

Bei einer Dual-World-Szene soll die Mittelachse beide Welten verbinden, nicht auseinanderreißen.

## 9. Typography Engine

TEXT_MODE=OPTIONAL
DEFAULT_TEXT=NONE
TEXT_EXACTNESS=STRICT
UNREQUESTED_TEXT=FORBIDDEN
RANDOM_TEXT=FORBIDDEN
RANDOM_LOGOS=FORBIDDEN
GIBBERISH_UI_TEXT=FORBIDDEN

Erlaubte Slots:
TOP_CENTER_TITLE
LEFT_WORLD_LABEL
RIGHT_WORLD_LABEL
BOTTOM_CENTER_STATEMENT

Wenn Text nicht explizit vorgegeben ist, bleiben alle Slots leer.

## 10. Light Integration

FRAME_LIGHT_SPILL=ENABLED
FRAME_REFLECTIONS=ENABLED
CONTACT_LIGHT=REQUIRED
GLOBAL_GLOW=CONTROLLED
WHITE_CLIPPING=FORBIDDEN
COLOR_CORE_RETENTION=REQUIRED

Violette Frame-Lichter dürfen:
- Metallkanten treffen
- Glasflächen reflektieren
- Haare und Kleidung leicht rim-lighten
- Umgebung schwach färben

Sie dürfen keine unphysikalische Vollflächen-Tönung erzeugen.

## 11. Render Pipeline

INPUT_IMAGE
→ SOURCE_LOCK
→ IDENTITY_LOCK
→ SAFE_AREA_ANALYSIS
→ OUTWARD_CANVAS_EXPANSION
→ COMPOSITION_PROFILE_SELECT
→ FRAME_STRUCTURE_BUILD
→ LYVRA_MOTIF_LAYER
→ OPTIONAL_DUAL_WORLD_COMPOSITION
→ LIGHTING_INTEGRATION
→ REFLECTION_PASS
→ MICRODETAIL_PASS
→ TYPOGRAPHY_INSERT_IF_REQUESTED
→ TEXT_QA
→ PHOTOREALISM_QA
→ COLLISION_QA
→ OUTPUT

## 12. Minimal-invasive Repair

Bei QA-Fehlern:

AUDIT_FAIL → IDENTIFY_LAYER → REPAIR_ONLY_AFFECTED_LAYER → RE-AUDIT.

Nicht erlaubt:
- komplette Szene neu interpretieren, wenn nur Text fehlerhaft ist
- Gesicht neu bauen, wenn nur Rahmen kollidiert
- Quellbild croppen, wenn Canvas-Erweiterung genügt
- vorhandene Parent-Module ersetzen

## 13. Negativregeln

FORBIDDEN:
- random extra words
- random logos
- collage appearance
- thick center seam
- frame covering faces
- giant corner ornaments
- purple overexposure
- gold dominance
- flat pasted-on border
- impossible reflections
- unmotivated light sources
- excessive bloom
- fake plastic skin
- anime / illustration conversion of real people
- replacement of source identity
- silent outfit replacement
- source-image crop without necessity
- duplicated competing frame engines

## 14. Input Schema

SOURCE_IMAGE=<required_for_frame_application>
FRAME_PROFILE=<ORNATE|BALANCED|MINIMAL>
DUAL_WORLD=<true|false>
LEFT_WORLD_STYLE=<custom|ANALYTICAL_CYBER_WORLD>
RIGHT_WORLD_STYLE=<custom|WARM_WONDERGARDEN_WORLD>
CENTER_DIVIDER=<true|false>
CENTER_EMBLEM=<true|false>
TEXT_ENABLED=<true|false>
TOP_CENTER_TITLE=<optional>
LEFT_WORLD_LABEL=<optional>
RIGHT_WORLD_LABEL=<optional>
BOTTOM_CENTER_STATEMENT=<optional>
ASPECT_RATIO=<16:9|4:5|1:1|9:16|custom>
FRAME_DENSITY=<1-10>
GOLD_LEVEL=<1-10>
VIOLET_LEVEL=<1-10>
PHOTOREALISM=<1-10>
SOURCE_PRESERVATION=<high|strict|max>

## 15. Integration Contract

INTEGRATION_MODE=ADD_ONLY
CORE_REPLACEMENT=FORBIDDEN
EXISTING_MODULE_RENAME=FORBIDDEN
EXISTING_PROMPT_LOGIC_DELETE=FORBIDDEN
EXISTING_PRESET_DELETE=FORBIDDEN
HOST_AUTHORITY=PARENT_GENERATOR
HOOK_STRATEGY=ADAPTER

RECOMMENDED_HOOK:
POST_SOURCE_ANALYSIS → LYVRA_FRAME_ADDON → PRE_RENDER_COMPOSITION

Wenn der Host bereits gleichwertige Frame-, Safe-Area-, Text- oder Photorealismusmodule besitzt:
DUPLICATE_FUNCTION → MAP_EXISTING_CAPABILITY → DO_NOT_DUPLICATE.

## 16. Freeze Status

ADDON_ID=PRG-ADDON-LYVRA-FRAME-DUALWORLD-001
VERSION=1.0.0
FREEZE_SCOPE=STANDALONE_DFRAMEWORK_ADDON_PACKAGE
HOST_INTEGRATION=NOT_PERFORMED
HOST_WRITE=NOT_PERFORMED
HOST_COMPATIBILITY=NOT_RUNTIME_VERIFIED
READY_FOR_PARENT_FRAMEWORK_INTEGRATION=TRUE
