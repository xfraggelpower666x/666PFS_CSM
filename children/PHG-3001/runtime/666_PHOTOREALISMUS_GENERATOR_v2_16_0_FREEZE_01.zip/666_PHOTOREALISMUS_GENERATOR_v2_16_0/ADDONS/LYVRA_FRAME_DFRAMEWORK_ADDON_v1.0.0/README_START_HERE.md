# LYVRA FRAME DFRAMEWORK ADDON v1.0.0

Dieses ZIP ist ein eigenständiges, nicht-destruktives DFramework-Addon für den 666 Photorealismus Generator (SYSTEM_ID 666-PRG-001 / PHG-3001).

## Enthalten

- vollständige Addon-Definition
- LYVRA Purple/Gold Frame-DNA
- Dual-World-Kompositor
- Safe-Area / Outward-Canvas-Regeln
- strikte Photorealismus-Grenze für reale Personen
- drei Presets
- negative Regeln
- Integrationsvertrag
- Referenzbild aus der im Chat entwickelten LYVRA-Rahmenfassung
- Audit-Checkliste und Build-Receipt

## Wichtig

Das Paket führt selbst keine Systemintegration aus. Es ist `ADD_ONLY` und für kontrollierte Parent-Integration vorbereitet. Bestehende Generatorregeln und Presets bleiben unangetastet.

Die Referenzgrafik ist `STYLE_AND_COMPOSITION_ONLY`. Sie darf nicht als Gesichts- oder Personenidentitätsquelle verwendet werden.

## Presets

1. `PRG-PRESET-LYVRA-ORNATE-FRAME-001` — voller violett/goldener LYVRA-Rahmen
2. `PRG-PRESET-LYVRA-DUAL-WORLD-001` — deutsch/amerikanische Dual-World-Gegenüberstellung als allgemeine Kompositionslogik
3. `PRG-PRESET-LYVRA-MINIMAL-FRAME-001` — reduzierte LYVRA-Rahmenvariante

## Status

PACKAGE_BUILD=VERIFIED
ZIP_TEST=PASS
HOST_INTEGRATION=NOT_PERFORMED
HOST_COMPATIBILITY=NOT_RUNTIME_VERIFIED
READY_FOR_PARENT_FRAMEWORK_INTEGRATION=TRUE
