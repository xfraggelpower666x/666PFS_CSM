PHOTOREALISTIC CYBER NEON SYMBOLIC COMPOSITION ADDON v1.0.0

Standalone Add-on-Entwurf für einen bestehenden Photorealistic Generator.

Enthalten:
- vollständige Framework-MD
- Manifest
- SHA-256 Prüfsummen

WICHTIG:
Dieses Paket verändert keinen bestehenden Generator.
Eine echte Integration benötigt die aktuellen Host-Dateien bzw. das Host-Framework.
