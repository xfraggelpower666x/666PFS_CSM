# 666 PHOTOREALISM — Emotional Visual Meaning Addon v1.0.0

Framework addon for a photorealistic image-generation pipeline.

## Purpose
Transforms emotional or relational meaning into causally justified visual elements while preserving photorealistic rendering.

## Core rule
**NO SYMBOL WITHOUT SEMANTIC CAUSE.**

Every prominent symbolic element must be traceable to the input meaning. Decorative symbolism must never overpower physical plausibility, subject identity, anatomy, lighting, material realism, or scene continuity.

## Pipeline
1. Meaning extraction
2. Emotional relationship mapping
3. Visual metaphor selection
4. Physical-world translation
5. Photorealism constraints
6. Cinematic composition
7. Symbol-density control
8. Anti-kitsch / anti-random audit
9. Final prompt augmentation

## Integration
Treat this package as an additive framework layer. It does not require replacement of an existing generator core. Map the module outputs into the host generator's semantic/composition prompt stage.

Status: STANDALONE_ADDON / NON_DESTRUCTIVE
