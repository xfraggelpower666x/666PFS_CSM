# Text-in-Image Meaning Layer

When text is requested:
- preserve exact supplied wording unless explicitly asked to rewrite it
- make text subordinate to scene meaning, not a substitute for it
- reserve clean negative space for legibility
- maintain hierarchy between headline, emotional statement and visual focal point
- avoid covering faces, hands, relationship gestures, or the primary semantic motif

If exact typography cannot be guaranteed by the image model, keep the semantic scene independently understandable without the text.
