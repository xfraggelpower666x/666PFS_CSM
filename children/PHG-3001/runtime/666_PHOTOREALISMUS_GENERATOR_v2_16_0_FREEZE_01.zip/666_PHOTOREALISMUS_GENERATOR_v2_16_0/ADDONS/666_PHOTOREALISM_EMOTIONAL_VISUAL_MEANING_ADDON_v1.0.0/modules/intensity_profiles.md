# Intensity Profiles

## SUBTLE
Meaning primarily through pose, light, depth, weather and environment.
No explicit iconography unless requested.

## CINEMATIC
One recognizable metaphor plus realistic environmental reinforcement.

## DEEP_SYMBOLIC
Layered causal symbolism with strong cinematic composition. Physical plausibility remains mandatory.

## SURREAL_PHOTOREAL
Impossible or metaphoric phenomena are allowed, but rendered with realistic optics, materials, scale, lighting and environmental interaction.
