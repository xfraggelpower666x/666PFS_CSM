# Emotional Visual Meaning Engine

## INPUT
Accept:
- literal scene request
- emotional statement
- relationship meaning
- desired visual intensity
- optional protected scene elements

## STAGE A — SEMANTIC EXTRACTION
Extract only supported concepts:
- primary emotion
- secondary emotion
- relationship state
- distance/proximity
- transformation
- permanence/time
- tension/conflict
- healing/reconnection
- destination/hope
- vulnerability/protection

Do not invent biography or relationship facts.

## STAGE B — CAUSAL VISUAL MAPPING
Each selected visual device MUST have:
`SOURCE_MEANING -> VISUAL_DEVICE -> INTENDED_READING`

Examples:
- enduring bond -> continuous light path -> connection persists
- separation overcome -> opened/broken barrier -> distance loses power
- shared future -> two subjects oriented toward same horizon -> common direction
- emotional permanence -> restrained infinity geometry -> continuity
- vulnerability -> physically plausible cracks/scars with transmitted light -> damage with surviving inner energy
- transformation -> material/state transition -> emotional change made visible

## STAGE C — PHYSICAL TRANSLATION
Prefer believable carriers of symbolism:
light, reflections, weather, architecture, landscape, pose, gaze, distance, depth, material wear, particles, shadows, lens behavior.

Abstract glyphs and floating symbols are secondary and must be restrained unless explicitly requested.

## STAGE D — SUBJECT RELATIONSHIP
Communicate connection using:
- gaze
- hand/body proximity
- parallel or converging posture
- shared illumination
- composition vectors
- foreground/background separation
- negative space

Never rely solely on hearts, text, or infinity signs.

## STAGE E — PHOTOREALISM LOCK
Preserve:
- plausible anatomy
- coherent perspective
- material-specific reflections
- physically motivated lighting
- realistic depth and atmospheric scattering
- lens-consistent bokeh and flare
- microtexture
- scene-scale consistency
- contact shadows
- environmental interaction

Symbolism may bend scene design but must not automatically convert the result into illustration/fantasy art.

## STAGE F — SYMBOL DENSITY
Default:
- 1 dominant semantic motif
- 1–3 supporting motifs
- micro-symbolism only when composition remains readable

Reject redundant symbols expressing the same concept without adding meaning.

## STAGE G — AUDIT
Reject or revise when:
- symbol has no causal source
- symbolism contradicts input
- decorative effects obscure subjects
- neon/glow destroys material realism
- text becomes the only meaning carrier
- composition becomes generic romance/fantasy
- excessive particles/chains/hearts/infinity motifs create visual noise
- emotional intensity is expressed only through saturation

## OUTPUT CONTRACT
Return a host-ready augmentation containing:
1. semantic intent
2. causal visual mappings
3. physical realism constraints
4. composition instructions
5. protected elements
6. exclusions / negative constraints
