# Example — Distance / Thoughts / Heart

Input meaning:
"You are never truly far from me, because you are always in my thoughts and forever within my heart"

Mapping:
- physical distance -> expansive spatial depth
- persistent mental presence -> subtle recurring reflected light / visual echo
- internal emotional presence -> shared light source visually connecting subject and environment
- permanence -> continuous horizon/path motif
- love surviving separation -> barrier or distance present but visually traversed by light
- future -> subjects/composition oriented toward an illuminated horizon

Avoid:
generic floating hearts, arbitrary chains, excessive infinity signs, unexplained cosmic debris.

Optional surreal-photoreal interpretation:
A physically convincing luminous phenomenon crosses a vast landscape between separated positions, converging into one warm focal region while realistic atmosphere, reflections and volumetric light make the metaphor feel materially present.
