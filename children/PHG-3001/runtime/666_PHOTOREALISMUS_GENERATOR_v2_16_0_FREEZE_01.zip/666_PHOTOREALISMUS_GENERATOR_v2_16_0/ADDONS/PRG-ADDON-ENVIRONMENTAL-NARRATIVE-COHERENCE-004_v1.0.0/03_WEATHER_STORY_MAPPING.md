# 03 — WEATHER STORY MAPPING

## Beispiel-Mapping

```text
RAIN
→ TRIAL / PERSISTENCE / PASSION / CLINGING TOGETHER

STORM
→ CONFLICT / PRESSURE / SURVIVAL / PROTECTION

FOG
→ MYSTERY / DISTANCE / UNKNOWABILITY

SUNSET
→ DEVOTION / SOFTNESS / EPILOGUE / MEMORY

CITY_NIGHT
→ INTENSITY / MODERN ROMANCE / DANGEROUS GLAMOUR
```

## Zweck

Wetter und Umweltzustände werden auf mögliche Story-Richtungen gemappt.

## Guard

```text
MAPPING = STORY POSSIBILITY
NOT MANDATORY STORY SENTENCE
```

Die finale Story entsteht erst im Zusammenspiel mit Personenverhalten, Symbolen, Text und Szene.
