# 05 — WET MATERIAL REALISM

## Zweck

Spezialisiert die Umweltkausalität für nasse Szenen.

## Prüfen

```text
WET_HAIR
WET_SKIN
WET_FABRIC
WET_LEATHER
SPECULAR_HIGHLIGHTS
DROP_ACCUMULATION
SURFACE_REFLECTION
ROAD_GLOSS
VEHICLE_GLOSS
```

## Materialregel

Unterschiedliche Materialien reagieren unterschiedlich auf Nässe:

```text
SKIN     = soft sheen / droplets
HAIR     = darker, clumped, weighted
LEATHER  = high specular reflectance
FABRIC   = darkened, clinging, shape-revealing
ROAD     = mirror-like light spread
```

## Ziel

Keine symbolische Regenkulisse ohne physische Plausibilität.
