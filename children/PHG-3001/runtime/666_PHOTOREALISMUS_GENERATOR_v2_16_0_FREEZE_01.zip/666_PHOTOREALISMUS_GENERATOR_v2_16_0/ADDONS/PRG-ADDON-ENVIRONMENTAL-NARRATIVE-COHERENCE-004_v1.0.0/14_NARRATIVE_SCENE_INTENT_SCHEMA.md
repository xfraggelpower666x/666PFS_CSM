# 14 — NARRATIVE SCENE INTENT SCHEMA

## Beispiel-Schema

```yaml
scene_intent:
  environment:
    event: RAIN
    narrative_meaning: ENDURANCE_LOVE
  relationship:
    behavior: CLOSE_PROTECTIVE_CONTACT
  frame:
    symbolic_family: HEART_ORNAMENT
  text:
    names:
      left: AMARIS
      right: AMARIN
    connector: "&"
    caption: "whatever storms may come."
  causality:
    wet_materials: REQUIRED
```

## Zweck

Einheitliches internes Modell für narrative Szenen.
