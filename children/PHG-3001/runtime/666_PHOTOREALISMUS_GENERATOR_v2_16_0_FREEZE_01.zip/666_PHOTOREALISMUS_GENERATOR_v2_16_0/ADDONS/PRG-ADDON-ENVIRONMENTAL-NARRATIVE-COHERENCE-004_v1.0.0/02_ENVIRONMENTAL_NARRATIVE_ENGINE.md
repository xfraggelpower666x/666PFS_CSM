# 02 — ENVIRONMENTAL NARRATIVE ENGINE

## Kernidee

Umweltereignisse können narrative Bedeutung tragen.

```text
RAIN
→ ADVERSITY
→ TOGETHERNESS
→ ENDURANCE

SUNSET
→ TENDERNESS
→ TRANSITION
→ WARMTH

NIGHT_CITY
→ DESIRE
→ MYSTERY
→ INTENSITY
```

## Aufgabe

Das Modul klassifiziert, welche Story-Bedeutung eine Szene bereits trägt oder tragen kann.

## Narrative Felder

```text
EVENT_TYPE
EMOTIONAL_SIGNAL
NARRATIVE_PRESSURE
RELATIONAL_IMPACT
SYMBOLIC_POTENTIAL
TEXT_COMPATIBILITY
FRAME_COMPATIBILITY
PHYSICAL_CONSEQUENCE_REQUIREMENT
```

## Regel

Umwelt ist nicht automatisch nur Kulisse.
Sie kann aktive Erzählebene sein.
