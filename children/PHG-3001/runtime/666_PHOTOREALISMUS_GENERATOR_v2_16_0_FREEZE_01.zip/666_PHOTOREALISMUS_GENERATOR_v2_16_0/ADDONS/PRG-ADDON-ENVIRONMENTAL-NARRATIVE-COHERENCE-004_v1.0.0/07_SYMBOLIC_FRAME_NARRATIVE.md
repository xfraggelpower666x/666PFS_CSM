# 07 — SYMBOLIC FRAME NARRATIVE

## Zweck

Rahmen werden nicht nur visuell, sondern semantisch gelesen.

## Beispiele

```text
HEART_FRAME
→ LOVE / DEVOTION / PROTECTION

HUD_FRAME
→ TECHNOLOGY / DISTANCE / CYBER CONTROL

ORNAMENTAL_GLOW
→ MEMORY / ROMANCE / CHAPTER-FEEL
```

## Narrative Frame Fusion

```text
SCENE
+
FRAME_SYMBOLISM
+
TEXT
=
NARRATIVE_READING
```

## Ziel

Der Rahmen soll dieselbe Geschichte unterstützen, nicht einer entgegengesetzten Bedeutung folgen.
