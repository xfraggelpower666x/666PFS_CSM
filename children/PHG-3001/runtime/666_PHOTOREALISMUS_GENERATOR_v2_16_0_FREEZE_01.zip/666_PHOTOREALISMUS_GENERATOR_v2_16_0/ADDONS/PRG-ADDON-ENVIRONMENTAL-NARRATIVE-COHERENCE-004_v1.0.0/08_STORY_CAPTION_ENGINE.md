# 08 — STORY CAPTION ENGINE

## Aufgabe

Verarbeitet kurze Story-Zeilen oder Captions im Bild.

## Felder

```text
CAPTION_TEXT
CAPTION_TONE
CAPTION_LENGTH
CAPTION_POSITION
CAPTION_SAFE_AREA
CAPTION_RELATION_TO_SCENE
CAPTION_RELATION_TO_FRAME
CAPTION_RELATION_TO_NAMES
```

## Regeln

- Caption darf Paarnamen nicht verdrängen.
- Caption darf Safe Areas nicht verletzen.
- Caption soll semantisch mit Szene und Symbolik harmonieren.
- Caption darf nicht generisch die Kernstory verwässern.

## Beispiel

```text
PRIMARY NAMES
SECONDARY CAPTION
```

Die Paaridentität bleibt immer priorisiert.
