# 15 — REFERENCE EVIDENCE PROFILE

## Beobachtete zusätzliche Evidenz

Die Referenz zeigt:

```text
RAIN / NIGHT / VEHICLE / CLOSE COUPLE / ORNAMENTAL HEART FRAME / STORY CAPTION
```

## Hauptbeobachtungen

1. Umwelt kann selbst Storyträger sein.
2. Text und Szene müssen semantisch zusammenpassen.
3. Symbolischer Rahmen kann dieselbe Story verstärken.
4. Regen verlangt physische Materialfolgen.
5. Name-Side-Binding muss auch bei dekorativen / narrativen Layouts hart abgesichert sein.

## Status

```text
SOURCE_TYPE = USER_PROVIDED_VISUAL_REFERENCE
LEARNING_STATE = OBSERVED_EVIDENCE_SET
CANONICAL = FALSE
PERSISTENT_LEARNING = FALSE
```
