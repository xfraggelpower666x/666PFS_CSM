# 04 — ENVIRONMENTAL CAUSALITY ENGINE

## Problem

Regen darf nicht nur als Effekt-Layer mit Strichen dargestellt werden.

## Kernmodell

```text
CAUSE = ENVIRONMENTAL_EVENT

EFFECTS:
HAIR_WETNESS
SKIN_WETNESS
FABRIC_WETNESS
LEATHER_REFLECTION
GROUND_REFLECTION
VEHICLE_REFLECTION
ATMOSPHERIC_SCATTER
LIGHT_DIFFUSION
```

## Regel

Wenn eine Umweltbedingung vorhanden ist, müssen ihre physischen Konsequenzen glaubwürdig in das Bild integriert werden.

## Guard

```text
EVENT_VISIBLE
BUT CONSEQUENCE_ABSENT
= COHERENCE FAILURE
```
