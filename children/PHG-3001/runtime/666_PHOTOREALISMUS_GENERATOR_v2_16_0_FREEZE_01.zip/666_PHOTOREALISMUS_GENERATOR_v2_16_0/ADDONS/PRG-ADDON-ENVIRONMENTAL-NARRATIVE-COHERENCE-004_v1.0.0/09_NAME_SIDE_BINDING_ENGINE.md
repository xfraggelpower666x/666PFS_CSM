# 09 — NAME SIDE BINDING ENGINE

## Harte Regel

```text
NAME_SIDE_BINDING = MANDATORY
NAME_PERSON_MATCH = HARD_LOCK
NAME_SWAP         = FORBIDDEN
```

## Bedeutung

- Der Name muss immer auf der Seite stehen, auf der die zugehörige Person ist.
- Der Name folgt der Person, nicht einem starren Layout-Default.
- Wenn die Person die Seite wechselt, wechselt der Name mit.
- Symmetrie, Designgewohnheit oder alphabetische Ordnung dürfen Name-Side-Binding nicht brechen.

## Logik

```text
PERSON_A_CURRENT_SIDE = LEFT | RIGHT
PERSON_B_CURRENT_SIDE = LEFT | RIGHT

NAME_A_POSITION MUST MATCH PERSON_A_CURRENT_SIDE
NAME_B_POSITION MUST MATCH PERSON_B_CURRENT_SIDE
```

## Regel für enge Paarbilder

Auch bei enger, verschachtelter oder überkreuzter Komposition bleibt Name-Side-Binding Pflicht.
Dann ggf. mit Sideplates, getrennten Nameplates oder klaren Kartuschen lösen.
