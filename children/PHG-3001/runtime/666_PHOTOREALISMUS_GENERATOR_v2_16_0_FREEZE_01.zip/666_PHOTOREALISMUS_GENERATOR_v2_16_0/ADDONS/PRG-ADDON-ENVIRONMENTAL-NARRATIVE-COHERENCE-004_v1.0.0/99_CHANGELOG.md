# 99 — CHANGELOG

## v1.0.0

Initiales viertes Addon-Pack.

Neu:

- Environmental Narrative Engine
- Weather Story Mapping
- Environmental Causality Engine
- Wet Material Realism
- Scene Text Semantic Link
- Symbolic Frame Narrative
- Story Caption Engine
- Name Side Binding Engine
- Name Order and Connector Guard
- Semantic Coherence Audit
- Environmental Repair Pass
- Physical Consequence Map
- Narrative Scene Intent Schema
- Integration Contract
- Test Plan
- Status / Handoff
