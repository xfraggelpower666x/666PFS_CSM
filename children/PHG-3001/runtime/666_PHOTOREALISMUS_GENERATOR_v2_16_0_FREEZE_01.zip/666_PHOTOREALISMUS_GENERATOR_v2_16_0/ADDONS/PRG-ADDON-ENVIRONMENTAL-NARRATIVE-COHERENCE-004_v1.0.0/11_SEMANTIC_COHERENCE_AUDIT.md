# 11 — SEMANTIC COHERENCE AUDIT

## Leitfrage

```text
DOES EVERYTHING TELL
THE SAME STORY?
```

## Audit-Gates

### Gate A — Environment
- Umweltereignis erkannt
- narrative Bedeutung ableitbar

### Gate B — Physical Causality
- sichtbare Konsequenzen des Umweltereignisses
- Materialreaktionen plausibel

### Gate C — Symbolic Support
- Rahmen/Symbole unterstützen die Story
- keine semantische Kollision

### Gate D — Text Coherence
- Caption passt zur Szene
- Names bleiben korrekt priorisiert

### Gate E — Name Binding
- Name links bei linker Person
- Name rechts bei rechter Person
- kein Swap
- kein Ambiguitätsfehler

## Ergebnisstatus

```text
PASS
PASS_WITH_MINOR_REPAIR
REPAIR_REQUIRED
HOLD
REJECT
```
