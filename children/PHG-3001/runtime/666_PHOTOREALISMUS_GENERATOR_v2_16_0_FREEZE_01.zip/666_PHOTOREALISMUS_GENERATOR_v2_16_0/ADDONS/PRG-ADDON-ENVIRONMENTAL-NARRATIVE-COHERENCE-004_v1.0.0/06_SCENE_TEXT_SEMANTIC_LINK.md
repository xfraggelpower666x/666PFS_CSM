# 06 — SCENE TEXT SEMANTIC LINK

## Kernidee

Text im Bild muss sinnvoll mit der Szene zusammenarbeiten.

## Dreifachbindung

```text
SCENE
↔
TEXT
↔
SYMBOL
```

## Beispiel

```text
RAIN_SCENE
↔ "whatever storms may come."
↔ HEART_FRAME
```

## Prüfen

```text
TEXT_SUPPORTS_SCENE
TEXT_CONTRADICTS_SCENE
TEXT_AMPLIFIES_SCENE
TEXT_IS_GENERIC
TEXT_HAS_RELATIONAL_FOCUS
```

## Regel

Text ist semantische Datenebene, nicht bloß Dekoration.
