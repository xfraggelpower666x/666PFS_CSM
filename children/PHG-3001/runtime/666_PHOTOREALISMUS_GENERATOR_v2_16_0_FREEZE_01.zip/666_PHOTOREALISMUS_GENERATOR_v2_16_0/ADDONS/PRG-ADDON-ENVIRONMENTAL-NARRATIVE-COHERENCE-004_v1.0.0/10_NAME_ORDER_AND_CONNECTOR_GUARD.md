# 10 — NAME ORDER AND CONNECTOR GUARD

## Zweck

Trennt zwei Dinge sauber:

```text
NAME_SIDE_BINDING
≠
NAME_ORDER_DISPLAY
```

## Regeln

1. Seitenzuordnung ist Pflicht.
2. Ein Connector zwischen den Namen ist erlaubt:
   - &
   - and
   - ♡
   - Emblem
3. Der Connector darf niemals die Zuordnung zerstören.
4. Gemeinsamer schwebender Joint-Text ohne klare Seitenbindung ist standardmäßig unzulässig.

## Auditfelder

```text
NAME_A_SIDE_CORRECT
NAME_B_SIDE_CORRECT
CONNECTOR_CENTERED
NO_NAME_SWAP
NO_LAYOUT_AMBIGUITY
```

## Ausnahme

Nur bei expliziter Nutzerfreigabe darf ein gemeinsamer Joint-Title ohne eindeutige Side-Binding-Logik verwendet werden.
