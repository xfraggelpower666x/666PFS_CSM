# 13 — PHYSICAL CONSEQUENCE MAP

## Allgemeines Schema

```text
ENVIRONMENTAL_CAUSE
→ SURFACE_RESPONSE
→ LIGHT_RESPONSE
→ ATMOSPHERIC_RESPONSE
→ COMPOSITIONAL_RESPONSE
```

## Beispiel: Rain

```text
RAIN
→ wet skin / hair / fabric / road / vehicle
→ specular lights / blooming highlights
→ mist / diffusion / droplets
→ closer posture / sheltering / intensity
```

## Beispiel: Storm Romance

```text
STORM
→ adversity
→ protective closeness
→ story tension
→ resilient symbolism
```

Dieses Mapping dient der internen Plausibilitätsprüfung.
