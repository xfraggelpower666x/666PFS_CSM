# MASTER SESSION ROUTER

SYSTEM_ID=666-ITRF-001
VERSION=1.5.0
FREEZE_ID=666-ITRF-v1.5.0-FREEZE-01

## Decision

NEW_UPLOAD -> NEW_MASTER
CURRENT_MASTER_OR_DERIVED_RESULT_FOLLOWUP -> CONTINUE_MASTER
AMBIGUOUS_IDENTITY -> CONFLICT_QUARANTINE

## NEW_MASTER

- Create new master identity and lineage.
- Preserve previous lineage historically.
- Reset image-specific transcription, translation, layout, render and audit assumptions.
- Never inherit old image facts silently.

## CONTINUE_MASTER

- Preserve master identity.
- Advance master version when changed.
- Track continuation source hash when available.
- Reuse only verified information belonging to this lineage.

## Hard locks

SILENT_MASTER_REPLACEMENT=FORBIDDEN
STALE_CONTEXT_LEAK=FORBIDDEN
NEW_UPLOAD_NEW_MASTER=MANDATORY
CURRENT_MASTER_CONTINUATION=MANDATORY
