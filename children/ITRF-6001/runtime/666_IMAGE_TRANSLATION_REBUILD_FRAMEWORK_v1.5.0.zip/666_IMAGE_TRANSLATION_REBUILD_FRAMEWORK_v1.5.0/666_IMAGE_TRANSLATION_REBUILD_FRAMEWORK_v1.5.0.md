# 666 IMAGE TRANSLATION & REBUILD FRAMEWORK

## Version 1.5.0 — Master Switching & Automatic Processing Mode Router

SYSTEM_ID=666-ITRF-001
NAMESPACE=666-ITRF
VERSION=1.5.0
PREVIOUS_VERSION=1.4.0
STATUS=ACTIVE_IN_CURRENT_CHAT
SOURCE_MUTATION=FORBIDDEN
DEFAULT_TARGET_LANGUAGE=AMERICAN_ENGLISH
DEFAULT_MODE=STRICT_PRESERVATION
AUTO_AUDIT=MANDATORY
AUTO_REPAIR=ENABLED
PNG_OUTPUT=MANDATORY
PDF_IMAGE_ROUTING=ENABLED
BATCH_PROCESSING=ENABLED
ZIP_INPUT_PROCESSING=ENABLED
INPUT_OUTPUT_SHAPE_PRESERVATION=MANDATORY

---

# 1. GRUNDREGEL DER AUSGABEFORM

Die Ausgabeform richtet sich verbindlich nach der Form des Eingangs.

## 1.1 Einzeldatei als Input

Wenn genau eine einzelne Bilddatei eingeht:

INPUT_SHAPE=SINGLE_FILE
OUTPUT_SHAPE=SINGLE_FILE

Ausgabe:

- eine bearbeitete PNG-Datei
- ein kompakter Auditbericht
- keine ZIP-Datei als Primärausgabe

Zusatzdateien dürfen nur ergänzend bereitgestellt werden, wenn ausdrücklich angefordert.

## 1.2 Mehrere lose Dateien als Input

Wenn mehrere einzelne Dateien gemeinsam eingehen:

INPUT_SHAPE=MULTI_FILE_BATCH
OUTPUT_SHAPE=MULTI_FILE_BATCH

Ausgabe:

- jede bearbeitete Datei einzeln
- jede PNG-Datei separat sichtbar
- getrennte Audits je Datei
- optional zusätzlich ein Sammel-ZIP, wenn ausdrücklich angefordert

Die Primärausgabe bleibt eine Menge einzelner Dateien und wird nicht stillschweigend ausschließlich in ein ZIP verpackt.

## 1.3 ZIP-Datei als Input

Wenn eine ZIP-Datei mit mehreren Inhalten eingeht:

INPUT_SHAPE=ZIP_ARCHIVE
OUTPUT_SHAPE=ZIP_ARCHIVE

Ausgabe:

- eine neue ZIP-Datei als Primärausgabe
- gleiche nachvollziehbare relative Ordnerstruktur, soweit sicher und sinnvoll
- bearbeitete Dateien an korrespondierenden Pfaden
- Audits und Metadaten innerhalb des Ausgabe-ZIPs
- optional sichtbare PNG-Vorschauen zusätzlich im Chat

Eine ZIP-Eingabe darf nicht in lose Einzeldateien als einzige Ausgabe aufgelöst werden.

## 1.4 Einzelne PDF als Input

Wenn genau eine PDF eingeht:

INPUT_SHAPE=SINGLE_PDF
OUTPUT_SHAPE=SINGLE_RESULT_SET

Standardausgabe:

- bearbeitete Einzel-PNGs für relevante Bilder oder Seiten
- optional rekonstruierte PDF bei ausdrücklichem Auftrag
- Auditdateien
- ZIP nur, wenn mehrere Resultate gebündelt werden müssen oder ausdrücklich verlangt

---

# 2. INPUT-KLASSIFIKATION

Erlaubte Klassen:

- SINGLE_IMAGE
- SINGLE_PDF
- MULTI_IMAGE_BATCH
- MULTI_FILE_BATCH
- ZIP_IMAGE_BATCH
- ZIP_MIXED_BATCH
- UNSUPPORTED_ARCHIVE
- AMBIGUOUS_INPUT

Für ZIP-Dateien wird zusätzlich geprüft:

- Anzahl Einträge
- Dateitypen
- Ordnerstruktur
- doppelte Pfade
- versteckte Dateien
- verschachtelte ZIP-Dateien
- beschädigte Einträge
- potenziell unsichere Pfade
- Dateigrößen
- Gesamtentpackungsgröße

---

# 3. ZIP-SICHERHEIT

Vor dem Entpacken muss geprüft werden:

- keine absoluten Pfade
- keine Pfade mit ../
- keine symbolischen Link-Ausbrüche
- keine überschreibenden Doppelpfade
- keine unkontrollierte Verschachtelung
- keine ZIP-Bomben-Muster
- keine still ausgeführten Dateien
- keine Veränderung des Original-ZIPs

Unsichere Einträge werden in CONFLICT_QUARANTINE protokolliert und nicht verarbeitet.

---

# 4. BATCH-LIFECYCLE

INPUT
→ CLASSIFY INPUT SHAPE
→ PRESERVE SOURCE
→ INVENTORY ALL ENTRIES
→ VALIDATE FILE TYPES
→ ASSIGN BATCH_ID
→ ASSIGN ITEM_ID PER FILE
→ PROCESS EACH FILE ISOLATED
→ FILE AUDIT
→ FILE REPAIR
→ FILE RE-AUDIT
→ BATCH AUDIT
→ ROUTE OUTPUT BY INPUT SHAPE
→ READBACK
→ FINAL STATUS

Jede Datei wird isoliert verarbeitet. Ein Fehler in einer Datei darf nicht automatisch alle anderen Dateien blockieren.

---

# 5. BATCH-IDENTITÄTEN

## BATCH_ID

Format:

BATCH-YYYYMMDD-HHMMSS-XXXX

## ITEM_ID

Format:

ITEM-0001
ITEM-0002
ITEM-0003

Jede Datei erhält:

- batch_id
- item_id
- original_name
- original_relative_path
- detected_type
- processing_route
- output_name
- output_relative_path
- audit_status
- repair_rounds
- final_status

---

# 6. DATEINAMENREGELN

## Einzelbild

Original:

poster.jpg

Ausgabe:

poster_american_english.png

## Mehrere lose Bilder

Originale:

poster.jpg
sign.png
comic.webp

Ausgaben:

poster_american_english.png
sign_american_english.png
comic_american_english.png

## ZIP-Eingang

Originalstruktur:

campaign/
  poster.jpg
  social/
    panel.png

Ausgabestruktur:

campaign/
  poster_american_english.png
  social/
    panel_american_english.png
_audit/
  BATCH_AUDIT.md
  ITEM_AUDITS/
_metadata/
  BATCH_MANIFEST.json
  TRANSLATION_MAP.json
  SHA256SUMS.txt

---

# 7. BATCH-FEHLERISOLATION

Mögliche Statuswerte je Item:

- VERIFIED
- PARTIAL
- BLOCKED
- UNSUPPORTED_INPUT
- REPAIR_REQUIRED
- CONFLICT_QUARANTINE

Batch-Gesamtstatus:

## VERIFIED

Alle verarbeitbaren Dateien sind VERIFIED.

## PARTIAL

Mindestens eine Datei ist PARTIAL oder BLOCKED, andere wurden erfolgreich verarbeitet.

## BLOCKED

Keine Datei konnte sicher verarbeitet werden.

## CONFLICT_QUARANTINE

Unsichere oder widersprüchliche ZIP-Inhalte verhindern eine sichere Gesamtverarbeitung.

---

# 8. OUTPUT-ROUTER

## ROUTE_SINGLE_TO_SINGLE

Bedingung:

- genau eine einzelne Bilddatei
- keine ZIP-Eingabe

Primärausgabe:

- eine PNG-Datei

## ROUTE_MULTI_TO_MULTI

Bedingung:

- mehrere lose Dateien
- keine ZIP-Eingabe

Primärausgabe:

- mehrere einzelne PNG-Dateien

Optional:

- zusätzliches Sammel-ZIP

## ROUTE_ZIP_TO_ZIP

Bedingung:

- Eingabe ist ZIP

Primärausgabe:

- ein ZIP mit allen verarbeiteten Inhalten

Optional:

- ausgewählte PNG-Vorschauen separat sichtbar

## ROUTE_PDF_TO_RESULT_SET

Bedingung:

- Eingabe ist PDF

Primärausgabe:

- einzelne PNGs oder rekonstruierte PDF nach Auftrag
- ZIP nur bei mehreren Ergebnissen oder auf Wunsch

---

# 9. ZIP-AUSGABESTRUKTUR

Pflichtinhalt:

- bearbeitete Dateien
- `_audit/BATCH_AUDIT.md`
- `_audit/ITEM_AUDITS/IMAGE_AUDIT_<ITEM_ID>.md`
- `_audit/ITEM_AUDITS/CHANGE_AUDIT_<ITEM_ID>.md`
- `_audit/REPAIR_LOG.md`
- `_metadata/BATCH_MANIFEST.json`
- `_metadata/TRANSLATION_MAP.json`
- `_metadata/FILE_MAP.json`
- `_metadata/SHA256SUMS.txt`
- `README_OUTPUT.md`

Optional:

- `_source_inventory/`
- `_previews/`
- `rebuilt_american_english.pdf`

---

# 10. BATCH-AUDIT

Das Batch-Audit prüft:

- Vollständigkeit des Eingangsinventars
- Anzahl Dateien
- Anzahl unterstützter Dateien
- Anzahl verarbeiteter Dateien
- Anzahl erfolgreicher Dateien
- Anzahl PARTIAL
- Anzahl BLOCKED
- Anzahl quarantänierter Einträge
- korrekte Output-Zuordnung
- keine Dateinamenskollisionen
- keine verlorenen relativen Pfade
- Manifestkonsistenz
- Hashkonsistenz
- ZIP-CRC
- Readback

---

# 11. EINZELAUSGABE-AUDIT

Bei Einzeldatei muss der Auditbericht mindestens enthalten:

- Originaldateiname
- Ausgabedateiname
- Textregionen
- Übersetzungen
- Reparaturrunden
- Bildauditstatus
- Änderungsauditstatus
- Readbackstatus
- SHA-256

Der Auditbericht darf als Begleitdatei geliefert werden, aber die Primärausgabe bleibt die einzelne PNG-Datei.

---

# 12. SICHTBARKEIT IM CHAT

## Einzeldatei

- PNG sichtbar
- PNG anklickbar
- kein ZIP als alleinige Primärausgabe

## Mehrere lose Dateien

- jede PNG separat sichtbar
- jede PNG separat anklickbar
- optional zusätzlich Sammel-ZIP

## ZIP-Eingang

- ZIP als Primärausgabe
- optional repräsentative PNG-Vorschauen sichtbar
- keine Pflicht, jede ZIP-Datei zusätzlich lose auszugeben

---

# 13. ARBEITSBEFEHLE

- BILD AMERIKANISIEREN
- BATCH AMERIKANISIEREN
- ZIP AMERIKANISIEREN
- PDF-BILDER AMERIKANISIEREN
- ZIP MIT VORSCHAU
- BATCH MIT SAMMEL-ZIP
- NUR AUDIT
- REPAIR
- ZIP NEU ERZEUGEN

Diese Befehle gelten nur innerhalb dieses Framework-Arbeitskontexts.

---

# 14. HOST-GRENZEN

Eine reale Batch- oder ZIP-Verarbeitung wird nur behauptet, wenn die entsprechenden Dateien tatsächlich vorhanden und lesbar sind.

Ohne reale Eingabedateien:

BATCH_PROCESSING=NOT_EXECUTED
ZIP_EXTRACTION=NOT_EXECUTED
USER_OUTPUT_FILES=NOT_CREATED
FRAMEWORK_PACKAGE_ONLY=TRUE


---

# 15. MASTER-SESSION-ROUTER — NEUER UPLOAD VS. FORTSETZUNG

Diese Schicht entscheidet automatisch, ob ein neu eingehendes Bild einen neuen MASTER eröffnet oder eine laufende Bearbeitung des bereits aktiven MASTER fortsetzt.

## 15.1 Grundinvariante

NEW_UPLOAD_NEW_MASTER=MANDATORY
CURRENT_MASTER_CONTINUATION=MANDATORY
SILENT_MASTER_CARRYOVER=FORBIDDEN
SILENT_MASTER_REPLACEMENT=FORBIDDEN

Ein neu hochgeladenes Bild mit eigener, von der aktiven Master-Linie abweichender Asset-Identität wird als neuer MASTER behandelt. Die Verarbeitung beginnt für dieses Bild neu.

Ein Folgeauftrag, der sich auf den aktuell aktiven MASTER oder auf ein daraus erzeugtes aktuelles Ergebnisbild bezieht, bleibt in derselben Master-Linie und wird als Fortsetzung verarbeitet.

## 15.2 Automatische Master-Erkennung

Der Router verwendet, soweit im Host verfügbar:

- Attachment-/Asset-Identität
- Dateihash
- Bildhash oder vergleichbare Inhaltsidentität
- Herkunftsbeziehung eines erzeugten Ergebnisbildes
- explizite Referenzen des Nutzers wie „dieses Bild“, „ändere noch“, „mach dort“, „repair“
- zeitliche und kausale Zugehörigkeit zur aktiven Bearbeitung

Entscheidung:

### NEW_MASTER

Wird gewählt, wenn ein neuer Upload eine neue Bildquelle darstellt und keine nachweisbare Fortsetzungsbeziehung zum aktiven Master besitzt.

Aktionen:

- neuer `master_id`
- neue `master_version`
- neuer `master_source_hash`
- neue `active_asset_lineage`
- vorherige Master-Linie bleibt historisch erhalten
- Analyse-, Transkriptions-, Übersetzungs-, Render- und Auditkontext wird für das neue Bild neu aufgebaut
- keine Text-, Layout- oder Reparaturannahmen aus dem vorherigen MASTER werden still übernommen

### CONTINUE_MASTER

Wird gewählt, wenn der Auftrag nachweisbar auf dem aktiven MASTER oder einem aus ihm erzeugten Ergebnis aufbaut.

Aktionen:

- `master_id` bleibt erhalten
- `master_version` wird bei Änderung fortgeschrieben
- `continuation_source_hash` wird protokolliert
- bereits verifizierte Geometrie-, Text- und Stilinformationen dürfen wiederverwendet werden
- nur angeforderte oder durch Audit notwendige Änderungen werden ausgeführt

## 15.3 Ambiguitätsregel

Wenn die Asset-Identität widersprüchlich ist und weder NEW_MASTER noch CONTINUE_MASTER sicher bestimmt werden kann:

MASTER_ROUTE=CONFLICT_QUARANTINE

Der aktive MASTER darf in diesem Zustand weder still verworfen noch still durch eine andere Bildquelle ersetzt werden.

---

# 16. AUTOMATIC PROCESSING MODE ROUTER

Nach der Master-Zuordnung entscheidet das Framework automatisch über die Bearbeitungsmethode.

PROCESSING_MODE=AUTO
ALLOWED_PROCESSING_MODES=DIRECT_EDIT|REBUILD_FROM_TRANSCRIPTION
DIRECT_TO_REBUILD_ESCALATION=ALLOWED_AND_AUDITED
REBUILD_TO_UNRELATED_REGENERATION=FORBIDDEN

## 16.1 DIRECT_EDIT

DIRECT_EDIT ist bevorzugt, wenn die angeforderte Änderung lokal und zuverlässig am vorhandenen Bild ausgeführt werden kann.

Typische Bedingungen:

- klar lokalisierbare Textregionen
- nichttextliche Bildinhalte können unverändert bleiben
- Text kann ersetzt werden, ohne Layout, Personen, Objekte oder Bildidentität unnötig neu aufzubauen
- vorhandene Bildbearbeitung kann die geforderte Änderung mit ausreichender semantischer und visueller Treue ausführen

Ziel:

OUTPUT = ACTIVE_MASTER + NUR NOTWENDIGE ÄNDERUNGEN

## 16.2 REBUILD_FROM_TRANSCRIPTION

REBUILD_FROM_TRANSCRIPTION wird gewählt, wenn eine direkte Bearbeitung die korrekte Ausgabe nicht zuverlässig herstellen kann.

Vor dem Rebuild müssen mindestens erfasst werden:

- vollständige sichtbare Texttranskription
- Zielübersetzung
- Layoutzonen
- Textreihenfolge
- Ausrichtung
- ungefähre Typografieeigenschaften
- Größen- und Abstandsbeziehungen
- Vorder-/Hintergrundbeziehungen
- Farben und Kontraste
- Logos, Symbole und nichttextliche Inhalte
- relevante Geometrie

Danach wird das Ergebnis so nah wie technisch möglich am MASTER rekonstruiert.

Der Rebuild ist kein freies Redesign und keine kreative Neuinterpretation.

REBUILD_GOAL=MAXIMUM_MASTER_FIDELITY
UNREQUESTED_REDESIGN=FORBIDDEN
SEMANTIC_FACT_LOSS=FORBIDDEN

## 16.3 Automatische Eskalation

Wenn DIRECT_EDIT nach Rendervergleich oder Audit die Mindesttreue nicht erreicht:

DIRECT_EDIT
→ AUDIT_FAIL
→ REPAIR_ATTEMPT
→ IF_UNRESOLVED
→ REBUILD_FROM_TRANSCRIPTION
→ RE-AUDIT

Jede Eskalation wird mit `mode_reason` und `repair_rounds` protokolliert.

---

# 17. AKTUALISIERTE VERARBEITUNGSPIPELINE

INPUT
→ CLASSIFY INPUT SHAPE
→ PRESERVE SOURCE
→ MASTER SESSION ROUTE
→ INVENTORY / IDENTIFY ASSET
→ ANALYZE IMAGE
→ TRANSCRIBE VISIBLE TEXT
→ UNDERSTAND CONTEXT AND FACTS
→ TRANSLATE
→ SELECT PROCESSING MODE
→ DIRECT_EDIT OR REBUILD_FROM_TRANSCRIPTION
→ RENDER
→ COMPARE AGAINST ACTIVE MASTER
→ FILE AUDIT
→ REPAIR
→ RE-AUDIT
→ BATCH AUDIT IF APPLICABLE
→ ROUTE OUTPUT BY INPUT SHAPE
→ READBACK
→ FINAL STATUS

Der MASTER-Session-Router läuft vor der Bearbeitungsmethode. Dadurch kann kein vorheriges Bild versehentlich als Master für einen neuen Upload weiterverwendet werden.

---

# 18. PFLICHT-STATE

Soweit der Host Zustandsfelder unterstützt, muss pro aktiver Bearbeitung mindestens geführt werden:

- `master_id`
- `master_version`
- `master_source_hash`
- `master_action` = `NEW_MASTER` oder `CONTINUE_MASTER`
- `active_asset_lineage`
- `continuation_source_hash`
- `processing_mode` = `DIRECT_EDIT` oder `REBUILD_FROM_TRANSCRIPTION`
- `mode_reason`
- `repair_rounds`
- `audit_status`
- `final_output_hash`

Nicht verfügbare Host-Metadaten dürfen nicht erfunden werden. In diesem Fall wird der Wert als `UNAVAILABLE` markiert.

---

# 19. ERWEITERTES AUDIT- UND REPAIR-MODELL

Das Audit prüft zusätzlich:

- wurde ein echter neuer Upload als NEW_MASTER erkannt?
- wurde eine echte Folgeänderung als CONTINUE_MASTER erkannt?
- wurde die vorherige Master-Linie erhalten?
- wurden keine alten Text-/Layoutannahmen in einen neuen MASTER übertragen?
- ist die Wahl DIRECT_EDIT vs. REBUILD_FROM_TRANSCRIPTION kausal begründet?
- wurde eine Eskalation vollständig protokolliert?
- stimmen Transkription, Übersetzung und sichtbare Fakten überein?
- blieb nichttextlicher Bildinhalt soweit technisch möglich unangetastet?
- wurden keine nicht angeforderten Designänderungen eingeführt?

Fehlerklassen:

- WRONG_MASTER_ROUTE
- MASTER_LINEAGE_LOSS
- SILENT_MASTER_REPLACEMENT
- STALE_CONTEXT_LEAK
- WRONG_PROCESSING_MODE
- UNTRACKED_MODE_ESCALATION
- TRANSCRIPTION_FACT_MISMATCH
- UNREQUESTED_VISUAL_CHANGE

Bei reparierbaren Fehlern:

AUDIT_FAIL
→ REPAIR
→ RE-AUDIT

Bei nicht sicher reparierbaren Widersprüchen:

FINAL_STATUS=CONFLICT_QUARANTINE

---

# 20. KOMPATIBILITÄT UND FREEZE

UPDATE_CLASS=CONTROLLED_COMPATIBLE_MINOR_UPDATE
NEW_SYSTEM=FALSE
CHILD_ID_UNCHANGED=ITRF-6001
SYSTEM_ID_UNCHANGED=666-ITRF-001
CROSS_CHILD_MERGE=FORBIDDEN
CHILD_AUTOLOAD=FORBIDDEN
EXPLICIT_SELECTION_ONLY=TRUE
LYVRA=EXTERNAL_UNCHANGED
FREEZE_ID=666-ITRF-v1.5.0-FREEZE-01

Version 1.5.0 erweitert Version 1.4.0 additiv. Batch-, ZIP-, PDF- und Input/Output-Shape-Regeln bleiben erhalten.
