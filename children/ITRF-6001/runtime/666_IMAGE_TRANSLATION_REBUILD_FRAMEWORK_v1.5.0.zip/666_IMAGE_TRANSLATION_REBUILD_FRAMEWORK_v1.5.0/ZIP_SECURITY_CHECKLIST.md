# ZIP SECURITY CHECKLIST

- [ ] Original ZIP preserved
- [ ] No absolute paths
- [ ] No ../ traversal
- [ ] No unsafe symlink escape
- [ ] No duplicate overwrite paths
- [ ] No suspicious expansion ratio
- [ ] No unsupported nested archive execution
- [ ] Hidden files inventoried
- [ ] Corrupt entries quarantined
- [ ] Total extracted size verified
- [ ] Safe extraction root used
