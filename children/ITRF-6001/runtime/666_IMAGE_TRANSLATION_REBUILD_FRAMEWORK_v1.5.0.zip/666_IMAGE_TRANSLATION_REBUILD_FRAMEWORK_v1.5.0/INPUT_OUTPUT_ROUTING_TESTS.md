# INPUT/OUTPUT ROUTING TESTS

## TEST_BATCH_001 — Single image

Input:
- one JPG

Expected primary output:
- one PNG
- no mandatory ZIP

## TEST_BATCH_002 — Multiple loose images

Input:
- three separate image files

Expected primary output:
- three separate PNG files
- optional additional ZIP only

## TEST_BATCH_003 — ZIP with images

Input:
- one ZIP containing three images

Expected primary output:
- one output ZIP
- preserved safe relative structure
- audits and metadata inside ZIP

## TEST_BATCH_004 — ZIP with mixed files

Input:
- images, PDF and unsupported files

Expected:
- supported files processed
- unsupported files documented
- batch may finish PARTIAL
- no silent deletion

## TEST_BATCH_005 — Partial batch failure

Input:
- two valid images
- one corrupt image

Expected:
- valid files still processed
- corrupt item BLOCKED
- batch status PARTIAL

## TEST_BATCH_006 — ZIP path traversal

Input:
- ZIP entry using ../

Expected:
- entry quarantined
- no unsafe extraction
- security event documented


## TEST_MASTER_007 — New upload becomes new master

Input:
- active master A
- a newly uploaded, different image B

Expected:
- B becomes NEW_MASTER
- no context from A is silently reused
- A remains historical

## TEST_MASTER_008 — Follow-up edit continues current master

Input:
- active master A
- generated result A1
- request to change one element on the current result

Expected:
- CONTINUE_MASTER
- same master lineage
- localized change only

## TEST_MODE_009 — Direct edit preferred

Input:
- one clearly bounded text region
- background and non-text content can remain intact

Expected:
- processing_mode=DIRECT_EDIT

## TEST_MODE_010 — Rebuild from transcription

Input:
- text cannot be replaced reliably in place without corrupting layout

Expected:
- complete transcription and layout analysis first
- processing_mode=REBUILD_FROM_TRANSCRIPTION
- reconstruction remains faithful to master

## TEST_MODE_011 — Direct-to-rebuild escalation

Input:
- DIRECT_EDIT attempted
- post-render audit fails fidelity threshold

Expected:
- audited repair attempt
- if unresolved, escalation to REBUILD_FROM_TRANSCRIPTION
- re-audit required

## TEST_MASTER_012 — Ambiguous asset identity

Input:
- conflicting or unavailable asset lineage
- master relation cannot be determined safely

Expected:
- MASTER_ROUTE=CONFLICT_QUARANTINE
- no silent replacement
