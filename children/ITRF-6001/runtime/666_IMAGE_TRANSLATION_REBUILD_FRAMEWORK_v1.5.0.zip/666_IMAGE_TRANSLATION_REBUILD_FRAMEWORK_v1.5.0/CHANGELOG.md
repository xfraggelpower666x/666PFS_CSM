# CHANGELOG

## 1.5.0

- Automatischen Master-Session-Router ergänzt.
- Neuer Upload startet automatisch als neuer MASTER.
- Folgeänderungen am aktiven Ergebnis bleiben in derselben Master-Linie.
- Automatische Wahl zwischen DIRECT_EDIT und REBUILD_FROM_TRANSCRIPTION eingeführt.
- Auditierbare DIRECT_EDIT→REBUILD-Eskalation ergänzt.
- Pflicht-State für Master-Lineage, Processing Mode und Repair-Runden ergänzt.
- Neue Fehlerklassen gegen stale context, falsche Master-Zuordnung und unprotokollierte Eskalation ergänzt.
- Routing-Testfälle für neue Uploads, Fortsetzungen, Moduswahl und Ambiguität ergänzt.
- Additive Minor-Version; bestehende Batch-/ZIP-/PDF-Routingregeln bleiben erhalten.

## 1.4.0

- Batch-Verarbeitung für mehrere lose Dateien ergänzt.
- ZIP-Eingang und ZIP-Ausgang ergänzt.
- Verbindliche Input/Output-Shape-Preservation eingeführt.
- Einzeldatei → Einzeldatei festgelegt.
- Mehrere lose Dateien → mehrere Einzelausgaben festgelegt.
- ZIP-Eingang → ZIP-Primärausgabe festgelegt.
- Batch-ID und Item-ID eingeführt.
- Fehlerisolation je Datei ergänzt.
- ZIP-Sicherheitsregeln ergänzt.
- Batch-Manifest, File-Map und Batch-Audit ergänzt.
- Dateinamens- und Pfadregeln ergänzt.
- Routing-Testfälle ergänzt.
