# PROCESSING MODE ROUTER

SYSTEM_ID=666-ITRF-001
VERSION=1.5.0

PROCESSING_MODE=AUTO

## DIRECT_EDIT
Use when the requested change is local, identifiable and can be made while keeping unrelated visual content intact.

## REBUILD_FROM_TRANSCRIPTION
Use when direct editing cannot reliably preserve correctness. Transcribe visible text and analyze layout/style/geometry before reconstruction. Rebuild must target maximum master fidelity, not free redesign.

## Escalation
DIRECT_EDIT -> AUDIT -> REPAIR -> if unresolved -> REBUILD_FROM_TRANSCRIPTION -> RE-AUDIT

Every routing decision must record `processing_mode` and `mode_reason` when the host supports state metadata.
