# 666 Cyber Bootscreen + Intro Template v1.2.0

Status: FROZEN / SYSTEMSICHERUNG READY

## Zweck
Universelles, projektunabhängiges Zwei-Phasen-Template:
1. Cyber-Bootscreen mit sichtbarem Endzustand `READY`
2. Intro-Template mit kontrolliertem lokalem Project-Content-Handoff

Es findet **keine automatische externe Weiterleitung** statt.

## v1.2.0 Änderungen
- Web-HQ Asset-Paket integriert; transparente PNGs bleiben transparent.
- Neue bereinigte `hud_eyes.png` mit deutlich gleichmäßigeren Außenkanten.
- Bildpayload gegenüber v1.0.0 massiv reduziert, ohne die vorhandenen Asset-Pfade zu ändern.
- Intrinsische Bildmaße und `decoding`/`fetchpriority` Hinweise gegen unnötige Layoutsprünge und für schnelleres Laden ergänzt.
- Kritische Hintergrund- und HUD-Grafik werden vorgeladen.
- HUD-Augen werden nicht mehr per `object-fit: cover` beschnitten; saubere Kontur bleibt sichtbar.
- Skip/Auto-Transition gegen doppelte Ausführung abgesichert.
- Bestehende Phasen-, Button-, READY- und No-Redirect-Architektur erhalten.

## Struktur
```text
666_cyber_intro_template_v1.2.0/
├── index.html
├── css/cyber-intro.css
├── js/cyber-intro.js
├── assets/images/
├── docs/
└── system/
```

## Deployment
Den Ordnerinhalt gemeinsam deployen. Pfade sind relativ und benötigen keinen Build-Schritt.
Für Produktionsserver statische Assets mit langem Cache ausliefern; `index.html` dagegen kurz cachen oder revalidieren.


## v1.2.0 Evolution
- Host integration events: `cyberintro:ready`, `cyberintro:intro`, `cyberintro:project-handoff`.
- Optional `window.startProjectSystem(...)` handoff hook.
- Reduced-motion and Save-Data aware boot completion.
- Hidden phases are non-interactive; skip control is disabled after READY.
- Additional critical image preloads and explicit low priority for deferred phase-2 images.
- No redirect; Phase 1 still terminates in READY.
