# REPAIR + VERBESSERUNG + WEITERENTWICKLUNG

DATE=2026-10-06
VERSION=1.1.0

Durchgeführt:
- Web-HQ Assets eingesetzt, Originalpfade beibehalten.
- HUD-Augen durch bereinigte transparente Variante ersetzt.
- HUD-Darstellung auf `contain` / saubere Skalierung umgestellt.
- Kritische Asset-Preloads ergänzt.
- Intrinsische Maße und Decoding-Hinweise ergänzt.
- Lazy Loading auf nicht kritische Dekoration begrenzt.
- Transition idempotent gemacht; Timer wird sauber aufgelöst.
- Performance-Hinweise dokumentiert.

BESTEHENDE_ARCHITEKTUR_ERHALTEN=TRUE
NO_REDIRECT=TRUE
READY_TERMINAL=TRUE
