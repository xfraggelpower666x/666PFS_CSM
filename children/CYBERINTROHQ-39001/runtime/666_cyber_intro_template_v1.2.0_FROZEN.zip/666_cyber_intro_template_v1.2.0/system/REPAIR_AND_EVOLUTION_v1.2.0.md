# Repair and Evolution v1.2.0

- Added host integration events and optional `window.startProjectSystem` hook.
- Preserved no-redirect contract.
- Added Save-Data and reduced-motion aware boot path.
- Disabled skip control after READY and guarded repeated handoff.
- Added non-active phase pointer fence.
- Added critical asset preloads and low priority to deferred assets.
- Preserved Clean-Eyes transparent PNG and all Web-HQ assets.
