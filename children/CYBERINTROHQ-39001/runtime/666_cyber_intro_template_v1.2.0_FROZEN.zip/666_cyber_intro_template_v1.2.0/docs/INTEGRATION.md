# Integration — v1.2.0

The template emits three browser events:
- `cyberintro:ready` after Phase 1 reaches READY.
- `cyberintro:intro` when Phase 2 becomes visible.
- `cyberintro:project-handoff` when the local project area is opened.

Optional host hook: define `window.startProjectSystem(payload)` before the handoff. No redirect is performed by the template.
