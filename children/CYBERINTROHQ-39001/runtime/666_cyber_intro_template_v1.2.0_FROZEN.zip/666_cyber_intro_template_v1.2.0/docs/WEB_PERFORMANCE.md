# Web Performance — v1.2.0

- Transparent PNG assets remain web-optimized.
- Critical Phase-1 assets are preloaded.
- Deferred Phase-2 character/speaker assets use lazy loading and low fetch priority.
- Image dimensions remain explicit to reduce layout shift.
- `Save-Data` and reduced-motion preferences avoid unnecessary boot animation time.
- No external dependencies are required.
