# Integration v1.1.0

- Das Template bleibt eigenständig und überschreibt keine Host-Anwendung.
- Phase 1 endet sichtbar mit `READY`.
- Phase 2 startet danach kontrolliert.
- `WEITER` öffnet nur `#projectContent`; kein externer Redirect.
- Projektinhalte können in `#projectContent` ergänzt oder über eigene Host-Logik angebunden werden.
- Asset-Pfade unter `assets/images/` bleiben stabil.
- `hud_eyes.png` besitzt Transparenz und soll nicht mit einem deckenden Hintergrund ersetzt werden.
