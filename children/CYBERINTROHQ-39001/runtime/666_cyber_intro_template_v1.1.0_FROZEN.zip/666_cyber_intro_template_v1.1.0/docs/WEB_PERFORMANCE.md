# Web Performance Hinweise

## Bereits umgesetzt
- transparente PNGs weboptimiert
- kritische Bilder vorgeladen
- intrinsische Maße gegen Layout Shift
- asynchrones Bild-Decoding
- Lazy Loading nur für nicht kritische Intro-Dekoration

## Empfohlene Server-/Cloudflare-Regeln
- `assets/*`: `Cache-Control: public, max-age=31536000, immutable` bei versionsgebundenen Deployments
- `css/*`, `js/*`: lange Cachezeit nur bei Dateiversionierung oder kontrollierter Invalidierung
- `index.html`: kurze Cachezeit / Revalidation
- Brotli/Gzip für HTML, CSS und JS aktivieren

Keine zusätzlichen Abos oder externen CDNs sind für das Template erforderlich.
