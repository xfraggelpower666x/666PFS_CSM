(() => {
  'use strict';

  const CONFIG = {
    bootDurationMs: 6200,
    readyHoldMs: 850,
    autoStartIntro: true,
    autoOpenProjectContent: false,
    projectTitle: 'CYBER INTRO TEMPLATE',
    projectSubtitle: 'Sound becomes feeling.',
    version: '1.1.0'
  };

  const messages = [
    'SYSTEM CORE ONLINE',
    'VISUAL LAYERS SYNCHRONIZED',
    'HUD CHANNELS LINKED',
    'AUDIO-REACTIVE PORTS STANDBY',
    'LYVRA IDENTITY LAYER AVAILABLE',
    'PROJECT HANDOFF PREPARED'
  ];

  const phaseBoot = document.getElementById('phaseBoot');
  const phaseIntro = document.getElementById('phaseIntro');
  const bootLog = document.getElementById('bootLog');
  const progressBar = document.getElementById('progressBar');
  const progressValue = document.getElementById('progressValue');
  const progressLabel = document.getElementById('progressLabel');
  const readyLabel = document.getElementById('readyLabel');
  const transitionFlash = document.getElementById('transitionFlash');
  const skipBoot = document.getElementById('skipBoot');
  const continueButton = document.getElementById('continueButton');
  const projectContent = document.getElementById('projectContent');

  document.getElementById('projectTitle').textContent = CONFIG.projectTitle;
  document.getElementById('projectSubtitle').textContent = CONFIG.projectSubtitle;

  let finished = false;
  let startAt = performance.now();
  let lastMessageIndex = -1;
  let rafId = null;
  let introTimer = null;
  let introShown = false;

  function appendMessage(index) {
    if (index <= lastMessageIndex || !messages[index]) return;
    const line = document.createElement('div');
    line.className = 'boot-line';
    line.textContent = messages[index];
    bootLog.appendChild(line);
    lastMessageIndex = index;
  }

  function renderProgress(now) {
    if (finished) return;
    const elapsed = now - startAt;
    const ratio = Math.min(1, elapsed / CONFIG.bootDurationMs);
    const percent = Math.round(ratio * 100);

    progressBar.style.width = `${percent}%`;
    progressValue.textContent = `${percent}%`;

    const messageIndex = Math.min(messages.length - 1, Math.floor(ratio * messages.length));
    appendMessage(messageIndex);

    if (ratio < .2) progressLabel.textContent = 'INITIALIZING';
    else if (ratio < .55) progressLabel.textContent = 'SYNCHRONIZING';
    else if (ratio < .86) progressLabel.textContent = 'ASSEMBLING';
    else progressLabel.textContent = 'FINALIZING';

    if (ratio >= 1) {
      completeBoot();
      return;
    }
    rafId = requestAnimationFrame(renderProgress);
  }

  function completeBoot() {
    if (finished) return;
    finished = true;
    if (rafId) cancelAnimationFrame(rafId);
    progressBar.style.width = '100%';
    progressValue.textContent = '100%';
    progressLabel.textContent = 'SYSTEM READY';
    messages.forEach((_, i) => appendMessage(i));
    readyLabel.classList.add('is-ready');

    if (CONFIG.autoStartIntro) {
      introTimer = window.setTimeout(showIntro, CONFIG.readyHoldMs);
    }
  }

  function showIntro() {
    if (introShown) return;
    introShown = true;
    if (introTimer) { window.clearTimeout(introTimer); introTimer = null; }
    transitionFlash.classList.remove('fire');
    void transitionFlash.offsetWidth;
    transitionFlash.classList.add('fire');

    phaseBoot.classList.remove('is-active');
    phaseIntro.classList.add('is-active');
  }

  function showProjectContent() {
    if (!CONFIG.autoOpenProjectContent) {
      // Kein Redirect: wir zeigen nur den lokalen Zielbereich.
      phaseIntro.classList.remove('is-active');
      projectContent.hidden = false;
      projectContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
  }

  skipBoot.addEventListener('click', () => {
    completeBoot();
    showIntro();
  });

  continueButton.addEventListener('click', showProjectContent);

  rafId = requestAnimationFrame(renderProgress);
})();
