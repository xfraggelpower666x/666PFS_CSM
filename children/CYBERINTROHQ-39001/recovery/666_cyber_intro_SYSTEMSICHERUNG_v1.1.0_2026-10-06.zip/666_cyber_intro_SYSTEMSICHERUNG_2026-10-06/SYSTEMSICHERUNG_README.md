# 666 Cyber Intro Systemsicherung

- Current frozen release: `666_cyber_intro_template_v1.1.0_FROZEN.zip`
- Preserved previous release: `PREVIOUS_666_cyber_intro_template_v1.0.0.zip`

The previous archive is retained unchanged for rollback/history.
