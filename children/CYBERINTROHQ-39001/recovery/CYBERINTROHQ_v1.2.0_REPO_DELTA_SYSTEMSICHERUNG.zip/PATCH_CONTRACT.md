# v1.1.0 -> v1.2.0 exact evolution contract

INDEX:
- title to v1.2.0
- preload brand_lyvra_primary.png and cyber_core.png
- aria-controls on INTRO STARTEN and WEITER
- fetchpriority=low on lazy Phase-2 character/speakers

JS:
- CONFIG.version=1.2.0
- detect prefers-reduced-motion and navigator.connection.saveData
- emit cyberintro:ready, cyberintro:intro, cyberintro:project-handoff
- optional window.startProjectSystem({source: CYBERINTROHQ, version: 1.2.0})
- repeated handoff guard
- disable skip after READY
- reduced-motion/save-data fast boot path

CSS APPEND:
.ghost-button:disabled { opacity: .5; cursor: default; transform: none; box-shadow: none; }
.phase:not(.is-active) { pointer-events: none; }
.phase.is-active { pointer-events: auto; }
@media (prefers-reduced-motion: reduce) { .bg-pulse, .cyber-core, .ring-a, .ring-b, .ready-label.is-ready { animation: none !important; } }
