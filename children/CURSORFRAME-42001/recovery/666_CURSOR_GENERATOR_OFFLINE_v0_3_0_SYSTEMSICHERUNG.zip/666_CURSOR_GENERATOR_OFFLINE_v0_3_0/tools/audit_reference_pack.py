from pathlib import Path
import sys, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.core.pack_scanner import extract_pack, scan_pack, save_report
src=ROOT/'reference_packs'/'666_LYVRA_NEON_CHARACTER_WINDOWS_CURSOR_PACK_v2_1_BATCH.zip'
work=ROOT/'projects'/'_reference_audit'
root=extract_pack(src,work)
rep=scan_pack(root)
out=ROOT/'logs'/'REFERENCE_PACK_AUDIT.json'
save_report(rep,out)
print(json.dumps(rep['summary'],indent=2))
print(out)
