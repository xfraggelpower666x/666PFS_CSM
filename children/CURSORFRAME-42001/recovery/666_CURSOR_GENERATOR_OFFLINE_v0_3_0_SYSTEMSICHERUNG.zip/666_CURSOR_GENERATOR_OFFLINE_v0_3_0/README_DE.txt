666 CURSOR GENERATOR — OFFLINE v0.3.0
=====================================

EIGENSTÄNDIGES OFFLINE-FRAMEWORK
Dieses Projekt ist das neue allgemeine lokale Cursor-Generator-Framework dieses Chats.
Es darf nicht allein wegen Namensähnlichkeit mit einem bereits existierenden PFS-Child
oder einem anderen Cursor-Generator zusammengeführt werden.

FUNKTIONEN
- ZIP-/Ordner-Import ohne destruktives Überschreiben
- 17 Windows-Cursorrollen
- 32 / 48 / 64 / 96 px
- Multi-Size CUR
- CUR Reader + Writer
- ANI Reader + Writer-Kern
- PNG-Ordner -> CUR-Set
- Role Editor für einzelne Rollen
- persistente Hotspot-Profile
- Glow-Parameter pro neu erzeugter Rolle
- Audit + SHA-256
- Pack-ZIP-Export mit Manifest und Checksums
- direkte Windows-Aktivierung mit Backup, Readback und Restore
- vollständig offline

START
`START_666_CURSOR_GENERATOR.bat`

ROLE EDITOR
1. Pack importieren oder erzeugen.
2. Rolle in der Matrix markieren.
3. ROLE EDITOR öffnen.
4. PNG wählen, Hotspot/Glow einstellen.
5. Nur diese Rolle wird in 32/48/64/96 und MULTI_SIZE neu erzeugt.

EXPORT ZIP
EXPORT ZIP erzeugt ein transportables Cursor-Pack. Vor dem ZIP werden PACK_INFO.json
und SHA256SUMS.txt aktualisiert. Neben dem ZIP entsteht eine `.zip.sha256`-Datei.

WINDOWS AKTIVIERUNG
Preflight -> Backup -> versionierte Installation -> Hash-Readback -> HKCU Registry ->
Schema-Registrierung -> Windows Reload -> Registry-Readback.

STATUS
Build-/Parser-/Generator-Audit: VERIFIZIERT.
Windows Runtime Activation: READBACK_PENDING, bis das Paket auf einem realen Windows-System getestet wurde.
