@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -c "import PIL" >nul 2>nul || (echo Pillow fehlt. Installiere offline/lokal nach requirements.txt.& pause& exit /b 2)
  py -3 app\main.py
) else (
  python -c "import PIL" >nul 2>nul || (echo Python/Pillow fehlt.& pause& exit /b 2)
  python app\main.py
)
if errorlevel 1 pause
