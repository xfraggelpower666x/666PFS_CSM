from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from PIL import Image, ImageTk
from app.core.image_pipeline import build_static_role

class RoleEditor(tk.Toplevel):
    def __init__(self, master, role:str, pack_root:Path, default_ratio=(0.5,0.5), on_saved=None):
        super().__init__(master)
        self.role=role; self.pack_root=Path(pack_root); self.on_saved=on_saved
        self.source:Path|None=None; self.preview_ref=None
        self.title(f'Role Editor — {role}'); self.geometry('680x520'); self.resizable(False,False)
        self.hx=tk.DoubleVar(value=default_ratio[0]); self.hy=tk.DoubleVar(value=default_ratio[1]); self.glow=tk.DoubleVar(value=0.0)
        self._build()

    def _build(self):
        frm=ttk.Frame(self,padding=14); frm.pack(fill='both',expand=True)
        ttk.Label(frm,text=f'Cursor-Rolle: {self.role}',font=('Segoe UI',14,'bold')).pack(anchor='w')
        ttk.Button(frm,text='PNG AUSWÄHLEN',command=self.choose).pack(anchor='w',pady=(12,8))
        self.path_lbl=ttk.Label(frm,text='Noch keine Quelle gewählt'); self.path_lbl.pack(anchor='w')
        self.canvas=tk.Canvas(frm,width=240,height=240,bg='#111',highlightthickness=1,highlightbackground='#555'); self.canvas.pack(pady=12)
        grid=ttk.Frame(frm); grid.pack(fill='x')
        ttk.Label(grid,text='Hotspot X (0..1)').grid(row=0,column=0,sticky='w'); ttk.Entry(grid,textvariable=self.hx,width=10).grid(row=0,column=1,padx=8)
        ttk.Label(grid,text='Hotspot Y (0..1)').grid(row=1,column=0,sticky='w'); ttk.Entry(grid,textvariable=self.hy,width=10).grid(row=1,column=1,padx=8)
        ttk.Label(grid,text='Glow (0..1)').grid(row=2,column=0,sticky='w'); ttk.Entry(grid,textvariable=self.glow,width=10).grid(row=2,column=1,padx=8)
        ttk.Label(grid,text='32 / 48 / 64 / 96 + MULTI_SIZE werden nur für diese Rolle neu erzeugt.').grid(row=3,column=0,columnspan=2,sticky='w',pady=(10,0))
        ttk.Button(frm,text='ROLLE GENERIEREN',command=self.generate).pack(anchor='e',pady=(16,0))

    def choose(self):
        p=filedialog.askopenfilename(parent=self,filetypes=[('PNG','*.png')])
        if not p:return
        self.source=Path(p); self.path_lbl.config(text=str(self.source))
        try:
            im=Image.open(self.source).convert('RGBA'); im.thumbnail((220,220),Image.Resampling.LANCZOS)
            self.preview_ref=ImageTk.PhotoImage(im); self.canvas.delete('all')
            self.canvas.create_image(120,120,image=self.preview_ref)
        except Exception as e: messagebox.showerror('Preview',str(e),parent=self)

    def generate(self):
        if not self.source:return messagebox.showerror('Fehlt','Bitte zuerst ein PNG wählen.',parent=self)
        try:
            hx,hy,glow=float(self.hx.get()),float(self.hy.get()),float(self.glow.get())
            if not (0<=hx<=1 and 0<=hy<=1 and 0<=glow<=1): raise ValueError('Hotspot und Glow müssen zwischen 0 und 1 liegen.')
            build_static_role(self.source,self.role,self.pack_root,(hx,hy),glow=glow)
            if self.on_saved:self.on_saved(self.role,(hx,hy))
            messagebox.showinfo('Gespeichert',f'{self.role} wurde neu erzeugt.',parent=self)
            self.destroy()
        except Exception as e: messagebox.showerror('Fehler',str(e),parent=self)
