from __future__ import annotations
import json, sys, threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from app.core.pack_scanner import extract_pack, scan_pack, save_report, ROLE_NAMES
from app.core.image_pipeline import build_pack_from_png_folder
from app.core.hotspot_profiles import load_profiles, save_profiles
from app.core.pack_exporter import export_pack_zip
from app.ui_role_editor import RoleEditor
from app.windows.cursor_activation import activate_from_dir, restore_from_backup, latest_backup

BG='#0b0713'; PANEL='#161126'; FG='#f4eaff'; CYAN='#38e8ff'; PINK='#ff2bd6'
HOTSPOT_RATIOS = {
    'Arrow':(.05,.05),'Help':(.05,.05),'AppStarting':(.05,.05),'Wait':(.5,.5),
    'Crosshair':(.5,.5),'IBeam':(.5,.5),'NWPen':(.08,.08),'No':(.5,.5),
    'SizeNS':(.5,.5),'SizeWE':(.5,.5),'SizeNWSE':(.5,.5),'SizeNESW':(.5,.5),
    'SizeAll':(.5,.5),'UpArrow':(.5,.08),'Hand':(.25,.08),'Pin':(.5,.08),'Person':(.5,.5)
}

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('666 CURSOR GENERATOR — OFFLINE v0.3.0')
        self.geometry('1240x800'); self.minsize(980,650); self.configure(bg=BG)
        self.pack_root: Path | None = None; self.report = None
        self.hotspots = load_profiles(ROOT/'presets'/'hotspots.json')
        self._style(); self._build()
        ref = ROOT/'reference_packs'/'666_LYVRA_NEON_CHARACTER_WINDOWS_CURSOR_PACK_v2_1_BATCH.zip'
        if ref.exists(): self.after(250, lambda: self.import_pack(ref))

    def _style(self):
        s=ttk.Style(self); s.theme_use('clam')
        s.configure('TFrame',background=BG); s.configure('Panel.TFrame',background=PANEL)
        s.configure('TLabel',background=BG,foreground=FG,font=('Segoe UI',10))
        s.configure('Title.TLabel',background=BG,foreground=PINK,font=('Segoe UI',20,'bold'))
        s.configure('TButton',font=('Segoe UI',9),padding=7); s.configure('Accent.TButton',font=('Segoe UI',10,'bold'),padding=8)
        s.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=FG,rowheight=26)
        s.configure('Treeview.Heading',font=('Segoe UI',9,'bold'))

    def _build(self):
        top=ttk.Frame(self); top.pack(fill='x',padx=18,pady=(16,8))
        ttk.Label(top,text='666 CURSOR GENERATOR',style='Title.TLabel').pack(side='left')
        ttk.Label(top,text='OFFLINE · NON-DESTRUCTIVE · WINDOWS',foreground=CYAN).pack(side='left',padx=18)
        row=ttk.Frame(self); row.pack(fill='x',padx=18,pady=5)
        ttk.Button(row,text='IMPORT ZIP',style='Accent.TButton',command=self.choose_zip).pack(side='left')
        ttk.Button(row,text='IMPORT ORDNER',command=self.choose_folder).pack(side='left',padx=5)
        ttk.Button(row,text='PNG-ORDNER → CUR SET',command=self.build_from_png_folder).pack(side='left',padx=5)
        ttk.Button(row,text='SCAN / AUDIT',command=self.scan).pack(side='left',padx=5)
        ttk.Button(row,text='AUDIT JSON',command=self.export_report).pack(side='left',padx=5)
        ttk.Button(row,text='ROLE EDITOR',command=self.open_role_editor).pack(side='left',padx=5)
        ttk.Button(row,text='EXPORT ZIP',command=self.export_zip).pack(side='left',padx=5)
        ttk.Button(row,text='RESTORE LETZTES BACKUP',command=self.restore_latest).pack(side='right',padx=5)
        ttk.Button(row,text='ACTIVATE',command=self.activate).pack(side='right')
        row2=ttk.Frame(self); row2.pack(fill='x',padx=18,pady=(0,6))
        ttk.Label(row2,text='Windows-Quelle:').pack(side='left')
        self.activate_mode=tk.StringVar(value='MULTI_SIZE')
        self.mode=ttk.Combobox(row2,textvariable=self.activate_mode,state='readonly',width=14,values=['MULTI_SIZE','32px','48px','64px','96px'])
        self.mode.pack(side='left',padx=6)
        self.status=tk.StringVar(value='OFFEN · Pack importieren')
        ttk.Label(self,textvariable=self.status,foreground=CYAN).pack(fill='x',padx=18,pady=(2,8))
        body=ttk.Panedwindow(self,orient='horizontal'); body.pack(fill='both',expand=True,padx=18,pady=(0,18))
        left=ttk.Frame(body,style='Panel.TFrame'); right=ttk.Frame(body,style='Panel.TFrame'); body.add(left,weight=3); body.add(right,weight=2)
        cols=('role','32','48','64','96','multi','ani')
        self.tree=ttk.Treeview(left,columns=cols,show='headings')
        for c,w in [('role',180),('32',55),('48',55),('64',55),('96',55),('multi',75),('ani',75)]:
            self.tree.heading(c,text=c.upper()); self.tree.column(c,width=w,anchor='center')
        self.tree.pack(fill='both',expand=True,padx=8,pady=8)
        self.details=tk.Text(right,bg=PANEL,fg=FG,insertbackground=FG,relief='flat',font=('Consolas',10),wrap='word')
        self.details.pack(fill='both',expand=True,padx=10,pady=10); self.tree.bind('<<TreeviewSelect>>',self.show_selected)

    def choose_zip(self):
        p=filedialog.askopenfilename(filetypes=[('Cursor Pack ZIP','*.zip'),('Alle Dateien','*.*')])
        if p:self.import_pack(Path(p))

    def choose_folder(self):
        p=filedialog.askdirectory()
        if p:self.import_pack(Path(p))

    def import_pack(self, source:Path):
        self.status.set('READBACK_PENDING · Pack wird lokal versioniert importiert…')
        def work():
            try:
                root=extract_pack(source,ROOT/'projects'); rep=scan_pack(root)
                self.pack_root=root; self.report=rep; self.after(0,self.render)
            except Exception as e:
                self.after(0,lambda err=e:(self.status.set('BLOCKIERT · Importfehler'),messagebox.showerror('Importfehler',str(err))))
        threading.Thread(target=work,daemon=True).start()

    def build_from_png_folder(self):
        src=filedialog.askdirectory(title='Ordner mit Arrow.png, Help.png, ... auswählen')
        if not src:return
        name=simpledialog.askstring('Set-Name','Name des neuen Cursor-Sets:',initialvalue='666_Custom_Cursor_Set')
        if not name:return
        safe=''.join(c if c.isalnum() or c in '._-' else '_' for c in name).strip('_') or 'CursorSet'
        out=ROOT/'projects'/f'{safe}__generated'
        if out.exists():
            i=2
            while (ROOT/'projects'/f'{safe}__generated_{i}').exists(): i+=1
            out=ROOT/'projects'/f'{safe}__generated_{i}'
        try:
            result=build_pack_from_png_folder(src,out,ROLE_NAMES,self.hotspots)
            self.pack_root=out; self.report=scan_pack(out); self.render()
            messagebox.showinfo('Generator',f"Erzeugt: {len(result['built'])} Rollen\nFehlend: {len(result['missing'])}\n{out}")
        except Exception as e: messagebox.showerror('Generatorfehler',str(e))


    def open_role_editor(self):
        if not self.pack_root:
            return messagebox.showinfo('Role Editor','Zuerst ein Pack importieren oder erzeugen.')
        sel=self.tree.selection()
        role=sel[0] if sel else 'Arrow'
        ratio=self.hotspots.get(role,(0.5,0.5))
        RoleEditor(self,role,self.pack_root,ratio,on_saved=self._role_saved)

    def _role_saved(self, role, ratio):
        self.hotspots[role]=ratio
        save_profiles(ROOT/'presets'/'hotspots.json',self.hotspots)
        self.report=scan_pack(self.pack_root)
        self.render()

    def export_zip(self):
        if not self.pack_root:
            return messagebox.showinfo('Export','Zuerst ein Pack importieren oder erzeugen.')
        p=filedialog.asksaveasfilename(defaultextension='.zip',initialfile=f'{self.pack_root.name}.zip',filetypes=[('ZIP','*.zip')])
        if not p:return
        try:
            out=export_pack_zip(self.pack_root,p)
            messagebox.showinfo('Export',f"ZIP erstellt\n{out['zip']}\nSHA256: {out['sha256']}")
        except Exception as e:
            messagebox.showerror('Exportfehler',str(e))

    def scan(self):
        if not self.pack_root:return
        self.report=scan_pack(self.pack_root); self.render()

    def render(self):
        for x in self.tree.get_children():self.tree.delete(x)
        r=self.report or {}
        for role in ROLE_NAMES:
            sizes=r.get('roles',{}).get(role,{})
            vals=[role]+[('✓' if str(s) in sizes else '—') for s in [32,48,64,96]]+[('✓' if role in r.get('multi_size',{}) else '—'),('✓' if role in r.get('ani',{}) else '—')]
            self.tree.insert('', 'end', iid=role, values=vals)
        s=r.get('summary',{})
        status='VERIFIZIERT' if s.get('error_count',1)==0 and s.get('core_roles_complete_all_sizes') and s.get('core_multi_complete') else ('PARTIAL' if s.get('error_count',0)==0 else 'REPAIR')
        self.status.set(f"{status} · Rollen {s.get('role_count_any',0)}/17 · MULTI {s.get('multi_size_count',0)}/17 · ANI {s.get('ani_role_count',0)} · Fehler {s.get('error_count',0)} · Warnungen {s.get('warning_count',0)}")
        self.details.delete('1.0','end'); self.details.insert('end',json.dumps({'root':r.get('root'),'summary':s,'errors':r.get('errors',[]),'warnings':r.get('warnings',[])},ensure_ascii=False,indent=2))

    def show_selected(self,_=None):
        sel=self.tree.selection()
        if not sel or not self.report:return
        role=sel[0]; d={'role':role,'sizes':self.report.get('roles',{}).get(role,{}),'multi_size':self.report.get('multi_size',{}).get(role),'ani':self.report.get('ani',{}).get(role)}
        self.details.delete('1.0','end');self.details.insert('end',json.dumps(d,ensure_ascii=False,indent=2))

    def export_report(self):
        if not self.report:return
        p=filedialog.asksaveasfilename(defaultextension='.json',initialfile='cursor_pack_audit.json',filetypes=[('JSON','*.json')])
        if p:save_report(self.report,p)

    def _activation_dir(self) -> Path | None:
        if not self.pack_root:return None
        mode=self.activate_mode.get()
        return self.pack_root/'MULTI_SIZE' if mode=='MULTI_SIZE' else self.pack_root/mode/'cursors'

    def activate(self):
        if sys.platform!='win32':
            return messagebox.showinfo('Windows erforderlich','Die Aktivierungs-Engine kann nur auf Windows ausgeführt werden. Der Code ist enthalten und offline.')
        cdir=self._activation_dir()
        if not cdir or not cdir.exists():return messagebox.showerror('Fehlt',f'Cursor-Quelle nicht gefunden: {cdir}')
        if not messagebox.askyesno('Cursor aktivieren','Preflight → Backup → versionierte Installation → Registry → Reload → Readback. Fortfahren?'):return
        try:
            out=activate_from_dir(cdir,self.pack_root.name,ROOT/'backups')
            messagebox.showinfo('Aktivierung',json.dumps({'status':out['status'],'backup':out['backup'],'installed_to':out['installed_to'],'reload_ok':out['reload_ok'],'mismatches':out['mismatches']},indent=2))
        except Exception as e:messagebox.showerror('Aktivierungsfehler',str(e))

    def restore_latest(self):
        if sys.platform!='win32': return messagebox.showinfo('Windows erforderlich','Restore kann nur auf Windows ausgeführt werden.')
        b=latest_backup(ROOT/'backups')
        if not b:return messagebox.showinfo('Backup','Noch kein Windows-Cursor-Backup vorhanden.')
        if not messagebox.askyesno('Restore',f'Letztes Backup wiederherstellen?\n{b}'):return
        try:
            out=restore_from_backup(b); messagebox.showinfo('Restore',json.dumps({'status':out['status'],'reload_ok':out['reload_ok'],'mismatches':out['mismatches']},indent=2))
        except Exception as e: messagebox.showerror('Restore-Fehler',str(e))

if __name__=='__main__': App().mainloop()
