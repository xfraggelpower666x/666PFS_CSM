from __future__ import annotations
from pathlib import Path
from datetime import datetime
import json, zipfile, shutil, hashlib, os
from .cursor_formats import read_cur, read_ani, cur_to_dict, ani_to_dict

ROLE_NAMES = ["Arrow","Help","AppStarting","Wait","Crosshair","IBeam","NWPen","No","SizeNS","SizeWE","SizeNWSE","SizeNESW","SizeAll","UpArrow","Hand","Pin","Person"]
CORE_ROLES = ROLE_NAMES[:15]
SIZES = [32,48,64,96]
MAX_ZIP_FILES = 5000
MAX_ZIP_UNCOMPRESSED = 512 * 1024 * 1024
MAX_MEMBER_SIZE = 64 * 1024 * 1024


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def _unique_target(dest: Path, stem: str) -> Path:
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    return dest / f'{stem}__import_{stamp}'


def extract_pack(source: str | Path, dest: str | Path) -> Path:
    source, dest = Path(source), Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    target = _unique_target(dest, source.stem if source.is_file() else source.name)
    if source.is_dir():
        shutil.copytree(source, target)
    else:
        if source.suffix.lower() != '.zip':
            raise ValueError('Nur Verzeichnis oder ZIP unterstützt')
        target.mkdir(parents=True)
        target_resolved = target.resolve()
        with zipfile.ZipFile(source) as z:
            members = z.infolist()
            if len(members) > MAX_ZIP_FILES:
                raise ValueError('ZIP enthält zu viele Einträge')
            total = 0
            for member in members:
                # Symlinks aus ZIPs werden nicht importiert.
                mode = (member.external_attr >> 16) & 0xFFFF
                if (mode & 0o170000) == 0o120000:
                    raise ValueError(f'Symlink im ZIP nicht erlaubt: {member.filename}')
                if member.file_size > MAX_MEMBER_SIZE:
                    raise ValueError(f'ZIP-Datei zu groß: {member.filename}')
                total += member.file_size
                if total > MAX_ZIP_UNCOMPRESSED:
                    raise ValueError('ZIP entpackt zu groß')
                out = (target / member.filename).resolve()
                try:
                    out.relative_to(target_resolved)
                except ValueError:
                    raise ValueError(f'Unsicherer ZIP-Pfad erkannt: {member.filename}')
                # zusätzlich absolute / drive paths verhindern
                if Path(member.filename).is_absolute() or os.path.splitdrive(member.filename)[0]:
                    raise ValueError(f'Absoluter ZIP-Pfad erkannt: {member.filename}')
            z.extractall(target)
    kids = [x for x in target.iterdir() if x.name != '__MACOSX']
    if len(kids) == 1 and kids[0].is_dir():
        return kids[0]
    return target


def scan_pack(root: str | Path) -> dict:
    root = Path(root)
    result = {
        'root': str(root), 'roles': {}, 'sizes': {}, 'multi_size': {},
        'ani': {}, 'errors': [], 'warnings': [], 'files': {}
    }
    for size in SIZES:
        cdir = root / f'{size}px' / 'cursors'
        found = []
        if cdir.exists():
            for role in ROLE_NAMES:
                cur = cdir / f'{role}.cur'
                ani = cdir / f'{role}.ani'
                if cur.exists():
                    try:
                        info = cur_to_dict(read_cur(cur)); found.append(role)
                        info['sha256'] = sha256(cur)
                        result['roles'].setdefault(role, {})[str(size)] = info
                    except Exception as e: result['errors'].append(f'{cur}: {e}')
                if ani.exists():
                    try:
                        info = ani_to_dict(read_ani(ani)); info['sha256'] = sha256(ani)
                        if not info['riff_ok']:
                            result['errors'].append(f'{ani}: RIFF/ACON ungültig')
                        result['ani'].setdefault(role, {})[str(size)] = info
                    except Exception as e: result['errors'].append(f'{ani}: {e}')
        result['sizes'][str(size)] = found
    mdir = root / 'MULTI_SIZE'
    if mdir.exists():
        for role in ROLE_NAMES:
            cur = mdir / f'{role}.cur'
            if cur.exists():
                try:
                    info = cur_to_dict(read_cur(cur)); info['sha256'] = sha256(cur)
                    dims = sorted({i['width'] for i in info['images']})
                    info['dimensions'] = dims
                    result['multi_size'][role] = info
                    missing_dims = [s for s in SIZES if s not in dims]
                    if missing_dims:
                        result['warnings'].append(f'MULTI_SIZE {role}: Größen fehlen {missing_dims}')
                except Exception as e: result['errors'].append(f'{cur}: {e}')
    for role in CORE_ROLES:
        if role not in result['multi_size']:
            result['warnings'].append(f'MULTI_SIZE fehlt: {role}')
    for size in SIZES:
        missing = [r for r in CORE_ROLES if r not in result['sizes'][str(size)]]
        if missing:
            result['warnings'].append(f'{size}px Kernrollen fehlen: {", ".join(missing)}')
    result['summary'] = {
        'role_count_any': len({r for r,s in result['roles'].items() if s}),
        'core_roles_complete_all_sizes': all(all(r in result['sizes'][str(s)] for r in CORE_ROLES) for s in SIZES),
        'multi_size_count': len(result['multi_size']),
        'core_multi_complete': all(r in result['multi_size'] for r in CORE_ROLES),
        'ani_role_count': len(result['ani']),
        'error_count': len(result['errors']),
        'warning_count': len(result['warnings'])
    }
    return result


def save_report(report: dict, path: str | Path):
    Path(path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
