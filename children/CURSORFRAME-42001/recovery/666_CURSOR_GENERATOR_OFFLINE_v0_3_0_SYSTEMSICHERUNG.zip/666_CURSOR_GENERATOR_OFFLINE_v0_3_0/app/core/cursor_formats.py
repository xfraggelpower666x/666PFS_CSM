from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable
import struct

@dataclass
class CurImage:
    width: int
    height: int
    hotspot_x: int
    hotspot_y: int
    bytes_in_res: int
    offset: int

@dataclass
class CurInfo:
    path: str
    count: int
    images: list[CurImage]

@dataclass
class AniInfo:
    path: str
    riff_ok: bool
    form: str
    chunks: list[str]
    frame_count_hint: int | None
    step_count_hint: int | None = None
    rate_jiffies_hint: int | None = None


def read_cur(path: str | Path) -> CurInfo:
    p = Path(path)
    data = p.read_bytes()
    if len(data) < 6:
        raise ValueError("CUR-Datei zu kurz")
    reserved, typ, count = struct.unpack_from("<HHH", data, 0)
    if reserved != 0 or typ != 2 or count < 1:
        raise ValueError("Keine gültige Windows-CUR-Datei")
    need = 6 + count * 16
    if len(data) < need:
        raise ValueError("CUR-Verzeichnis abgeschnitten")
    images: list[CurImage] = []
    for i in range(count):
        off = 6 + i * 16
        w, h, _colors, entry_reserved, hx, hy, size, offset = struct.unpack_from("<BBBBHHII", data, off)
        if entry_reserved != 0:
            raise ValueError(f"CUR-Eintrag {i} hat ungültiges Reserved-Byte")
        w = 256 if w == 0 else w
        h = 256 if h == 0 else h
        if hx >= w or hy >= h:
            raise ValueError(f"CUR-Hotspot {i} außerhalb des Bildes: {hx},{hy} bei {w}x{h}")
        if size < 8 or offset < need or offset + size > len(data):
            raise ValueError(f"CUR-Bild {i} zeigt außerhalb der Datei")
        images.append(CurImage(w, h, hx, hy, size, offset))
    return CurInfo(str(p), count, images)


def _chunk(cid: bytes, payload: bytes) -> bytes:
    if len(cid) != 4:
        raise ValueError("RIFF Chunk-ID muss 4 Bytes lang sein")
    out = cid + struct.pack("<I", len(payload)) + payload
    if len(payload) & 1:
        out += b"\x00"
    return out


def _parse_ani_chunks(data: bytes, start: int, end: int, chunks: list[str]) -> tuple[int | None, int | None, int | None]:
    frames = steps = rate = None
    pos = start
    while pos + 8 <= end:
        cid = data[pos:pos+4]
        size = struct.unpack_from("<I", data, pos+4)[0]
        payload = pos + 8
        chunk_end = payload + size
        if chunk_end > end or chunk_end > len(data):
            raise ValueError("ANI-Chunk abgeschnitten")
        name = cid.decode("ascii", "replace")
        chunks.append(name)
        if cid == b"anih" and size >= 36:
            vals = struct.unpack_from("<9I", data, payload)
            frames, steps, rate = vals[1], vals[2], vals[7]
        elif cid == b"LIST" and size >= 4:
            list_type = data[payload:payload+4].decode("ascii", "replace")
            chunks.append(f"LIST:{list_type}")
            f2, s2, r2 = _parse_ani_chunks(data, payload+4, chunk_end, chunks)
            frames = frames if frames is not None else f2
            steps = steps if steps is not None else s2
            rate = rate if rate is not None else r2
        pos = chunk_end + (size & 1)
    return frames, steps, rate


def read_ani(path: str | Path) -> AniInfo:
    p = Path(path)
    data = p.read_bytes()
    if len(data) < 12 or data[:4] != b"RIFF":
        return AniInfo(str(p), False, "", [], None)
    riff_size = struct.unpack_from("<I", data, 4)[0]
    if riff_size + 8 > len(data):
        raise ValueError("ANI-RIFF-Größe zeigt außerhalb der Datei")
    form = data[8:12].decode("ascii", "replace")
    chunks: list[str] = []
    frames, steps, rate = _parse_ani_chunks(data, 12, min(len(data), riff_size + 8), chunks)
    return AniInfo(str(p), form == "ACON", form, chunks, frames, steps, rate)


def write_cur_from_pngs(entries: Iterable[tuple[str | Path, int, int]], output: str | Path) -> Path:
    """Erzeugt eine statische Windows-CUR mit einem oder mehreren PNG-Bildressourcen.

    Moderne Windows-Versionen akzeptieren PNG-komprimierte Cursor-Ressourcen. Die PNGs
    müssen quadratisch sein und zwischen 1 und 256 px liegen.
    """
    from PIL import Image
    prepared: list[tuple[int, int, int, int, bytes]] = []
    for png_path, hx, hy in entries:
        p = Path(png_path)
        raw = p.read_bytes()
        with Image.open(p) as im:
            w, h = im.size
        if not (1 <= w <= 256 and 1 <= h <= 256):
            raise ValueError(f"CUR-PNG außerhalb 1..256 px: {p} ({w}x{h})")
        if w != h:
            raise ValueError(f"CUR-PNG muss quadratisch sein: {p} ({w}x{h})")
        if not (0 <= hx < w and 0 <= hy < h):
            raise ValueError(f"Hotspot außerhalb des Bildes: {p} -> {hx},{hy}")
        if not raw.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError(f"Keine PNG-Datei: {p}")
        prepared.append((w, h, int(hx), int(hy), raw))
    if not prepared:
        raise ValueError("Keine CUR-Bilder angegeben")
    if len(prepared) > 65535:
        raise ValueError("Zu viele CUR-Bilder")
    header = struct.pack("<HHH", 0, 2, len(prepared))
    offset = 6 + 16 * len(prepared)
    directory = bytearray()
    payload = bytearray()
    for w, h, hx, hy, raw in prepared:
        wb = 0 if w == 256 else w
        hb = 0 if h == 256 else h
        directory += struct.pack("<BBBBHHII", wb, hb, 0, 0, hx, hy, len(raw), offset)
        payload += raw
        offset += len(raw)
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(header + bytes(directory) + bytes(payload))
    read_cur(out)  # direkter struktureller Readback
    return out


def write_ani_from_cur_frames(frame_paths: Iterable[str | Path], output: str | Path,
                              rate_jiffies: int = 6, sequence: list[int] | None = None) -> Path:
    """Erzeugt einen Windows-ANI-Container aus CUR-Frames.

    60 jiffies = 1 Sekunde. rate_jiffies=6 entspricht ca. 10 FPS.
    """
    frames = [Path(p) for p in frame_paths]
    if not frames:
        raise ValueError("Keine ANI-Frames angegeben")
    for p in frames:
        read_cur(p)
    if not (1 <= rate_jiffies <= 6000):
        raise ValueError("rate_jiffies außerhalb des erlaubten Bereichs")
    seq = sequence[:] if sequence is not None else list(range(len(frames)))
    if not seq or any(i < 0 or i >= len(frames) for i in seq):
        raise ValueError("Ungültige ANI-Sequenz")
    flags = 0x1 | 0x2  # AF_ICON | AF_SEQUENCE
    anih = struct.pack("<9I", 36, len(frames), len(seq), 0, 0, 0, 0, rate_jiffies, flags)
    rate = struct.pack("<" + "I" * len(seq), *([rate_jiffies] * len(seq)))
    seq_payload = struct.pack("<" + "I" * len(seq), *seq)
    fram_payload = b"fram" + b"".join(_chunk(b"icon", p.read_bytes()) for p in frames)
    body = b"ACON" + _chunk(b"anih", anih) + _chunk(b"rate", rate) + _chunk(b"seq ", seq_payload) + _chunk(b"LIST", fram_payload)
    riff = b"RIFF" + struct.pack("<I", len(body)) + body
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(riff)
    info = read_ani(out)
    if not info.riff_ok or info.frame_count_hint != len(frames):
        raise ValueError("ANI-Readback fehlgeschlagen")
    return out


def cur_to_dict(info: CurInfo):
    return {"path": info.path, "count": info.count, "images": [asdict(x) for x in info.images]}


def ani_to_dict(info: AniInfo):
    return asdict(info)
