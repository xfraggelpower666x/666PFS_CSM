from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, re

PROJECT_VERSION = 2

def safe_name(name: str) -> str:
    name = re.sub(r'[^A-Za-z0-9._-]+', '_', name.strip()).strip('._-')
    return name or 'CursorProject'


def create_project(projects_root: str | Path, name: str) -> Path:
    root = Path(projects_root) / safe_name(name)
    root.mkdir(parents=True, exist_ok=False)
    data = {
        'format': '666cursor-project',
        'format_version': PROJECT_VERSION,
        'name': name,
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'updated_utc': datetime.now(timezone.utc).isoformat(),
        'non_destructive': True,
        'roles': {}
    }
    save_project(root, data)
    return root


def save_project(root: str | Path, data: dict) -> Path:
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    data = dict(data)
    data['updated_utc'] = datetime.now(timezone.utc).isoformat()
    path = root / 'project.666cursor.json'
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)
    return path


def load_project(root: str | Path) -> dict:
    p = Path(root) / 'project.666cursor.json'
    data = json.loads(p.read_text(encoding='utf-8'))
    if data.get('format') != '666cursor-project':
        raise ValueError('Unbekanntes Projektformat')
    return data
