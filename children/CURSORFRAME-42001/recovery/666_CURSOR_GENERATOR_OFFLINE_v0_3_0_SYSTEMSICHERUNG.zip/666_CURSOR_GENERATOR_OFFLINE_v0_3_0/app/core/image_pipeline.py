from __future__ import annotations
from pathlib import Path
from typing import Mapping
from PIL import Image, ImageFilter
from .cursor_formats import write_cur_from_pngs

DEFAULT_SIZES = (32, 48, 64, 96)


def _safe_role(role: str) -> str:
    return ''.join(c for c in role if c.isalnum() or c in '_-')


def render_variant(source: str | Path, output: str | Path, size: int,
                   padding_ratio: float = 0.06, glow: float = 0.0) -> Path:
    if size < 16 or size > 256:
        raise ValueError("Cursorgröße muss zwischen 16 und 256 px liegen")
    src = Path(source)
    with Image.open(src) as im:
        rgba = im.convert('RGBA')
        pad = max(0, int(round(size * padding_ratio)))
        box = max(1, size - pad * 2)
        rgba.thumbnail((box, box), Image.Resampling.LANCZOS)
        canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        x = (size - rgba.width) // 2
        y = (size - rgba.height) // 2
        if glow > 0:
            alpha = rgba.getchannel('A')
            radius = max(1, round(size * min(glow, 1.0) * 0.06))
            halo = alpha.filter(ImageFilter.GaussianBlur(radius))
            glow_layer = Image.new('RGBA', rgba.size, (255, 255, 255, 0))
            glow_layer.putalpha(halo)
            canvas.alpha_composite(glow_layer, (x, y))
        canvas.alpha_composite(rgba, (x, y))
        out = Path(output)
        out.parent.mkdir(parents=True, exist_ok=True)
        canvas.save(out, 'PNG', optimize=True)
        return out


def build_static_role(source: str | Path, role: str, pack_root: str | Path,
                      hotspot_ratio: tuple[float, float] = (0.05, 0.05),
                      sizes=DEFAULT_SIZES, glow: float = 0.0) -> dict:
    pack = Path(pack_root)
    role = _safe_role(role)
    entries = []
    result = {'role': role, 'sizes': {}, 'multi_size': None}
    for size in sizes:
        png = pack / '_sources_rendered' / role / f'{size}.png'
        render_variant(source, png, int(size), glow=glow)
        hx = max(0, min(size - 1, round((size - 1) * hotspot_ratio[0])))
        hy = max(0, min(size - 1, round((size - 1) * hotspot_ratio[1])))
        cur = pack / f'{size}px' / 'cursors' / f'{role}.cur'
        write_cur_from_pngs([(png, hx, hy)], cur)
        result['sizes'][str(size)] = str(cur)
        entries.append((png, hx, hy))
    multi = pack / 'MULTI_SIZE' / f'{role}.cur'
    write_cur_from_pngs(entries, multi)
    result['multi_size'] = str(multi)
    return result


def build_pack_from_png_folder(source_folder: str | Path, output_root: str | Path,
                               roles: list[str], hotspot_ratios: Mapping[str, tuple[float,float]],
                               sizes=DEFAULT_SIZES) -> dict:
    src = Path(source_folder)
    out = Path(output_root)
    out.mkdir(parents=True, exist_ok=True)
    built, missing = {}, []
    for role in roles:
        candidates = [src / f'{role}.png', src / f'{role.lower()}.png']
        source = next((p for p in candidates if p.exists()), None)
        if source is None:
            missing.append(role)
            continue
        built[role] = build_static_role(source, role, out, hotspot_ratios.get(role, (0.5,0.5)), sizes=sizes)
    return {'built': built, 'missing': missing}
