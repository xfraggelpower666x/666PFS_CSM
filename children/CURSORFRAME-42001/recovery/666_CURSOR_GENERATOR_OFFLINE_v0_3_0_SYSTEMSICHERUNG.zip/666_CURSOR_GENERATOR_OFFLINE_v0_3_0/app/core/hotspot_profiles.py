from __future__ import annotations
from pathlib import Path
import json

DEFAULT_RATIOS = {
    'Arrow':(0.05,0.05),'Help':(0.05,0.05),'AppStarting':(0.05,0.05),'Wait':(0.5,0.5),
    'Crosshair':(0.5,0.5),'IBeam':(0.5,0.5),'NWPen':(0.08,0.08),'No':(0.5,0.5),
    'SizeNS':(0.5,0.5),'SizeWE':(0.5,0.5),'SizeNWSE':(0.5,0.5),'SizeNESW':(0.5,0.5),
    'SizeAll':(0.5,0.5),'UpArrow':(0.5,0.08),'Hand':(0.25,0.08),'Pin':(0.5,0.08),'Person':(0.5,0.5)
}

def load_profiles(path: str | Path | None = None) -> dict[str, tuple[float,float]]:
    result = dict(DEFAULT_RATIOS)
    if path is None:
        return result
    p = Path(path)
    if not p.exists():
        return result
    raw = json.loads(p.read_text(encoding='utf-8'))
    for role, value in raw.items():
        if isinstance(value, list) and len(value) == 2:
            x,y = float(value[0]), float(value[1])
            if 0 <= x <= 1 and 0 <= y <= 1:
                result[role] = (x,y)
    return result

def save_profiles(path: str | Path, profiles: dict[str, tuple[float,float]]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {k:[float(v[0]),float(v[1])] for k,v in sorted(profiles.items())}
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(p)
    return p
