from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

EXCLUDE_PARTS = {'__pycache__', '.git'}

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def collect_files(root: Path):
    for p in sorted(root.rglob('*')):
        if not p.is_file():
            continue
        if any(part in EXCLUDE_PARTS for part in p.parts):
            continue
        if p.suffix.lower() in {'.pyc', '.tmp'}:
            continue
        yield p

def write_pack_metadata(root: str | Path) -> tuple[Path,Path]:
    root = Path(root)
    files=[]
    for p in collect_files(root):
        rel=p.relative_to(root).as_posix()
        if rel in {'SHA256SUMS.txt','PACK_INFO.json'}:
            continue
        files.append({'path':rel,'size':p.stat().st_size,'sha256':sha256_file(p)})
    info={
        'format':'666-cursor-pack',
        'generated_utc':datetime.now(timezone.utc).isoformat(),
        'file_count':len(files),
        'files':files,
    }
    info_path=root/'PACK_INFO.json'
    sums_path=root/'SHA256SUMS.txt'
    info_path.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    sums_path.write_text('\n'.join(f"{x['sha256']}  {x['path']}" for x in files)+'\n',encoding='utf-8')
    return info_path,sums_path

def export_pack_zip(root: str | Path, destination: str | Path) -> dict:
    root=Path(root)
    if not root.is_dir():
        raise FileNotFoundError(root)
    write_pack_metadata(root)
    dst=Path(destination)
    dst.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(dst,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in collect_files(root):
            z.write(p, arcname=f'{root.name}/{p.relative_to(root).as_posix()}')
    digest=sha256_file(dst)
    dst.with_suffix(dst.suffix+'.sha256').write_text(f'{digest}  {dst.name}\n',encoding='utf-8')
    return {'zip':str(dst),'sha256':digest,'size':dst.stat().st_size}
