from __future__ import annotations
from pathlib import Path
from datetime import datetime
import json, os, shutil, sys, hashlib

REG_PATH = r"Control Panel\Cursors"
SCHEMES_PATH = REG_PATH + r"\Schemes"
ROLES = ["Arrow","Help","AppStarting","Wait","Crosshair","IBeam","NWPen","No","SizeNS","SizeWE","SizeNWSE","SizeNESW","SizeAll","UpArrow","Hand","Pin","Person"]
SCHEME_ROLES = ROLES[:15]


def _require_windows():
    if sys.platform != 'win32':
        raise RuntimeError('Windows-Aktivierung ist nur unter Windows verfügbar.')


def _winreg():
    _require_windows(); import winreg; return winreg


def _hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def read_state() -> dict:
    w = _winreg()
    state = {'registry_path': REG_PATH, 'values': {}}
    with w.OpenKey(w.HKEY_CURRENT_USER, REG_PATH, 0, w.KEY_READ) as k:
        for name in [''] + ROLES:
            try:
                v, typ = w.QueryValueEx(k, name)
                state['values'][name or '(Default)'] = {'value': v, 'type': typ}
            except FileNotFoundError:
                state['values'][name or '(Default)'] = {'value': None, 'type': None}
    return state


def backup_state(backup_root: str | Path) -> Path:
    root = Path(backup_root)
    stamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S_%f')
    out = root / stamp
    out.mkdir(parents=True, exist_ok=False)
    state = read_state()
    (out/'registry_state.json').write_text(json.dumps(state, indent=2), encoding='utf-8')
    manifest = {'created': stamp, 'copied_cursor_files': {}}
    snapshot = out / 'cursor_files'
    snapshot.mkdir()
    for name, item in state['values'].items():
        val = item.get('value')
        if not val or name == '(Default)':
            continue
        try:
            p = Path(os.path.expandvars(val))
            if p.is_file() and p.suffix.lower() in ('.cur','.ani'):
                dst = snapshot / f'{name}{p.suffix.lower()}'
                shutil.copy2(p, dst)
                manifest['copied_cursor_files'][name] = {'source': str(p), 'backup': str(dst), 'sha256': _hash(dst)}
        except Exception as e:
            manifest['copied_cursor_files'][name] = {'source': val, 'warning': str(e)}
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    return out


def _stable_install_dir(set_name: str) -> Path:
    base = Path(os.environ.get('LOCALAPPDATA', str(Path.home()/ 'AppData/Local')))
    safe = ''.join(c if c.isalnum() or c in '._-' else '_' for c in set_name).strip('_') or 'CursorSet'
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    return base / '666CursorGenerator' / 'InstalledSets' / safe / stamp


def preflight_source(source_dir: str | Path) -> dict:
    src = Path(source_dir)
    if not src.is_dir():
        raise FileNotFoundError(src)
    found = {}
    for role in ROLES:
        choices = [src/f'{role}.ani', src/f'{role}.cur']
        p = next((x for x in choices if x.exists()), None)
        if p:
            found[role] = p
    core_missing = [r for r in SCHEME_ROLES if r not in found]
    if core_missing:
        raise ValueError('Kernrollen fehlen: ' + ', '.join(core_missing))
    return {'source': str(src), 'found': {r:str(p) for r,p in found.items()}, 'core_missing': core_missing}


def install_files(source_dir: str | Path, set_name: str) -> tuple[Path, dict]:
    pf = preflight_source(source_dir)
    dst = _stable_install_dir(set_name)
    dst.mkdir(parents=True, exist_ok=False)
    copied = {}
    for role, value in pf['found'].items():
        p = Path(value)
        target = dst / p.name
        shutil.copy2(p, target)
        if _hash(p) != _hash(target):
            raise IOError(f'Hash-Readback fehlgeschlagen: {p.name}')
        copied[role] = str(target)
    (dst/'INSTALL_MANIFEST.json').write_text(json.dumps({'set_name':set_name,'source':pf['source'],'files':copied},indent=2),encoding='utf-8')
    return dst, copied


def _reload_cursors() -> bool:
    import ctypes
    ok = ctypes.windll.user32.SystemParametersInfoW(0x0057, 0, None, 0x01 | 0x02)
    return bool(ok)


def _register_scheme(name: str, paths: dict[str,str]):
    w = _winreg()
    with w.CreateKeyEx(w.HKEY_CURRENT_USER, SCHEMES_PATH, 0, w.KEY_SET_VALUE) as k:
        value = ','.join(paths.get(role, '') for role in SCHEME_ROLES)
        w.SetValueEx(k, name, 0, w.REG_EXPAND_SZ, value)


def activate_from_dir(source_dir: str | Path, set_name: str, backup_root: str | Path) -> dict:
    _require_windows()
    w = _winreg()
    preflight_source(source_dir)  # keine Mutation vor erfolgreichem Preflight
    before = backup_state(backup_root)
    dst, copied = install_files(source_dir, set_name)
    expected = {}
    try:
        with w.OpenKey(w.HKEY_CURRENT_USER, REG_PATH, 0, w.KEY_SET_VALUE | w.KEY_READ) as k:
            for role, chosen in copied.items():
                w.SetValueEx(k, role, 0, w.REG_EXPAND_SZ, chosen)
                expected[role] = chosen
            w.SetValueEx(k, '', 0, w.REG_SZ, set_name)
        _register_scheme(set_name, expected)
        ok = _reload_cursors()
        after = read_state()
        mismatches = {}
        for role, val in expected.items():
            actual = after['values'].get(role, {}).get('value')
            if os.path.normcase(os.path.normpath(actual or '')) != os.path.normcase(os.path.normpath(val)):
                mismatches[role] = {'expected':val,'actual':actual}
        default_actual = after['values'].get('(Default)',{}).get('value')
        if default_actual != set_name:
            mismatches['(Default)'] = {'expected':set_name,'actual':default_actual}
        status = 'VERIFIED' if ok and not mismatches else 'PARTIAL'
        return {'backup': str(before), 'installed_to': str(dst), 'reload_ok': ok, 'expected': expected, 'readback': after, 'mismatches': mismatches, 'status': status}
    except Exception:
        # fail-safe: Registry-Zustand unmittelbar zurückspielen
        try: restore_from_backup(before)
        finally: raise


def restore_from_backup(backup_dir: str | Path) -> dict:
    _require_windows(); w = _winreg()
    p = Path(backup_dir)/'registry_state.json'
    state = json.loads(p.read_text(encoding='utf-8'))
    with w.OpenKey(w.HKEY_CURRENT_USER, REG_PATH, 0, w.KEY_SET_VALUE) as k:
        for name, item in state['values'].items():
            reg_name = '' if name == '(Default)' else name
            if item['value'] is None:
                try: w.DeleteValue(k, reg_name)
                except FileNotFoundError: pass
            else:
                w.SetValueEx(k, reg_name, 0, item['type'], item['value'])
    ok = _reload_cursors()
    after = read_state()
    mismatches = {}
    for name, item in state['values'].items():
        actual = after['values'].get(name, {}).get('value')
        if actual != item['value']:
            mismatches[name] = {'expected':item['value'],'actual':actual}
    return {'status':'VERIFIED' if ok and not mismatches else 'PARTIAL','reload_ok':ok,'readback':after,'mismatches':mismatches}


def latest_backup(backup_root: str | Path) -> Path | None:
    root = Path(backup_root)
    if not root.exists(): return None
    dirs = sorted((p for p in root.iterdir() if p.is_dir() and (p/'registry_state.json').exists()), reverse=True)
    return dirs[0] if dirs else None
