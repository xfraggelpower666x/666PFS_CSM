from pathlib import Path
import json, tempfile, unittest, zipfile
from PIL import Image
from app.core.hotspot_profiles import save_profiles, load_profiles
from app.core.image_pipeline import build_static_role
from app.core.pack_exporter import export_pack_zip
from app.core.pack_scanner import scan_pack

class V030FeatureTests(unittest.TestCase):
    def test_hotspot_profiles_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'hotspots.json'
            save_profiles(p,{'Arrow':(0.1,0.2)})
            got=load_profiles(p)
            self.assertEqual(got['Arrow'],(0.1,0.2))
            self.assertIn('Wait',got)

    def test_single_role_generation_and_export(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); src=root/'src.png'; pack=root/'pack'
            Image.new('RGBA',(200,140),(255,0,255,180)).save(src)
            build_static_role(src,'Arrow',pack,(0.05,0.05))
            report=scan_pack(pack)
            self.assertIn('Arrow',report['multi_size'])
            self.assertEqual(report['multi_size']['Arrow']['dimensions'],[32,48,64,96])
            out=export_pack_zip(pack,root/'pack.zip')
            self.assertTrue(Path(out['zip']).exists())
            self.assertEqual(len(out['sha256']),64)
            with zipfile.ZipFile(out['zip']) as z:
                names=z.namelist()
                self.assertTrue(any(n.endswith('/PACK_INFO.json') for n in names))
                self.assertTrue(any(n.endswith('/SHA256SUMS.txt') for n in names))

if __name__=='__main__': unittest.main()
