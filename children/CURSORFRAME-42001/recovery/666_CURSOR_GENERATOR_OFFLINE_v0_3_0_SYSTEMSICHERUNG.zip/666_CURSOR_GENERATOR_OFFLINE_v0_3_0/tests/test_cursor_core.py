from pathlib import Path
import tempfile, unittest, zipfile
from PIL import Image
from app.core.cursor_formats import write_cur_from_pngs, read_cur, write_ani_from_cur_frames, read_ani
from app.core.pack_scanner import extract_pack

class CursorCoreTests(unittest.TestCase):
    def test_cur_roundtrip_multisize(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); entries=[]
            for s in (32,48,64,96):
                p=root/f'{s}.png'; Image.new('RGBA',(s,s),(255,0,255,180)).save(p)
                entries.append((p, min(2,s-1), min(3,s-1)))
            out=root/'test.cur'; write_cur_from_pngs(entries,out)
            info=read_cur(out)
            self.assertEqual(info.count,4)
            self.assertEqual([x.width for x in info.images],[32,48,64,96])
    def test_ani_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); frames=[]
            for i in range(3):
                p=root/f'{i}.png'; Image.new('RGBA',(32,32),(255,i*50,255,255)).save(p)
                c=root/f'{i}.cur'; write_cur_from_pngs([(p,1,1)],c); frames.append(c)
            out=root/'test.ani'; write_ani_from_cur_frames(frames,out,6)
            info=read_ani(out)
            self.assertTrue(info.riff_ok); self.assertEqual(info.frame_count_hint,3)
    def test_zip_slip_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); z=root/'bad.zip'
            with zipfile.ZipFile(z,'w') as f: f.writestr('../evil.txt','x')
            with self.assertRaises(ValueError): extract_pack(z,root/'out')

if __name__=='__main__': unittest.main()
