# Changelog

## v0.3.0 — 2026-10-06 — AUDIT / REPAIR / EVOLUTION / FREEZE
- v0.2.0 vollständig als Ausgangsstand erhalten und weiterentwickelt.
- Role Editor ergänzt: einzelne Windows-Cursorrolle aus PNG gezielt neu erzeugen.
- Hotspot-Profile persistent unter `presets/hotspots.json`.
- Role Editor erlaubt Hotspot X/Y und Glow pro Rolle.
- Nur die gewählte Rolle wird neu erzeugt; andere Rollen bleiben unangetastet.
- Pack-Exporter ergänzt: ZIP + `PACK_INFO.json` + `SHA256SUMS.txt` + externe `.sha256`.
- Export-Hashes werden direkt nach Erstellung berechnet.
- GUI um `ROLE EDITOR` und `EXPORT ZIP` erweitert.
- Testabdeckung erweitert: 5/5 PASS.
- Referenz-Pack erneut geprüft: 17/17 Rollen, 17/17 MULTI_SIZE, 2 ANI, 0 Fehler, 0 Warnungen.
- Windows-Aktivierung bleibt unverändert geschützt: Preflight → Backup → Installation → Hash-Readback → Registry → Reload → Readback.
- Keine Cloud, kein Server, kein Account, keine Telemetrie.

## Noch offen
- echter Windows-Laufzeittest von Registry und SPI_SETCURSORS;
- direkter visueller Hotspot-Canvas mit Klickpunkt-Verschiebung;
- visueller ANI-Frame-Editor und Live-Animation;
- fertige portable EXE muss auf Windows gebaut und dort readback-getestet werden.
