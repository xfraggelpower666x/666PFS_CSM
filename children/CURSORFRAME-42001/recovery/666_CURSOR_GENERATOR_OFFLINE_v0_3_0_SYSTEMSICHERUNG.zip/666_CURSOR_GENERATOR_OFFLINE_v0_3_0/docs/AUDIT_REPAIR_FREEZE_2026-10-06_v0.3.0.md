# 666 CURSOR GENERATOR OFFLINE — AUDIT / REPAIR / EVOLUTION / FREEZE

DATE=2026-10-06
VERSION=v0.3.0
PROJECT_KIND=NEW_GENERAL_OFFLINE_CURSOR_FRAMEWORK
IDENTITY_GUARD=DO_NOT_MERGE_WITH_OTHER_CURSOR_GENERATOR_BY_NAME_SIMILARITY
CLOUD=FORBIDDEN
TELEMETRY=NONE

## AUDIT 1 — Ausgangsstand v0.2.0
- Bestehende Struktur erhalten.
- Windows-Aktivierungsengine nicht vereinfacht oder entfernt.
- Referenz-Pack und Vorgängerhistorie erhalten.

## REPAIR
- Hotspot-Konfiguration aus fest verdrahteter GUI-Logik in persistente Profile überführt.
- Einzelrollenbearbeitung ergänzt, damit Änderungen nicht das gesamte Set neu erzeugen.
- Pack-Ausgabe um reproduzierbare Inhaltsliste und SHA-256-Evidenz erweitert.

## VERBESSERUNG / WEITERENTWICKLUNG
- Role Editor: PNG-Auswahl, Vorschau, Hotspot X/Y, Glow.
- Erzeugung der selektierten Rolle in 32/48/64/96 sowie MULTI_SIZE.
- Export-ZIP mit PACK_INFO.json, SHA256SUMS.txt und externer ZIP-Prüfsumme.
- Persistente Hotspot-Profile unter presets/hotspots.json.
- UI-Schaltflächen ROLE EDITOR und EXPORT ZIP.

## AUDIT 2
- Python compileall: PASS
- Unit Tests: 5/5 PASS
- CUR Multi-Size Roundtrip: PASS
- ANI Roundtrip: PASS
- ZIP traversal block: PASS
- Hotspot Profile Roundtrip: PASS
- Einzelrollen-Generator + ZIP-Export: PASS
- LYVRA Referenz-Pack: 17/17 Rollen, 17/17 MULTI_SIZE, 2 ANI-Rollen, 0 Fehler, 0 Warnungen

## FREEZE
FREEZE_STATE=FROZEN_SOURCE_V0.3.0
WINDOWS_RUNTIME_ACTIVATION=READBACK_PENDING
WINDOWS_EXE_BUILD=READBACK_PENDING

## OFFEN
- echter Windows-Laufzeittest der Registry-/SPI_SETCURSORS-Aktivierung;
- visueller Klick-Hotspot-Editor auf Canvas;
- visueller ANI-Timeline-/Frame-Editor;
- Windows-EXE bauen und anschließend direkt testen.
