# 666 CURSOR GENERATOR — Audit / Repair / Evolution / Freeze

DATE=2026-10-06
VERSION=v0.2.0
MODE=OFFLINE_PERSONAL_WINDOWS_TOOL
CLOUD=FORBIDDEN
TELEMETRY=NONE

## Audit 1 — v0.1.0

Befunde:
- Importer behauptete ZIP/Ordner, GUI bot nur ZIP-Auswahl an.
- Import überschieb bei gleichem Namen still den bestehenden Projektordner.
- ZIP-Pfadschutz war als String-Präfixprüfung unnötig schwach; Symlinks/Archivgrößen waren nicht begrenzt.
- CUR-Parser prüfte grundlegende Struktur, aber Reserved-Byte und Hotspot-Grenzen nicht streng.
- ANI-Parser las nur Top-Level-Chunks.
- Generator/Writer fehlten; v0.1.0 war primär Import/Audit/Activation-Basis.
- Windows-Aktivierung installierte in einen stabilen Ordner und konnte dort bestehende Dateien ersetzen.
- Preflight der 15 Kernrollen vor Mutation fehlte.
- Backup enthielt Registryzustand, aber keine best-effort Cursor-Dateisnapshots.
- GUI bot keinen Restore-Button und keine Wahl zwischen Multi-Size und Einzelgröße.

## Repair / Evolution

Implementiert in v0.2.0:
- versionierter, nicht-destruktiver Import für ZIP und Verzeichnis;
- Path-Traversal-, Symlink- und ZIP-Größenhärtung;
- strenger CUR-Readback;
- CUR-Writer aus PNG-Ressourcen inklusive Multi-Size;
- ANI-Writer-Kern und rekursiver ANI-Parser;
- PNG-Ordner -> 17 Rollen -> 32/48/64/96 + MULTI_SIZE;
- SHA-256-Audit und Kernrollen-Vollständigkeitsprüfung;
- Aktivierungsauswahl MULTI_SIZE / 32 / 48 / 64 / 96;
- Windows-Preflight vor Mutation;
- versioniertes LOCALAPPDATA-Installationsziel je Aktivierung;
- Hash-Readback der kopierten Cursor-Dateien;
- Schema-Registrierung;
- Default-Schema in Registry-Readback;
- Fail-safe Restore bei Aktivierungsausnahme;
- best-effort Snapshot bereits referenzierter CUR/ANI-Dateien;
- Restore des letzten Backups in der GUI;
- Unit-Tests.

## Audit 2

VERIFIZIERT in Buildumgebung:
- Python compileall: PASS
- Unit tests: 3/3 PASS
- CUR Multi-Size Roundtrip: PASS
- ANI Roundtrip: PASS
- ZIP traversal block: PASS
- synthetischer 17-Rollen PNG -> CUR Generator: 17/17, Fehler 0, Warnungen 0
- LYVRA Referenz-Pack: Rollen 17/17, Multi-Size 17/17, ANI-Rollen 2, Fehler 0, Warnungen 0

OFFEN:
- echter Windows Registry-/SPI_SETCURSORS-Laufzeittest;
- visuelle Qualitätsprüfung der erzeugten Cursor auf Windows;
- visueller Hotspot-Editor;
- visueller ANI-Frame-Editor;
- Character-DNA/AI-Erzeugung ist bewusst nicht Teil des vollständig lokalen Basiskerns.

## Freeze

FREEZE_STATE=FROZEN_SOURCE_CANDIDATE_V0.2.0
MUTATION_AFTER_FREEZE_IN_THIS_BUILD=FORBIDDEN
PREVIOUS_VERSION=v0.1.0_PRESERVED_IN_HISTORY
REFERENCE_PACK=PRESERVED_UNMODIFIED
WINDOWS_RUNTIME_VERIFICATION=READBACK_PENDING
