@echo off
setlocal
cd /d "%~dp0"
echo [666 CURSOR GENERATOR] Windows EXE Build v0.3.0
where py >nul 2>nul || (echo Python 3 fehlt.& pause & exit /b 1)
py -3 -m pip show Pillow >nul 2>nul || (echo Pillow fehlt. Bitte: py -3 -m pip install -r requirements.txt& pause & exit /b 2)
py -3 -m PyInstaller --version >nul 2>nul || (echo PyInstaller fehlt. Bitte lokal installieren.& pause & exit /b 3)
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name 666CursorGenerator --add-data "presets;presets" --add-data "reference_packs;reference_packs" --hidden-import PIL._tkinter_finder app\main.py
if errorlevel 1 (echo BUILD FEHLGESCHLAGEN& pause& exit /b 4)
echo Fertig: dist\666CursorGenerator.exe
pause
