# LYVRADASH-39001 Changelog v1.1.0

- Externalized dashboard CSS and JavaScript for browser caching.
- Reduced HTML shell from 35,728 bytes to 9,167 bytes.
- Added deferred JavaScript loading.
- Added WebRadio origin preconnect and DNS-prefetch hints.
- Added preload hints for the initial brand and LYVRA avatar visuals.
- Added off-screen rendering optimization with content-visibility.
- Preserved all transparent PNG identity assets.
- Preserved radio iframe and audio-analysis behavior.
- No Base64 image regression.
