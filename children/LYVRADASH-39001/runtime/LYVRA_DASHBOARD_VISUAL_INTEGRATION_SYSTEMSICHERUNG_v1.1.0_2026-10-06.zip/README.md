# LYVRA Dashboard – additive Visual Identity Extension (2026-10-04)

Status: locally prepared, NOT pushed to GitHub / not deployed.

## Files
- `dashboard/index.html`: original 7.8 MB LYVRA dashboard plus isolated CSS and semantic image panel immediately after original header.
- `dashboard/assets/lyvra-identity/`: five user-supplied original pictures, unchanged bytes.

## Installation / scope
After reviewing the current productive branch and taking a fresh backup, copy the `dashboard` contents to `WEBLyvra/live/dist/dashboard/` (preserve other existing files). Do not replace the root `WEBLyvra/live/dist/index.html`. On deployment, verify the Cloudflare Pages build root points to `WEBLyvra/live/dist`, check `/dashboard/` desktop + iPhone, and check all existing topic-banner videos remain unchanged on the main page.

## Safeguards
This only inserts one section after `</header>` in the Dashboard HTML. All existing JS, callbacks, player sources, identity references and existing site videos are unmodified. Images use lazy loading, local relative paths and responsive CSS. No direct auto-sync to Suno or live state is asserted.

## v1.1.0 performance freeze — 2026-10-06
This package is an additive successor to v1.0.0. CSS and JavaScript are external cacheable assets under `dashboard/assets/runtime/`; the visual identity and radio integration remain unchanged in intent. Do not replace the WEBLYVRA native root without an explicit integration step.
