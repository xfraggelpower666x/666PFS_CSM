# CHANGELOG · LYVRA Dashboard · 2026-10-06

- Identity Assets: JPEG -> PNG nach Nutzerzuordnung.
- PNG-Weboptimierung mit erhaltener Transparenz.
- Inline-Base64-Visuals aus HTML ausgelagert und cachebar gemacht.
- Runtime-Visuals webgerecht dimensioniert.
- Haupt-HTML massiv verkleinert.
- Transparenter Neutral-Asset-Hintergrund in CSS aktiviert.
- Intrinsic Image Dimensions / Decode-Hints ergänzt.
- HTML, JS, lokale Pfade und lokaler HTTP-Serve re-auditiert.
- Stand eingefroren und mit SHA-256-Manifest gesichert.
