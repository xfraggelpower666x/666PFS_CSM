# CHANGELOG v1.4.0
- Cyber Freak Love central theme hard-locked.
- Adult-character gate added.
- Sparse/minimal neon cyber fashion made default without explicit nudity.
- Outfit presets retained as optional overrides.
- Ten cockpit/holo-cockpit frame presets added.
- Creature/vehicle/spacecraft support preserved and subordinated to core theme.
- Additional QA gates added.
- Re-audit PASS and freeze 666CFL-1.4.0.
