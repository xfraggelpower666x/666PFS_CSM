# 3DX INFORMATION & COMMAND INTELLIGENCE FRAMEWORK

**Framework ID:** `3DX-INFO-FRAMEWORK`
**Version:** `1.1.0`
**Previous Version:** `1.0.0`
**Audit Date:** `2026-08-18`
**Audit Status:** `REPAIRED / EXTENDED / SOURCE-PRESERVING`
**Status:** `ACTIVE / EXTENDABLE`
**Scope:** 3DXChat, Meredian und eindeutig gekennzeichnete 3DX-basierte Systeme
**Primary Language:** Deutsch
**Command Syntax:** Originalsyntax unverändert erhalten

---


# 0. AUDIT / REPAIR v1.1.0

## Audit-Ziel

Version `1.1.0` führt einen vollständigen Konsistenz-Audit der vorhandenen v1.0.0-Struktur durch, repariert widersprüchliche Statuslogik und erweitert das Framework, ohne die bestehende Systemtrennung oder verifizierte Command-Einträge zu entfernen.

## Reparierte Inkonsistenzen

### A01 — Statusvokabular war unvollständig

In v1.0.0 wurden Statuswerte wie `HISTORICALLY_VERIFIED`, `PARAMETER_TEST_REQUIRED` und `INERT` verwendet, ohne sie vollständig im Evidence-Modell zu definieren.

**Repair:** Statusmodell erweitert und kanonische Begriffe eingeführt.

### A02 — Beweisquelle und Testergebnis waren vermischt

`EVIDENCE PRIORITY` behandelte Quelle, Live-Test und Ergebnis wie eine einzige Skala.

**Repair:** Quellenstärke und Testergebnis werden ab v1.1.0 getrennt bewertet.

### A03 — `/ghost` Tier-Gate war zu stark formuliert

Die Annahme eines Premium-/VIP-/Bezahlstufen-Gates ist möglich, aber durch die bisherigen Beobachtungen nicht positiv belegt.

**Repair:** `TIER_GATE_SUSPECTED` wird für `/ghost` auf `HYPOTHESIS_ONLY` zurückgestuft. Die Hypothese bleibt erhalten, wird aber nicht als Befund ausgegeben.

### A04 — Fehlende Fehlermeldung wurde nicht ausreichend abgegrenzt

Keine `Unknown command`-Antwort bedeutet nicht automatisch, dass ein Command erkannt oder ausgeführt wurde.

**Repair:** Explizite Regel `NO_ERROR != COMMAND_RECOGNIZED`.

### A05 — Vollständigkeit des Help-Captures fehlte als Metadatum

Der Nutzer bestätigte, dass die bereitgestellte Meredian-Hilfe die gesamte Ausgabe war, die der Chat geliefert hat.

**Repair:** `HELP_CAPTURE_COMPLETENESS = USER_CONFIRMED_COMPLETE_CAPTURE` ergänzt.

### A06 — Datenbankschema war für Live-Forensik zu knapp

Command-Echo, explizite Reject-Antwort, Risiko, Provenienz und Hypothesenstatus fehlten.

**Repair:** Schema erweitert.

### A07 — Risikoklassen fehlten

Commands können reine Infoabfragen, Room-State-Änderungen, Moderation, Währung oder externe Geräte betreffen.

**Repair:** Risk Classification v1 eingeführt.

## Erhaltungsregel

- Keine bestehende Systemklasse wurde entfernt.
- Keine verifizierte Help-Command-Zeile wurde gelöscht.
- Legacy und aktuelle Systeme bleiben strikt getrennt.
- Unsichere Aussagen wurden nicht gelöscht, sondern als Hypothese oder offener Testpunkt neu klassifiziert.

---

# 1. ZWECK

Dieses Framework sammelt, prüft und klassifiziert Informationen über:

- Chatbefehle
- Room-Befehle
- Avatar-/Effektbefehle
- Serverbefehle
- Gruppenchat-Funktionen
- private Nachrichten
- Währungssysteme
- Moderationsfunktionen
- Account-/Bezahlstufen
- versteckte oder undokumentierte Commands
- Legacy-Funktionen
- Unterschiede zwischen 3DXChat und Meredian
- Live-Testergebnisse
- Client-/Server-Verhalten

Das Framework verhindert ausdrücklich, dass Commands verschiedener 3DX-Systeme ungeprüft miteinander vermischt werden.

---

# 2. SYSTEMTRENNUNG

Jeder Command erhält zwingend eine Systemzuordnung.

## SYSTEM: OFFICIAL\_3DXCHAT

Offizieller 3DXChat-Client / offizieller Server.

## SYSTEM: MEREDIAN

Meredian-Client und Meredian-Server.

## SYSTEM: LEGACY\_3DX

Historische 3DX-/Private-Server-Implementierungen.

## SYSTEM: UNKNOWN\_3DX\_DERIVATIVE

3DX-basierte Systeme, deren Herkunft nicht eindeutig verifiziert wurde.

**Regel:**

Ein Command aus `LEGACY_3DX` darf niemals automatisch als `MEREDIAN` oder `OFFICIAL_3DXCHAT` markiert werden.

---

# 3. EVIDENCE LEVELS

Ab v1.1.0 werden **Quellenbeleg**, **Live-Ergebnis** und **Hypothese** getrennt geführt.

## 🟢 VERIFIED_HELP

Command wurde direkt in der eingebauten Client-Hilfe angezeigt.

Belegt: dokumentierte Existenz im getesteten Help-Kontext.

Belegt nicht automatisch: erfolgreiche Wirkung, Berechtigung jeder Accountstufe oder Persistenz.

## 🟢 VERIFIED_LIVE_SUCCESS

Command wurde im laufenden Client getestet und eine erwartete Wirkung oder eindeutige Systemantwort wurde beobachtet.

Gültigkeit ist immer auf den getesteten Client-/Server-/Account-Kontext begrenzt.

## 🟢 VERIFIED_LIVE_NEGATIVE

Live-Test ergab eine eindeutige negative Antwort, zum Beispiel `Unknown command`.

Dieser Status beweist das negative Ergebnis für den getesteten Kontext.

## 🟢 VERIFIED_OFFICIAL

Command ist durch eine aktuelle offizielle bzw. primäre Dokumentation belegt.

## 🟡 HISTORICALLY_VERIFIED

Command war in einer älteren offiziellen oder belastbaren historischen Quelle belegt, aktueller Status ist aber noch offen.

## 🟡 PARTIAL

Es liegen Beobachtungen vor, aber Erkennung, Wirkung, Voraussetzungen oder Scope sind noch nicht vollständig geklärt.

## 🟡 LEGACY

Command ist aus älteren 3DX-Systemen bekannt.

## 🟡 UNDOCUMENTED

Command ist nicht in der aktuell erfassten Client-Hilfe dokumentiert.

## 🟡 NO_OBSERVABLE_EFFECT

Ein Command wurde eingegeben, aber im getesteten Kontext wurde keine sichtbare oder anderweitig bestätigte Wirkung festgestellt.

Dieser Status bedeutet **nicht automatisch**, dass der Command unbekannt ist.

## 🟡 PARAMETER_TEST_REQUIRED

Der Grundcommand ist belegt, einzelne Parameter oder Werte sind aber noch nicht aktuell verifiziert.

## 🟠 HYPOTHESIS_ONLY

Eine mögliche Erklärung oder Funktion wird untersucht, es fehlt jedoch direkter positiver Beleg.

Beispiel: Premium-/VIP-/Tier-Gate als mögliche Erklärung für einen inerten Command.

## 🔴 UNKNOWN_COMMAND

Server oder Client antwortet ausdrücklich mit einer Unknown-Command-Meldung, beispielsweise:

`Unknown command`

Kanonischer Live-Status dazu:

`VERIFIED_LIVE_NEGATIVE`

## 🔴 NOT_VERIFIED

Nur Behauptung, unbestätigte externe Information oder noch nicht reproduzierter Fund.

## Compatibility Alias

Der v1.0.0-Begriff `VERIFIED_LIVE` bleibt für Altimporte lesbar, wird für neue Einträge aber durch `VERIFIED_LIVE_SUCCESS` oder `VERIFIED_LIVE_NEGATIVE` ersetzt.

---

# 4. EVIDENCE PRIORITY

## 4.1 Quellenstärke

Quellenstärke in absteigender Reihenfolge:

1. reproduzierbarer Live-Test im exakt dokumentierten aktuellen Client-/Server-/Account-Kontext
2. eingebaute Command-Hilfe des getesteten Clients
3. aktuelle offizielle Dokumentation
4. aktuelle Server-/Entwicklerdokumentation
5. reproduzierbarer Vergleichstest eines zweiten Accounts
6. aktuelle Community-Dokumentation
7. ältere Dokumentation
8. Legacy-/Private-Server-Dokumentation
9. Forumsaussage
10. Vermutung

## 4.2 Ergebnisregel

Quellenstärke darf nicht mit dem Ergebnisstatus vermischt werden.

Beispiele:

- Help-Eintrag vorhanden → `VERIFIED_HELP`
- Live erfolgreich → `VERIFIED_LIVE_SUCCESS`
- Live `Unknown command` → `VERIFIED_LIVE_NEGATIVE / UNKNOWN_COMMAND`
- keine Fehlermeldung + kein Effekt → `PARTIAL / NO_OBSERVABLE_EFFECT`
- vermutete Bezahlstufe ohne positiven Vergleich → `HYPOTHESIS_ONLY`

## 4.3 Scope-Regel

Ein Live-Ergebnis gilt nur für den dokumentierten Testkontext.

Es darf nicht automatisch auf andere:

- Client-Versionen
- Serverstände
- Accountstufen
- Rollen
- Regionen
- Events
- Private-Server

übertragen werden.

---

# 5. OFFICIAL 3DXCHAT COMMAND REGISTRY

## `/me TEXT`

**System:** OFFICIAL\_3DXCHAT
**Kategorie:** CHAT / ROLEPLAY
**Status:** 🟢 VERIFIED\_OFFICIAL

Funktion:

Normale Chatdarstellung:

`PLAYER: TEXT`

wird sinngemäß zu:

`PLAYER TEXT`

und als Action-/RP-Nachricht dargestellt.

---

## `/roll6`

**System:** OFFICIAL\_3DXCHAT
**Kategorie:** RNG
**Status:** 🟢 VERIFIED\_OFFICIAL

Erzeugt:

`1–6`

---

## `/roll12`

**System:** OFFICIAL\_3DXCHAT
**Kategorie:** RNG
**Status:** 🟢 VERIFIED\_OFFICIAL

Erzeugt:

`1–12`

---

## `/roll100`

**System:** OFFICIAL\_3DXCHAT
**Kategorie:** RNG
**Status:** 🟢 VERIFIED\_OFFICIAL

Erzeugt:

`1–100`

---

## `/roll`

**System:** OFFICIAL\_3DXCHAT
**Kategorie:** RNG
**Status:** 🟡 HISTORICALLY\_VERIFIED

Historischer Zufallswurf.

Aktuelles exaktes Verhalten noch separat zu prüfen.

---

# 6. MEREDIAN VERIFIED COMMAND REGISTRY

Quelle:

`MEREDIAN CLIENT BUILT-IN COMMAND HELP`

Status der folgenden Commands:

🟢 `VERIFIED_HELP`

**Help Capture Completeness:** `USER_CONFIRMED_COMPLETE_CAPTURE`

**Capture Date:** `2026-08-18`

**Interpretation:** Die vom Nutzer bereitgestellten Screenshots bilden nach Nutzerbestätigung die vollständige Help-Ausgabe ab, die der Chat geliefert hat. Dies beweist nicht, dass keine undokumentierten oder serverseitig reservierten Commands existieren.

---

## GENERAL

### `/players`

Zeigt die Anzahl der Spieler in Standard-Locations.

---

### `/afk MESSAGE`

Aktiviert bzw. deaktiviert AFK.

Während AFK erhalten Personen, die dem Spieler schreiben, die angegebene Nachricht.

---

### `/myonline`

Zeigt die gesamte Onlinezeit über alle Charaktere des Accounts.

---

### `/pm PLAYER`

Öffnet ein privates Nachrichtenfenster mit dem angegebenen Spieler.

---

# 7. RNG / SOCIAL

## `/dice NUMBER`

Würfelt mit dem angegebenen Zahlenbereich.

Wird `NUMBER` weggelassen:

Default:

`6`

---

## `/spin`

Flasche drehen.

**Scope:**

`GROUP CHAT ONLY`

---

## `/syncdance`

Synchronisiert den aktuell ausgeführten Tanz.

**Scope:**

`GROUP CHAT ONLY`

---

# 8. MEREDIAN FIREWORK SYSTEM

## `/firework`

Startet ein Feuerwerk.

---

## `/firework test`

Testet Feuerwerk kostenlos.

Beschränkung:

- eigener nichtöffentlicher Raum
- oder Room Editor

---

# 9. MEREDIAN CURRENCY SYSTEM

## `/pay PLAYER AMOUNT`

Überträgt Ingame-Währung an einen anderen Spieler.

Je nach Kontext kann `PLAYER` möglicherweise entfallen, wenn der Befehl direkt auf die Zielperson angewendet wird.

---

## `/give`

Funktional ähnlich `/pay`.

Zusätzliche Wirkung:

Der Transfer wird im Local Chat angekündigt.

---

# 10. PLAYER CONTROL

## `/expel PLAYER MINUTES`

Entfernt einen Spieler aus der eigenen Location.

Optional:

`MINUTES`

Fehlt der Zeitwert, erfolgt nur ein Kick.

Je nach Kontext kann der Spielername entfallen, wenn der Command direkt auf den betreffenden Spieler angewendet wird.

---

# 11. MEREDIAN ROOM MODERATION

## `/room moderators`

Zeigt die aktuellen Room-Moderatoren.

---

## `/room moderators set PLAYER_NAME_1 PLAYER_NAME_2 ...`

Setzt Room-Moderatoren.

---

## `/room moderators reset`

Entfernt alle Room-Moderatoren.

---

# 12. ROOM LIFECYCLE

## `/room persist`

Macht einen Raum semi-persistent.

Der Raum bleibt nach Disconnect des Owners noch für eine gewisse Zeit verfügbar.

---

## `/room close`

Schließt den aktuell öffentlich geteilten Raum.

---

## `/room limit NUMBER`

Setzt das maximale Besucherlimit.

Beispiel:

`/room limit 30`

---

# 13. ROOM POLICY

## `/room sex VALUE`

Unterstützte Werte laut Help:

`allow`

`forbid`

Beispiel:

`/room sex allow`

---

## `/room fireworks VALUE`

Unterstützte Werte:

`1`

\= Feuerwerke erlaubt

`0`

\= Feuerwerke verboten

Default laut Help:

`0`

---

# 14. ROOM PROMPT SYSTEM

## `/room prompt VALUE`

Definiert die Welcome-/Hinweismeldung eines Raumes.

Unterstützt:

`\n`

für einen Zeilenumbruch.

Beispiel:

`/room prompt Welcome to the room\nEnjoy the music\nHave fun`

---

# 15. ROOM CHAT CONTROL

## `/room slowmode MODE`

Konfiguriert den Room-Chat-Slowmode.

Bekannte Modi:

`reset`

Slowmode zurücksetzen.

`mute`

Andere Teilnehmer stummschalten.

Zusätzlich kann ein Sekundenintervall verwendet werden.

Beispielkandidat:

`/room slowmode 10`

Exakte Intervallwirkung:

🟡 PARTIAL / LIVE TEST REQUIRED

---

# 16. EXTENDED INTERACTION PERMISSIONS

## `/sex VALUE`

Bekannte Werte:

### `sub`

Erlaubt bestimmte Posen ohne zusätzliche Bestätigung.

### `deny`

Lehnt eingehende Partneranfragen ab.

### `reset`

Setzt die Einstellung auf Standard zurück.

---

# 17. LANGUAGE SYSTEM

## `/lang`

Zeigt bzw. konfiguriert die Sprache der Serverantworten.

**VERIFIZIERT:**

`/lang`

**Noch nicht durch aktuelle Meredian-Hilfe verifiziert:**

`/lang en`

`/lang ru`

Status:

🟡 PARAMETER\_TEST\_REQUIRED

---

# 18. MEREDIAN LOVENSE NAMESPACE

## `/l-connect ADDRESS`

Verbindet Meredian mit Lovense Connect.

Bekanntes Format:

`/l-connect http://IP:20010`

---

## `/l-help`

Zeigt Lovense-bezogene Commands bzw. Einstellungen.

Namespace:

`/l-*`

---

# 19. LEGACY COMMAND INVESTIGATION

Folgende Commands existieren in älteren 3DX-basierten Systemen, sind aber nicht automatisch Meredian-Funktionen.

---

## `/color`

Historische Funktion:

Nickname-Farben anzeigen bzw. verändern.

### Meredian Live-Test

Eingabe:

`/color`

Ergebnis:

`Unknown command, see /help`

Status:

🔴 `UNKNOWN_COMMAND`

Damit im getesteten aktuellen Meredian-System nicht verfügbar.

---

## `/ghost`

Historische Funktion:

temporärer Ghost-/Geist-Avatar.

Mögliche historische Eigenschaften:

- andere Avatarfarbe
- zufällige Ghost-Farbe
- temporärer Zustand
- Reset bei Location-Wechsel
- teilweise mögliche Kosten

### Meredian Live-Test

Mehrfach getestet.

Beobachtungen:

- kein Goldabzug
- keine Fehlermeldung
- keine sichtbare Systemantwort
- keine sichtbare Veränderung beim eigenen Avatar
- keine sichtbare Veränderung aus Sicht eines zweiten Spielers
- nicht in `/help` aufgeführt

Status:

🟡 `PARTIAL / UNDOCUMENTED / NO_OBSERVABLE_EFFECT`

Zusätzliche Live-Einordnung:

- `UNKNOWN_COMMAND_RESPONSE = NO_OBSERVED`
- `COMMAND_RECOGNITION = UNRESOLVED`
- `LOCAL_EFFECT = NONE_OBSERVED`
- `REMOTE_EFFECT = NONE_OBSERVED`
- `CURRENCY_DEDUCTION = NONE_OBSERVED`

Wichtige Interpretationsregel:

`NO_ERROR != COMMAND_RECOGNIZED`

Das Ausbleiben einer Fehlermeldung ist allein kein positiver Nachweis, dass `/ghost` aktiv erkannt oder ausgeführt wurde.

Tier-/Bezahlstufen-Hypothese:

`HYPOTHESIS_ONLY`

`TIER_GATE_EVIDENCE = NONE_DIRECT`

Mögliche, aber derzeit nicht verifizierte Ursachen:

- deaktivierter Legacy-Handler
- Premium-/VIP-/Account-Gate
- Rollenberechtigung
- Eventfunktion
- serverseitig deaktivierte Funktion
- reservierter Command
- still verworfene oder unvollständige Legacy-Implementierung

---

# 20. BEZAHLSTUFEN / ACCOUNT-GATES

Neues Informationsmodul:

`3DX_ACCOUNT_TIER_INTELLIGENCE`

Jede Funktion kann zusätzlich folgende Eigenschaften erhalten:

- FREE
- PREMIUM
- VIP
- EVENT\_ONLY
- MODERATOR
- ROOM\_OWNER
- ADMIN
- PAID\_CURRENCY
- SUBSCRIPTION\_REQUIRED
- UNKNOWN

Beispiel:

`/ghost`

Aktuell:

`TIER_REQUIREMENT = UNKNOWN`

`TIER_GATE_HYPOTHESIS = OPEN`

`TIER_GATE_EVIDENCE = NONE_DIRECT`

`TIER_GATE_STATUS = HYPOTHESIS_ONLY`

---

# 21. LIVE TEST PROTOCOL

Jeder neue Command wird mit folgendem Verfahren getestet.

## PHASE 0 – SAFETY / RISK GATE

Vor dem Test klassifizieren:

- mögliche Währungskosten
- Room-State-Änderung
- Moderationswirkung
- Account-/Rollenwirkung
- externe Geräteintegration
- mögliche Persistenz

Commands mit unklaren Kosten oder destruktiver Wirkung werden nicht blind ausgeführt.

---

## PHASE 1 – BASELINE

Dokumentieren:

- Account
- Client
- Server
- Raum
- Account-/Bezahlstufe
- Gold vorher
- Avatarzustand
- Room-State

---

## PHASE 2 – COMMAND

Command exakt eingeben.

Keine Varianten gleichzeitig testen.

---

## PHASE 3 – RESPONSE

Prüfen:

- erscheint Command als Chattext?
- erscheint Systemantwort?
- erscheint `Unknown command`?
- erscheint Fehler?
- wird Command still verarbeitet?
- wird der eingegebene Slash-Text als normale Chatzeile gespiegelt?
- kommt die Antwort sofort oder verzögert?

### CONTROL COMPARISON

Wenn Erkennung unklar bleibt, Vergleich mit:

1. einem sicher funktionierenden Help-Command
2. einem absichtlich ungültigen Kontroll-Command

Dadurch wird das Verhalten von:

- Command-Echo
- Unknown-Command-Antwort
- serverseitiger Verarbeitung

vergleichbar.

---

## PHASE 4 – EFFECT

Prüfen:

- Avatar
- Animation
- Kamera
- Chat
- Nickname
- Room-State
- andere Spieler
- Currency
- Moderation
- UI

---

## PHASE 5 – SECOND CLIENT CHECK

Wenn möglich, zweiten Spieler prüfen lassen:

- sieht der andere Client einen Effekt?
- verändert sich Raumstatus?
- verändert sich Avatar?
- erscheint Systemmeldung?

---

## PHASE 6 – PERSISTENCE

Prüfen:

- nach Reconnect
- nach Room-Wechsel
- nach Client-Neustart
- nach Owner-Disconnect

---

# 22. COMMAND DATABASE SCHEMA

Jeder Eintrag soll künftig mindestens enthalten:

`COMMAND`

`SYSTEM`

`CLIENT_VERSION`

`CATEGORY`

`PARAMETERS`

`DESCRIPTION`

`HELP_DOCUMENTED`

`LIVE_TESTED`

`SERVER_RESPONSE`

`COMMAND_ECHO`

`UNKNOWN_COMMAND_RESPONSE`

`RECOGNITION_STATE`

`VISIBLE_EFFECT`

`REMOTE_EFFECT`

`CURRENCY_COST`

`ROOM_OWNER_REQUIRED`

`MODERATOR_REQUIRED`

`ACCOUNT_TIER`

`ACCOUNT_TIER_EVIDENCE`

`RISK_CLASS`

`PERSISTENCE`

`SOURCE`

`SOURCE_TYPE`

`PROVENANCE`

`EVIDENCE_LEVEL`

`LAST_TESTED`

`HYPOTHESIS_STATUS`

`NOTES`

---

# 23. INFORMATION CATEGORIES

Das Framework wird modular erweitert.

## CHAT

Chatformatierung, RP, PM, Local, World, Group.

## ROOM

Room Creation, Persistenz, Besucherlimit, Welcome Message.

## MODERATION

Moderatoren, Kick, Expel, Mute.

## AVATAR

Ghost, Farben, Transformationen, Animationen.

## SOCIAL

Spin, Syncdance, Interaktionen.

## RNG

Dice, Roll.

## CURRENCY

Pay, Give, Gold.

## FIREWORKS

Firework Commands und Room Policy.

## SEX / CONSENT

Room- und personenbezogene Berechtigungen.

## LANGUAGE

Serverantwort-Sprache.

## DEVICE INTEGRATION

Lovense und zukünftige Geräteintegration.

## ACCOUNT TIERS

Free/Premium/VIP/Moderator/Admin/Event.

## LEGACY

Alte oder versteckte Funktionen.

---

# 24. CURRENT MEREDIAN AUDIT

`/players` → 🟢 VERIFIED\_HELP
`/afk` → 🟢 VERIFIED\_HELP
`/firework` → 🟢 VERIFIED\_HELP
`/firework test` → 🟢 VERIFIED\_HELP
`/myonline` → 🟢 VERIFIED\_HELP
`/pm` → 🟢 VERIFIED\_HELP
`/dice` → 🟢 VERIFIED\_HELP
`/spin` → 🟢 VERIFIED\_HELP
`/syncdance` → 🟢 VERIFIED\_HELP
`/pay` → 🟢 VERIFIED\_HELP
`/give` → 🟢 VERIFIED\_HELP
`/expel` → 🟢 VERIFIED\_HELP
`/room moderators` → 🟢 VERIFIED\_HELP
`/room moderators set` → 🟢 VERIFIED\_HELP
`/room moderators reset` → 🟢 VERIFIED\_HELP
`/room persist` → 🟢 VERIFIED\_HELP
`/room close` → 🟢 VERIFIED\_HELP
`/room limit` → 🟢 VERIFIED\_HELP
`/room sex` → 🟢 VERIFIED\_HELP
`/room fireworks` → 🟢 VERIFIED\_HELP
`/room prompt` → 🟢 VERIFIED\_HELP
`/room slowmode` → 🟢 VERIFIED\_HELP
`/sex` → 🟢 VERIFIED\_HELP
`/lang` → 🟢 VERIFIED\_HELP

`/color` → 🔴 VERIFIED\_LIVE\_NEGATIVE / UNKNOWN\_COMMAND
`/ghost` → 🟡 PARTIAL / UNDOCUMENTED / NO\_OBSERVABLE\_EFFECT / HYPOTHESIS\_ONLY

---

# 25. FRAMEWORK RULES

1. Keine Vermutung wird als verifiziert ausgegeben.
2. Meredian und offizieller 3DXChat bleiben getrennt.
3. Legacy-Commands erhalten immer `LEGACY`.
4. Screenshots aus dem laufenden Client gelten als starke Primärbelege für das sichtbare Ergebnis.
5. Live-Tests überschreiben widersprüchliche ältere Dokumentation nur für den exakt getesteten Kontext.
6. Account-/Bezahlstufen werden separat dokumentiert.
7. Commands mit möglichen Kosten werden nicht blind getestet.
8. Room-State-verändernde Commands nur kontrolliert testen.
9. Testergebnis und Interpretation werden getrennt gespeichert.
10. `NO_ERROR != COMMAND_RECOGNIZED`.
11. Ein Command-Echo im Chat beweist weder Erkennung noch Nichterkennung.
12. Ein Help-Eintrag beweist dokumentierte Existenz, aber nicht automatisch Berechtigung oder Wirkung.
13. Negative Live-Ergebnisse werden nicht ohne neuen Test auf andere Versionen oder Accountstufen generalisiert.
14. Hypothesen bleiben explizit als `HYPOTHESIS_ONLY` markiert.
15. Das Framework bleibt versionsfähig und erweiterbar.

---

# 26. NEXT RESEARCH TARGETS

1. Meredian Account-/Premium-/VIP-Stufen mit direkter Quelle erfassen.
2. `/ghost` nur mit dokumentierten unterschiedlichen Accountstufen vergleichen.
3. `/ghost` zusätzlich gegen positiven und negativen Kontroll-Command testen.
4. `/lang`-Parameter vollständig bestimmen.
5. `/room slowmode` exakt vermessen.
6. zusätzliche nicht dokumentierte Commands kontrolliert testen.
7. Unterschiede Meredian ↔ offizieller 3DXChat dokumentieren.
8. Client-Version und Serverstand bei jedem zukünftigen Test erfassen.
9. Command-Verhalten nach Serverupdates erneut prüfen.
10. Kosten-/Risikostatus für `/firework`, `/pay`, `/give` und weitere Currency-/Room-State-Commands verifizieren.

---

# 27. CURRENT FRAMEWORK STATE

**3DX Official Commands:** PARTIAL
**Meredian Built-in Help:** VERIFIED
**Meredian Live Tests:** ACTIVE
**Legacy Commands:** SEPARATED
**Account Tier Mapping:** OPEN / EVIDENCE REQUIRED
**Hidden Command Research:** ACTIVE / CONTROLLED
**Command Database Architecture:** READY / EXTENDED
**Audit Consistency:** PASS
**Source Preservation:** PASS
**Risk Classification:** READY

**Framework Version:** `1.1.0`

---

# 28. RISK CLASSIFICATION v1

Jeder Command erhält vor Live-Tests eine Risikoklasse.

## R0 — INFORMATION ONLY

Nur lesende bzw. informative Funktion.

Beispiele:

- `/players`
- `/myonline`
- `/room moderators`

## R1 — LOCAL / COSMETIC

Mögliche visuelle oder lokale Änderung ohne bekannten persistenten Room-State.

Beispiele:

- historische Avatar-/Farbcommands
- `/ghost` als Untersuchungskandidat

## R2 — ROOM STATE

Verändert Eigenschaften eines eigenen Raums.

Beispiele:

- `/room limit`
- `/room prompt`
- `/room slowmode`
- `/room fireworks`
- `/room sex`
- `/room persist`
- `/room close`

## R3 — MODERATION / OTHER USERS

Wirkt auf andere Nutzer oder Rollen.

Beispiele:

- `/expel`
- `/room moderators set`
- `/room moderators reset`

## R4 — CURRENCY / POSSIBLE COST

Kann Ingame-Währung übertragen oder verbrauchen.

Beispiele:

- `/pay`
- `/give`
- `/firework`, falls Kosten im aktuellen Kontext nicht ausgeschlossen sind

## R5 — EXTERNAL DEVICE / NETWORK

Bindet externe Geräte oder lokale Netzwerkdienste ein.

Beispiele:

- `/l-connect`

**Regel:** Je höher die Risikoklasse, desto stärker müssen Baseline, Scope und Readback dokumentiert werden.

---

# 29. MEREDIAN LIVE OBSERVATION LEDGER

## TEST: `/color`

**System:** `MEREDIAN`  
**Evidence:** Nutzer-Screenshot  
**Date:** `2026-08-18`  
**Result:** `Unknown command, see /help`  
**Classification:** `VERIFIED_LIVE_NEGATIVE / UNKNOWN_COMMAND`  
**Risk:** `R1`  
**Interpretation:** Im getesteten Kontext nicht als gültiger Command akzeptiert.

## TEST: `/ghost`

**System:** `MEREDIAN`  
**Evidence:** Nutzer-Screenshots + Nutzerbeobachtung  
**Date:** `2026-08-18`

Beobachtet:

- mehrfach eingegeben
- kein Goldabzug beobachtet
- keine Fehlermeldung beobachtet
- keine sichtbare Systembestätigung beobachtet
- kein lokaler Avatar-Effekt beobachtet
- kein Effekt aus Sicht eines zweiten Spielers beobachtet
- nicht in der erfassten Help-Ausgabe enthalten

**Classification:** `PARTIAL / UNDOCUMENTED / NO_OBSERVABLE_EFFECT`  
**Recognition State:** `UNRESOLVED`  
**Risk:** `R1`  
**Tier Gate:** `HYPOTHESIS_ONLY`  
**Direct Tier Evidence:** `NONE`

**Nicht zulässige Schlussfolgerung:** Aus dem Fehlen einer Fehlermeldung darf nicht abgeleitet werden, dass `/ghost` sicher erkannt wird.

---

# 30. HELP CAPTURE PROVENANCE

**System:** `MEREDIAN`  
**Source Type:** `CLIENT_BUILT_IN_HELP_SCREENSHOT`  
**Capture Date:** `2026-08-18`  
**Completeness:** `USER_CONFIRMED_COMPLETE_CAPTURE`

Der Nutzer bestätigte, dass die bereitgestellten Screenshots die gesamte Help-Ausgabe darstellen, die der Chat in diesem Test geliefert hat.

Diese Vollständigkeitsangabe bezieht sich ausschließlich auf die sichtbare Help-Ausgabe.

Sie ist **kein Beweis**, dass:

- keine versteckten Commands existieren
- keine rollenabhängigen Commands existieren
- keine Premium-/VIP-Kommandos existieren
- keine serverseitig reservierten Commands existieren
- keine veralteten oder deaktivierten Handler vorhanden sind

---

# 31. CHANGELOG v1.1.0

## PRESERVED

- Systemtrennung `OFFICIAL_3DXCHAT / MEREDIAN / LEGACY_3DX / UNKNOWN_3DX_DERIVATIVE`
- vorhandene Official-3DXChat-Registry
- vollständige vorhandene Meredian-Help-Registry
- Legacy-Untersuchung
- Live-Test-Protokoll
- Account-Tier-Modul
- Command-Datenbankschema

## REPAIRED

- fehlende Statusdefinitionen ergänzt
- Quellenstärke von Testergebnis getrennt
- `/ghost` Tier-Gate von Verdacht auf reine Hypothese zurückgestuft
- `NO_ERROR != COMMAND_RECOGNIZED` verbindlich gemacht
- `/color` als kanonisches negatives Live-Ergebnis normalisiert
- `/ghost` als `NO_OBSERVABLE_EFFECT` statt pauschal `INERT` präzisiert

## EXTENDED

- Help-Capture-Provenienz
- Risk Classification
- Live Observation Ledger
- Control-Comparison im Testprotokoll
- erweitertes Datenbankschema
- Scope-Regel für Live-Ergebnisse
- Hypothesenstatus

**Release:** `3DX-INFO-FRAMEWORK v1.1.0`

