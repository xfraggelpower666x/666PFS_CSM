# Live Drive + PFS Synchronization Policy

LIVE_DRIVE_NAME=666TRACKDESIGNHUB
PFS_CHILD_ENTRY=TRACKHUB-32001
SYNC_MODEL=ONE_FREEZE_TWO_TARGETS
BIDIRECTIONAL_SYNC=FALSE

A material update is complete only if the same Freeze ID and package hashes are verified at Live Drive and PFS. Live success without PFS success is PARTIAL. PFS success without Live success is PARTIAL. External/manual Live edits are evidence only until diff-audited and frozen through `666TDH UPDATE`.
