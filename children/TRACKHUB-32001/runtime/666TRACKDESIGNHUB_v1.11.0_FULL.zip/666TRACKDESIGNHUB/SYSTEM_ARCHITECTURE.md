# Architecture

666TRACKDESIGNHUB (daily namespace `666TDH`, preserved ID `666TRACKHUB-001`)
- TD -> child 1 / 666TRACKDESIGN / independent musical runtime
- LCTS -> child 2 / 666LCTS / independent longform runtime
- DTSTE -> child 3 / 666DTSTE-001 / DTSTE ULTRA CORE SYSTEM / independent native state-based runtime
- FSE -> child 4 / 666FSE-001 / FRAGGLE SYSTEM EXPORT wrapper / independent source-preserving runtime
- DAEMON -> always operational validation/continuity companion, authority NONE
- NEW CHAT HANDOFF -> persistent single-use continuity transport
- HOST RECOVERY -> context recovery service, authority NONE
- DUAL PUBLISH -> Live Drive + PFS preservation target from one verified freeze

CROSS_SYSTEM_MERGE=FORBIDDEN
TD_MUSICAL_INHERITANCE_TO_FSE=FORBIDDEN
LCTS_MUSICAL_INHERITANCE_TO_FSE=FORBIDDEN
DTSTE_MUSICAL_INHERITANCE_TO_FSE=FORBIDDEN
FSE_SOURCE_PACKAGE_AUTHORITY=PRESERVED
FSE_NATIVE_SYSTEM_IDENTITY=UNRESOLVED_HOLD

Shared layers allowed for FSE by explicit user authority/context:
- universal visual style
- output presentation style, target-native
- daemon / force validation layer
- dedicated FSE trigger branch

Shared musical/runtime semantics are not implied.
