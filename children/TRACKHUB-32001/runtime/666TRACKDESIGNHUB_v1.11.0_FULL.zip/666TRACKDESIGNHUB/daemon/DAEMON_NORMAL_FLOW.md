# Normal Guided Flow

01 Intent/Source -> 02 Track Meaning -> 03 Story/Identity -> 04 BPM/Physical Character -> 05 Motor Relation -> 06 Experience/Card Resonance -> 07 Mid/High Living Field -> 08 Vocal/Story Relation -> 09 Creative Decision -> 10 Voraudit -> 11 Box1 -> 12 Box2 -> 13 Sliders -> 14 Box3 -> 15 Box4 -> 16 Forecast/Drift -> 17 Generation -> 18 Render Review -> 19 DJ Review -> 20 Causal Learning -> 21 Repair/Regenerate/Accept -> Finalization.

These are guidance states, not a fixed musical arrangement template.
