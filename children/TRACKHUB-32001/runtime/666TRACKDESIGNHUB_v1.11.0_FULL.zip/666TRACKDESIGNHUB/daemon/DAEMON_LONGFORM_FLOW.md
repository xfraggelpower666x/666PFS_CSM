# Longform Guided Flow

01 Concept -> 02 Target Runtime -> 03 BPM/Motor Identity -> 04 Story/Long Arc -> 05 Stage Intent -> 06 Base Package -> 07 Base Generation -> 08 Base Review -> 09 Continuation Zone -> 10 Extend Anchor -> 11 Extension -> 12 Motor Drift Review -> 13 Identity/Story Review -> 14 Accept/Regenerate -> 15 Get Whole Song -> 16 Whole Song Review -> 17 Continuity State Update -> 18 Next Stage Decision -> repeat -> Final Stage -> Final Review -> DJ-compatible termination.

Every status panel must expose CURRENT / DONE / NOW / NEXT / DO NOT.
