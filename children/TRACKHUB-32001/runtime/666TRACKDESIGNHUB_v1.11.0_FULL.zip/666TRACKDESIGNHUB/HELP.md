# 666TRACKDESIGNHUB HELP

## Identity
Full name: `666TRACKDESIGNHUB`
Daily short trigger namespace: `666TDH`
Preserved internal System ID: `666TRACKHUB-001`
PFS entry: `TRACKHUB-32001`

## Quick Start
Hub: `666TDH SYSTEMSTART`
Normal Track: `666TDH TD SYSTEMSTART`
Longform: `666TDH LCTS SYSTEMSTART`
Continue: `666TDH WEITER`
Prepare automatic fresh-chat continuation: `666TDH NEW CHAT`
Universal update/save: `666TDH UPDATE`
Host recovery: `666TDH HOST RECOVERY`

The Daemon activates automatically with Hub Systemstart. It remains a companion with authority NONE.

## Branch Continuity
`666TDH TD NEW CHAT` arms a single-use TD handoff.
`666TDH LCTS NEW CHAT` arms a single-use LCTS handoff.
In the next chat the operator enters only `666TDH SYSTEMSTART`. The hub validates the handoff, activates the Daemon, starts the recorded branch, restores the persisted session state and marks the handoff CONSUMED. Without a valid pending handoff, Systemstart starts only the hub + Daemon.

## Normal Track Output Contract
Voraudit 8–10 sentences -> Box 1 Title <=80 -> Box 2 Extended <=1000 -> relational Sliderblock -> Box 3 Style <=1000 -> Box 4 Lyrics/Structure <=5000 -> Success Forecast -> Drift Probability -> Why Drift. Box 5/6 <=4000 each only on explicit request.

## Longform Workflow
Concept -> Runtime -> Motor -> Arc -> Base -> Review -> Continuation Zone -> Anchor -> Extend -> Drift Check -> Accept/Regenerate -> Whole Song -> Review -> Continuity State -> Next Stage -> Final.

## Protected Distribution
A material `666TDH UPDATE` publishes one verified freeze to both the Live Drive `666TRACKDESIGNHUB` and PFS Child `TRACKHUB-32001`. FULL + PORTABLE archives are read back. Pointer promotion is last. Partial publication never becomes COMPLETE_VERIFIED.

## Universal Update / Save
Only `666TDH UPDATE` commits durable system changes. It saves and republishes Hub, TD, LCTS, Daemon continuity, FULL/PORTABLE packages, Live Drive and PFS Child as one protected transaction. There is no separate SAVE trigger and no TD/LCTS UPDATE trigger.
