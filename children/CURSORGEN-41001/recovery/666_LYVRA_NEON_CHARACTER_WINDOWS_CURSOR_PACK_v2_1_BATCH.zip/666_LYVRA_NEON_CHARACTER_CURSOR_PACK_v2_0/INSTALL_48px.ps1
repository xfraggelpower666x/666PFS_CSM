$ErrorActionPreference="Stop"
$SIZE="48px"
$PackRoot=Join-Path $env:LOCALAPPDATA "666LYVRANeonCharacterCursors"
$PackDir=Join-Path $PackRoot $SIZE
$Src=Join-Path $PSScriptRoot "$SIZE\cursors"
$Backup=Join-Path $PackRoot "cursor-backup.json"
New-Item -ItemType Directory -Path $PackDir -Force | Out-Null
Copy-Item (Join-Path $Src "*") $PackDir -Force

$reg="HKCU:\Control Panel\Cursors"
$names=@("Arrow","Help","AppStarting","Wait","Crosshair","IBeam","NWPen","No","SizeNS","SizeWE","SizeNWSE","SizeNESW","SizeAll","UpArrow","Hand","Pin","Person")
if (!(Test-Path $Backup)) {
  $old=@{}
  foreach($n in $names){ try{$old[$n]=(Get-ItemProperty -Path $reg -Name $n -ErrorAction Stop).$n}catch{$old[$n]=""} }
  $old | ConvertTo-Json | Set-Content $Backup -Encoding UTF8
}
$map=@{
Arrow="Arrow.cur";Help="Help.cur";AppStarting="AppStarting.ani";Wait="Wait.ani";Crosshair="Crosshair.cur";
IBeam="IBeam.cur";NWPen="NWPen.cur";No="No.cur";SizeNS="SizeNS.cur";SizeWE="SizeWE.cur";
SizeNWSE="SizeNWSE.cur";SizeNESW="SizeNESW.cur";SizeAll="SizeAll.cur";UpArrow="UpArrow.cur";
Hand="Hand.cur";Pin="Pin.cur";Person="Person.cur"
}
foreach($n in $map.Keys){Set-ItemProperty -Path $reg -Name $n -Value (Join-Path $PackDir $map[$n])}
Set-ItemProperty -Path $reg -Name "(Default)" -Value "666 LYVRA Neon Character $SIZE"
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class CursorRefresh2 {
[DllImport("user32.dll",SetLastError=true)]
public static extern bool SystemParametersInfo(int a,int b,IntPtr c,int d);
}
"@
[CursorRefresh2]::SystemParametersInfo(0x0057,0,[IntPtr]::Zero,0)|Out-Null
Write-Host "LYVRA Neon Character Cursor Pack $SIZE aktiviert." -ForegroundColor Cyan
