@echo off
setlocal
cd /d "%~dp0"
title 666 LYVRA NEON CHARACTER CURSOR PACK

if exist "%~dp0preview" (
    start "" "%~dp0preview"
) else (
    echo Vorschau-Ordner nicht gefunden.
    pause
)
exit /b 0
