@echo off
setlocal
cd /d "%~dp0"
title 666 LYVRA NEON CHARACTER CURSOR PACK

echo Oeffne Windows Maus-/Zeiger-Einstellungen...
start "" control.exe main.cpl,,1
exit /b 0
