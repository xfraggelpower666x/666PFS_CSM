666 LYVRA NEON CHARACTER WINDOWS CURSOR PACK v2.0
==================================================

DESIGN
- Pink / Lila / Cyan Neon-Blitz + Laser
- Originalfigur an die Cursorformen gekoppelt
- Transparente Hintergruende
- Vier komplette Groessen-Sets: 32 / 48 / 64 / 96 px
- Zusaetzlich MULTI_SIZE .cur Dateien mit allen vier Aufloesungen
- Wait + AppStarting animiert (.ani)

INSTALLATION
Waehle eine Groesse:
  INSTALL_32px.ps1
  INSTALL_48px.ps1
  INSTALL_64px.ps1
  INSTALL_96px.ps1

Empfehlung:
48px = kompakt
64px = beste Balance
96px = maximale Sichtbarkeit / Character Detail

Der Installer:
- ueberschreibt KEINE Windows-Systemdateien
- kopiert nur nach %LOCALAPPDATA%\666LYVRANeonCharacterCursors
- aendert nur HKCU\Control Panel\Cursors
- speichert die vorherige Cursorbelegung vor der ersten Aktivierung

RESTORE
RESTORE_PREVIOUS_CURSORS.ps1

ROLLEN
Arrow, Help, AppStarting, Wait, Crosshair, IBeam, NWPen, No, SizeNS, SizeWE, SizeNWSE, SizeNESW, SizeAll, UpArrow, Hand, Pin, Person

HINWEIS
Die Figur stammt direkt aus der von dir bereitgestellten transparenten PNG und wird nicht
durch eine generische Ersatzfigur ausgetauscht.

BATCH-DATEIEN (v2.1)
====================
START_HERE_CURSOR_MENU.bat
  -> zentrale Auswahl fuer Installation, Restore, Vorschau und Windows-Zeigereinstellungen

INSTALL_32px.bat
INSTALL_48px.bat
INSTALL_64px.bat
INSTALL_96px.bat
  -> starten jeweils den zugehoerigen PowerShell-Installer automatisch mit
     -NoProfile -ExecutionPolicy Bypass

RESTORE_PREVIOUS_CURSORS.bat
  -> stellt die vorherige Cursor-Belegung ueber das vorhandene Restore-Skript wieder her

OPEN_WINDOWS_CURSOR_SETTINGS.bat
  -> oeffnet direkt die klassische Windows-Seite fuer Mauszeiger

OPEN_PREVIEW.bat
  -> oeffnet den Vorschauordner

EMPFOHLENER START
Doppelklick auf:
START_HERE_CURSOR_MENU.bat

HINWEIS
Die Batch-Dateien fuehren keine destruktiven Systemdatei-Aenderungen durch.
Sie rufen nur die vorhandenen, reversiblen Benutzer-Installer auf.
