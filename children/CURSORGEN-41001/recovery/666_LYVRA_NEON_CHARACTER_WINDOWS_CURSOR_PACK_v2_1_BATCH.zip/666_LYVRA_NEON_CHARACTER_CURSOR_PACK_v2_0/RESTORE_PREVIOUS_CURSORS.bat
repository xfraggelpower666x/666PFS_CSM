@echo off
setlocal
cd /d "%~dp0"
title 666 LYVRA NEON CHARACTER CURSOR PACK

echo.
echo ============================================
echo   666 LYVRA CURSOR RESTORE
echo ============================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RESTORE_PREVIOUS_CURSORS.ps1"
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
    echo [FEHLER] Restore konnte nicht abgeschlossen werden.
    echo Fehlercode: %ERR%
    pause
    exit /b %ERR%
)
echo [OK] Vorherige Cursorbelegung wurde wiederhergestellt.
echo.
pause
exit /b 0
