@echo off
setlocal
cd /d "%~dp0"
title 666 LYVRA NEON CHARACTER CURSOR PACK

:MENU
cls
echo ==========================================================
echo       666 LYVRA NEON CHARACTER WINDOWS CURSOR PACK
echo ==========================================================
echo.
echo   [1] 32px  - klein / kompakt
echo   [2] 48px  - kompakt / gut sichtbar
echo   [3] 64px  - empfohlen / beste Balance
echo   [4] 96px  - maximal gross / maximale Figur
echo.
echo   [5] Vorherige Windows-Cursor wiederherstellen
echo   [6] Cursor-Ordner oeffnen
echo   [7] Vorschau-Ordner oeffnen
echo   [8] Windows Maus-/Zeiger-Einstellungen oeffnen
echo.
echo   [0] Beenden
echo.
set /p "CHOICE=Auswahl: "

if "%CHOICE%"=="1" call "%~dp0INSTALL_32px.bat" & goto MENU
if "%CHOICE%"=="2" call "%~dp0INSTALL_48px.bat" & goto MENU
if "%CHOICE%"=="3" call "%~dp0INSTALL_64px.bat" & goto MENU
if "%CHOICE%"=="4" call "%~dp0INSTALL_96px.bat" & goto MENU
if "%CHOICE%"=="5" call "%~dp0RESTORE_PREVIOUS_CURSORS.bat" & goto MENU
if "%CHOICE%"=="6" start "" "%~dp0" & goto MENU
if "%CHOICE%"=="7" start "" "%~dp0preview" & goto MENU
if "%CHOICE%"=="8" start "" control.exe main.cpl,,1 & goto MENU
if "%CHOICE%"=="0" exit /b 0

echo.
echo Ungueltige Auswahl.
timeout /t 2 /nobreak >nul
goto MENU
