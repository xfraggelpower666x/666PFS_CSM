@echo off
setlocal
cd /d "%~dp0"
title 666 LYVRA NEON CHARACTER CURSOR PACK

echo.
echo ============================================
echo   666 LYVRA NEON CHARACTER CURSOR PACK
echo   INSTALLATION: 64px
echo ============================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_64px.ps1"
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
    echo [FEHLER] Installation konnte nicht abgeschlossen werden.
    echo Fehlercode: %ERR%
    pause
    exit /b %ERR%
)
echo [OK] 64px Cursor-Set wurde aktiviert.
echo.
pause
exit /b 0
