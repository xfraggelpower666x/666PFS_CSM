$ErrorActionPreference="Stop"
$PackRoot=Join-Path $env:LOCALAPPDATA "666LYVRANeonCharacterCursors"
$Backup=Join-Path $PackRoot "cursor-backup.json"
$reg="HKCU:\Control Panel\Cursors"
if(!(Test-Path $Backup)){Write-Host "Kein Cursor-Backup gefunden." -ForegroundColor Yellow; exit 1}
$old=Get-Content $Backup -Raw | ConvertFrom-Json
foreach($p in $old.PSObject.Properties){Set-ItemProperty -Path $reg -Name $p.Name -Value ([string]$p.Value)}
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class CursorRefresh2 {
[DllImport("user32.dll",SetLastError=true)]
public static extern bool SystemParametersInfo(int a,int b,IntPtr c,int d);
}
"@
[CursorRefresh2]::SystemParametersInfo(0x0057,0,[IntPtr]::Zero,0)|Out-Null
Write-Host "Vorherige Cursor-Zuordnung wiederhergestellt." -ForegroundColor Green
