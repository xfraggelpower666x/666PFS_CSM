# NEW CHAT HANDOFF — ICON / ICO FRAMEWORK

HANDOFF_ID=ICON-ICO-FRAMEWORK-HANDOFF-2026-08-28_1613_BERLIN
LOCAL_FREEZE_ID=ICON-ICO-FRAMEWORK-v1.2.0-R1-LOCAL-FREEZE-01
STATUS=READY_FOR_CONTINUATION

## What was completed

A complete local recovery cycle was executed:

AUDIT → REPAIR → DEVELOPMENT → RE-AUDIT → REPAIR PASS 2 → FINAL AUDIT → LOCAL FREEZE → SYSTEMSICHERUNG

The actual 3DX SCRIPT regression artifact passed multi-size ICO validation.

## Critical behavior now required

```text
ICON_REQUEST_COMPLETION_GUARD=MANDATORY
PNG_OUTPUT=INTERMEDIATE_ONLY
ICON_REQUEST_NOT_COMPLETE_UNTIL_ICO_EXISTS=TRUE
ICO_READBACK_REQUIRED=TRUE
DOWNLOAD_LINK_MUST_REFERENCE_REAL_ICO=TRUE
FINAL_SUCCESS_BEFORE_ICO=FORBIDDEN
```

Natural-language requests like:

`ich brauche ein 3DX SCRIPT ICON`

must execute the complete pipeline through `.ico`, not stop at image preview.

## Identity warning

Do NOT register or rename the framework from historical package metadata.

Historical:
- obsolete TIICO identity
- historical GPT naming
- conflicting entry 11001

Current local recovery:
- functional framework repaired
- current live renamed identity still unresolved
- no live Child ID claimed
- no Drive pointer claimed

## First action in a new chat

If the user explicitly activates 666PFS and wants Drive continuation:

1. verify live Google Drive connector and current account
2. read current 666PFS System Registry
3. read Child Registry
4. read current Core Pointer
5. search by functional content and prior SYSTEM_ID evidence
6. resolve the actual renamed framework identity
7. compare this local v1.2.0-R1 candidate against live state
8. perform only the minimal verified delta
9. audit → repair if required → re-audit
10. freeze
11. save Canonical + Backup
12. read back hashes/content
13. publish Registry/Pointer only when identity authority is verified

Never invent a new Child ID merely because the local package needs publication.
Never assign the framework based on the target label `3DX SCRIPT`.
Keep CODEFORGE/11001 untouched.
Keep LYVRA external and unchanged.
