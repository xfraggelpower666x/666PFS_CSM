# HISTORY

These files are evidence only.

They may contain obsolete names, obsolete GPT wording, TIICO metadata, and the historical
11001 collision. They MUST NOT be treated as live Registry/Pointer authority.

11001 remains protected from reuse based on the preserved conflict evidence.
