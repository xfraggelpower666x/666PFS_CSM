# ICO EXPORT + VALIDATION SPEC v1.2.0-R1

## Required sizes

```text
16,24,32,48,64,96,128,256
```

## Technical algorithm

1. locate actual generated/uploaded source file
2. decode source image
3. convert to RGBA
4. preserve aspect ratio
5. square-pad rather than stretch if needed
6. save Windows ICO with all required sizes
7. reopen the produced ICO
8. enumerate embedded sizes
9. compare against the required set
10. verify non-zero file size
11. calculate SHA-256
12. expose only the actual verified output file

## Validation pseudocode

```python
required = {(16,16),(24,24),(32,32),(48,48),
            (64,64),(96,96),(128,128),(256,256)}

assert output.exists()
assert output.stat().st_size > 0

with Image.open(output) as ico:
    assert ico.format == "ICO"
    actual = set(ico.ico.sizes())
    assert required.issubset(actual)
```

## Fail closed

A file extension alone does not prove ICO validity.
A preview alone does not prove ICO validity.
An inaccessible or invented path must never be delivered.
