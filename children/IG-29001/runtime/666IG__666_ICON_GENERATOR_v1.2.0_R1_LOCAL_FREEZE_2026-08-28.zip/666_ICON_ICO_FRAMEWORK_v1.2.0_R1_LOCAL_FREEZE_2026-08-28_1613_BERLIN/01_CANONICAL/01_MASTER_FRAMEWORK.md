# 666 TEXT TO IMAGE TO ICON TO ICO FRAMEWORK
## Local Recovery Candidate v1.2.0-R1

CANONICAL_NAME_AUTHORITY=UNRESOLVED_PENDING_LIVE_DRIVE_AUTHORITY
LOCAL_WORKING_NAME=666 TEXT TO IMAGE TO ICON TO ICO FRAMEWORK
FRAMEWORK_ROLE=TEXT_IMAGE_ICON_ICO_PIPELINE
LOCAL_CANDIDATE_VERSION=1.2.0-R1
PUBLICATION_STATUS=LOCAL_FREEZE_NOT_REGISTERED
PARENT_NAMESPACE=666PFS
CHILD_AUTOLOAD=FORBIDDEN
EXPLICIT_SELECTION_ONLY=TRUE
STANDALONE_TRIGGER=FORBIDDEN
SECOND_BOOTSTRAP=FORBIDDEN
SECOND_UPDATE_ROUTE=FORBIDDEN
CORE_MUTATION=FALSE
LYVRA=EXTERNAL_UNCHANGED

## Purpose

This framework converts a user request into a usable Windows icon artifact.

Canonical causal pipeline:

```text
REQUEST
→ INTENT_RESOLUTION
→ SOURCE_OR_IMAGE_GENERATION
→ ICON_OPTIMIZATION
→ PNG_INTERMEDIATE
→ ICO_MULTI_SIZE_EXPORT
→ ICO_READBACK
→ FILE_EXISTENCE_CHECK
→ REAL_DOWNLOAD_LINK
→ CLEAR_TEMPORARY_TARGET_CONTEXT
→ COMPLETE
```

A PNG is never sufficient to complete an ICO workflow.

## Supported intent forms

### Explicit

```text
ICON: <description>
ICO: <uploaded image>
ICO EDIT: <edit instruction>
```

### Natural-language intent

Requests such as:

```text
ich brauche ein 3DX SCRIPT ICON
mach mir ein Windows Icon für mein Script
erstelle ein Icon für mein Tool
das Bild bitte als ICO
```

must be understood semantically and causally, not only by prefix matching.

Within this framework, an ordinary request for an app/tool/script/Windows icon defaults to:

```text
ICO_REQUIRED=TRUE
```

unless the user explicitly requests image-only output.

## Generator identity protection

```text
GENERATOR_IDENTITY_IS_IMMUTABLE=TRUE
TARGET_CONTEXT_IS_NOT_IDENTITY=TRUE
LAST_OUTPUT_IS_NOT_IDENTITY=TRUE
GENERATED_ASSET_CONTEXT=TEMPORARY
OUTPUT_FILENAME_IS_NOT_FRAMEWORK_IDENTITY=TRUE
AFTER_ASSET_EXPORT=CLEAR_TARGET_CONTEXT_AND_REASSERT_GENERATOR_IDENTITY
PROHIBITED_INHERITANCE=TARGET_NAME|TARGET_ID|ICON_FILENAME|ASSET_FILENAME|LAST_PROJECT_CONTEXT|LAST_OUTPUT
```

The words printed inside an icon describe the target asset. They never rename the framework.

## Image generation/edit routing

TEXT_ICON_REQUEST:
- create a square app-icon image
- use the user-requested subject/style
- preserve icon-safe margins
- then continue to ICO conversion

IMAGE_TO_ICO:
- reuse the provided image when the user requests no artistic changes
- square-pad proportionally when technically necessary
- preserve alpha/transparency

ICO_EDIT:
- require a usable source image
- perform requested image edit
- then continue to ICO conversion

## Icon visual profile

- square 1:1 composition
- preferred source resolution >= 1024×1024
- centered main subject
- icon-safe border >= 8% where feasible
- high contrast at small sizes
- no accidental cropping of text/symbols
- no stretching
- transparency preserved
- text only when requested or clearly intrinsic to the target identity
- target branding is temporary asset context, not framework identity

## Windows ICO profile

Mandatory embedded sizes:

```text
16x16
24x24
32x32
48x48
64x64
96x96
128x128
256x256
```

## Completion guard

```text
ICON_REQUEST_COMPLETION_GUARD=MANDATORY
PNG_OUTPUT=INTERMEDIATE_ONLY
ICON_REQUEST_NOT_COMPLETE_UNTIL_ICO_EXISTS=TRUE
ICO_MULTI_SIZE_REQUIRED=16|24|32|48|64|96|128|256
ICO_READBACK_REQUIRED=TRUE
DOWNLOAD_LINK_MUST_REFERENCE_REAL_ICO=TRUE
FINAL_SUCCESS_BEFORE_ICO=FORBIDDEN
IF_ICO_CONVERSION_FAILS=REPORT_BLOCKED_NOT_SUCCESS
```

If the image exists but the ICO does not, status is:

```text
PARTIAL
IMAGE_STATUS=PASS
ICO_STATUS=PENDING_OR_BLOCKED
TASK_COMPLETE=FALSE
```

Never present that state as success.

## Filename policy

1. preserve meaningful user label
2. spaces → underscores
3. remove Windows-invalid characters `< > : " / \ | ? *`
4. collapse repeated underscores
5. use exact `.ico` extension
6. never link a non-existing path

## Mandatory readback

Before delivery:

```text
FILE_EXISTS=TRUE
FILE_SIZE_GT_ZERO=TRUE
FORMAT=ICO
EXPECTED_SIZES_PRESENT=TRUE
READBACK=PASS
DOWNLOAD_TARGET_EXISTS=TRUE
```

Only then:

```text
TASK_COMPLETE=TRUE
ICO_STATUS=PASS
```

## Host/tool failure

If any required capability is unavailable:

- do not invent completion
- do not invent a sandbox path
- preserve the last verified intermediate
- return `BLOCKED` or `PARTIAL`
- state exactly which stage failed

## Output contract

Successful completion must include an actual user-accessible `.ico` file reference/download.

The generated PNG may additionally be provided, but is not a substitute for the ICO.
