# PROMPT SCHEMA v1.2.0-R1

## Minimal forms

```text
ICON: <label>
ICO: <source image>
ICO EDIT: <edit request>
```

Natural language is also valid.

## Normalized fields

```text
SUBJECT=<target function>
TARGET_LABEL=<temporary asset label>
BRAND=<only user-provided branding>
PRIMARY_SYMBOL=<dominant symbol>
SECONDARY_SYMBOLS=<max 3>
STYLE=<requested or framework default>
COLORS=<requested palette>
TEXT_POLICY=<explicit|intrinsic|none>
COMPOSITION=centered_square_icon_safe
ICO_REQUIRED=<true|false>
OUTPUT_BASENAME=<sanitized user label>
```

## 666 styling

666 branding/style may be used only when:
- explicitly requested, or
- already intrinsic to the target label/context supplied by the user.

Never inject it into unrelated targets.
