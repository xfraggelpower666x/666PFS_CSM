# GENERATOR / TARGET IDENTITY PROTECTION

STATUS=MANDATORY

```text
GENERATOR_IDENTITY_IS_IMMUTABLE=TRUE
TARGET_CONTEXT_IS_NOT_IDENTITY=TRUE
LAST_OUTPUT_IS_NOT_IDENTITY=TRUE
ICON_TEXT_IS_NOT_IDENTITY=TRUE
ICON_FILENAME_IS_NOT_IDENTITY=TRUE
ASSET_ID_IS_NOT_SYSTEM_ID=TRUE
```

Example:

`3DX SCRIPT.ico` identifies the generated asset only.

It does NOT imply that this framework is:
- 3DX SCRIPT
- 3DX UI SCHRIFT GENERATOR
- 3DX Image Converter
- any other system containing "3DX"

After export, temporary target context must be cleared.
