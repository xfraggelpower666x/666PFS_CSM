# INTENT ROUTER v1.2.0-R1

## Resolution priority

1. explicit `ICO EDIT`
2. explicit `ICO`
3. explicit `ICON`
4. natural-language Windows/app/tool/script icon intent
5. image-only icon intent when the user explicitly excludes ICO

## Natural-language ICO signals

Strong ICO-required signals:
- Windows icon
- `.ico`
- shortcut icon
- EXE icon
- script icon
- tool icon
- program icon
- app icon in a desktop/Windows context
- "zum Download" after asking for an icon

Within this dedicated framework, an unqualified software-icon request defaults to ICO completion.

## Anti-false-completion

The following are never terminal success states for an ICO-required request:
- image generated
- PNG generated
- preview displayed
- image tool returned successfully

Terminal success requires verified `.ico`.
