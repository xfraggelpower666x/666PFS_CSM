# START HERE — LOCAL FRAMEWORK RECOVERY / FREEZE

PACKAGE=666_ICON_ICO_FRAMEWORK_v1.2.0_R1_LOCAL_FREEZE_2026-08-28_1613_BERLIN
DATE_BERLIN=2026-08-28
SOURCE_BASELINE=historical v1.1.0 package
LOCAL_CANDIDATE_VERSION=1.2.0-R1
PUBLICATION_STATUS=LOCAL_FREEZE_ONLY
DRIVE_WRITE=FALSE
DRIVE_REGISTRY_MUTATION=FALSE
CHILD_POINTER_MUTATION=FALSE
CORE_POINTER_MUTATION=FALSE
LYVRA=EXTERNAL_UNCHANGED

## Important identity rule

The historical package contains obsolete/conflicting identity metadata.
Those historical identifiers are retained only in `06_HISTORY/`.

The local repaired framework deliberately does NOT claim a live 666PFS Child ID.

CANONICAL_NAME_AUTHORITY=UNRESOLVED_PENDING_LIVE_DRIVE_AUTHORITY
LOCAL_WORKING_NAME=666 TEXT TO IMAGE TO ICON TO ICO FRAMEWORK
LIVE_CHILD_ID=UNASSIGNED
LIVE_ENTRY_ID=UNASSIGNED
LIVE_POINTER=UNASSIGNED

Never derive framework identity from:
- target application name
- generated icon text
- output filename
- 3DX SCRIPT
- previous output
- historical TIICO metadata
- historical entry number 11001

Before any future Drive publication:
1. read live 666PFS registry
2. read live current pointer
3. resolve actual renamed framework identity
4. confirm free/authorized ID if registration is needed
5. keep CODEFORGE ownership of 11001 unchanged
