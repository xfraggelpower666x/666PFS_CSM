# REPAIR LOG

REPAIR_MODE=MINIMAL_SAFE_PLUS_CAUSAL_HARDENING

## Repair 1 — identity decontamination
Removed live authority claims from the local canonical candidate.
Historical TIICO/GPT/11001 material moved to HISTORY only.

## Repair 2 — host-neutral framework
Canonical candidate no longer defines itself by a specific GPT identity.
Execution is described by capabilities and stages instead of product naming.

## Repair 3 — mandatory completion guard
PNG is explicitly intermediate.
A real `.ico` plus readback plus real file reference is required for success.

## Repair 4 — natural-language routing
Software icon requests such as `ich brauche ein 3DX SCRIPT ICON` are valid inputs
without requiring a special prefix.

## Repair 5 — immutable generator identity
Target labels, filenames, generated text, last project, and last output cannot rename
or rebind the framework.

## Repair 6 — partial/block semantics
If conversion cannot finish, the system must say PARTIAL/BLOCKED instead of implying success.

## Repair 7 — regression test
The actual 2026-08-28 `3DX SCRIPT` PNG + multi-size ICO are included as a test fixture.
