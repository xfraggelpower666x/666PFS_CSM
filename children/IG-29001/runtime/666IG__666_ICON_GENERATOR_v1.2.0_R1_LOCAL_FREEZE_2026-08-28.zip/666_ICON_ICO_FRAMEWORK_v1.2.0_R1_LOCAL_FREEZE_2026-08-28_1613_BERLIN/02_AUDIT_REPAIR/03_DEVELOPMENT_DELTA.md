# DEVELOPMENT DELTA v1.2.0-R1

## Added capabilities

- implicit natural-language icon intent recognition
- mandatory end-to-end completion state machine
- actual-file download guard
- generator/target identity firewall
- post-export temporary-context reset
- regression fixture from real 3DX SCRIPT incident
- explicit local-vs-live authority separation
- host-neutral canonical description

## Causal state machine

```text
INTAKE
→ INTENT_RESOLVED
→ SOURCE_READY
→ IMAGE_READY
→ PNG_INTERMEDIATE_READY
→ ICO_WRITTEN
→ ICO_READBACK_PASS
→ DOWNLOAD_REFERENCE_PASS
→ CONTEXT_RESET
→ COMPLETE
```

Any failed stage stops forward success propagation.

## No duplicate-system rule

The repair is an evolution of the existing functional framework.
It does not justify creating a second icon/ICO framework.
Future live publication must rebind to the verified renamed identity if one exists.
