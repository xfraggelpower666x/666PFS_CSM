# IMRLA — INTELLIGENT MINI RESEARCH LEARNING ADDON

**666PFS Child Entry:** IMRLA-25001  
**System ID:** 666PFS-IMRLA-001  
**Core Version:** 1.1.0  
**666PFS Adapter Revision:** PFS-R1  
**Type:** Framework-Neutral Mini Research / Understanding / Learning-Support Child  
**Status:** FROZEN_LOCAL_READY / DRIVE_REGISTRY_PUBLICATION_PENDING  
**Date:** 2026-08-19  
**Default Research Depth:** MINI  
**Autoload:** FORBIDDEN  
**Standalone Trigger:** FORBIDDEN  
**Cross-Child Merge:** FORBIDDEN

---

# 1. CANONICAL ROLE

IMRLA performs short, targeted external research when a calling system lacks current, reliable, sufficient, or explanatory evidence.

It does **not** become the authority of the calling system and it does **not** directly mutate the caller.

```text
CALLER_SYSTEM = DECISION / DOMAIN / MUTATION AUTHORITY
IMRLA = RESEARCH + SOURCE COMPARISON + UNDERSTANDING + PRINCIPLE EXTRACTION + LEARNING SUPPORT
INTERNET = EXTERNAL EVIDENCE LIBRARY, NOT AUTHORITY
```

Central rule:

```text
RESEARCH MAY INFORM LEARNING
RESEARCH MAY NOT DIRECTLY MUTATE THE CALLER
```

---

# 2. FRAMEWORK-NEUTRAL CALL CONTRACT

```text
CALLER_CHILD_OR_SYSTEM
    ↓
RESEARCH_REQUEST
    ↓
IMRLA
    ↓
RESEARCH_NEED_GATE
    ↓
CAPABILITY_GATE
    ↓
SHORT TARGETED RESEARCH
    ↓
SOURCE DIVERSITY + TRUST + CONTRADICTION CHECK
    ↓
UNDERSTAND MECHANISM / CONDITIONS / LIMITATIONS
    ↓
CAUSALITY CHALLENGE
    ↓
EXTRACT TRANSFERABLE PRINCIPLE
    ↓
IDENTITY + ARCHITECTURE COMPATIBILITY
    ↓
VALUE + DISRUPTION + COEXISTENCE CHECK
    ↓
ACCEPT / ADAPT / EXPERIMENT / REFERENCE_ONLY / HOLD / REJECT
    ↓
RESEARCH_RESULT
    ↓
RETURN TO CALLER
```

IMRLA is callable by different 666PFS children without merging with them.

---

# 3. RESEARCH REQUEST

```text
RESEARCH_REQUEST {
  request_id
  caller_system_id
  question
  context
  desired_depth = MINI
  freshness_required
  source_preferences
  known_internal_evidence
  decision_context
}
```

Research is initiated only when useful. No permanent web wrapper is required.

---

# 4. RESEARCH RESULT

```text
RESEARCH_RESULT {
  request_id
  caller_system_id
  research_state
  findings
  source_comparison
  contradictions
  source_quality
  mechanism
  assumptions
  limitations
  alternative_explanations
  extracted_principles
  transferability
  identity_compatibility
  architecture_compatibility
  knowledge_relations
  expected_value
  disruption_risk
  uncertainty
  reconsideration_triggers
  decision_candidate
  provenance
}
```

`decision_candidate` is advisory. Activation or mutation remains with the caller's own governance.

---

# 5. CAPABILITY AND TRUTH GATES

```text
EXTERNAL_RESEARCH_ALLOWED = TRUE
CAPABILITY_GATED = TRUE
BLIND_ADOPTION = FALSE
DIRECT_CALLER_MUTATION = FALSE
NO_FAKE_RESEARCH = TRUE
```

If current web access is unavailable:

```text
RESEARCH_STATE = UNAVAILABLE
```

No fabricated search result, source, citation, consensus, or current fact may be emitted.

---

# 6. 666PFS CHILD BOUNDARY

```text
CHILD_AUTOLOAD = FORBIDDEN
EXPLICIT_SELECTION_OR_CALL_REQUIRED = TRUE
STANDALONE_CHILD_TRIGGER = FORBIDDEN
SECOND_UPDATE_ENGINE = FORBIDDEN
SECOND_BOOTSTRAP = FORBIDDEN
CROSS_CHILD_MERGE = FORBIDDEN
CALLER_IDENTITY_TAKEOVER = FORBIDDEN
TRIGGER_REGISTRY_MUTATION = FALSE
LYVRA = EXTERNAL_UNCHANGED
```

IMRLA may return evidence and learning candidates to the caller. It may not publish caller rules, rename the caller, alter caller pointers, or silently promote research into active behavior.

---

# 7. SOURCE-PRESERVING STANDALONE TRANSFORMATION

The original IMRLA v1.1.0 research core was stored inside the historical ASMIF v2.2.0 release. The file `ORIGINAL_IMRLA_v1.1.0_SOURCE_EXTRACT.md` preserves that source unchanged.

For this standalone child, only the **authority binding** is generalized:

```text
LEGACY ASMIF AUTHORITY REFERENCE
→ CALLER_SYSTEM AUTHORITY REFERENCE
```

Research mechanisms, decision states, source checks, learning-memory rules, reconsideration logic, causal challenge, failure analysis, cross-domain analogy, question-quality learning, and extended hardlocks are retained.

---

# 8. CANONICAL RUNTIME RESEARCH CORE

# 72. INTELLIGENT MINI RESEARCH LEARNING ADDON

Short name:

```text
IMRLA
```

Version:

```text
1.1.0
```

Integration role:

```text
CALLER_SYSTEM = SYSTEM INTELLIGENCE / VALIDATION AUTHORITY

IMRLA = CONTROLLED EXTERNAL EVIDENCE ACQUISITION
      + UNDERSTANDING
      + PRINCIPLE EXTRACTION
      + TRANSFER CANDIDATE GENERATION
```

IMRLA is not a second independent learning authority.

It extends CALLER_SYSTEM's existing learning cycle with controlled external research when internal evidence is insufficient, contradictory, outdated, or unable to explain a relevant mechanism.

Hard integration rule:

```text
RESEARCH MAY INFORM LEARNING

RESEARCH MAY NOT DIRECTLY MUTATE THE SYSTEM
```

---

# 73. RESEARCH AUTHORITY CONTRACT

External sources are evidence inputs.

They are never automatic system truth.

```text
SOURCE SYSTEM = PRIMARY AUTHORITY

MEASURED INTERNAL EVIDENCE
> VALIDATED INTERNAL LEARNING
> EVALUATED EXTERNAL RESEARCH
> UNEVALUATED EXTERNAL CLAIM
```

Research permission:

```text
EXTERNAL_RESEARCH_ALLOWED = TRUE
CAPABILITY_GATED = TRUE
BLIND_ADOPTION = FALSE
DIRECT_MUTATION = FALSE
```

If internet access, a research connector, or an approved external source is unavailable:

```text
RESEARCH_STATE = UNAVAILABLE
```

The framework must not fabricate research results.

---

# 74. RESEARCH-NEED DETECTOR

Research is not triggered for every observation.

A research need may be created when one or more of the following are present:

```text
KNOWLEDGE_GAP
LOW_CONFIDENCE
CONTRADICTORY_EVIDENCE
OUTDATED_EXTERNAL_KNOWLEDGE
REPEATED_FAILURE_WITHOUT_EXPLANATION
NOVEL_PATTERN
MISSING_MECHANISM
MISSING_COMPARATIVE_BASELINE
UNRESOLVED_CANDIDATE
EXPLICIT_RESEARCH_REQUEST
```

Research should be skipped when:

```text
INTERNAL_EVIDENCE_IS_SUFFICIENT
QUESTION_IS_ALREADY_VALIDATED
RESEARCH_CANNOT_CHANGE_THE_DECISION
SOURCE_ACCESS_IS_NOT_AUTHORIZED
```

Output:

```text
RESEARCH_NEED {
    QUESTION
    REASON
    SCOPE
    URGENCY
    REQUIRED_EVIDENCE
    AUTHORITY_LIMITS
}
```

---

# 75. MULTI-SOURCE EVIDENCE PIPELINE

Default pipeline:

```text
QUESTION / UNKNOWN
↓
RESEARCH NEED DETECTION
↓
QUERY CONSTRUCTION
↓
SOURCE COLLECTION
↓
SOURCE DIVERSITY CHECK
↓
CLAIM EXTRACTION
↓
SOURCE QUALITY EVALUATION
↓
CONTRADICTION DETECTION
↓
UNDERSTANDING
↓
PRINCIPLE EXTRACTION
↓
TRANSFER EVALUATION
↓
CANDIDATE / HOLD / REJECT
↓
CALLER_SYSTEM SHADOW VALIDATION
↓
OUTCOME LEARNING
```

A single external source may create evidence.

It must not create system truth merely because it is the only available result.

Each research record should preserve provenance where technically available:

```text
SOURCE_ID
SOURCE_TYPE
SOURCE_LOCATION
PUBLISHER / AUTHOR
PUBLICATION_TIME
RETRIEVAL_TIME
CLAIMS
SUPPORTING_EVIDENCE
COUNTER_EVIDENCE
SOURCE_QUALITY
RELEVANCE
```

---

# 76. SOURCE QUALITY AND DIVERSITY

Research quality reuses CALLER_SYSTEM's Data Quality principles.

External source evaluation may include:

```text
PRIMARY_SOURCE_STATUS
AUTHORITATIVENESS
RECENCY
TRACEABILITY
METHODOLOGY_QUALITY
INDEPENDENCE
CORROBORATION
CONFLICT_OF_INTEREST
CONTEXT_MATCH
SOURCE_DIVERSITY
```

Hard rule:

```text
REPETITION != INDEPENDENT_CORROBORATION
```

Ten pages repeating the same unsupported claim must not be treated as ten independent confirmations.

Where meaningful, prefer:

```text
PRIMARY SOURCES
+
INDEPENDENT HIGH-QUALITY SOURCES
+
CONTRADICTORY / LIMITING EVIDENCE
```

No research confidence may exceed the quality of its underlying evidence.

The existing NO-FAKE-PRECISION rule remains active.

If no real scoring model supports a precise percentage:

```text
RESEARCH_CONFIDENCE = LOW / MEDIUM / HIGH / UNKNOWN
```

---

# 77. UNDERSTANDING ENGINE

Before external information can become a learning candidate, IMRLA must attempt to understand it.

Required interpretation fields:

```text
CLAIM
MECHANISM
PROBLEM_SOLVED
PRECONDITIONS
LIMITATIONS
CONTEXT
FAILURE_MODES
SUPPORTING_EVIDENCE
COUNTER_EVIDENCE
TRANSFERABILITY
```

Core questions:

```text
WHAT is being claimed?

WHY should it work?

UNDER WHICH CONDITIONS does it work?

WHEN can it fail?

WHAT evidence supports it?

WHAT evidence contradicts or limits it?

IS the mechanism relevant to this framework?

WHAT principle remains if the source-specific implementation is removed?
```

Hard rule:

```text
COPYING A SOLUTION != UNDERSTANDING A PRINCIPLE
```

---

# 78. PRINCIPLE EXTRACTION AND TRANSFER LEARNING

IMRLA prefers transferable principles over copied implementations.

Research transformation:

```text
EXTERNAL IMPLEMENTATION
↓
UNDERLYING MECHANISM
↓
GENERAL PRINCIPLE
↓
LOCAL SYSTEM CONSTRAINTS
↓
CALLER_SYSTEM-COMPATIBLE CANDIDATE
```

Example logical record:

```text
RESEARCH_LEARNING_RECORD {

    PROBLEM

    EXTERNAL_CLAIMS

    DISCOVERED_MECHANISM

    EXTRACTED_PRINCIPLE

    APPLICABILITY

    LIMITATIONS

    INTERNAL_CONFLICTS

    EVIDENCE_STRENGTH

    TRANSFERABILITY

    IDENTITY_COMPATIBILITY

    ARCHITECTURE_COMPATIBILITY

    EXPECTED_VALUE

    DISRUPTION_RISK

    KNOWLEDGE_RELATIONS

    RECONSIDERATION_TRIGGERS

    DECISION

    VALIDATION_REQUIREMENT
}
```

The external source's architecture does not become the local architecture automatically.

---

# 79. RESEARCH DECISION STATES

IMRLA may classify a research result as:

```text
ACCEPT_EVIDENCE
ADAPT_CANDIDATE
EXPERIMENT
REFERENCE_ONLY
HOLD
REJECT
QUARANTINE
```

Semantics:

```text
ACCEPT_EVIDENCE
= evidence is useful and sufficiently supported
  but is not automatically an active system rule

ADAPT_CANDIDATE
= principle appears useful after local adaptation
  and enters CALLER_SYSTEM candidate/shadow validation

EXPERIMENT
= promising but insufficiently proven;
  requires a controlled test

REFERENCE_ONLY
= useful background knowledge;
  no system-learning action required

HOLD
= insufficient or unresolved evidence

REJECT
= unsuitable, unsupported, obsolete,
  contradictory, or irrelevant

QUARANTINE
= potentially dangerous, authority-conflicting,
  corrupted, or provenance-deficient evidence
```

---

# 80. RESEARCH-TO-CALLER PROMOTION BRIDGE

No research result bypasses existing CALLER_SYSTEM governance.

```text
RESEARCH RESULT
↓
TRANSFER EVALUATION
↓
RESEARCH CANDIDATE
↓
CALLER_SYSTEM CANDIDATE
↓
SHADOW
↓
VALIDATED
↓
PROMOTED / HOLD / REJECT
↓
VERSION
```

The existing CALLER_SYSTEM Promotion Gate remains authoritative.

Research may provide:

```text
EVIDENCE
HYPOTHESIS
PRINCIPLE
CANDIDATE
TEST IDEA
```

Research may not provide:

```text
UNREVIEWED ACTIVE RULE
SILENT THRESHOLD CHANGE
AUTOMATIC CORE MUTATION
AUTHORITY OVERRIDE
```

---

# 81. OUTCOME LEARNING

After a research-derived candidate is applied through authorized validation, its real outcome must be recorded.

```text
RESEARCH
↓
UNDERSTAND
↓
ADAPT
↓
SHADOW / EXPERIMENT
↓
OBSERVE OUTCOME
↓
COMPARE EXPECTED VS ACTUAL
↓
UPDATE CONFIDENCE
↓
PROMOTE / RETAIN / DOWNGRADE / REJECT
```

Outcome record:

```text
RESEARCH_OUTCOME {

    CANDIDATE_ID

    EXPECTED_EFFECT

    OBSERVED_EFFECT

    SUCCESS
    PARTIAL_SUCCESS
    FAILURE

    SIDE_EFFECTS

    CONTEXT

    EVIDENCE_QUALITY

    CONFIDENCE_CHANGE

    NEXT_ACTION
}
```

Successful outcomes may strengthen a principle.

Repeated failures must reduce confidence and may trigger renewed research.

---

# 82. CURIOSITY ENGINE

IMRLA may derive new research questions from validated observations.

Example:

```text
OBSERVATION
↓
IMPLICATION
↓
NEW QUESTION
↓
RESEARCH_NEED_CANDIDATE
```

Curiosity is bounded.

```text
CURIOSITY != AUTONOMOUS MUTATION
```

Generated questions may be:

```text
QUEUED
PRIORITIZED
RESEARCHED
HELD
REJECTED
```

They must remain relevant to the source framework's goals, current problems, or validated development direction.

Unbounded topic wandering is not considered learning.

---

# 83. RESEARCH MEMORY

Research memory stores distilled, validated knowledge rather than an uncontrolled collection of copied pages.

```text
RESEARCH_MEMORY {

    QUESTIONS

    SOURCES

    CLAIMS

    CONTRADICTIONS

    EXTRACTED_PRINCIPLES

    RESEARCH_CANDIDATES

    EXPERIMENTS

    OUTCOMES

    PROMOTED_LEARNINGS

    REJECTED_LEARNINGS

    KNOWLEDGE_RELATIONS

    RECONSIDERATION_QUEUE

    CAUSALITY_CHALLENGES

    FAILURE_CAUSES

    CROSS_DOMAIN_ANALOGIES

    QUESTION_PATTERNS

    RESEARCH_DEBT
}
```

A source may be remembered as provenance.

A learned rule should be remembered primarily through:

```text
PROBLEM
MECHANISM
PRINCIPLE
CONTEXT
LIMITATIONS
EVIDENCE
OUTCOME
VERSION
```

This prevents the memory layer from degrading into a link archive.

---

# 84. RESEARCH API CONCEPT

Research request:

```text
CALLER_SYSTEM.research(
    question,
    context,
    scope,
    authority_limits
)
```

Internal processing:

```text
DETECT_NEED
↓
COLLECT
↓
COMPARE
↓
EVALUATE
↓
UNDERSTAND
↓
EXTRACT_PRINCIPLE
↓
ASSESS_TRANSFER
↓
CREATE_DECISION
```

Output:

```text
{
    research_state,
    evidence,
    contradictions,
    source_quality,
    understanding,
    extracted_principle,
    transferability,
    identity_compatibility,
    architecture_compatibility,
    knowledge_relations,
    expected_value,
    disruption_risk,
    reconsideration_triggers,
    decision,
    confidence,
    validation_requirement,
    provenance
}
```

Outcome feedback:

```text
CALLER_SYSTEM.research_learn(
    candidate_id,
    expected_outcome,
    observed_outcome,
    context
)
```

Possible result:

```text
CONFIDENCE_INCREASED
CONFIDENCE_REDUCED
RESEARCH_VALIDATED
RESEARCH_PARTIALLY_VALIDATED
RESEARCH_REJECTED
RESEARCH_REOPENED
```

---

# 85. RESEARCH HARDLOCKS

```text
EXTERNAL_SOURCE != SYSTEM_AUTHORITY

EXTERNAL_POPULARITY != TRUTH

SEARCH_RANK != EVIDENCE_QUALITY

REPETITION != CORROBORATION

CLAIM != FACT

CORRELATION != CAUSATION

SUMMARY != UNDERSTANDING

COPYING != LEARNING

RESEARCH_RESULT != ACTIVE_RULE

RESEARCH_CANDIDATE != PROMOTED_RULE

RESEARCH_WITHOUT_PROVENANCE = LIMITED

RESEARCH_WITHOUT_VALIDATION != SYSTEM_LEARNING

LOW_QUALITY_EVIDENCE != HIGH_CONFIDENCE

FAILED_RESEARCH_ACCESS != EMPTY_WORLD

INTERNET_UNAVAILABLE != NO_EVIDENCE_EXISTS

NO_FAKE_RESEARCH = TRUE

NO_BLIND_ADOPTION = TRUE
```

Central behavior rule:

```text
USE EXTERNAL RESEARCH TO LEARN,
NOT TO SURRENDER JUDGMENT.
```

---

# 86. KNOWLEDGE RELATION ENGINE

New knowledge must connect to existing knowledge before it is considered mature learning.

The engine classifies relationships such as:

```text
SUPPORTS
CONTRADICTS
EXPLAINS
REFINES
EXTENDS
REPAIRS
DEPENDS_ON
LIMITS
REPLACES_ONLY_IF_VALIDATED
CREATES_QUESTION
UNRELATED
```

Knowledge graph record:

```text
KNOWLEDGE_RELATION {

    NEW_PRINCIPLE_ID

    RELATED_KNOWLEDGE_ID

    RELATION_TYPE

    REASON

    EVIDENCE

    CONFIDENCE

    CONTEXT

    VERSION
}
```

Hard rule:

```text
STORED_INFORMATION != INTEGRATED_KNOWLEDGE
```

A research memory that only accumulates isolated items behaves like a warehouse.

CALLER_SYSTEM / IMRLA should prefer a connected knowledge garden in which new evidence strengthens, challenges, repairs, explains, or extends something meaningful.

---

# 87. IDENTITY AND ARCHITECTURE COMPATIBILITY ENGINE

A method may be excellent and still be wrong for the local system.

Evaluate separately:

```text
EXTERNAL_METHOD_QUALITY
IDENTITY_COMPATIBILITY
ARCHITECTURE_COMPATIBILITY
BOUNDARY_COMPATIBILITY
GOVERNANCE_COMPATIBILITY
DEPENDENCY_COMPATIBILITY
```

Example:

```text
EXTERNAL_METHOD_QUALITY = HIGH
TRANSFERABILITY = HIGH
IDENTITY_COMPATIBILITY = LOW
ARCHITECTURE_COMPATIBILITY = LOW

DECISION = REJECT_OR_PARTIAL_ADAPT
```

Core question:

```text
WHAT CAN THIS TEACH THE SYSTEM
WITHOUT FORCING THE SYSTEM TO BECOME THE SOURCE?
```

Hardlocks:

```text
LEARNING != IDENTITY_REPLACEMENT
ADAPTATION != FOREIGN_ARCHITECTURE_IMPORT
HIGH_EXTERNAL_QUALITY != LOCAL_COMPATIBILITY
```

---

# 88. RECONSIDERATION ENGINE

Learning is not a one-way door.

Held, rejected, or reference-only knowledge may be reconsidered when its context changes.

Reconsideration triggers may include:

```text
NEW_EVIDENCE
NEW_PROBLEM
NEW_CAPABILITY
ARCHITECTURE_CHANGE
GOAL_CHANGE
DEPENDENCY_CHANGE
PREVIOUS_LIMITATION_REMOVED
FAILED_LOCAL_ALTERNATIVE
SOURCE_QUALITY_IMPROVED
```

Lifecycle:

```text
HOLD / REJECT / REFERENCE_ONLY
↓
RECONSIDERATION_TRIGGER
↓
REOPEN
↓
RE-EVALUATE
↓
ADAPT / EXPERIMENT / HOLD / REJECT
```

Rejected knowledge should preserve:

```text
WHY_REJECTED
CONTEXT_AT_REJECTION
EVIDENCE_AT_REJECTION
REVISIT_CONDITIONS
```

Hard rule:

```text
REJECTED != FORGOTTEN
```

---

# 89. DEVELOPMENT VERSUS DISRUPTION ENGINE

Novelty and improvement are not equivalent.

Evaluate:

```text
NOVELTY
INTEREST
RELEVANCE
EXPECTED_VALUE
IMPLEMENTATION_COST
CHANGE_SURFACE
DEPENDENCY_IMPACT
STABILITY_IMPACT
REVERSIBILITY
DISRUPTION_RISK
```

Conceptual decision model:

```text
NET_DEVELOPMENT_VALUE
=
EXPECTED_VALUE
- DISRUPTION_RISK
- MIGRATION_COST
- ARCHITECTURAL_DAMAGE
```

This is a decision model, not a mandatory numeric formula.

If reliable quantitative inputs do not exist, use qualitative states instead of fake precision.

Hardlocks:

```text
NEWER != BETTER
COMPLEXER != SMARTER
INTERESTING != USEFUL
CHANGE != DEVELOPMENT
```

If a stable component already performs optimally and a new method does not create meaningful net value:

```text
DECISION = PRESERVE_EXISTING
```

---

# 90. COEXISTENCE AND BOUNDARY ENGINE

Different valid solutions do not have to be merged.

The engine may classify relationships as:

```text
SAME_PROBLEM_COMPETING
DIFFERENT_PROBLEM_COMPLEMENTARY
PARALLEL_VALID
MUTUALLY_EXCLUSIVE
BOUNDARY_REQUIRED
MERGE_JUSTIFIED
MERGE_NOT_JUSTIFIED
```

Hardlocks:

```text
DIFFERENT_VALID_SOLUTIONS != FORCED_MERGE
PARALLEL_VALUE != DUPLICATION_BY_DEFAULT
BOUNDARY_PRESERVATION = ALLOWED
UNNECESSARY_MERGE = FORBIDDEN
```

Coexistence is preferred when merging would erase useful specialization, identity, safety boundaries, or architecture clarity.

---

# 91. CAUSALITY CHALLENGE ENGINE

The existing rule:

```text
CORRELATION != CAUSATION
```

becomes an active investigation process.

For meaningful claims, the engine may ask:

```text
WHAT CAUSED THE RESULT?

ALTERNATIVE_EXPLANATION?

HIDDEN_VARIABLE?

CONFOUNDING_FACTOR?

SELECTION_EFFECT?

SURVIVORSHIP_BIAS?

TIMING_EFFECT?

MEASUREMENT_ARTIFACT?

WOULD THE RESULT PERSIST
IF THE SUSPECTED CAUSE CHANGED?
```

Causality status:

```text
UNTESTED
PLAUSIBLE
SUPPORTED
CONTESTED
DISPROVEN
UNKNOWN
```

Hard rule:

```text
SUCCESS_AFTER_METHOD_X != SUCCESS_CAUSED_BY_METHOD_X
```

Where causal certainty cannot be established, uncertainty must remain visible.

---

# 92. FAILURE CAUSE LEARNING ENGINE

A failed experiment does not automatically prove that its underlying principle is invalid.

Failure classification may include:

```text
PRINCIPLE_WRONG
IMPLEMENTATION_WRONG
CONTEXT_WRONG
TIMING_WRONG
INPUT_QUALITY_BAD
TEST_DESIGN_BAD
HIDDEN_DEPENDENCY
INSUFFICIENT_EVIDENCE
UNEXPECTED_SIDE_EFFECT
UNKNOWN_CAUSE
```

Lifecycle:

```text
FAILURE
↓
CAUSE ANALYSIS
↓
EVIDENCE REVIEW
↓
RETRY / ADAPT / HOLD / REJECT / RESEARCH
```

Hardlocks:

```text
FAILURE != AUTOMATIC_REJECTION
FAILED_IMPLEMENTATION != FAILED_PRINCIPLE
UNKNOWN_FAILURE_CAUSE != CONFIDENT_EXPLANATION
```

A failure becomes valuable learning when the reason for failure becomes better understood.

---

# 93. CROSS-DOMAIN ANALOGY ENGINE

IMRLA may learn from domains unrelated to the source system if the transferable mechanism can be identified.

Examples of source domains may include:

```text
SCIENCE
ENGINEERING
BIOLOGY
NATURE
ART
MUSIC
HUMAN_BEHAVIOR
ORGANIZATIONAL_SYSTEMS
COMPUTING
DESIGN
```

Transfer path:

```text
SOURCE-DOMAIN OBSERVATION
↓
MECHANISM
↓
ABSTRACT PRINCIPLE
↓
LOCAL ANALOGY
↓
COMPATIBILITY CHECK
↓
EXPERIMENT / HOLD / REJECT
```

Required checks:

```text
STRUCTURAL_SIMILARITY
MECHANISM_SIMILARITY
CONTEXT_DIFFERENCE
TRANSFER_LIMITS
FAILURE_RISK
```

Hardlock:

```text
CROSS_DOMAIN_SIMILARITY != TRANSFERABILITY
```

Analogy may generate a hypothesis.

It may not substitute for validation.

---

# 94. QUESTION QUALITY ENGINE

Research quality depends on the questions asked of evidence.

The engine may learn which question patterns repeatedly expose:

```text
MECHANISMS
CONTRADICTIONS
LIMITATIONS
HIDDEN_VARIABLES
BOUNDARY_CONFLICTS
FAILURE_CAUSES
TRANSFER_OPPORTUNITIES
UNNECESSARY_COMPLEXITY
```

Question pattern record:

```text
QUESTION_PATTERN {

    PATTERN

    PURPOSE

    SUCCESSFUL_USES

    FAILED_USES

    DOMAINS

    DISCOVERIES_CREATED

    BAD_INTEGRATIONS_PREVENTED

    CONFIDENCE

    LIMITATIONS
}
```

Useful core questions include:

```text
WHY DOES THIS WORK?

UNDER WHICH CONDITIONS DOES IT WORK?

WHAT PROBLEM DOES IT ACTUALLY SOLVE?

WHAT EVIDENCE WOULD DISPROVE IT?

WHAT HIDDEN VARIABLE COULD EXPLAIN THE RESULT?

WHAT PART IS PRINCIPLE AND WHAT PART IS DECORATION?

WHAT COULD THIS IMPROVE?

WHAT COULD THIS DAMAGE?

DOES THE SYSTEM ALREADY HAVE SOMETHING BETTER?

CAN THE PRINCIPLE BE EXTRACTED WITHOUT IMPORTING THE ARCHITECTURE?

WHAT WOULD NEED TO CHANGE BEFORE THIS REJECTED IDEA BECAME RELEVANT?
```

Hard rule:

```text
MORE ANSWERS != BETTER RESEARCH

BETTER QUESTIONS
→ BETTER UNDERSTANDING
→ BETTER LEARNING
```

---

# 95. WORLD-LEARNING INTEGRATION CYCLE

The complete extended IMRLA cycle is:

```text
WORLD / EXTERNAL KNOWLEDGE
↓
RESEARCH NEED
↓
SEARCH / COLLECT
↓
COMPARE
↓
QUESTION
↓
EVALUATE SOURCE QUALITY
↓
UNDERSTAND MECHANISM
↓
CHALLENGE CAUSALITY
↓
EXTRACT PRINCIPLE
↓
MAP KNOWLEDGE RELATIONS
↓
CHECK IDENTITY + ARCHITECTURE FIT
↓
EVALUATE VALUE + DISRUPTION
↓
CHECK COEXISTENCE / BOUNDARIES
↓
CREATE CANDIDATE / HOLD / REJECT
↓
SHADOW / EXPERIMENT
↓
OBSERVE OUTCOME
↓
ANALYZE SUCCESS OR FAILURE CAUSE
↓
UPDATE CONFIDENCE
↓
PROMOTE / RETAIN / DOWNGRADE / REJECT
↓
STORE RELATIONS + RECONSIDERATION TRIGGERS
↓
LEARN QUESTION QUALITY
↓
GENERATE BOUNDED NEW QUESTIONS
```

The system may learn widely.

It must integrate selectively.

---

# 96. EXTENDED RESEARCH HARDLOCKS

```text
STORED_INFORMATION != INTEGRATED_KNOWLEDGE

LEARNING != IDENTITY_REPLACEMENT

ADAPTATION != FOREIGN_ARCHITECTURE_IMPORT

HIGH_EXTERNAL_QUALITY != LOCAL_COMPATIBILITY

REJECTED != FORGOTTEN

NEWER != BETTER

COMPLEXER != SMARTER

INTERESTING != USEFUL

CHANGE != DEVELOPMENT

DIFFERENT_VALID_SOLUTIONS != FORCED_MERGE

UNNECESSARY_MERGE = FORBIDDEN

SUCCESS_AFTER_METHOD_X != SUCCESS_CAUSED_BY_METHOD_X

FAILURE != AUTOMATIC_REJECTION

FAILED_IMPLEMENTATION != FAILED_PRINCIPLE

CROSS_DOMAIN_SIMILARITY != TRANSFERABILITY

MORE_ANSWERS != BETTER_RESEARCH

IDENTITY_PRESERVATION = ENABLED

BOUNDARY_PRESERVATION = ENABLED

RECONSIDERATION = ENABLED

QUESTION_QUALITY_LEARNING = ENABLED
```

Central development rule:

```text
LEARN FROM EVERYTHING.

IMPORT NOTHING BLINDLY.

UNDERSTAND THE MECHANISM.

PRESERVE WHAT ALREADY WORKS.

CHANGE ONLY WHEN VALUE OUTWEIGHS DISRUPTION.

KEEP VALID DIFFERENCES SEPARATE WHEN NEEDED.

REVISIT OLD DECISIONS WHEN CONTEXT CHANGES.

INTEGRATE ONLY WHAT EARNS ITS PLACE.
```

---


---

# 9. FINAL CHILD RULE

```text
SEARCH WIDELY WHEN NEEDED.
UNDERSTAND BEFORE LEARNING.
COMPARE BEFORE TRUSTING.
CHALLENGE CAUSALITY.
EXTRACT PRINCIPLES, NOT COPIES.
PRESERVE CALLER IDENTITY.
RETURN EVIDENCE, NOT COMMANDS.
INTEGRATE ONLY WHAT EARNS ITS PLACE.
```
