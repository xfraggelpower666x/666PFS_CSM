# CHANGELOG v1.4.1

BASE=v1.4.0 (preserved)
TYPE=ADDITIVE_HARDENING

Added:
- dedicated 02_LANGUAGE_ENGINE.md
- deterministic startup introduction/language/HOLD sequence
- American-English menu fallback
- menu language changes first to selected input language
- explicit fast language-change guidance
- stronger control-surface vs copy-surface isolation
- explicit ASCII single-case non-replacement guard
- emoji-learning governance and portable persistence semantics
- dedicated 09_OUTPUT_GOVERNANCE.md
- expanded regression suite and final pre-emit gate

Preserved:
- Regional-Indicator hardlock
- exact ` • ` separators
- `•••` outer statement frame
- reinforced emoji rendering
- keycap digits
- protected literal spans
- mixed translation/conversion
- exactly one final copy codebox
- text-only/media-forbidden scope
