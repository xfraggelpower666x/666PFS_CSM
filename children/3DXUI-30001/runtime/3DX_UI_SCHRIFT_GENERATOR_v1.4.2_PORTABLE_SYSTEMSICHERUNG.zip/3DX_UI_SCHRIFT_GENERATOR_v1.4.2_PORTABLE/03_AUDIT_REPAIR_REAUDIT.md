# AUDIT → REPAIR → IMPROVEMENT → DEVELOPMENT → RE-AUDIT → REPAIR → FREEZE

TARGET=3DX UI SCHRIFT GENERATOR
SOURCE_VERSION=1.4.1
SOURCE_PACKAGE_SHA256=a03d6136eea1bf64e45fca19e574b9b2940913d74d0f67d76c97ead857b645c3
TARGET_VERSION=1.4.2
METHOD=BASELINE_PRESERVE_PLUS_MESSAGE_SPLIT_ENGINE

## Audit 1
PASS:
- v1.4.1 ZIP CRC valid
- baseline package readable
- Regional-Indicator, separator, frame, keycap, language, protected-literal and emoji hardlocks preserved
- existing single-message Golden Render preserved

GAP:
- v1.4.1 enforced exactly one final codebox globally
- user-established 3DXChat practical length boundary requires logically split 2+ messages when rendered output is too long
- raw character counting is unsafe because Regional Indicators/emoji/combining sequences may be counted differently by the client
- no explicit continuity validator existed for split output

## Repair 1
- replaced global ONE_FENCED_CODEBOX invariant with ONE_FENCED_CODEBOX_PER_MESSAGE_SEGMENT
- preserved exactly one codebox for normal unsplit outputs
- made every split segment independently framed and sendable

## Improvement
- added reference-calibrated safe-envelope logic instead of inventing a brittle universal integer limit
- added safety reserve before the demonstrated maximum boundary
- boundary priority: sentence > complete thought/clause > phrase > earlier safe token boundary
- forbidden word/protected-span splitting

## Development
- added `10_MESSAGE_SPLIT_ENGINE.md`
- added recursive 2+ segment support
- added 100% source coverage / zero loss / zero duplication invariants
- added T14-T20 regression tests
- expanded output governance and main pre-emit validators

## Re-Audit
PASS:
- short messages still produce exactly one codebox
- overlength messages produce exactly one codebox per message segment
- each segment preserves independent `••• ... •••` framing
- no baseline 3DX mapping/number/language/emoji/protected-literal behavior removed
- Golden Render unchanged
- no segment labels inserted unless explicitly requested
- split engine activates only when needed

## Repair 2
PASS_NOT_REQUIRED after final consistency validation.

FINAL_AUDIT=PASS
FREEZE_READY=TRUE
