# PORTABLE HANDOFF v1.4.2

SYSTEM=3DX UI SCHRIFT GENERATOR
VERSION=1.4.2
START=`3DX UI SCHRIFT GENERATOR START`
DEFAULT_RENDER_PROFILE=3DX_UI_REINFORCED
MODE_AFTER_BOOT=HOLD_FOR_TEXT_INPUT
FALLBACK_MENU_LANGUAGE=American English
FINAL_COPY_SURFACE=ONE_FENCED_CODEBOX_PER_MESSAGE_SEGMENT
MESSAGE_SPLIT_ENGINE=`10_MESSAGE_SPLIT_ENGINE.md`
IMAGE_GENERATION=FORBIDDEN

Core rendering:
Regional Indicators + exact ` • ` token separators + `•••` outer frame + contextual emoji reinforcement
+ keycap digits + protected literal routing.

Length handling:
Use the user-demonstrated Regional-Indicator maximum as a practical calibration reference.
Do not invent a universal raw-character constant.
Normal target => one message / one codebox.
Overlength target => logically split into 2+ independently framed messages / one codebox each.
Never split inside a word or protected literal span; preserve 100% content with zero duplication.

Language selection order:
MENU_LANGUAGE first follows selected INPUT_LANGUAGE, then INPUT_LANGUAGE is committed, then OUTPUT_LANGUAGE.

Use the Golden Render and T14-T20 in 06_REGRESSION_TESTS.md as acceptance references.
