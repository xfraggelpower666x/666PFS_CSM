# REGRESSION TESTS v1.4.2

T01 `I LOVE YOU`
EXPECT: outer frame + Regional Indicators + exact token separators + reinforced emoji unless PLAIN.

T02 GOLDEN
EXPECT:
••• • 💖 • 🇭 🇪 🇱 🇱 🇴 • 🇲 🇾 • 🇩 🇦 🇷 🇱 🇮 🇳 🇬 • 💖 • 🇦 • 🇳 🇪 🇼 • 🇫 🇮 🇳 🇦 🇱 • 🇻 🇪 🇷 🇸 🇮 🇴 🇳 • ⚡ • •••

T03 `666SOUNDSDESIGN`
EXPECT: 6️⃣6️⃣6️⃣ + Regional-Indicator letters; no generic 🔢 substitution.

T04 protected multilingual literal
INPUT protected: `buenos dias / good morning / guten morgen / bom dia`
EXPECT: semantic/language content unchanged; transformation only.

T05 mixed route
Protected greeting + suffix explicitly requested in American English.
EXPECT: only eligible suffix translated; protected span untouched; all eligible letters transformed; digits keycap-rendered.

T06 menu/copy isolation
EXPECT: intro/menu/language/HOLD in plain chat; final target exactly one fenced codebox; no duplicate outside.

T07 emoji reinforcement
EXPECT: contextual reinforcement survives final rendering and every emoji is a separated token.

T08 unresolved menu language
EXPECT: initial MENU_LANGUAGE=American English.

T09 language selection ordering
Choose INPUT=German, OUTPUT=American English.
EXPECT order: MENU_LANGUAGE=German → INPUT_LANGUAGE=German → OUTPUT_LANGUAGE=American English.

T10 startup end-state
EXPECT: RENDER_PROFILE=3DX_UI_REINFORCED → HOLD_FOR_TEXT_INPUT → explicit request for text.

T11 ASCII single-case
EXPECT: only when explicitly requested; must not replace default Regional-Indicator conversion.

T12 scope guard
EXPECT: no image/media generation path becomes active.

T13 emoji at statement start/end
EXPECT:
START `••• • ⚡ • ...`
END `... • ⚡ • •••`


T14 short-message non-split
INPUT: a normal short 3DX target.
EXPECT: exactly one independently framed message in exactly one fenced codebox.

T15 calibrated overlength split
INPUT: a long Regional-Indicator target whose rendered form approaches/exceeds the user-demonstrated maximum envelope.
EXPECT: split before overflow at a logical boundary; at least two independently framed messages; one codebox per segment.

T16 split continuity
EXPECT: concatenated semantic content of all segments equals the unsplit semantic target; no word/token omission, duplication or reordering.

T17 independent segment framing
EXPECT each segment begins with `••• ` and ends with ` •••`; exact ` • ` token rhythm remains valid inside each segment.

T18 no mid-word / no protected-span split
EXPECT: boundary relocation to an earlier safe semantic/token boundary.

T19 multi-segment copy surface
EXPECT: N segments => exactly N fenced codeboxes; no "Part 1/2" labels and no transformed duplicate outside codeboxes.

T20 recursive split
INPUT: target requiring more than two safe messages.
EXPECT: 3+ segments are allowed and use the identical independent-message schema.
