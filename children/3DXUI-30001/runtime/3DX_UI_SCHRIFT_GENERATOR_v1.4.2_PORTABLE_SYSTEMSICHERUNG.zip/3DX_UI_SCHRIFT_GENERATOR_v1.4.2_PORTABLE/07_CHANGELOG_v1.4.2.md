# CHANGELOG v1.4.2

BASE=v1.4.1 (preserved)
TYPE=ADDITIVE_MESSAGE_LENGTH_HARDENING_AND_DEVELOPMENT

Integrated user rule:
- Regional-Indicator 3DXChat messages that exceed the demonstrated practical input envelope
  are automatically divided into logically coherent 2+ messages.
- every resulting message uses the exact same independent 3DX schema as a normal message.

Added:
- `10_MESSAGE_SPLIT_ENGINE.md`
- reference-calibrated safe-envelope policy
- semantic split priority: sentence > thought/clause > phrase > earlier safe token boundary
- safety reserve before the maximum envelope
- recursive 2+ message splitting
- one fenced copybox per message segment
- independent outer frame on every segment
- no word/protected-span splitting
- 100% coverage / zero omission / zero duplication validators
- regression tests T14-T20

Changed:
- old global `exactly one final codebox` hardlock is now conditional:
  unsplit output = exactly one codebox;
  split output = exactly one codebox per independently sendable message.

Preserved:
- Regional-Indicator mapping
- exact ` • ` separator
- `•••` outer frame
- reinforced emoji rendering
- keycap digits
- protected literal spans
- translation routing
- language/startup governance
- text-only/media-forbidden scope
- Golden Render
