# CHANGELOG v1.4.0
- Preserved verified v1.3.7 architecture and accepted later copy-surface behavior.
- Keycap digits are default numeric UI rendering.
- Added protected literal-span no-translation routing.
- Hardened mixed translate/convert behavior.
- Extended validators and regression tests.
