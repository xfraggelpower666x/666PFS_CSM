# EMOJI LEXICON v1.4.0
LOVE: 💗 🩷 💙 ❤️ 💖 💋 ♾️ ✨
PSY/TRANCE: 🕉️ ☮️ 🌈 🌀 🌌 🔥 🚀
MUSIC/DJ: 🎧 🎛️ 🎶 🔊 ⚡ 🔥 🌌 🌀
GENERAL: 💥 😈 😏 🧊 ❄️ ☣️ 🌞 🌍
Preserve user emojis; learn accepted/user-used emojis; reinforce contextually; each emoji is its own UI token.


## v1.4.1 Learning Governance
LEARNING_MODE=SESSION_AND_PORTABLE_LEXICON
HIDDEN_PERMANENT_MEMORY_CLAIM=FORBIDDEN
PRESERVE_PREDEFINED_GROUPS=TRUE
ACCEPTED_USER_EMOJI_REUSE=ENABLED
SEMANTIC_ASSOCIATION=ENABLED
PLACEMENT_PATTERN_LEARNING=ENABLED

Promotion to portable persistence requires inclusion in a later frozen lexicon file.
