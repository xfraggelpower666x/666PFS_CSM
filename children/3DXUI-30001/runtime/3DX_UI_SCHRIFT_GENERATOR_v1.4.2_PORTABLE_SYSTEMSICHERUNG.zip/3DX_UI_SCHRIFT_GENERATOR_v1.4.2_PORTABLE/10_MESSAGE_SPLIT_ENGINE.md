# MESSAGE SPLIT ENGINE v1.4.2

STATUS=ACTIVE_HARDLOCK
PURPOSE=LOGICAL_MULTI_MESSAGE_SPLIT_FOR_3DXCHAT_LENGTH_SAFETY
CALIBRATION_SOURCE=USER_DEMONSTRATED_MAXIMUM_REGIONAL_INDICATOR_INPUT
LIMIT_MODEL=REFERENCE_CALIBRATED_NOT_RAW_CHARACTER_CONSTANT
SAFETY_MARGIN=ENABLED
EXACT_CLIENT_COUNT_ASSUMPTION=FORBIDDEN

## Why reference-calibrated
3DX output contains Regional-Indicator symbols, emoji, combining marks and keycap sequences.
Different clients may count these as code points, UTF-16 units, graphemes, bytes, or visual symbols.
Therefore v1.4.2 does not invent a fixed universal integer limit from one observation.

## Segmentation order
1. produce semantic target
2. transform to final 3DX token stream
3. test rendered size against calibrated safe envelope
4. if split not required => one segment
5. if split required => choose latest safe natural boundary before limit
6. frame each segment independently
7. validate continuity/no-loss/no-duplication
8. emit one fenced codebox per segment

## Boundary priority
P1=SENTENCE_END
P2=CLAUSE_OR_COMPLETE_THOUGHT
P3=PHRASE_BOUNDARY
P4=EARLIER_SAFE_TOKEN_BOUNDARY

Never split in the middle of a word or protected literal span.
Never create a segment that depends on an omitted frame from another segment.

## Independent-message schema
Every segment follows exactly the same schema as a normal single message:
`••• ` + content with exact ` • ` token separators + ` •••`

Emoji at segment start:
`••• • <EMOJI> • TEXT`

Emoji at segment end:
`TEXT • <EMOJI> • •••`

## Copy surface
SINGLE_SEGMENT => exactly 1 fenced codebox.
MULTI_SEGMENT(N) => exactly N fenced codeboxes.
No headings, segment labels, explanatory prose or counters inside copy codeboxes unless user requests them.

## Continuity invariants
SOURCE_COVERAGE=100_PERCENT
TOKEN_LOSS=0
TOKEN_DUPLICATION=0
ORDER_PRESERVATION=TRUE
SEMANTIC_CONTINUITY=TRUE
PROTECTED_LITERAL_INTEGRITY=TRUE
PUNCTUATION_INTEGRITY=TRUE
FRAME_PER_SEGMENT=TRUE
