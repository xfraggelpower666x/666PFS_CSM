# GLOBAL TIMEZONE CONVERSION FRAMEWORK

FRAMEWORK_NAME=GLOBAL_TIMEZONE_CONVERSION_FRAMEWORK
SHORT_NAME=GTCF
VERSION=1.2.0
STATUS=FREEZE
MODE=BIDIRECTIONAL
PRIMARY_PAIR=ALABAMA_USA<->GERMANY
DATE_AWARE=true
DST_AWARE=true
UTC_NORMALIZATION=REQUIRED

---

## 1. PURPOSE

GTCF converts local date/time values bidirectionally between Alabama, USA and Germany.
Neither side is permanently fixed as source or target. Direction is detected from the user's input.

Canonical timezone mapping:

- Alabama, USA -> America/Chicago
- Germany -> Europe/Berlin

Important: The numeric hour difference MUST NOT be hardcoded because daylight-saving transitions in the USA and Europe occur on different dates.

---

## 2. SUPPORTED DIRECTIONS

### A -> B
Alabama -> Germany

Example:
15:00 Alabama -> 22:00 Germany

### B -> A
Germany -> Alabama

Example:
22:00 Germany -> 15:00 Alabama

Both examples are valid for 2026-08-19, when Alabama uses CDT (UTC-5) and Germany uses CEST (UTC+2).

---

## 3. INPUT MODEL

Required logical fields:

SOURCE_LOCATION
SOURCE_LOCAL_TIME
SOURCE_DATE
TARGET_LOCATION

Optional:

INPUT_LANGUAGE
OUTPUT_FORMAT
12H_OR_24H
EXPLICIT_TIMEZONE

Accepted natural-language patterns include:

- 15 Uhr Alabama in Deutschland
- 15 Uhr Alabama nach Deutschland
- Wenn es in Alabama 15 Uhr ist, wie spät ist es in Deutschland?
- 22 Uhr Deutschland in Alabama
- 3pm Alabama to Germany
- 10pm Germany to Alabama

---

## 4. DIRECTION DETECTION

No fixed source and no fixed target.

Rules:

1. "X in Y" -> X=SOURCE, Y=TARGET
2. "X nach Y" -> X=SOURCE, Y=TARGET
3. "X to Y" -> X=SOURCE, Y=TARGET
4. "wenn es in X TIME ist, wie spät ist es in Y" -> X=SOURCE, Y=TARGET
5. Arrow notation X -> Y -> X=SOURCE, Y=TARGET

If direction is ambiguous, status must be OPEN instead of guessing.

---

## 5. TIMEZONE RESOLUTION

Canonical IANA zones:

ALABAMA_USA=America/Chicago
GERMANY=Europe/Berlin

Location aliases:

ALABAMA -> Alabama, USA -> America/Chicago
GERMANY -> Germany -> Europe/Berlin
DEUTSCHLAND -> Germany -> Europe/Berlin

Timezone resolution must be date-aware.

---

## 6. CONVERSION CORE

SOURCE_LOCAL_DATETIME
-> resolve SOURCE UTC offset for exact date/time
-> normalize to UTC
-> resolve TARGET UTC offset for same instant
-> convert to TARGET local datetime
-> verify date transition
-> render output

Formula:

UTC = SOURCE_LOCAL_TIME - SOURCE_UTC_OFFSET
TARGET_LOCAL_TIME = UTC + TARGET_UTC_OFFSET

The implementation must use timezone-aware datetime logic, not a stored +/-7 hour rule.

---

## 7. DATE CHANGE LOGIC

The framework MUST detect:

DAY_CHANGE=-1
DAY_CHANGE=0
DAY_CHANGE=+1

It must also detect month and year rollover.

Example:

Alabama 2026-08-19 20:00
-> Germany 2026-08-20 03:00
DAY_CHANGE=+1

Reverse:

Germany 2026-08-20 03:00
-> Alabama 2026-08-19 20:00
DAY_CHANGE=-1

---

## 8. DST / OFFSET SAFETY

Mandatory guards:

BIDIRECTIONAL=true
FIXED_SOURCE=false
FIXED_TARGET=false
DATE_AWARE=true
DST_CHECK=REQUIRED
IANA_TIMEZONE_REQUIRED=true
UTC_NORMALIZATION=REQUIRED
HARDCODED_TIME_DIFFERENCE=FORBIDDEN
DAY_CHANGE_CHECK=REQUIRED
MONTH_CHANGE_CHECK=REQUIRED
YEAR_CHANGE_CHECK=REQUIRED
AMBIGUOUS_LOCATION=OPEN
AMBIGUOUS_LOCAL_TIME=OPEN

Special DST edge cases:

- Non-existent local clock times during spring-forward MUST NOT be silently normalized.
- Repeated local clock times during fall-back MUST be marked ambiguous unless a UTC offset/fold is explicitly resolved.

---

## 9. STANDARD OUTPUT

Example for 2026-08-19:

🌍 ZEITUMRECHNUNG

📍 Alabama, USA
🕒 15:00
🕓 CDT / UTC-5

↕ BIDIRECTIONAL CONVERSION

📍 Deutschland
🕙 22:00
🕓 CEST / UTC+2

OFFSET_DIFFERENCE=+7h
DAY_CHANGE=0
STATUS=VERIFIED

Reverse:

📍 Deutschland 22:00
-> 📍 Alabama, USA 15:00
OFFSET_DIFFERENCE=-7h
DAY_CHANGE=0
STATUS=VERIFIED

---

## 10. SHORT OUTPUT MODE

Alabama -> Germany:

🇺🇸 Alabama 15:00 -> 🇩🇪 Deutschland 22:00 (+7h)

Germany -> Alabama:

🇩🇪 Deutschland 22:00 -> 🇺🇸 Alabama 15:00 (-7h)

The displayed difference must be computed for the requested date.

---

## 11. VALIDATION PIPELINE

1. Parse date
2. Parse time
3. Parse source location
4. Parse target location
5. Detect direction
6. Resolve IANA zones
7. Validate source local datetime
8. Resolve source UTC offset
9. Normalize to UTC
10. Resolve target UTC offset
11. Convert target local datetime
12. Check day/month/year transition
13. Render result
14. Return status

---

## 12. STATUS MODEL

VERIFIED
- conversion completed with resolved timezone/date information

DERIVED
- result logically derived from authoritative timezone data already available in runtime

OPEN
- missing or ambiguous date/time/location prevents safe conversion

BLOCKED
- timezone resolution or required data source unavailable

REPAIR
- an internal validation mismatch was detected and corrected before output

---

## 13. INTEGRATION AUDIT

AUDIT_ID=GTCF-AUDIT-2026-08-19-A

Checked:

[PASS] Bidirectional conversion preserved
[PASS] Chicago location label replaced by Alabama
[PASS] Alabama correctly mapped to America/Chicago
[PASS] Germany mapped to Europe/Berlin
[PASS] Fixed source/target removed
[PASS] UTC normalization retained
[PASS] DST-aware conversion retained
[PASS] Day rollover supported both directions
[PASS] Month/year rollover explicitly required
[PASS] Hardcoded 7-hour offset prohibited

Finding:
The prior framework stated DST awareness but did not explicitly define handling for non-existent and repeated local times during DST transitions.

REPAIR_APPLIED=true

Repair:
Added DST edge-case guards for spring-forward gaps and fall-back repeated times.

---

## 14. CONTROLLED DEVELOPMENT v1.2.0

Changes from v1.1.0:

1. Replaced Chicago as user-facing endpoint with Alabama, USA.
2. Preserved America/Chicago as Alabama's canonical IANA timezone.
3. Added explicit alias mapping.
4. Added ambiguous-direction fail-safe.
5. Added DST gap/fold protection.
6. Added formal status model.
7. Added validation pipeline.
8. Added month/year rollover requirements.
9. Added freeze metadata and audit trail.

No destructive architectural change was made.

---

## 15. RE-AUDIT

AUDIT_ID=GTCF-AUDIT-2026-08-19-B

[PASS] Source/target symmetry
[PASS] Alabama/Germany mapping
[PASS] Date-aware conversion architecture
[PASS] DST edge-case handling
[PASS] UTC normalization
[PASS] Bidirectional day rollover
[PASS] Ambiguity handling
[PASS] No hardcoded permanent offset
[PASS] Existing natural-language input patterns retained
[PASS] Freeze candidate internally consistent

REPAIR_REQUIRED=false
RE_AUDIT_RESULT=PASS

---

## 16. FREEZE

FREEZE_ID=GTCF-FREEZE-1.2.0
FREEZE_DATE=2026-08-19
FREEZE_STATUS=PASS

Protected core:

- Alabama <-> Germany bidirectional operation
- America/Chicago <-> Europe/Berlin canonical mapping
- Date awareness
- DST awareness
- UTC normalization
- Date rollover detection
- No permanent hardcoded offset

Future changes require version increment and post-change audit.

---

## 17. FINAL STATE

SYSTEM=GTCF
VERSION=1.2.0
STATE=FROZEN
INTEGRATION=PASS
AUDIT=PASS
REPAIR=APPLIED
DEVELOPMENT=PASS
RE_AUDIT=PASS
FINAL_REPAIR=NOT_REQUIRED
SYSTEM_BACKUP=READY
