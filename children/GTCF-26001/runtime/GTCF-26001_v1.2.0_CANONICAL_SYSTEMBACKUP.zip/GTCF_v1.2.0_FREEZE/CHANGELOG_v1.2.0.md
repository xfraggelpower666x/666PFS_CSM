# GTCF v1.2.0 CHANGELOG

Date: 2026-08-19

## Integrated
- Bidirectional Alabama <-> Germany conversion.
- Alabama replaces Chicago as the user-facing US endpoint.
- Canonical Alabama timezone remains America/Chicago.

## Repaired
- Added explicit DST gap/fold ambiguity handling.
- Added fail-safe for ambiguous conversion direction.
- Added explicit month/year rollover checks.

## Developed
- Formal validation pipeline.
- Formal status model.
- Alias resolution.
- Freeze metadata.

## Audit
- Integration audit: PASS after repair.
- Re-audit: PASS.
- Final repair: not required.

## Freeze
- Version: 1.2.0
- State: FROZEN
