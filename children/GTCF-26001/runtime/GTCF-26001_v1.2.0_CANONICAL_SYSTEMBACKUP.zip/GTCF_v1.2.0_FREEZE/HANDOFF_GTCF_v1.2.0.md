# GTCF v1.2.0 HANDOFF

SYSTEM=GLOBAL_TIMEZONE_CONVERSION_FRAMEWORK
SHORT_NAME=GTCF
VERSION=1.2.0
STATE=FROZEN

PRIMARY_PAIR:
Alabama, USA <-> Germany

CANONICAL_TIMEZONES:
Alabama=America/Chicago
Germany=Europe/Berlin

CORE_RULES:
- Bidirectional; no fixed source or target.
- Date-aware and DST-aware.
- Always normalize through UTC.
- Never hardcode a permanent hour difference.
- Detect day/month/year rollovers.
- Mark ambiguous DST local times OPEN instead of guessing.

LAST_AUDIT=PASS
LAST_REPAIR=DST edge-case guards added
FINAL_REPAIR_REQUIRED=false

CONTINUATION_RULE:
Preserve v1.2.0 core. Any extension requires version increment, audit, repair if needed, re-audit, then freeze.
