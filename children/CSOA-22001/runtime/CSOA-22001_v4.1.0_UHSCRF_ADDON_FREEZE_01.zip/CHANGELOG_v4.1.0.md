# ChatGPT Search over all — CHANGELOG v4.1.0

- Integrated UHSCRF as internal CSOA add-on, not a new 666PFS Child.
- Preserved all existing CSOA v4.0.0 search/recovery handlers.
- Added explicit UHSCRF lineage and ownership mapping.
- Added anti-duplication and future-delta admission gate.
- Kept legacy UHSCRF triggers inert.
- No new top-level trigger, bootstrap, router, update route, menu entry, or child identity.
- Repair strategy: new release/pointer IDs replace reliance on the previously referenced but currently inaccessible canonical MD ID.
