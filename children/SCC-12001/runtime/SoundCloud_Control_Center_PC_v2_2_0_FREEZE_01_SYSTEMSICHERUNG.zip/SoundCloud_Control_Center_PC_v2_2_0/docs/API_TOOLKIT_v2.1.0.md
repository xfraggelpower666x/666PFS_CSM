# SCC-PC v2.1.0 — API-Zentrale

## Neue Option

Der neue Tab `API-Zentrale` erweitert den bestehenden SoundCloud Control Center PC, ohne die Analyse- oder Cleanup-Architektur zu ersetzen.

### SoundCloud API-App / Referenz

Speichert ausschließlich nicht-geheime App-Metadaten lokal:

- App-Name
- Beschreibung
- Website

Zusätzlich sind direkte Schaltflächen für SoundCloud Apps, API Explorer, OpenAPI JSON und API Guide vorhanden.

### Public API — Client Credentials

- browserfreier Test für öffentliche API-Ressourcen
- separater Token-Namespace
- Access-Token-Cache
- Single-Use Refresh-Token-Austausch
- Rate-Limit-Backoff
- Benutzer-OAuth bleibt unverändert

### Track-Suche

Implementiert `search_tracks(query, access_token, limit=20)` gegen `GET /tracks` mit:

- `Authorization: OAuth <access_token>`
- `linked_partitioning=true`
- `limit` 1..200
- Rückgabe `collection` + `next_href`
- nächste Seite über `next_href`
- 401/429 als klare Exceptions
- Host-Validierung von `next_href` auf `https://api.soundcloud.com`

## Status

Lokale Tests und Mock-API-Tests sind ausführbar. Ein echter SoundCloud-API-Readback benötigt die lokal im Windows Credential Manager gespeicherten Credentials des Benutzers.
