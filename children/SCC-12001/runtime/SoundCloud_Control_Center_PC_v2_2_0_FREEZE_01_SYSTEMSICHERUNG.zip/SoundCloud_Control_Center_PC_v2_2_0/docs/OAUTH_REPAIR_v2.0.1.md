# SCC-PC v2.0.1 — OAuth Desktop Repair Candidate

STATUS=PARTIAL_RUNTIME_CANDIDATE
SYSTEM_ID=666PFS-SCC-PC-001
BASELINE=2.0.0
CANDIDATE=2.0.1
SCOPE=OAUTH_DESKTOP_LOGIN_ONLY

## Repariert

- `https://example.com/callback` ist nicht mehr stiller Standard.
- Neuer Desktop-Standard: `sccpc://soundcloud/callback`.
- Die Redirect-URI wird vor OAuth validiert.
- `display=popup` wird im Desktop-Flow nicht mehr gesetzt.
- Unter Windows wird der Anmelde-Link ausdrücklich über den Systembrowser gestartet; `webbrowser` bleibt Fallback.
- Custom-Protocol-Redirects werden unter HKCU ohne Administratorrechte registriert.
- OAuth-Callback wird an die laufende Anwendung zurückgereicht und automatisch gegen Access-/Refresh-Token getauscht.
- Manuelles Einfügen einer Redirect-URL bleibt als Fallback erhalten.
- OAuth-Fehler zeigen zusätzlich `error_description`, falls SoundCloud sie liefert.
- Secrets/Tokens werden nicht in Logs oder Projektdateien geschrieben.

## Wichtig für SoundCloud

Die Redirect-URI in den SoundCloud-App-Einstellungen muss exakt mit der URI im Control Center übereinstimmen. Für diesen Kandidaten ist `sccpc://soundcloud/callback` vorgesehen.

## Nicht verändert

Analyse, Likes/Favoriter, Evidence, Full Account, Cleanup, Export, Checkpoints und bestehende sichere Credential-Speicherung bleiben funktional unverändert.

## Offener Runtime-Gate

Der echte SoundCloud-Login und der Windows-Custom-Protocol-Rücksprung müssen auf dem Benutzer-PC verifiziert werden, bevor dieser Kandidat gefreezt oder als aktive Child-Version publiziert wird.
