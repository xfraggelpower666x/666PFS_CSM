# SoundCloud API Quellen — SCC-PC v2.1.0 API Toolkit Candidate

STATUS=VERIFIZIERT_GEGEN_OFFIZIELLE_SOUNDCLOUD_QUELLEN

## Autoritative Quellen

- API Explorer / OpenAPI UI: https://developers.soundcloud.com/docs/api/explorer/open-api
- OpenAPI JSON: https://developers.soundcloud.com/docs/api/explorer/api.json
- OpenAPI YAML: https://github.com/soundcloud/api/blob/master/openapi/api.yaml
- API Guide: https://developers.soundcloud.com/docs/api/guide
- App-Registrierung: https://developers.soundcloud.com/docs/api/register-app
- LLM Context: https://developers.soundcloud.com/docs/llm-context

## Im Kandidaten belegte Regeln

- API-Basis: `https://api.soundcloud.com`
- Token-Endpunkt: `https://secure.soundcloud.com/oauth/token`
- API-Header: `Authorization: OAuth <access_token>`
- Authorization Code: OAuth 2.1 + PKCE; Benutzerressourcen wie `/me` benötigen diesen Modus.
- Client Credentials: nur öffentliche Ressourcen; Credentials werden am Token-Endpunkt per HTTP Basic gesendet.
- Access-Tokens werden gecacht; Refresh-Tokens werden als Single-Use behandelt und nach erfolgreichem Refresh ersetzt.
- `GET /tracks` unterstützt `q`, `limit` und `linked_partitioning=true`.
- Paginated responses liefern `collection` und optional `next_href`.
- `limit`: 1 bis 200.
- 429/503: begrenztes Retry mit Backoff; keine Endlosschleife.

## Trennung im Tool

### Benutzerkonto-Modus

Für `/me`, eigene Tracks, Cleanup, Likes/Favoriter und accountbezogene Aktionen. Nutzt den bestehenden Authorization-Code-/PKCE-Token und überschreibt den Public-API-Token nicht.

### Public-API-Modus

Für öffentliche Track-Suche und weitere öffentliche Endpunkte. Nutzt Client Credentials, einen getrennten Token-Cache und überschreibt niemals den Benutzerkonto-Token.

## Geheimnisschutz

Client-ID, Client-Secret, Access-Token und Refresh-Token werden nicht in diese Dokumentation geschrieben und nicht in Logs ausgegeben. Nicht-geheime App-Metadaten dürfen lokal als Referenz gespeichert werden.
