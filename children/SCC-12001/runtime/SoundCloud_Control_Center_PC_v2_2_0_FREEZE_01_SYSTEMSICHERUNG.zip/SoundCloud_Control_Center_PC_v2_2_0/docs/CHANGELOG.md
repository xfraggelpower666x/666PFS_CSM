# Changelog

## 2.0.1 OAuth Repair Candidate
- Desktop-OAuth-Flow repariert.
- Ungültigen example.com-Redirect-Standard entfernt.
- Custom-Protocol-Callback `sccpc://soundcloud/callback` ergänzt.
- Windows-Systembrowser + Browser-Fallback ergänzt.
- Desktop-Auth ohne mobilen `display=popup`-Parameter.
- Automatischen Callback-Tokenaustausch und manuelles Fallback ergänzt.


## 2.0.0 FREEZE 01
- Windows-PC-GUI ergänzt, Original-Scriptable-Quelle unverändert erhalten.
- Native Launcher-EXE und automatischer Batch-Bootstrap.
- OAuth/PKCE, Windows Credential Manager, Token-Refresh.
- Hintergrund-Taskmanager mit Fortschritt und sicheren Abbruchpunkten.
- Cleanup, Likes/Favoriter, LYVRA Evidence und vollständige Kontoanalyse portiert.
- TXT/JSON/CSV/JSONL-Ausgaben beibehalten; kein Excel.
- Atomare Writes, SHA-256-Manifeste, Readback und Checkpoints.

## v2.1.0 API Toolkit Candidate 01 — 2026-08-08

- neuer Tab `API-Zentrale`
- nicht-geheime SoundCloud-App-Referenz im GUI
- direkte Links zu API Explorer, OpenAPI JSON und API Guide
- neuer `PublicApiClient` mit getrenntem Public-Token-Namespace
- Client-Credentials-Token via HTTP Basic
- Token-Cache und Single-Use Refresh-Token-Ersetzung
- neue Funktion `search_tracks(query, access_token, limit=20)`
- `linked_partitioning=true` und `next_href` Pagination
- 401/429 klare Fehlerbehandlung
- begrenztes 429/503 Backoff
- `next_href` Host-Validierung
- bestehender User-OAuth-/Analyse-/Cleanup-Code bleibt erhalten

## 2.2.0 Public Analyzer Candidate
- browserfreier Public-Profile-Analyzer per Client Credentials
- Profil-Auflösung über `/resolve`
- Track-Census über `/users/{user_urn}/tracks` mit linked partitioning
- Favoriter über `/tracks/{track_urn}/favoriters`
- Public Vollanalyse, Likes/Favoriter und Evidence als Read-only-Modi
- bestehender `/me`-OAuth-Pfad und Cleanup unverändert erhalten
- einmalige 401-Token-Recovery ohne Endlosschleife
