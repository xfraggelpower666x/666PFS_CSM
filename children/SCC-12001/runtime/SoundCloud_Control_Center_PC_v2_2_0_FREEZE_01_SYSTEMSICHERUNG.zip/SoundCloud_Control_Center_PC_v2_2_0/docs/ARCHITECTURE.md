# Architektur

GUI → TaskManager → AnalysisService → SoundCloudClient → HttpClient

Persistenz: ConfigManager, SecureStore, CheckpointStore, atomare Exporter.
Die Scriptable-Quelle unter `source_original/` bleibt fachliche Referenz und wird nicht überschrieben.
