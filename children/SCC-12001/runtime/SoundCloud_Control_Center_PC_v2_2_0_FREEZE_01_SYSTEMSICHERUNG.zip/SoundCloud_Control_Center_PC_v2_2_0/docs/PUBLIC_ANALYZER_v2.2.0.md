# SCC-PC v2.2.0 — Public Analyzer

Der Analyzer besitzt zwei getrennte Zugänge:

1. `Public API (ohne Login)` — Client Credentials, öffentliche Profildaten, Tracks und Favoriter.
2. `User OAuth (/me)` — bestehender Authorization-Code/PKCE-Pfad für private Benutzerressourcen und destruktive Aktionen.

Der Public-Modus ist strikt read-only. Cleanup/Delete bleiben am User-OAuth gebunden.
