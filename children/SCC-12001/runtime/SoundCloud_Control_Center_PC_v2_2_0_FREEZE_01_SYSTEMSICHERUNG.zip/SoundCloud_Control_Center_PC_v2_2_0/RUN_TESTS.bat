@echo off
cd /d "%~dp0"
if not exist ".runtime\Scripts\python.exe" call START.bat --prepare-only
.runtime\Scripts\python.exe -m unittest discover -s tests -v
pause
