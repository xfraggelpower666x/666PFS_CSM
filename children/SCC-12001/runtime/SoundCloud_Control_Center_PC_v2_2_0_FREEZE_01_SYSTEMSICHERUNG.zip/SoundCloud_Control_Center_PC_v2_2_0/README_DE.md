# SoundCloud Control Center PC v2.2.0 — Public Analyzer

STATUS=FROZEN_WITH_EXTERNAL_RUNTIME_READBACK_PENDING
SOURCE_BASE=SCC-PC v2.0.0 + OAuth Repair v2.0.1

## Start

1. Paket vollständig entpacken.
2. `START.bat` doppelklicken.
3. Der vorhandene Bootstrap startet die Windows-PC-Anwendung. Die ursprüngliche Scriptable-Quelle bleibt unverändert unter `source_original/` erhalten.

## Bestehende Funktionen bleiben erhalten

- Kontoanalyse
- Likes / Favoriter
- LYVRA Evidence
- Cleanup mit Backup und Bestätigung
- TXT, JSON, CSV und JSONL
- Hintergrundaufgaben und Fortschritt
- OAuth 2.1 / PKCE für Benutzerkonto-Funktionen
- sicherer Credential Store über `keyring` / Windows Credential Manager

## Neu: API-Zentrale

Der Tab `API-Zentrale` trennt zwei SoundCloud-API-Modi sauber:

### 1. Benutzerkonto-Modus

Authorization Code + PKCE für `/me`, eigene Tracks und accountbezogene Aktionen. Dieser Modus benötigt den SoundCloud-Login und behält seinen bisherigen Token-Namespace.

### 2. Public-API-Modus

Client Credentials für öffentliche Ressourcen. Dieser Modus kann ohne Benutzer-Login einen App-Token beziehen, cachen und über den Single-Use Refresh-Token erneuern. Er überschreibt niemals den Benutzerkonto-Token.

Enthalten:

- Public-API-Diagnose
- Public-Token Cache / Refresh / Löschen
- Track-Suche über `GET https://api.soundcloud.com/tracks`
- `linked_partitioning=true`
- `next_href` Pagination
- 401/429 Fehlerstatus
- begrenztes Rate-Limit-Backoff
- Buttons zu API Explorer, OpenAPI JSON und API Guide

## Nicht-geheime App-Referenz

Im GUI können App-Name, Beschreibung und Website als lokale Referenz gespeichert werden. Client-ID, Client-Secret und Token werden nicht in die Projektdateien geschrieben.

## OAuth-Reparatur aus v2.0.1 bleibt erhalten

- Desktop-PKCE ohne `display=popup`
- `sccpc://soundcloud/callback` als Desktop-Callback-Option
- Windows-Systembrowser
- Callback-Fallback
- Migration des alten `https://example.com/callback` Platzhalters

## Autoritative SoundCloud-Quellen

Siehe `docs/SOUNDCLOUD_API_SOURCES_v2.1.0.md`.

## Freeze-Status

FREEZE_ID=SCC-PC-v2.2.0-FREEZE-01

Der Code-, Paket- und Mock/API-Contract-Audit ist abgeschlossen. Der reale Windows-/SoundCloud-Live-Readback bleibt als externer Runtime-Checkpoint offen, bis er auf dem Ziel-PC mit lokal gespeicherten Credentials durchgeführt wurde.

## v2.2.0 — Browserfreier Public Analyzer

Im Tab **Analysen** gibt es jetzt zwei getrennte Zugänge:

- **Public API (ohne Login)**: Client Credentials; Profil-URL angeben; read-only Vollanalyse, Likes/Favoriter und Evidence.
- **User OAuth (/me)**: bestehender PKCE-Pfad für private Benutzerressourcen und Cleanup/Delete.

Empfohlener Funktionstest:
1. Token Manager: bestehende Client-ID + Client-Secret speichern.
2. API-Zentrale: `Public API testen`.
3. Analysen: `Public API (ohne Login)` wählen.
4. Eigene vollständige SoundCloud-Profil-URL eintragen.
5. Zunächst `Vollständige Kontoanalyse`, Scope `latest_n`, Wert `50`, Favoriter-Limit `0` starten.
6. Danach Favoriter schrittweise auf 50/100/ALL erhöhen.

Der Public-Modus führt niemals Delete/Update/Like/Repost aus.
