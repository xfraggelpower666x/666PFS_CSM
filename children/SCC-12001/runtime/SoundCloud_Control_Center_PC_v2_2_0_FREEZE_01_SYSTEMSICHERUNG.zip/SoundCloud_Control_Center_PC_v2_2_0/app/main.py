from __future__ import annotations
import os
import sys
from pathlib import Path

if __package__ in (None, ""):
    root = Path(__file__).resolve().parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

from app.gui.window import MainWindow
from app.core.desktop_oauth import write_callback_url


def main() -> int:
    try:
        if "--oauth-callback" in sys.argv:
            index = sys.argv.index("--oauth-callback")
            if index + 1 >= len(sys.argv):
                raise ValueError("OAuth-Callback-URL fehlt.")
            write_callback_url(sys.argv[index + 1])
            return 0
        window = MainWindow()
        window.mainloop()
        return 0
    except Exception as exc:
        try:
            import tkinter.messagebox as mb
            mb.showerror("SoundCloud Control Center", str(exc))
        except Exception:
            print(exc, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
