from __future__ import annotations
import json
import statistics
from collections import Counter
from datetime import datetime
from typing import Any
from app.core.tasks import TaskContext
from app.core.utils import atomic_write_json, atomic_write_text, csv_text
from app.services.analysis import compact_track, compact_user, filter_scope, _manifest, _run_folder


class PublicProfileAnalysisService:
    """Read-only analyzer using Client Credentials and public SoundCloud endpoints."""
    def __init__(self, public_api, config, logger=None):
        self.api = public_api
        self.config = config
        self.logger = logger

    def _fetch_base(self, ctx: TaskContext, profile_url: str):
        ctx.update(3, "Öffentliches SoundCloud-Profil wird aufgelöst")
        account = self.api.resolve_profile(profile_url)
        ctx.update(7, "Öffentliche Tracks werden paginiert geladen")
        tracks = self.api.fetch_user_tracks(
            account.get("urn"),
            progress=lambda page, rows: ctx.update(min(35, 7 + page * 2), f"Trackseite {page}: {rows} Tracks"),
            cancel_event=ctx.cancel_event,
        )
        return account, tracks

    def _favoriters(self, ctx, tracks, favoriter_limit):
        liked = [t for t in tracks if int(t.get("likes_count") or t.get("favoritings_count") or 0) > 0]
        if favoriter_limit is not None:
            liked = liked[:favoriter_limit]
        if favoriter_limit == 0:
            return [], [], {}
        results=[]; failures=[]; users={}
        for i, track in enumerate(liked, 1):
            ctx.check_cancelled()
            try:
                rows=[compact_user(u) for u in self.api.fetch_track_favoriters(track, ctx.cancel_event)]
                results.append({"track":compact_track(track, preserve_missing=True),"expected_likes_count":track.get("likes_count"),"retrieved_favoriters_count":len(rows),"favoriters":rows})
                for u in rows:
                    k=str(u.get("urn") or u.get("id") or u.get("username"))
                    rec=users.setdefault(k,{"user":u,"liked_track_count":0,"liked_tracks":[]})
                    rec["liked_track_count"]+=1
                    rec["liked_tracks"].append({"urn":track.get("urn"),"title":track.get("title")})
            except Exception as exc:
                failures.append({"track":compact_track(track),"error":str(exc)})
            ctx.update(45 + 45*i/max(len(liked),1), f"Favoriter {i}/{len(liked)}")
        return results, failures, users

    def likes_analysis(self, ctx: TaskContext, profile_url: str, scope: dict[str, Any], favoriter_limit: int | None):
        account, all_tracks=self._fetch_base(ctx, profile_url)
        selected=filter_scope(all_tracks, scope)
        results, failures, users=self._favoriters(ctx, selected, favoriter_limit)
        top=sorted(users.values(), key=lambda x:x["liked_track_count"], reverse=True)[:100]
        folder=_run_folder(self.config,"soundcloud_public_likes")
        payload={"generated_at":datetime.now().astimezone().isoformat(),"version":"2.2.0","mode":"PUBLIC_CLIENT_CREDENTIALS","read_only":True,"profile_url":profile_url,"account":compact_user(account),"scope":scope,"tracks_total":len(all_tracks),"tracks_selected":len(selected),"favoriter_rows":sum(x.get("retrieved_favoriters_count",0) for x in results),"unique_users":len(users),"top_users":top,"details":results,"failures":failures}
        atomic_write_json(folder/'public_likes_report.json',payload)
        rows=[]
        for e in results:
            for u in e.get('favoriters',[]): rows.append([e['track'].get('urn') or e['track'].get('id'),e['track'].get('title'),u.get('urn') or u.get('id'),u.get('username'),u.get('permalink_url')])
        atomic_write_text(folder/'public_favoriters.csv',csv_text(['track_urn','track_title','user_urn','username','profile_url'],rows))
        atomic_write_text(folder/'public_likes_summary.txt',f"PUBLIC SOUNDCLOUD LIKES ANALYSIS\nProfile: {account.get('username')}\nTracks selected: {len(selected)}\nFavoriter rows: {payload['favoriter_rows']}\nUnique users: {len(users)}\nFailures: {len(failures)}")
        manifest=_manifest(folder,{"module":"public_likes","auth":"client_credentials","read_only":True,"readback_pass":True})
        return {"folder":str(folder),"tracks":len(selected),"favoriter_rows":payload['favoriter_rows'],"unique_users":len(users),"failures":len(failures),"manifest":str(manifest)}

    def evidence_analysis(self, ctx: TaskContext, profile_url: str, scope: dict[str, Any], favoriter_limit: int | None):
        account, all_tracks=self._fetch_base(ctx, profile_url)
        selected=filter_scope(all_tracks, scope)
        evidence=[]
        for t in selected:
            c=compact_track(t, preserve_missing=True)
            plays=t.get('playback_count'); likes=t.get('likes_count'); reposts=t.get('reposts_count'); comments=t.get('comment_count')
            evidence.append({**c,"field_status":{"playback_count":"PRESENT" if 'playback_count' in t else 'FIELD_MISSING',"likes_count":"PRESENT" if 'likes_count' in t else 'FIELD_MISSING',"reposts_count":"PRESENT" if 'reposts_count' in t else 'FIELD_MISSING',"comment_count":"PRESENT" if 'comment_count' in t else 'FIELD_MISSING'},"visible_signal":bool((plays or 0) or (likes or 0) or (reposts or 0) or (comments or 0))})
        folder=_run_folder(self.config,'soundcloud_public_evidence')
        play_values=[int(x.get('playback_count') or 0) for x in evidence if x.get('playback_count') is not None]
        payload={"generated_at":datetime.now().astimezone().isoformat(),"version":"2.2.0","mode":"PUBLIC_CLIENT_CREDENTIALS","read_only":True,"account":compact_user(account),"scope":scope,"tracks":evidence,"summary":{"tracks":len(evidence),"known_play_sum":sum(play_values),"known_play_median":statistics.median(play_values) if play_values else None,"likes_sum":sum(int(x.get('likes_count') or 0) for x in evidence),"comments_sum":sum(int(x.get('comment_count') or 0) for x in evidence),"reposts_sum":sum(int(x.get('reposts_count') or 0) for x in evidence)},"interpretation_guards":["MISSING_FIELD_IS_NOT_ZERO","PLAYBACK_COUNT_IS_NOT_UNIQUE_LISTENERS","CORRELATION_IS_NOT_CAUSATION"]}
        atomic_write_json(folder/'public_evidence.json',payload)
        atomic_write_text(folder/'public_evidence.txt',json.dumps(payload['summary'],indent=2,ensure_ascii=False))
        manifest=_manifest(folder,{"module":"public_evidence","auth":"client_credentials","read_only":True,"readback_pass":True})
        return {"folder":str(folder),**payload['summary'],"manifest":str(manifest)}

    def full_profile_analysis(self, ctx: TaskContext, profile_url: str, scope: dict[str, Any], favoriter_limit: int | None):
        account, all_tracks=self._fetch_base(ctx, profile_url)
        selected=filter_scope(all_tracks, scope)
        seen=set(); unique=[]; duplicates=[]
        for t in selected:
            k=str(t.get('urn') or t.get('id') or '')
            if k and k in seen: duplicates.append(compact_track(t)); continue
            if k: seen.add(k)
            unique.append(t)
        phase=[compact_track(t, preserve_missing=True) for t in unique]
        results, failures, users=self._favoriters(ctx, unique, favoriter_limit)
        folder=_run_folder(self.config,'soundcloud_public_full_analysis')
        summary={"tracks":len(unique),"duplicate_records":len(duplicates),"known_play_sum":sum(int(t.get('playback_count') or 0) for t in unique),"likes_sum":sum(int(t.get('likes_count') or 0) for t in unique),"comments_sum":sum(int(t.get('comment_count') or 0) for t in unique),"reposts_sum":sum(int(t.get('reposts_count') or 0) for t in unique),"favoriter_rows":sum(x.get('retrieved_favoriters_count',0) for x in results),"unique_favoriters":len(users),"favoriter_failures":len(failures)}
        payload={"generated_at":datetime.now().astimezone().isoformat(),"version":"2.2.0","mode":"PUBLIC_PROFILE_COMPLETE","auth":"CLIENT_CREDENTIALS","read_only":True,"destructive_actions_allowed":False,"profile_url":profile_url,"account":compact_user(account),"scope":scope,"summary":summary,"tracks":phase,"duplicate_records":duplicates,"favoriters":results,"favoriter_failures":failures,"limitations":["PUBLIC_PROFILE_ONLY","PRIVATE_USER_RESOURCES_REQUIRE_AUTHORIZATION_CODE","MISSING_FIELD_IS_NOT_ZERO"]}
        atomic_write_json(folder/'public_full_snapshot.json',payload)
        rows=[[t.get('urn') or t.get('id'),t.get('title'),t.get('created_at_local'),t.get('duration_text'),t.get('playback_count'),t.get('likes_count'),t.get('comment_count'),t.get('reposts_count'),t.get('permalink_url')] for t in phase]
        atomic_write_text(folder/'public_tracks.csv',csv_text(['track_urn','title','created_at_local','duration','plays','likes','comments','reposts','url'],rows))
        atomic_write_text(folder/'public_summary.txt','\n'.join(['SOUNDCLOUD PUBLIC PROFILE COMPLETE ANALYSIS',f"Profile: {account.get('username')}",f"Tracks: {summary['tracks']}",f"Known plays: {summary['known_play_sum']}",f"Likes: {summary['likes_sum']}",f"Favoriter rows: {summary['favoriter_rows']}",f"Unique favoriters: {summary['unique_favoriters']}",f"Failures: {summary['favoriter_failures']}"]))
        manifest=_manifest(folder,{"module":"public_full_profile","auth":"client_credentials","read_only":True,"readback_pass":True})
        return {"folder":str(folder),**summary,"manifest":str(manifest)}
