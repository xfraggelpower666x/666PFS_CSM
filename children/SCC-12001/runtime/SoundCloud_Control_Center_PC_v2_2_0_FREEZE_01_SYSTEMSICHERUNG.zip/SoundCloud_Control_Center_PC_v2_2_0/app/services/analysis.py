from __future__ import annotations
import json
import math
import statistics
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from app.core.checkpoints import CheckpointStore
from app.core.config import ConfigManager
from app.core.soundcloud import SoundCloudClient
from app.core.tasks import TaskContext
from app.core.utils import (atomic_write_json, atomic_write_text, csv_text, format_duration,
                            local_date_key, local_datetime_text, normalize_title, sanitize_filename, sha256_file)

DURATION_TOLERANCE_MS = 3000


def compact_track(track: dict[str, Any], preserve_missing: bool = False) -> dict[str, Any]:
    def val(name: str, default=None):
        if preserve_missing:
            return track.get(name) if name in track else None
        return track.get(name, default)
    return {
        "id": track.get("id"), "urn": track.get("urn"), "title": track.get("title") or "",
        "duration": (track.get("duration") if "duration" in track else None) if preserve_missing else track.get("duration", 0),
        "duration_text": format_duration(track.get("duration")), "created_at": track.get("created_at"),
        "created_at_local": local_datetime_text(track.get("created_at")), "local_date_key": local_date_key(track.get("created_at")),
        "permalink_url": track.get("permalink_url"), "playback_count": val("playback_count", 0),
        "likes_count": val("likes_count", 0), "comment_count": val("comment_count", 0),
        "reposts_count": val("reposts_count", None), "download_count": val("download_count", None),
        "downloadable": None if preserve_missing and "downloadable" not in track else bool(track.get("downloadable")),
        "sharing": track.get("sharing"), "state": track.get("state"), "genre": track.get("genre") or "",
        "tag_list": track.get("tag_list") or "", "description": track.get("description"),
        "artwork_url": track.get("artwork_url"), "waveform_url": track.get("waveform_url")
    }


def compact_user(user: dict[str, Any]) -> dict[str, Any]:
    return {k: user.get(k) for k in ["id", "urn", "username", "full_name", "permalink", "permalink_url", "avatar_url", "city", "country_code", "followers_count", "followings_count", "track_count"]}


def latest_tracks(tracks: list[dict[str, Any]], count: int) -> list[dict[str, Any]]:
    return sorted(tracks, key=lambda t: (t.get("created_at") or ""), reverse=True)[:count]


def filter_scope(tracks: list[dict[str, Any]], scope: dict[str, Any]) -> list[dict[str, Any]]:
    mode = scope.get("mode", "all")
    if mode in ("all", "full_account", "snapshot_delta"):
        return list(tracks)
    if mode == "latest_n":
        return latest_tracks(tracks, int(scope.get("limit", 500)))
    if mode == "single_day":
        key = scope.get("date")
        return [t for t in tracks if local_date_key(t.get("created_at")) == key]
    if mode == "date_range":
        start, end = scope.get("from"), scope.get("to")
        return [t for t in tracks if (k := local_date_key(t.get("created_at"))) and (not start or k >= start) and (not end or k <= end)]
    if mode == "track_ids":
        wanted = {str(x) for x in scope.get("track_ids", [])}
        return [t for t in tracks if str(t.get("id")) in wanted]
    return list(tracks)


def build_duplicate_plan(tracks: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for track in tracks:
        key = normalize_title(track.get("title"))
        if key:
            groups[key].append(track)
    duplicate_groups, candidates = [], []
    for title, items in groups.items():
        ordered = sorted(items, key=lambda t: t.get("created_at") or "")
        clusters: list[list[dict[str, Any]]] = []
        for track in ordered:
            duration = int(track.get("duration") or 0)
            match = next((c for c in clusters if abs(duration - int(c[0].get("duration") or 0)) <= DURATION_TOLERANCE_MS), None)
            if match is not None:
                match.append(track)
            else:
                clusters.append([track])
        for cluster in clusters:
            if len(cluster) > 1:
                keep, remove = cluster[0], cluster[1:]
                group = {"normalized_title": title, "keep": compact_track(keep), "remove": [compact_track(x) for x in remove]}
                duplicate_groups.append(group)
                candidates.extend(group["remove"])
    return duplicate_groups, candidates


def _timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")


def _run_folder(config: ConfigManager, prefix: str) -> Path:
    path = config.export_root / f"{sanitize_filename(prefix)}_{_timestamp()}"
    path.mkdir(parents=True, exist_ok=False)
    return path


def _manifest(folder: Path, metadata: dict[str, Any]) -> Path:
    files = {}
    for path in sorted(folder.rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            files[str(path.relative_to(folder))] = {"bytes": path.stat().st_size, "sha256": sha256_file(path)}
    payload = {"generated_at": datetime.now().astimezone().isoformat(), **metadata, "files": files}
    path = folder / "manifest.json"
    atomic_write_json(path, payload)
    # Readback validation
    parsed = json.loads(path.read_text(encoding="utf-8"))
    if parsed.get("files") != files:
        raise RuntimeError("Manifest-Readback fehlgeschlagen.")
    return path


class AnalysisService:
    def __init__(self, client: SoundCloudClient, config: ConfigManager, logger=None):
        self.client = client
        self.config = config
        self.logger = logger
        self.checkpoints = CheckpointStore()

    def _fetch_base(self, ctx: TaskContext) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        ctx.update(2, "Account wird geprüft")
        account = self.client.fetch_account(ctx.cancel_event)
        ctx.update(5, "Tracks werden paginiert geladen")
        tracks = self.client.fetch_all_tracks(lambda page, rows: ctx.update(min(35, 5 + page * 2), f"Trackseite {page}: {rows} Tracks"), ctx.cancel_event)
        return account, tracks

    def cleanup_analyze(self, ctx: TaskContext, scope: dict[str, Any], operation: str, latest_count: int = 0,
                        delete_confirmed: bool = False) -> dict[str, Any]:
        account, all_tracks = self._fetch_base(ctx)
        selected = filter_scope(all_tracks, scope)
        groups, duplicates = build_duplicate_plan(selected)
        effective: list[dict[str, Any]] = []
        if operation == "duplicates": effective = duplicates
        elif operation == "all": effective = [compact_track(t) for t in selected]
        elif operation == "latest": effective = [compact_track(t) for t in latest_tracks(selected, latest_count)]
        folder = _run_folder(self.config, "soundcloud_control_cleanup")
        report = {"generated_at": datetime.now().isoformat(), "version": "2.0.0", "module": "cleanup", "operation": operation,
                  "scope": scope, "account": {"id": account.get("id"), "username": account.get("username")},
                  "statistics": {"total_account_tracks": len(all_tracks), "selected_scope_tracks": len(selected),
                  "duplicate_groups": len(groups), "duplicate_delete_candidates": len(duplicates), "effective_candidates": len(effective)},
                  "duplicate_groups": groups, "duplicate_delete_candidates": duplicates, "effective_candidates": effective}
        atomic_write_json(folder / "cleanup_report.json", report)
        atomic_write_json(folder / "selected_tracks.json", [compact_track(t) for t in selected])
        lines = ["SOUNDCLOUD CONTROL CENTER CLEANUP REPORT", "Version: 2.0.0", "", f"Account: {account.get('username')}",
                 f"Aktion: {operation}", f"Scope: {scope}", f"Tracks im Account: {len(all_tracks)}", f"Tracks im Scope: {len(selected)}",
                 f"Duplikat-Gruppen: {len(groups)}", f"Effektiv betroffen: {len(effective)}", ""]
        for item in effective:
            lines += [f"ID: {item.get('id')}", f"Titel: {item.get('title')}", f"Dauer: {item.get('duration_text')}", f"URL: {item.get('permalink_url') or ''}", "---"]
        atomic_write_text(folder / "cleanup_report.txt", "\n".join(lines))
        result = {"folder": str(folder), "deleted": 0, "failed": 0, "candidates": len(effective)}
        if operation != "analyze" and delete_confirmed and effective:
            ctx.update(55, "Löschung startet; Backup wurde geschrieben")
            failures = []
            for index, track in enumerate(effective, 1):
                ctx.check_cancelled()
                try:
                    self.client.delete_track(track["id"], ctx.cancel_event)
                    result["deleted"] += 1
                except Exception as exc:
                    result["failed"] += 1
                    failures.append({"track": track, "error": str(exc)})
                ctx.update(55 + 40 * index / max(len(effective), 1), f"Löschung {index}/{len(effective)}")
                if index < len(effective): time.sleep(self.config.config.delete_delay_seconds)
            atomic_write_json(folder / "delete_result.json", {**result, "failures": failures})
        _manifest(folder, {"freeze": "runtime-export", "module": "cleanup", "readback_pass": True})
        return result


    def cleanup_delete_from_backup(self, ctx: TaskContext, folder_path: str, expected_count: int) -> dict[str, Any]:
        folder = Path(folder_path)
        report_path = folder / "cleanup_report.json"
        if not report_path.exists():
            raise RuntimeError("Cleanup-Backup fehlt; Löschung wird blockiert.")
        report = json.loads(report_path.read_text(encoding="utf-8"))
        candidates = report.get("effective_candidates", [])
        if len(candidates) != int(expected_count):
            raise RuntimeError("Kandidatenzahl stimmt nicht mit der Bestätigung überein; Löschung wird blockiert.")
        result = {"folder": str(folder), "deleted": 0, "failed": 0, "candidates": len(candidates)}
        failures = []
        for index, track in enumerate(candidates, 1):
            ctx.check_cancelled()
            try:
                self.client.delete_track(track["id"], ctx.cancel_event)
                result["deleted"] += 1
            except Exception as exc:
                result["failed"] += 1
                failures.append({"track": track, "error": str(exc)})
            ctx.update(5 + 90 * index / max(len(candidates), 1), f"Löschung {index}/{len(candidates)}")
            if index < len(candidates):
                time.sleep(self.config.config.delete_delay_seconds)
        atomic_write_json(folder / "delete_result.json", {**result, "failures": failures, "completed_at": datetime.now().isoformat()})
        _manifest(folder, {"freeze": "runtime-export", "module": "cleanup", "delete_completed": True, "readback_pass": True})
        return result

    def likes_analysis(self, ctx: TaskContext, scope: dict[str, Any], favoriter_limit: int | None) -> dict[str, Any]:
        account, all_tracks = self._fetch_base(ctx)
        selected = filter_scope(all_tracks, scope)
        liked = [t for t in selected if int(t.get("likes_count") or 0) > 0]
        if favoriter_limit is not None: liked = liked[:favoriter_limit]
        results, failures, users = [], [], {}
        key = "likes_" + sanitize_filename(f"{account.get('id')}_{scope}_{favoriter_limit}")
        checkpoint = self.checkpoints.load(key) or {}
        completed = set(str(x) for x in checkpoint.get("completed_ids", []))
        results = checkpoint.get("results", [])
        failures = checkpoint.get("failures", [])
        for index, track in enumerate(liked, 1):
            if str(track.get("id")) in completed: continue
            ctx.check_cancelled()
            try:
                raw_users = self.client.fetch_favoriters(track, ctx.cancel_event)
                compact_users = [compact_user(u) for u in raw_users]
                entry = {"track": compact_track(track), "expected_likes_count": track.get("likes_count", 0),
                         "retrieved_favoriters_count": len(compact_users), "favoriters": compact_users}
                results.append(entry)
            except Exception as exc:
                failure = {"track": compact_track(track), "error": str(exc)}
                failures.append(failure)
                results.append({"track": compact_track(track), "expected_likes_count": track.get("likes_count", 0),
                                "retrieved_favoriters_count": 0, "favoriters": [], "error": str(exc)})
            completed.add(str(track.get("id")))
            if len(completed) % self.config.config.checkpoint_every == 0 or index == len(liked):
                self.checkpoints.save(key, {"status": "PARTIAL", "completed_ids": sorted(completed), "results": results, "failures": failures})
            ctx.update(35 + 55 * index / max(len(liked), 1), f"Favoriter {index}/{len(liked)}")
            if index < len(liked): time.sleep(self.config.config.favoriter_delay_seconds)
        self.checkpoints.clear(key)
        for entry in results:
            for user in entry.get("favoriters", []):
                ukey = str(user.get("id") or user.get("permalink") or user.get("username"))
                rec = users.setdefault(ukey, {"user": user, "liked_track_count": 0, "liked_tracks": []})
                rec["liked_track_count"] += 1
                rec["liked_tracks"].append({"id": entry["track"].get("id"), "title": entry["track"].get("title"), "permalink_url": entry["track"].get("permalink_url")})
        top_users = sorted(users.values(), key=lambda x: x["liked_track_count"], reverse=True)[:100]
        summary = {"unique_users": len(users), "total_favoriter_rows": sum(len(e.get("favoriters", [])) for e in results), "top_users": top_users}
        folder = _run_folder(self.config, "soundcloud_control_likes")
        report = {"generated_at": datetime.now().isoformat(), "version": "2.0.0", "module": "likes_favoriter_analyzer",
                  "account": {"id": account.get("id"), "username": account.get("username")}, "scope": scope,
                  "statistics": {"total_account_tracks": len(all_tracks), "selected_scope_tracks": len(selected), "tracks_with_likes": len(liked),
                                 "total_favoriter_rows": summary["total_favoriter_rows"], "unique_users": summary["unique_users"], "failed_track_requests": len(failures)},
                  "top_users": top_users, "track_like_details": results, "failures": failures}
        atomic_write_json(folder / "likes_report.json", report)
        atomic_write_json(folder / "selected_tracks.json", [compact_track(t) for t in selected])
        rows=[]
        for e in results:
            if not e.get("favoriters"):
                rows.append([e["track"].get("id"), e["track"].get("title"), e["track"].get("permalink_url"), e["track"].get("created_at_local"), e.get("expected_likes_count"), e.get("retrieved_favoriters_count"), "", "", "", "", "", "", "", ""])
            for u in e.get("favoriters", []):
                rows.append([e["track"].get("id"), e["track"].get("title"), e["track"].get("permalink_url"), e["track"].get("created_at_local"), e.get("expected_likes_count"), e.get("retrieved_favoriters_count"), u.get("id"), u.get("username"), u.get("full_name"), u.get("permalink_url"), u.get("city"), u.get("country_code"), u.get("followers_count"), u.get("track_count")])
        atomic_write_text(folder / "likes_report.csv", csv_text(["track_id","track_title","track_url","track_created_local","track_likes_count","retrieved_favoriters_count","user_id","username","full_name","user_permalink_url","city","country_code","followers_count","user_track_count"], rows))
        text=["SOUNDCLOUD CONTROL CENTER LIKES REPORT", "Version: 2.0.0", "", f"Account: {account.get('username')}", f"Scope: {scope}", f"Tracks im Account: {len(all_tracks)}", f"Tracks im Scope: {len(selected)}", f"Favoriter-Zeilen: {summary['total_favoriter_rows']}", f"Einzigartige User: {summary['unique_users']}", "", "TOP USER"]
        for item in top_users[:50]: text += [f"{item['liked_track_count']} Likes von: {item['user'].get('username') or item['user'].get('id')}", f"  Profil: {item['user'].get('permalink_url') or ''}"]
        atomic_write_text(folder / "likes_report.txt", "\n".join(text))
        _manifest(folder, {"module": "likes", "readback_pass": True})
        return {"folder": str(folder), "tracks": len(selected), "favoriter_rows": summary["total_favoriter_rows"], "unique_users": summary["unique_users"], "failures": len(failures)}

    def evidence_analysis(self, ctx: TaskContext, scope: dict[str, Any], favoriter_limit: int | None) -> dict[str, Any]:
        # Reuse verified collection pipeline, then add evidence-specific classification and integrity manifest.
        account, all_tracks = self._fetch_base(ctx)
        selected = filter_scope(all_tracks, scope)
        evidence=[]
        for t in selected:
            c=compact_track(t, preserve_missing=True)
            combined=" ".join(str(t.get(k) or "").lower() for k in ("title","description","genre","tag_list"))
            if "lyvra" in combined: relation="LYVRA_CURRENT"
            elif any(x in combined for x in ("fraggle","666soundsdesign","666 sounds design","666sound")): relation="LYVRA_HISTORICAL_VERSION"
            else: relation="UNCERTAIN"
            plays=int(t.get("playback_count") or 0); likes=int(t.get("likes_count") or 0); reposts=int(t.get("reposts_count") or 0); comments=int(t.get("comment_count") or 0)
            level=2 if likes or reposts or comments else (1 if plays else 0)
            evidence.append({"track_id":t.get("id"), **{k:v for k,v in c.items() if k!="id"}, "lyvra_relation":relation,
                             "evidence_classification":{"level":level,"label":["NO_VISIBLE_SIGNAL","PLATFORM_CONTACT","EXPLICIT_REACTION"][level]}})
        plays=[int(x.get("playback_count") or 0) for x in evidence]
        summary={"total_tracks":len(evidence),"total_plays":sum(plays),"total_likes":sum(int(x.get("likes_count") or 0) for x in evidence),
                 "total_reposts":sum(int(x.get("reposts_count") or 0) for x in evidence),"total_comments":sum(int(x.get("comment_count") or 0) for x in evidence),
                 "mean_plays":statistics.mean(plays) if plays else None,"median_plays":statistics.median(plays) if plays else None,
                 "p90_plays":sorted(plays)[max(0, math.ceil(.9*len(plays))-1)] if plays else None}
        # Optional favoriter details use same checked implementation.
        reactions={"favoriter_policy":"none","results":[],"failures":[],"unique_users":0,"total_favoriter_rows":0}
        if favoriter_limit != 0:
            liked=[t for t in selected if int(t.get("likes_count") or 0)>0]
            if favoriter_limit is not None: liked=liked[:favoriter_limit]
            users={}
            for i,t in enumerate(liked,1):
                try:
                    us=[compact_user(u) for u in self.client.fetch_favoriters(t,ctx.cancel_event)]
                    reactions["results"].append({"track_id":t.get("id"),"likes_count_reported":t.get("likes_count"),"favoriters_fetched":len(us),"favoriter_fetch_status":"PASS","favoriters":us})
                    reactions["total_favoriter_rows"]+=len(us)
                    for u in us: users[str(u.get("id") or u.get("username"))]=u
                except Exception as exc: reactions["failures"].append({"track_id":t.get("id"),"error":str(exc)})
                ctx.update(40+45*i/max(len(liked),1),f"Evidence-Favoriter {i}/{len(liked)}")
            reactions["unique_users"]=len(users); reactions["favoriter_policy"]="limited" if favoriter_limit is not None else "all"
        ids=[str(x.get("track_id") or "") for x in evidence]
        duplicate_ids=[k for k,v in Counter(ids).items() if k and v>1]
        anomaly={"duplicate_track_ids":bool(duplicate_ids),"duplicate_track_id_groups":duplicate_ids,
                 "note":"Anomalien sind Prüfhinweise und keine Manipulationsbehauptungen."}
        completeness="COMPLETE" if len(set(ids))==len(ids) else "COUNT_MISMATCH"
        confidence="MODERATE_POSITIVE" if summary["total_plays"]>10000 and (summary["total_likes"] or summary["total_comments"] or summary["total_reposts"]) else ("WEAK_POSITIVE" if summary["total_plays"] else "NONE")
        lyvra={"verified_registered_plays":summary["total_plays"],"verified_likes":summary["total_likes"],"verified_reposts":summary["total_reposts"],"verified_comments":summary["total_comments"],"unique_listeners":None,"listener_retention":None,"confidence_signal":confidence,"limitations":["UNIQUE_HUMAN_LISTENERS_NOT_AVAILABLE_FROM_CURRENT_TRACK_FIELDS","CORRELATION_IS_NOT_CAUSATION"]}
        folder=_run_folder(self.config,"soundcloud_analysis_evidence")
        payload={"schema_version":"2.0.0","generated_at_utc":datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),"module":"LYVRA_REAL_WORLD_EVIDENCE_ANALYZER","read_only":True,"destructive_actions_allowed":False,"account":account,"mode":scope,"completeness_status":completeness,"summary":summary,"anomaly_flags":anomaly,"reactions":reactions,"lyvra_real_world_evidence":lyvra,"tracks":evidence}
        atomic_write_json(folder/"evidence.json",payload)
        track_rows=[[x.get("track_id"),x.get("title"),x.get("permalink_url"),x.get("created_at"),x.get("created_at_local"),x.get("duration"),x.get("duration_text"),x.get("playback_count"),x.get("likes_count"),x.get("reposts_count"),x.get("comment_count"),x.get("lyvra_relation"),x["evidence_classification"]["level"],x["evidence_classification"]["label"]] for x in evidence]
        atomic_write_text(folder/"evidence_tracks.csv",csv_text(["track_id","title","permalink_url","created_at_utc","created_at_local","duration_ms","duration_human","playback_count","likes_count","reposts_count","comment_count","lyvra_relation","evidence_level","evidence_label"],track_rows))
        atomic_write_text(folder/"evidence.txt","\n".join(["SOUNDCLOUD / LYVRA REAL-WORLD EVIDENCE REPORT",f"Vollständigkeit: {completeness}",f"TOTAL_TRACKS: {summary['total_tracks']}",f"TOTAL_PLAYS: {summary['total_plays']}",f"TOTAL_LIKES: {summary['total_likes']}",f"Confidence Signal: {confidence}","Playback zählt Plattformaktivität, beweist aber keine unique listener oder Kausalität."]))
        _manifest(folder,{"module":"evidence","completeness_status":completeness,"readback_pass":True})
        return {"folder":str(folder),"tracks":len(evidence),"plays":summary["total_plays"],"confidence":confidence,"completeness":completeness}

    def full_account_analysis(self, ctx: TaskContext, scope: dict[str, Any], favoriter_limit: int | None) -> dict[str, Any]:
        account, all_tracks = self._fetch_base(ctx)
        scoped=filter_scope(all_tracks,scope)
        seen=set(); unique=[]; duplicate_records=[]
        for t in scoped:
            key=str(t.get("id") or t.get("urn") or "")
            if key and key in seen: duplicate_records.append(compact_track(t)); continue
            if key: seen.add(key)
            unique.append(t)
        batches_map=defaultdict(list)
        for t in unique: batches_map[local_date_key(t.get("created_at")) or "unknown"].append(t)
        batches=[]; batch_index={}
        for key,items in sorted(batches_map.items()):
            ordered=sorted(items,key=lambda x:x.get("created_at") or "")
            rows=[]
            for i,t in enumerate(ordered,1):
                rows.append({"track_id":t.get("id"),"title":t.get("title"),"batch_position":i,"created_at":t.get("created_at")})
                batch_index[str(t.get("id"))]={"batch_key":key,"batch_size":len(ordered),"batch_position":i}
            batches.append({"batch_key":key,"batch_size":len(ordered),"tracks":rows})
        def field_desc(t,name):
            present=name in t; raw=t.get(name) if present else None
            status="FIELD_MISSING" if not present else ("FIELD_NULL" if raw is None else ("FIELD_PRESENT_ZERO" if isinstance(raw,(int,float)) and raw==0 else "FIELD_PRESENT_POSITIVE"))
            return {"field_present":present,"raw_value":raw,"normalized_value":raw if present else None,"source_field":name if present else None,"status":status}
        phase=[]; errors=[]
        for i,t in enumerate(unique,1):
            try:
                likes=field_desc(t,"likes_count") if "likes_count" in t else field_desc(t,"favoritings_count")
                stats={"playback_count":field_desc(t,"playback_count"),"likes":likes,"comment_count":field_desc(t,"comment_count"),"reposts_count":field_desc(t,"reposts_count"),"download_count":field_desc(t,"download_count")}
                phase.append({"track_id":t.get("id"),"urn":t.get("urn"),"base_metadata":compact_track(t,preserve_missing=True),"statistics":stats,"field_availability":{k:v["status"] for k,v in stats.items()},"memberships":{"album_memberships":[],"playlist_memberships":[],"status":"ENDPOINT_NOT_CALLED"},"batch_context":batch_index.get(str(t.get("id")),{}),"lyvra_provenance":{"title_family_key":normalize_title(t.get("title")),"source_account_track":True,"status":"DERIVED_FROM_AVAILABLE_METADATA"},"phase_a_status":"PHASE_A_COMPLETE"})
            except Exception as exc: errors.append({"phase":"PHASE_A","track_id":t.get("id"),"error":str(exc)})
            if i%250==0: ctx.update(35+10*i/max(len(unique),1),f"Phase A {i}/{len(unique)}")
        fields=["playback_count","likes","comment_count","reposts_count","download_count"]
        availability={f:{"total_tracks":len(phase),"statuses":dict(Counter(x["field_availability"].get(f,"FIELD_MISSING") for x in phase))} for f in fields}
        aggregates={"totals":{"tracks":len(unique),"duration_sum_ms":sum(int(t.get("duration") or 0) for t in unique),"playback_count_sum":sum(int(t.get("playback_count") or 0) for t in unique),"likes_count_sum":sum(int(t.get("likes_count") or t.get("favoritings_count") or 0) for t in unique),"comment_count_sum":sum(int(t.get("comment_count") or 0) for t in unique),"reposts_count_sum":sum(int(t.get("reposts_count") or 0) for t in unique)},"interpretation_guards":["MISSING_FIELD_IS_NOT_ZERO","PLAYBACK_COUNT_IS_NOT_UNIQUE_LISTENERS","CORRELATION_IS_NOT_CAUSATION"]}
        families_map=defaultdict(list)
        for t in unique: families_map[normalize_title(t.get("title"))].append(compact_track(t))
        families=[{"family_key":k,"member_count":len(v),"members":v} for k,v in families_map.items() if k and len(v)>1]
        # Optional phase B favoriter checkpoint.
        liked=[t for t in unique if int(t.get("likes_count") or t.get("favoritings_count") or 0)>0]
        if favoriter_limit is not None: liked=liked[:favoriter_limit]
        phase_b={"policy":{"mode":"none" if favoriter_limit==0 else "limited" if favoriter_limit is not None else "all","label":str(favoriter_limit)},"requested_tracks_with_likes":len(liked),"analyzed_tracks_with_likes":0,"results":[],"failures":[],"summary":{"unique_users":0,"total_favoriter_rows":0,"top_users":[]}}
        if favoriter_limit!=0:
            key="full_account_"+sanitize_filename(f"{account.get('id')}_{scope}_{favoriter_limit}")
            cp=self.checkpoints.load(key) or {}; completed=set(cp.get("completed_ids",[])); phase_b["results"]=cp.get("results",[]); phase_b["failures"]=cp.get("failures",[])
            for i,t in enumerate(liked,1):
                sid=str(t.get("id"))
                if sid in completed: continue
                try:
                    us=[compact_user(u) for u in self.client.fetch_favoriters(t,ctx.cancel_event)]
                    phase_b["results"].append({"track":compact_track(t),"expected_likes_count":t.get("likes_count"),"retrieved_favoriters_count":len(us),"favoriters":us})
                except Exception as exc: phase_b["failures"].append({"track":compact_track(t),"error":str(exc)})
                completed.add(sid); phase_b["analyzed_tracks_with_likes"]=len(completed)
                if len(completed)%self.config.config.checkpoint_every==0 or i==len(liked): self.checkpoints.save(key,{"status":"PARTIAL","completed_ids":list(completed),"results":phase_b["results"],"failures":phase_b["failures"]})
                ctx.update(45+40*i/max(len(liked),1),f"Phase B Favoriter {i}/{len(liked)}")
            self.checkpoints.clear(key)
            users={}
            for e in phase_b["results"]:
                for u in e.get("favoriters",[]):
                    k=str(u.get("id") or u.get("username")); rec=users.setdefault(k,{"user":u,"liked_track_count":0,"liked_tracks":[]}); rec["liked_track_count"]+=1; rec["liked_tracks"].append({"id":e["track"].get("id"),"title":e["track"].get("title")})
            phase_b["summary"]={"unique_users":len(users),"total_favoriter_rows":sum(len(e.get("favoriters",[])) for e in phase_b["results"]),"top_users":sorted(users.values(),key=lambda x:x["liked_track_count"],reverse=True)[:100]}
        complete=len(phase)==len(unique)==len(scoped)
        completeness={"account":"COMPLETE","tracks":"COMPLETE" if complete else "PARTIAL","track_metadata":"COMPLETE" if complete else "PARTIAL","play_counts":"COMPLETE_FIELD_CLASSIFICATION","like_counts":"COMPLETE_FIELD_CLASSIFICATION","favoriters":"NOT_REQUESTED" if favoriter_limit==0 else ("PARTIAL" if phase_b["failures"] else "COMPLETE_FOR_REQUESTED_TRACKS"),"comments":"COMPLETE_COUNTERS_ONLY","comment_details":"NOT_REQUESTED","reposts":"COMPLETE_COUNTERS_ONLY","repost_users":"UNAVAILABLE","albums_playlists":"ENDPOINT_NOT_CALLED","batches":"DERIVED_COMPLETE","followers":"NOT_AVAILABLE","insights":"NOT_AVAILABLE","snapshots":"COMPLETE_CURRENT_SNAPSHOT","phase_a":"PHASE_A_COMPLETE" if complete else "PHASE_A_PARTIAL","phase_b":"PHASE_B_NOT_REQUESTED" if favoriter_limit==0 else ("PHASE_B_PARTIAL" if phase_b["failures"] else "PHASE_B_COMPLETE_FOR_REQUESTED_FAVORITER_SCOPE")}
        folder=_run_folder(self.config,"full_account_complete_analysis")
        prefix="full_account"
        snapshot={"generated_at":datetime.now().isoformat(),"version":"2.0.0","mode":"FULL_ACCOUNT_GOLD_DATA","read_only":True,"account":account,"scope":scope,"source_tracks_count":len(scoped),"unique_tracks_count":len(unique),"duplicate_id_records":duplicate_records,"phase_a_tracks":phase,"aggregates":aggregates,"field_availability":availability,"domain_completeness":completeness,"phase_b":phase_b,"batches":batches,"work_families":families,"errors":errors}
        atomic_write_json(folder/f"{prefix}_complete_snapshot.json",snapshot)
        atomic_write_json(folder/f"{prefix}_account.json",account)
        atomic_write_json(folder/f"{prefix}_batches.json",batches)
        atomic_write_json(folder/f"{prefix}_work_families.json",families)
        atomic_write_json(folder/f"{prefix}_field_availability.json",availability)
        atomic_write_json(folder/f"{prefix}_errors.json",errors)
        atomic_write_json(folder/f"{prefix}_capabilities.json",{"account":"AVAILABLE","tracks":"AVAILABLE","track_metadata":"AVAILABLE","counters":"AVAILABLE_WITH_FIELD_CLASSIFICATION","favoriters":"OPTIONAL_ENDPOINT","comments":"COUNTERS_ONLY","comment_details":"ENDPOINT_NOT_CALLED","reposts":"COUNTERS_ONLY","repost_users":"UNAVAILABLE","albums_playlists":"ENDPOINT_NOT_CALLED","batches":"DERIVED","followers":"NOT_AVAILABLE","insights":"NOT_AVAILABLE","destructive_actions":"FORBIDDEN"})
        atomic_write_json(folder/f"{prefix}_albums_playlists.json",{"status":"ENDPOINT_NOT_CALLED","albums":[],"playlists":[],"memberships":[]})
        atomic_write_text(folder/f"{prefix}_tracks.jsonl","\n".join(json.dumps(x,ensure_ascii=False) for x in phase))
        rows=[]
        for x in phase:
            m=x["base_metadata"]; s=x["statistics"]
            rows.append([x["track_id"],m.get("title"),m.get("created_at_local"),m.get("duration_text"),s["playback_count"]["normalized_value"],s["playback_count"]["status"],s["likes"]["normalized_value"],s["likes"]["status"],s["comment_count"]["normalized_value"],s["comment_count"]["status"],s["reposts_count"]["normalized_value"],s["reposts_count"]["status"],s["download_count"]["normalized_value"],s["download_count"]["status"],x["batch_context"].get("batch_key"),x["batch_context"].get("batch_position"),m.get("permalink_url")])
        atomic_write_text(folder/f"{prefix}_tracks.csv",csv_text(["track_id","title","created_at_local","duration_text","playback_value","playback_status","resolved_like_value","like_status","comment_value","comment_status","repost_value","repost_status","download_value","download_status","batch_key","batch_position","permalink_url"],rows))
        fav_rows=[]
        for e in phase_b["results"]:
            if not e.get("favoriters"): fav_rows.append([e["track"].get("id"),e["track"].get("title"),e["expected_likes_count"],"",""])
            for u in e.get("favoriters",[]): fav_rows.append([e["track"].get("id"),e["track"].get("title"),e["expected_likes_count"],u.get("id"),u.get("username")])
        fav_csv=csv_text(["track_id","track_title","track_likes_count","favoriter_user_id","favoriter_username"],fav_rows)
        atomic_write_text(folder/f"{prefix}_favoriters.csv",fav_csv); atomic_write_text(folder/f"{prefix}_reactions.csv",fav_csv)
        atomic_write_text(folder/f"{prefix}_comments.csv",csv_text(["track_id","comment_id","comment_author","comment_body","status"],[]))
        atomic_write_text(folder/f"{prefix}_reposts.csv",csv_text(["track_id","repost_user_id","repost_username","status"],[]))
        summary=["SOUNDCLOUD FULL ACCOUNT ANALYSIS","Version: 2.0.0","READ_ONLY=TRUE","DELETE_ALLOWED=FALSE",f"Account: {account.get('username')}",f"Tracks aus API/Scope: {len(scoped)}",f"Eindeutige Track-IDs: {len(unique)}",f"Phase-A-Records: {len(phase)}",f"Play-Summe: {aggregates['totals']['playback_count_sum']}",f"Like-Summe: {aggregates['totals']['likes_count_sum']}",f"Basiscensus: {completeness['phase_a']}",f"Detailabfragen: {completeness['phase_b']}","MISSING_FIELD_IS_NOT_ZERO","PLAYBACK_COUNT_IS_NOT_UNIQUE_LISTENERS","CORRELATION_IS_NOT_CAUSATION"]
        atomic_write_text(folder/f"{prefix}_summary.txt","\n".join(summary))
        manifest=_manifest(folder,{"manifest_type":"SOUNDCLOUD_FULL_ACCOUNT_COMPLETE_ANALYSIS","domain_completeness":completeness,"verification":{"readback_required":True,"missing_field_not_zero":True,"all_scope_tracks_included_independent_of_reactions":len(phase)==len(unique)}})
        readback=json.loads((folder/f"{prefix}_complete_snapshot.json").read_text(encoding="utf-8"))
        if len(readback.get("phase_a_tracks",[]))!=len(unique): raise RuntimeError("Full-Account-Readback-Prüfung fehlgeschlagen.")
        return {"folder":str(folder),"tracks":len(unique),"phase_a":completeness["phase_a"],"phase_b":completeness["phase_b"],"errors":len(errors),"manifest":str(manifest)}
