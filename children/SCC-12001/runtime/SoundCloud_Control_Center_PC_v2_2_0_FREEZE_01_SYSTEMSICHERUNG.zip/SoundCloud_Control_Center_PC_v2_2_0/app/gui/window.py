from __future__ import annotations
import json
import os
import webbrowser
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from app.core.audit import run_installation_audit
from app.core.config import ConfigManager
from app.core.logging_setup import configure_logging
from app.core.paths import project_root
from app.core.secure_store import SecureStore
from app.core.desktop_oauth import consume_callback_url, is_custom_scheme
from app.core.soundcloud import SoundCloudClient
from app.core.public_api import PublicApiClient
from app.core.tasks import TaskManager, TaskUpdate
from app.services.analysis import AnalysisService
from app.services.public_analysis import PublicProfileAnalysisService
from app.version import APP_NAME, APP_VERSION, SOURCE_VERSION, FREEZE_ID

BG="#101116"; PANEL="#171922"; FG="#e9e9ef"; MUTED="#a4a8b8"; ACCENT="#8d5cff"; GOOD="#31c48d"; WARN="#f6ad55"; BAD="#f05252"


class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} — {APP_VERSION}")
        self.geometry("1160x760")
        self.minsize(980,650)
        self.configure(bg=BG)
        self.logger=configure_logging(); self.config_manager=ConfigManager(); self.secure=SecureStore()
        self.client=SoundCloudClient(self.config_manager,self.secure,self.logger)
        self.public_api=PublicApiClient(self.client,self.config_manager,self.secure,self.logger)
        self.tasks=TaskManager(self.config_manager.config.max_parallel_tasks)
        self.analysis=AnalysisService(self.client,self.config_manager,self.logger)
        self.public_analysis=PublicProfileAnalysisService(self.public_api,self.config_manager,self.logger)
        self.task_rows={}; self.last_selected_task=""; self.pending_cleanup={}; self.pending_api={}; self.api_next_href=""
        self._style(); self._build(); self.after(150,self._poll_updates)

    def _style(self):
        s=ttk.Style(self); s.theme_use("clam")
        s.configure(".",background=BG,foreground=FG,fieldbackground=PANEL,font=("Segoe UI",10))
        s.configure("TNotebook",background=BG,borderwidth=0); s.configure("TNotebook.Tab",background=PANEL,foreground=FG,padding=(14,8)); s.map("TNotebook.Tab",background=[("selected",ACCENT)])
        s.configure("TFrame",background=BG); s.configure("Card.TFrame",background=PANEL); s.configure("TLabel",background=BG,foreground=FG); s.configure("Card.TLabel",background=PANEL,foreground=FG)
        s.configure("TButton",background=ACCENT,foreground="white",padding=(10,7)); s.map("TButton",background=[("active","#7448da")])
        s.configure("Danger.TButton",background=BAD); s.configure("Treeview",background=PANEL,fieldbackground=PANEL,foreground=FG,rowheight=27); s.configure("Treeview.Heading",background="#242735",foreground=FG)
        s.configure("Horizontal.TProgressbar",troughcolor="#292c39",background=ACCENT)

    def _build(self):
        header=tk.Frame(self,bg=BG); header.pack(fill="x",padx=18,pady=(14,4))
        tk.Label(header,text="SOUNDCLOUD CONTROL CENTER",font=("Segoe UI Semibold",20),fg=FG,bg=BG).pack(side="left")
        tk.Label(header,text=f"PC {APP_VERSION}  •  Source {SOURCE_VERSION}  •  {FREEZE_ID}",font=("Segoe UI",9),fg=MUTED,bg=BG).pack(side="right")
        self.notebook=ttk.Notebook(self); self.notebook.pack(fill="both",expand=True,padx=16,pady=12)
        self.tabs={name:ttk.Frame(self.notebook) for name in ["Dashboard","Token Manager","API-Zentrale","Analysen","Cleanup","Aufgaben","System"]}
        for name,frame in self.tabs.items(): self.notebook.add(frame,text=name)
        self._dashboard(); self._token(); self._api_tools(); self._analyses(); self._cleanup(); self._tasks_tab(); self._system()
        self.after(500, self._poll_oauth_callback)

    def _card(self,parent,title):
        f=ttk.Frame(parent,style="Card.TFrame",padding=16); ttk.Label(f,text=title,style="Card.TLabel",font=("Segoe UI Semibold",13)).pack(anchor="w",pady=(0,10)); return f

    def _dashboard(self):
        tab=self.tabs["Dashboard"]; top=ttk.Frame(tab); top.pack(fill="both",expand=True,padx=12,pady=12)
        card=self._card(top,"Systemstatus"); card.pack(fill="x")
        self.status_text=tk.StringVar(value="Bereit")
        ttk.Label(card,textvariable=self.status_text,style="Card.TLabel",font=("Segoe UI",12)).pack(anchor="w")
        self.overall=ttk.Progressbar(card,maximum=100); self.overall.pack(fill="x",pady=12)
        info=self._card(top,"Architektur-Schutz"); info.pack(fill="x",pady=12)
        ttk.Label(info,text="Bestehende Scriptable-Quelle bleibt unverändert. PC-Module sind Adapter/Erweiterung. Exporte: TXT, JSON, CSV und JSONL — kein Excel.",style="Card.TLabel",wraplength=1000).pack(anchor="w")
        quick=self._card(top,"Schnellstart"); quick.pack(fill="x")
        ttk.Button(quick,text="Account testen",command=self._test_account).pack(side="left",padx=(0,8)); ttk.Button(quick,text="Vollständige Kontoanalyse",command=lambda:self._launch_analysis("full")).pack(side="left",padx=8); ttk.Button(quick,text="Exportordner öffnen",command=self._open_exports).pack(side="left",padx=8)

    def _token(self):
        tab=self.tabs["Token Manager"]; card=self._card(tab,"SoundCloud OAuth / PKCE"); card.pack(fill="x",padx=12,pady=12)
        creds=self.client.credentials(); self.client_id=tk.StringVar(value=creds["client_id"]); self.client_secret=tk.StringVar(value=creds["client_secret"]); self.redirect=tk.StringVar(value=creds["redirect_uri"]); self.redirect_result=tk.StringVar()
        for label,var,show in [("Client-ID",self.client_id,""),("Client-Secret",self.client_secret,"•"),("Redirect-URI",self.redirect,"")]:
            row=ttk.Frame(card,style="Card.TFrame"); row.pack(fill="x",pady=4); ttk.Label(row,text=label,width=18,style="Card.TLabel").pack(side="left"); ttk.Entry(row,textvariable=var,show=show).pack(side="left",fill="x",expand=True)
        buttons=ttk.Frame(card,style="Card.TFrame"); buttons.pack(fill="x",pady=10)
        ttk.Button(buttons,text="Konfiguration speichern",command=self._save_credentials).pack(side="left",padx=4); ttk.Button(buttons,text="1. Anmeldung öffnen",command=self._open_auth).pack(side="left",padx=4); ttk.Button(buttons,text="Token testen",command=self._test_account).pack(side="left",padx=4); ttk.Button(buttons,text="Token erneuern",command=self._refresh_token).pack(side="left",padx=4); ttk.Button(buttons,text="Alle Token-Daten löschen",style="Danger.TButton",command=self._clear_tokens).pack(side="right",padx=4)
        red=self._card(tab,"2. Vollständige Redirect-URL einfügen"); red.pack(fill="x",padx=12,pady=12); ttk.Entry(red,textvariable=self.redirect_result).pack(fill="x",pady=5); ttk.Button(red,text="Authorization Code austauschen",command=self._exchange).pack(anchor="w",pady=5)
        ttk.Label(red,text=f"Sicherer Speicher: {self.secure.backend}",style="Card.TLabel").pack(anchor="w")
        self.oauth_status=tk.StringVar(value="Bereit")
        ttk.Label(red,textvariable=self.oauth_status,style="Card.TLabel").pack(anchor="w",pady=(5,0))


    def _api_tools(self):
        tab=self.tabs["API-Zentrale"]
        app=self._card(tab,"SoundCloud API-App / Referenz")
        app.pack(fill="x",padx=12,pady=(12,6))
        self.api_app_name=tk.StringVar(value=self.config_manager.config.soundcloud_app_name)
        self.api_app_description=tk.StringVar(value=self.config_manager.config.soundcloud_app_description)
        self.api_app_website=tk.StringVar(value=self.config_manager.config.soundcloud_app_website)
        for label,var in [("App-Name",self.api_app_name),("Beschreibung",self.api_app_description),("Website",self.api_app_website)]:
            row=ttk.Frame(app,style="Card.TFrame"); row.pack(fill="x",pady=3)
            ttk.Label(row,text=label,width=18,style="Card.TLabel").pack(side="left")
            ttk.Entry(row,textvariable=var).pack(side="left",fill="x",expand=True)
        buttons=ttk.Frame(app,style="Card.TFrame"); buttons.pack(fill="x",pady=(8,0))
        ttk.Button(buttons,text="App-Referenz speichern",command=self._save_api_app_reference).pack(side="left",padx=4)
        ttk.Button(buttons,text="SoundCloud Apps öffnen",command=lambda:webbrowser.open("https://soundcloud.com/you/apps")).pack(side="left",padx=4)
        ttk.Button(buttons,text="API Explorer",command=lambda:webbrowser.open("https://developers.soundcloud.com/docs/api/explorer/open-api")).pack(side="left",padx=4)
        ttk.Button(buttons,text="OpenAPI JSON",command=lambda:webbrowser.open("https://developers.soundcloud.com/docs/api/explorer/api.json")).pack(side="left",padx=4)
        ttk.Button(buttons,text="API Guide",command=lambda:webbrowser.open("https://developers.soundcloud.com/docs/api/guide")).pack(side="left",padx=4)

        public=self._card(tab,"Public API — browserfrei per Client Credentials")
        public.pack(fill="x",padx=12,pady=6)
        self.public_api_status=tk.StringVar(value="Nicht geprüft")
        ttk.Label(public,text="Für öffentliche Ressourcen wie Track-Suche. Nutzt dieselbe Client-ID/Secret aus dem Token Manager, überschreibt aber niemals den Benutzer-OAuth-Token.",style="Card.TLabel",wraplength=1040).pack(anchor="w")
        row=ttk.Frame(public,style="Card.TFrame"); row.pack(fill="x",pady=8)
        ttk.Button(row,text="Public API testen",command=self._test_public_api).pack(side="left",padx=4)
        ttk.Button(row,text="Public Token aktualisieren",command=self._refresh_public_api).pack(side="left",padx=4)
        ttk.Button(row,text="Public Token löschen",style="Danger.TButton",command=self._clear_public_api).pack(side="left",padx=4)
        ttk.Label(row,textvariable=self.public_api_status,style="Card.TLabel").pack(side="left",padx=12)

        search=self._card(tab,"Track-Suche — OpenAPI /tracks")
        search.pack(fill="both",expand=True,padx=12,pady=(6,12))
        row=ttk.Frame(search,style="Card.TFrame"); row.pack(fill="x",pady=(0,8))
        ttk.Label(row,text="Suche",width=10,style="Card.TLabel").pack(side="left")
        self.api_query=tk.StringVar(value="")
        ttk.Entry(row,textvariable=self.api_query).pack(side="left",fill="x",expand=True,padx=(0,8))
        ttk.Label(row,text="Limit",style="Card.TLabel").pack(side="left")
        self.api_limit=tk.StringVar(value="20")
        ttk.Combobox(row,textvariable=self.api_limit,state="readonly",values=["10","20","50","100","200"],width=6).pack(side="left",padx=6)
        ttk.Button(row,text="Suchen",command=self._search_public_tracks).pack(side="left",padx=4)
        self.api_next_button=ttk.Button(row,text="Nächste Seite",command=self._search_next_page,state="disabled")
        self.api_next_button.pack(side="left",padx=4)
        cols=("title","artist","access","likes","plays","urn")
        self.api_tree=ttk.Treeview(search,columns=cols,show="headings",height=10)
        widths={"title":300,"artist":180,"access":80,"likes":70,"plays":80,"urn":250}
        labels={"title":"Titel","artist":"Artist","access":"Access","likes":"Likes","plays":"Plays","urn":"URN / ID"}
        for c in cols:
            self.api_tree.heading(c,text=labels[c]); self.api_tree.column(c,width=widths[c],anchor="w")
        self.api_tree.pack(fill="both",expand=True)
        self.api_search_status=tk.StringVar(value="Bereit")
        ttk.Label(search,textvariable=self.api_search_status,style="Card.TLabel").pack(anchor="w",pady=(6,0))

    def _save_api_app_reference(self):
        self.config_manager.config.soundcloud_app_name=self.api_app_name.get().strip()
        self.config_manager.config.soundcloud_app_description=self.api_app_description.get().strip()
        self.config_manager.config.soundcloud_app_website=self.api_app_website.get().strip()
        self.config_manager.save()
        messagebox.showinfo("Gespeichert","Die nicht-geheimen SoundCloud-App-Metadaten wurden lokal gespeichert.")

    def _test_public_api(self):
        tid=self._submit("Public API Diagnose",lambda ctx:(ctx.update(25,"Public Token/Endpoint werden geprüft"),self.public_api.diagnostic())[1])
        self.pending_api[tid]={"kind":"diagnostic"}

    def _refresh_public_api(self):
        tid=self._submit("Public Token aktualisieren",lambda ctx:(ctx.update(25,"Token-Cache / Single-Use Refresh wird geprüft"),self.public_api.renew_public_token(),{"status":"PASS","message":"Public Token aktualisiert"})[-1])
        self.pending_api[tid]={"kind":"token"}

    def _clear_public_api(self):
        self.public_api.clear_public_tokens(); self.public_api_status.set("Public Token gelöscht"); messagebox.showinfo("Gelöscht","Nur die getrennten Public-API-Tokens wurden gelöscht. Benutzer-OAuth bleibt erhalten.")

    def _search_public_tracks(self):
        query=self.api_query.get().strip()
        if not query:
            messagebox.showerror("Eingabe","Suchbegriff fehlt."); return
        try: limit=int(self.api_limit.get())
        except ValueError: messagebox.showerror("Eingabe","Ungültiges Limit."); return
        self.api_search_status.set("Suche läuft …")
        tid=self._submit("Public Track-Suche",lambda ctx:(ctx.update(20,"SoundCloud /tracks wird abgefragt"),self.public_api.search_tracks(query,limit))[1])
        self.pending_api[tid]={"kind":"search","append":False}

    def _search_next_page(self):
        if not self.api_next_href:
            return
        url=self.api_next_href
        self.api_search_status.set("Nächste Seite wird geladen …")
        tid=self._submit("Public Track-Suche nächste Seite",lambda ctx:(ctx.update(20,"next_href wird geladen"),self.public_api.fetch_next_page(url))[1])
        self.pending_api[tid]={"kind":"search","append":True}

    def _render_api_results(self, rows, next_href, append=False):
        if not append:
            for item in self.api_tree.get_children(): self.api_tree.delete(item)
        for track in rows:
            user=track.get("user") if isinstance(track.get("user"),dict) else {}
            artist=track.get("metadata_artist") or user.get("username") or ""
            urn=track.get("urn") or track.get("id") or ""
            self.api_tree.insert("","end",values=(track.get("title") or "",artist,track.get("access") or "",track.get("likes_count") if track.get("likes_count") is not None else "",track.get("playback_count") if track.get("playback_count") is not None else "",urn))
        self.api_next_href=next_href or ""
        self.api_next_button.configure(state="normal" if self.api_next_href else "disabled")
        self.api_search_status.set(f"{len(rows)} Ergebnisse geladen" + (" — weitere Seite verfügbar" if self.api_next_href else " — Ende"))

    def _scope_controls(self,parent):
        row=ttk.Frame(parent,style="Card.TFrame"); row.pack(fill="x",pady=5)
        ttk.Label(row,text="Scope",width=18,style="Card.TLabel").pack(side="left")
        mode=tk.StringVar(value="all"); combo=ttk.Combobox(row,textvariable=mode,state="readonly",values=["all","latest_n","single_day","date_range","track_ids"],width=18); combo.pack(side="left")
        val=tk.StringVar(value="500"); ttk.Entry(row,textvariable=val,width=35).pack(side="left",padx=8)
        ttk.Label(row,text="latest: Zahl | day: YYYY-MM-DD | range: FROM,TO | IDs: kommasepariert",style="Card.TLabel").pack(side="left")
        return mode,val

    def _parse_scope(self,mode,val):
        m=mode.get(); text=val.get().strip()
        if m=="latest_n": return {"mode":m,"limit":max(1,int(text or 500))}
        if m=="single_day": return {"mode":m,"date":text}
        if m=="date_range":
            p=[x.strip() for x in text.split(",")]; return {"mode":m,"from":p[0] if p else "","to":p[1] if len(p)>1 else p[0] if p else ""}
        if m=="track_ids": return {"mode":m,"track_ids":[x.strip() for x in text.replace(";",",").split(",") if x.strip()]}
        return {"mode":"all"}

    def _analyses(self):
        tab=self.tabs["Analysen"]; card=self._card(tab,"Analysemodul"); card.pack(fill="x",padx=12,pady=12)
        self.analysis_access=tk.StringVar(value="Public API (ohne Login)")
        access_row=ttk.Frame(card,style="Card.TFrame"); access_row.pack(fill="x",pady=4)
        ttk.Label(access_row,text="Analysezugang",width=18,style="Card.TLabel").pack(side="left")
        ttk.Combobox(access_row,textvariable=self.analysis_access,state="readonly",values=["Public API (ohne Login)","User OAuth (/me)"],width=28).pack(side="left")
        profile_row=ttk.Frame(card,style="Card.TFrame"); profile_row.pack(fill="x",pady=4)
        ttk.Label(profile_row,text="SoundCloud-Profil",width=18,style="Card.TLabel").pack(side="left")
        self.public_profile_url=tk.StringVar(value=self.config_manager.config.public_profile_url)
        ttk.Entry(profile_row,textvariable=self.public_profile_url).pack(side="left",fill="x",expand=True)
        ttk.Label(profile_row,text="nur für Public API",style="Card.TLabel").pack(side="left",padx=8)
        self.analysis_mode=tk.StringVar(value="Vollständige Kontoanalyse")
        ttk.Combobox(card,textvariable=self.analysis_mode,state="readonly",values=["Likes / Favoriter","LYVRA Evidence","Vollständige Kontoanalyse"],width=40).pack(anchor="w",pady=4)
        self.scope_mode,self.scope_value=self._scope_controls(card)
        row=ttk.Frame(card,style="Card.TFrame"); row.pack(fill="x",pady=5); ttk.Label(row,text="Favoriter-Limit",width=18,style="Card.TLabel").pack(side="left"); self.fav_limit=tk.StringVar(value="0"); ttk.Combobox(row,textvariable=self.fav_limit,state="readonly",values=["0","50","100","250","ALL"],width=15).pack(side="left"); ttk.Label(row,text="0 = nicht abrufen; ALL = alle Tracks mit Likes",style="Card.TLabel").pack(side="left",padx=8)
        ttk.Button(card,text="Analyse als Hintergrundaufgabe starten",command=lambda:self._launch_analysis()).pack(anchor="w",pady=12)
        note=self._card(tab,"Ausgabe"); note.pack(fill="x",padx=12,pady=12); ttk.Label(note,text="Jeder Lauf erzeugt einen eigenen Ordner mit Originalformaten, Manifest, SHA-256 und Readback-Prüfung. Laufende Aufgaben blockieren die Oberfläche nicht.",style="Card.TLabel",wraplength=1000).pack(anchor="w")

    def _cleanup(self):
        tab=self.tabs["Cleanup"]; card=self._card(tab,"Track Cleanup Manager"); card.pack(fill="x",padx=12,pady=12)
        self.cleanup_scope_mode,self.cleanup_scope_value=self._scope_controls(card)
        self.cleanup_op=tk.StringVar(value="analyze"); row=ttk.Frame(card,style="Card.TFrame"); row.pack(fill="x",pady=5); ttk.Label(row,text="Aktion",width=18,style="Card.TLabel").pack(side="left"); ttk.Combobox(row,textvariable=self.cleanup_op,state="readonly",values=["analyze","duplicates","latest","all"],width=18).pack(side="left")
        self.cleanup_latest=tk.StringVar(value="50"); ttk.Label(row,text="Letzte N",style="Card.TLabel").pack(side="left",padx=(18,4)); ttk.Entry(row,textvariable=self.cleanup_latest,width=8).pack(side="left")
        ttk.Button(card,text="Cleanup starten",command=self._launch_cleanup).pack(anchor="w",pady=12)
        ttk.Label(card,text="Vor jeder Löschung werden TXT/JSON-Backups geschrieben. Löschungen erfordern zusätzlich die exakte Texteingabe DELETE <Anzahl>.",style="Card.TLabel",wraplength=1000).pack(anchor="w")

    def _tasks_tab(self):
        tab=self.tabs["Aufgaben"]; card=self._card(tab,"Laufende und abgeschlossene Aufgaben"); card.pack(fill="both",expand=True,padx=12,pady=12)
        cols=("name","status","progress","message"); self.tree=ttk.Treeview(card,columns=cols,show="headings");
        for c,w in [("name",250),("status",110),("progress",90),("message",520)]: self.tree.heading(c,text=c.title()); self.tree.column(c,width=w,anchor="w")
        self.tree.pack(fill="both",expand=True); self.tree.bind("<<TreeviewSelect>>",lambda e:self._select_task())
        ttk.Button(card,text="Ausgewählte Aufgabe abbrechen",style="Danger.TButton",command=self._cancel_task).pack(anchor="e",pady=8)

    def _system(self):
        tab=self.tabs["System"]; card=self._card(tab,"System / Audit / Freeze"); card.pack(fill="x",padx=12,pady=12)
        self.system_info=tk.Text(card,height=16,bg=PANEL,fg=FG,insertbackground=FG,relief="flat"); self.system_info.pack(fill="both",expand=True)
        self.system_info.insert("1.0",json.dumps({"app_version":APP_VERSION,"source_version":SOURCE_VERSION,"freeze_id":FREEZE_ID,"config":self.config_manager.config.__dict__,"secure_store":self.secure.backend},indent=2,ensure_ascii=False))
        buttons=ttk.Frame(card,style="Card.TFrame"); buttons.pack(fill="x",pady=8); ttk.Button(buttons,text="Selbst-Audit",command=self._self_audit).pack(side="left",padx=4); ttk.Button(buttons,text="Exportpfad ändern",command=self._change_export).pack(side="left",padx=4); ttk.Button(buttons,text="Logordner öffnen",command=self._open_logs).pack(side="left",padx=4)

    def _save_credentials(self):
        try: self.client.save_credentials(self.client_id.get(),self.client_secret.get(),self.redirect.get()); messagebox.showinfo("Gespeichert","Konfiguration wurde gespeichert.")
        except Exception as e: messagebox.showerror("Fehler",str(e))
    def _open_auth(self):
        try:
            self.client.save_credentials(self.client_id.get(),self.client_secret.get(),self.redirect.get())
            url=self.client.open_authorization()
            self.clipboard_clear(); self.clipboard_append(url)
            custom=is_custom_scheme(self.redirect.get())
            self.oauth_status.set("SoundCloud-Anmeldung im Standardbrowser geöffnet" + (" — Rückkehr erfolgt automatisch" if custom else " — Redirect-URL danach hier einfügen"))
            messagebox.showinfo("Anmeldung","SoundCloud wurde im Windows-Standardbrowser geöffnet.\n\nDer Anmelde-Link liegt zusätzlich in der Zwischenablage. Falls das Browserfenster weiß bleibt, öffne einen neuen Chrome-/Edge-Tab und füge den Link dort ein." + ("\n\nNach erfolgreicher Anmeldung kehrt SoundCloud automatisch zum Control Center zurück." if custom else "\n\nBei HTTPS-Redirects die vollständige Redirect-URL anschließend im Feld einfügen."))
        except Exception as e:
            self.oauth_status.set("OAuth-Start fehlgeschlagen")
            messagebox.showerror("Fehler",str(e))

    def _poll_oauth_callback(self):
        try:
            url=consume_callback_url()
            if url:
                self.redirect_result.set(url)
                self.oauth_status.set("OAuth-Callback empfangen — Token wird ausgetauscht")
                self.client.exchange_redirect_url(url)
                self.oauth_status.set("OAuth erfolgreich — Access- und Refresh-Token gespeichert")
                messagebox.showinfo("SoundCloud verbunden","OAuth erfolgreich. Access- und Refresh-Token wurden sicher gespeichert.")
        except Exception as e:
            self.oauth_status.set("OAuth-Callback fehlgeschlagen")
            messagebox.showerror("OAuth-Callback",str(e))
        finally:
            self.after(500, self._poll_oauth_callback)
    def _exchange(self):
        try: self.client.exchange_redirect_url(self.redirect_result.get()); messagebox.showinfo("Token gespeichert","Access- und Refresh-Token wurden gespeichert.")
        except Exception as e: messagebox.showerror("Fehler",str(e))
    def _refresh_token(self):
        self._submit("Token erneuern",lambda ctx:(ctx.update(20,"Token wird erneuert"),self.client.refresh_access_token(),{"message":"Token erneuert"})[-1])
    def _test_account(self):
        self._submit("Account testen",lambda ctx:(ctx.update(20,"Account wird geprüft"),self.client.fetch_account(ctx.cancel_event))[1])
    def _clear_tokens(self):
        if messagebox.askyesno("Alle Token-Daten löschen","Client-ID, Client-Secret und Tokens wirklich löschen?"): self.client.clear_all(); self.client_id.set(""); self.client_secret.set(""); messagebox.showinfo("Gelöscht","Token-Daten wurden entfernt.")
    def _limit(self):
        v=self.fav_limit.get(); return None if v=="ALL" else int(v)
    def _launch_analysis(self,forced=None):
        try: scope=self._parse_scope(self.scope_mode,self.scope_value); limit=self._limit(); mode=forced or self.analysis_mode.get()
        except Exception as e: messagebox.showerror("Eingabe",str(e)); return
        if self.analysis_access.get()=="Public API (ohne Login)":
            profile=self.public_profile_url.get().strip()
            if not profile:
                messagebox.showerror("Eingabe","Für die browserfreie Analyse fehlt die SoundCloud-Profil-URL."); return
            self.config_manager.config.public_profile_url=profile; self.config_manager.save()
            if mode in ("full","Vollständige Kontoanalyse"): self._submit("Public Vollanalyse",lambda ctx:self.public_analysis.full_profile_analysis(ctx,profile,scope,limit))
            elif mode=="Likes / Favoriter": self._submit("Public Likes / Favoriter",lambda ctx:self.public_analysis.likes_analysis(ctx,profile,scope,limit))
            else: self._submit("Public LYVRA Evidence",lambda ctx:self.public_analysis.evidence_analysis(ctx,profile,scope,limit))
            return
        if mode in ("full","Vollständige Kontoanalyse"): self._submit("Vollständige Kontoanalyse",lambda ctx:self.analysis.full_account_analysis(ctx,scope,limit))
        elif mode=="Likes / Favoriter": self._submit("Likes / Favoriter",lambda ctx:self.analysis.likes_analysis(ctx,scope,limit))
        else: self._submit("LYVRA Evidence",lambda ctx:self.analysis.evidence_analysis(ctx,scope,limit))
    def _launch_cleanup(self):
        try: scope=self._parse_scope(self.cleanup_scope_mode,self.cleanup_scope_value); op=self.cleanup_op.get(); count=int(self.cleanup_latest.get() or 0)
        except Exception as e: messagebox.showerror("Eingabe",str(e)); return
        task_id=self._submit("Cleanup-Analyse",lambda ctx:self.analysis.cleanup_analyze(ctx,scope,op,count,False))
        if op!="analyze":
            self.pending_cleanup[task_id]={"operation":op}
    def _prompt(self,title,text):
        d=tk.Toplevel(self); d.title(title); d.configure(bg=BG); d.transient(self); d.grab_set(); value=tk.StringVar(); ttk.Label(d,text=text,wraplength=500).pack(padx=18,pady=12); e=ttk.Entry(d,textvariable=value,width=50); e.pack(padx=18,pady=8); out={"v":""}; ttk.Button(d,text="Übernehmen",command=lambda:(out.update(v=value.get()),d.destroy())).pack(pady=12); self.wait_window(d); return out["v"]
    def _submit(self,name,func):
        tid=self.tasks.submit(name,func); self.notebook.select(self.tabs["Aufgaben"]); self.status_text.set(f"Gestartet: {name}"); return tid
    def _poll_updates(self):
        try:
            while True:
                u=self.tasks.updates.get_nowait(); self._apply_update(u)
        except Exception: pass
        self.after(150,self._poll_updates)
    def _apply_update(self,u:TaskUpdate):
        vals=(u.name,u.status,f"{u.progress:.0f}%",u.message)
        if u.task_id in self.task_rows: self.tree.item(u.task_id,values=vals)
        else: self.tree.insert("",0,iid=u.task_id,values=vals); self.task_rows[u.task_id]=True
        self.overall["value"]=u.progress; self.status_text.set(f"{u.name}: {u.message}")
        if u.status=="COMPLETED":
            api_pending=self.pending_api.pop(u.task_id,None)
            if api_pending:
                kind=api_pending.get("kind")
                if kind=="search" and isinstance(u.result,tuple) and len(u.result)==2:
                    rows,next_href=u.result
                    self._render_api_results(rows,next_href,bool(api_pending.get("append")))
                    return
                if kind=="diagnostic" and isinstance(u.result,dict):
                    self.public_api_status.set("PASS — Public API erreichbar, Token gültig")
                    messagebox.showinfo("Public API Diagnose",json.dumps(u.result,indent=2,ensure_ascii=False))
                    return
                if kind=="token":
                    self.public_api_status.set("PASS — Public Token aktualisiert")
                    messagebox.showinfo("Public API","Public Token wurde aktualisiert und sicher gespeichert.")
                    return
            pending=self.pending_cleanup.pop(u.task_id,None)
            if pending and isinstance(u.result,dict):
                count=int(u.result.get("candidates",0)); folder=str(u.result.get("folder","") or "")
                if count>0:
                    expected=f"DELETE {count}"
                    answer=self._prompt("Endgültige Löschung bestätigen",f"Backup und Analyse sind abgeschlossen. Tippe exakt {expected}, um {count} Tracks endgültig zu löschen.")
                    if answer==expected:
                        self._submit("Cleanup-Löschung",lambda ctx:self.analysis.cleanup_delete_from_backup(ctx,folder,count))
                    else:
                        messagebox.showinfo("Löschung abgebrochen","Backup bleibt erhalten; es wurde nichts gelöscht.")
                else:
                    messagebox.showinfo("Cleanup abgeschlossen","Keine Tracks betroffen; es wurde nichts gelöscht.")
            else:
                msg=json.dumps(u.result,indent=2,ensure_ascii=False,default=str) if isinstance(u.result,(dict,list)) else str(u.result); messagebox.showinfo(f"{u.name} abgeschlossen",msg[:4000])
        elif u.status in ("FAILED","CANCELLED"):
            api_pending=self.pending_api.pop(u.task_id,None)
            if api_pending:
                if api_pending.get("kind")=="search": self.api_search_status.set(f"{u.status}: {u.message}")
                else: self.public_api_status.set(f"{u.status}: {u.message}")
            messagebox.showerror(f"{u.name}: {u.status}",u.message)
    def _select_task(self):
        sel=self.tree.selection(); self.last_selected_task=sel[0] if sel else ""
    def _cancel_task(self):
        if self.last_selected_task and self.tasks.cancel(self.last_selected_task): messagebox.showinfo("Abbruch","Abbruchsignal wurde gesetzt. Die Aufgabe stoppt am nächsten sicheren Checkpoint.")
    def _open_path(self,path):
        path=Path(path); path.mkdir(parents=True,exist_ok=True)
        if os.name=="nt": os.startfile(path)  # type: ignore
        else: messagebox.showinfo("Pfad",str(path))
    def _open_exports(self): self._open_path(self.config_manager.export_root)
    def _open_logs(self): from app.core.paths import ensure_runtime_dirs; self._open_path(ensure_runtime_dirs()["logs"])
    def _change_export(self):
        p=filedialog.askdirectory(initialdir=str(self.config_manager.export_root));
        if p: self.config_manager.config.export_directory=p; self.config_manager.save(); messagebox.showinfo("Gespeichert",p)
    def _self_audit(self):
        result=run_installation_audit(project_root()); self.system_info.delete("1.0","end"); self.system_info.insert("1.0",json.dumps(result,indent=2,ensure_ascii=False)); messagebox.showinfo("Selbst-Audit",result["status"])
