from __future__ import annotations
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from .paths import ensure_runtime_dirs


@dataclass
class AppConfig:
    redirect_uri: str = "sccpc://soundcloud/callback"
    soundcloud_app_name: str = "666SOUNDCLOUD ANALYTICS"
    soundcloud_app_description: str = "666SOUNDsDESIGn - 666SOUNDCLOUD ANALYTICS"
    soundcloud_app_website: str = "https://666soundsdesign.neocities.org/"
    public_profile_url: str = ""
    export_directory: str = ""
    page_limit: int = 200
    request_delay_seconds: float = 0.6
    favoriter_delay_seconds: float = 0.8
    delete_delay_seconds: float = 1.2
    timeout_seconds: int = 120
    checkpoint_every: int = 25
    max_parallel_tasks: int = 3
    auto_refresh_token: bool = True
    theme: str = "dark"


class ConfigManager:
    def __init__(self) -> None:
        dirs = ensure_runtime_dirs()
        self.path = dirs["config"] / "config.json"
        self.config = self.load()

    def load(self) -> AppConfig:
        if not self.path.exists():
            cfg = AppConfig(export_directory=str(ensure_runtime_dirs()["exports"]))
            self.save(cfg)
            return cfg
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            allowed = {field.name for field in AppConfig.__dataclass_fields__.values()}
            values = {k: v for k, v in raw.items() if k in allowed}
            cfg = AppConfig(**values)
            if cfg.redirect_uri.strip().lower() == "https://example.com/callback":
                cfg.redirect_uri = "sccpc://soundcloud/callback"
                self.save(cfg)
            if not cfg.export_directory:
                cfg.export_directory = str(ensure_runtime_dirs()["exports"])
            return cfg
        except Exception:
            cfg = AppConfig(export_directory=str(ensure_runtime_dirs()["exports"]))
            self.save(cfg)
            return cfg

    def save(self, config: AppConfig | None = None) -> None:
        if config is not None:
            self.config = config
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(self.config), indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    @property
    def export_root(self) -> Path:
        path = Path(self.config.export_directory).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        return path
