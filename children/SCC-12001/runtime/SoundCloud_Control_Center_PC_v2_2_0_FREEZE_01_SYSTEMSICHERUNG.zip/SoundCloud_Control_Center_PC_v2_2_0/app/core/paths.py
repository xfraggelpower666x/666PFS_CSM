from __future__ import annotations
import os
from pathlib import Path

APP_DIR_NAME = "SoundCloudControlCenter"
VENDOR_DIR_NAME = "666SOUNDsDESIGN"


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def user_data_root() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    path = base / VENDOR_DIR_NAME / APP_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def user_cache_root() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    path = base / VENDOR_DIR_NAME / APP_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def default_export_root() -> Path:
    docs = Path.home() / "Documents"
    if not docs.exists():
        docs = Path.home()
    path = docs / "SoundCloud_Control_Center_Exports"
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_runtime_dirs() -> dict[str, Path]:
    root = user_data_root()
    paths = {
        "config": root / "config",
        "logs": root / "logs",
        "checkpoints": root / "checkpoints",
        "backups": root / "backups",
        "history": root / "history",
        "cache": user_cache_root(),
        "exports": default_export_root(),
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths
