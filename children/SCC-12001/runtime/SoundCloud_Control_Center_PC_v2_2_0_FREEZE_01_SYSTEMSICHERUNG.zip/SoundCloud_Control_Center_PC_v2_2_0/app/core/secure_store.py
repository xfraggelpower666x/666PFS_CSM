from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Optional
from .paths import ensure_runtime_dirs

SERVICE = "666SOUNDsDESIGN.SoundCloudControlCenter"


class SecureStore:
    """Windows uses Credential Manager through keyring. A restricted local fallback is only used if no backend exists."""
    def __init__(self) -> None:
        self._fallback = ensure_runtime_dirs()["config"] / "credential_fallback.json"
        self.backend = "keyring"
        try:
            import keyring  # type: ignore
            self._keyring = keyring
            # Some Linux environments expose a fail backend. Test only backend priority/name, never write here.
            name = type(keyring.get_keyring()).__name__.lower()
            if "fail" in name:
                raise RuntimeError("No keyring backend")
        except Exception:
            self._keyring = None
            self.backend = "restricted_local_fallback"

    def get(self, key: str) -> str:
        if self._keyring is not None:
            try:
                return self._keyring.get_password(SERVICE, key) or ""
            except Exception:
                pass
        return self._read_fallback().get(key, "")

    def set(self, key: str, value: str) -> None:
        if self._keyring is not None:
            try:
                self._keyring.set_password(SERVICE, key, str(value))
                return
            except Exception:
                pass
        data = self._read_fallback()
        data[key] = str(value)
        self._write_fallback(data)

    def delete(self, key: str) -> None:
        if self._keyring is not None:
            try:
                self._keyring.delete_password(SERVICE, key)
            except Exception:
                pass
        data = self._read_fallback()
        if key in data:
            del data[key]
            self._write_fallback(data)

    def clear(self, keys: list[str]) -> None:
        for key in keys:
            self.delete(key)

    def _read_fallback(self) -> dict[str, str]:
        try:
            return json.loads(self._fallback.read_text(encoding="utf-8")) if self._fallback.exists() else {}
        except Exception:
            return {}

    def _write_fallback(self, data: dict[str, str]) -> None:
        self._fallback.parent.mkdir(parents=True, exist_ok=True)
        self._fallback.write_text(json.dumps(data, indent=2), encoding="utf-8")
        try:
            os.chmod(self._fallback, 0o600)
        except OSError:
            pass
