from __future__ import annotations

import time
import urllib.parse
from typing import Any

import requests

TOKEN_URL = "https://secure.soundcloud.com/oauth/token"
API_BASE = "https://api.soundcloud.com"
PUBLIC_TOKEN_KEYS = ["public_access_token", "public_refresh_token", "public_expires_at"]


class SoundCloudPublicApiError(RuntimeError):
    def __init__(self, message: str, status: int = 0, response_text: str = "") -> None:
        super().__init__(message)
        self.status = status
        self.response_text = response_text


def _error_for_response(response: requests.Response, operation: str) -> SoundCloudPublicApiError:
    status = int(response.status_code)
    if status == 401:
        message = f"{operation}: HTTP 401 — Token oder App-Credentials wurden von SoundCloud abgelehnt."
    elif status == 429:
        message = f"{operation}: HTTP 429 — SoundCloud Rate Limit erreicht. Bitte später erneut versuchen."
    else:
        message = f"{operation}: HTTP {status} — SoundCloud-Anfrage fehlgeschlagen."
    return SoundCloudPublicApiError(message, status, (response.text or "")[:4000])


def _request_with_backoff(
    session: requests.Session | Any,
    method: str,
    url: str,
    *,
    operation: str,
    max_attempts: int = 3,
    **kwargs: Any,
) -> requests.Response:
    """Perform a SoundCloud request with bounded exponential backoff for HTTP 429/503.

    This helper never retries indefinitely. Retry-After is honored when present;
    otherwise the delay grows exponentially. Authentication errors are surfaced
    immediately so the caller can decide whether a token refresh is appropriate.
    """
    response: requests.Response | None = None
    for attempt in range(1, max(1, int(max_attempts)) + 1):
        response = session.request(method.upper(), url, **kwargs)
        if response.ok:
            return response
        if response.status_code not in (429, 503) or attempt >= max_attempts:
            raise _error_for_response(response, operation)
        retry_after = (response.headers or {}).get("Retry-After", "")
        try:
            wait = float(retry_after)
        except (TypeError, ValueError):
            wait = float(2 ** (attempt - 1))
        time.sleep(max(1.0, min(wait, 30.0)))
    assert response is not None
    raise _error_for_response(response, operation)


def search_tracks(query: str, access_token: str, limit: int = 20) -> tuple[list[dict[str, Any]], str | None]:
    """Search SoundCloud tracks using the published OpenAPI contract.

    Endpoint: GET https://api.soundcloud.com/tracks
    Auth: Authorization: OAuth <access_token>
    Pagination: linked_partitioning=true -> (collection, next_href)

    The function accepts an already-issued token and never embeds a client secret.
    """
    q = (query or "").strip()
    if not q:
        raise ValueError("Suchbegriff fehlt.")
    try:
        normalized_limit = int(limit)
    except (TypeError, ValueError) as exc:
        raise ValueError("Limit muss eine Zahl zwischen 1 und 200 sein.") from exc
    if normalized_limit < 1 or normalized_limit > 200:
        raise ValueError("Limit muss zwischen 1 und 200 liegen.")
    token = (access_token or "").strip()
    if not token:
        raise ValueError("Access-Token fehlt.")

    session = requests.Session()
    response = _request_with_backoff(
        session,
        "GET",
        f"{API_BASE}/tracks",
        operation="Track-Suche",
        params={"q": q, "limit": normalized_limit, "linked_partitioning": "true"},
        headers={
            "Accept": "application/json; charset=utf-8",
            "Authorization": f"OAuth {token}",
        },
        timeout=60,
    )
    try:
        data = response.json()
    except ValueError as exc:
        raise SoundCloudPublicApiError(
            "Track-Suche: SoundCloud lieferte kein gültiges JSON.",
            response.status_code,
            response.text,
        ) from exc

    if isinstance(data, dict):
        collection = data.get("collection")
        if not isinstance(collection, list):
            raise SoundCloudPublicApiError("Track-Suche: Unerwartetes Pagination-Format von SoundCloud.")
        results = [item for item in collection if isinstance(item, dict)]
        next_href = str(data.get("next_href") or "").strip() or None
        return results, next_href
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)], None
    raise SoundCloudPublicApiError("Track-Suche: Unerwartetes Antwortformat von SoundCloud.")


class PublicApiClient:
    """Public-resource client using cached Client Credentials tokens.

    Public tokens are kept separate from user-delegated OAuth tokens so a public
    search can never replace the account token used by /me and destructive tools.
    """

    def __init__(self, soundcloud_client, config_manager, secure_store, logger=None) -> None:
        self.soundcloud_client = soundcloud_client
        self.config_manager = config_manager
        self.secure = secure_store
        self.logger = logger
        self.session = requests.Session()

    def _credentials(self) -> tuple[str, str]:
        credentials = self.soundcloud_client.credentials()
        client_id = str(credentials.get("client_id") or "").strip()
        client_secret = str(credentials.get("client_secret") or "").strip()
        if not client_id or not client_secret:
            raise RuntimeError("Client-ID und Client-Secret müssen zuerst im Token Manager gespeichert werden.")
        return client_id, client_secret

    @staticmethod
    def _sleep_for_attempt(attempt: int, response: requests.Response) -> None:
        retry_after = (response.headers or {}).get("Retry-After", "")
        try:
            wait = float(retry_after)
        except (TypeError, ValueError):
            wait = min(2 ** max(attempt - 1, 0), 8)
        time.sleep(max(1.0, min(wait, 30.0)))

    def _token_request(self, *, grant_type: str, refresh_token: str = "") -> dict[str, Any]:
        client_id, client_secret = self._credentials()
        for attempt in range(1, 4):
            if grant_type == "client_credentials":
                response = self.session.post(
                    TOKEN_URL,
                    data={"grant_type": "client_credentials"},
                    auth=(client_id, client_secret),
                    headers={"Accept": "application/json; charset=utf-8"},
                    timeout=self.config_manager.config.timeout_seconds,
                )
            elif grant_type == "refresh_token":
                response = self.session.post(
                    TOKEN_URL,
                    data={
                        "grant_type": "refresh_token",
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "refresh_token": refresh_token,
                    },
                    headers={"Accept": "application/json; charset=utf-8"},
                    timeout=self.config_manager.config.timeout_seconds,
                )
            else:
                raise ValueError("Nicht unterstützter Token-Grant.")

            if response.ok:
                try:
                    data = response.json()
                except ValueError as exc:
                    raise SoundCloudPublicApiError("Public-Token: SoundCloud lieferte kein gültiges JSON.", response.status_code, response.text) from exc
                if not isinstance(data, dict) or not data.get("access_token"):
                    raise SoundCloudPublicApiError("Public-Token: Access-Token fehlt in der SoundCloud-Antwort.")
                return data
            if response.status_code == 429 and attempt < 3:
                self._sleep_for_attempt(attempt, response)
                continue
            raise _error_for_response(response, "Public-Token")
        raise SoundCloudPublicApiError("Public-Token: maximale Wiederholungszahl erreicht.")

    def _save_token(self, data: dict[str, Any]) -> str:
        token = str(data.get("access_token") or "").strip()
        if not token:
            raise SoundCloudPublicApiError("Public-Token: Access-Token fehlt.")
        self.secure.set("public_access_token", token)
        if data.get("refresh_token"):
            # Refresh tokens are single-use. Always replace the old one atomically
            # from the application's point of view as soon as SoundCloud returns it.
            self.secure.set("public_refresh_token", str(data["refresh_token"]))
        if data.get("expires_in"):
            self.secure.set("public_expires_at", str(int(time.time()) + int(data["expires_in"])))
        return token

    def obtain_client_credentials_token(self, force_new: bool = False) -> str:
        if not force_new:
            cached = self.secure.get("public_access_token")
            expires = self.secure.get("public_expires_at")
            if cached and expires:
                try:
                    if int(expires) > int(time.time()) + 120:
                        return cached
                except ValueError:
                    pass
            refresh = self.secure.get("public_refresh_token")
            if refresh:
                return self.refresh_public_token(refresh)
        return self._save_token(self._token_request(grant_type="client_credentials"))

    def refresh_public_token(self, refresh_token: str | None = None) -> str:
        refresh = (refresh_token or self.secure.get("public_refresh_token") or "").strip()
        if not refresh:
            raise RuntimeError("Kein Public-Refresh-Token gespeichert.")
        # Exactly one refresh exchange. No recursive retry / no fallback loop.
        return self._save_token(self._token_request(grant_type="refresh_token", refresh_token=refresh))

    def renew_public_token(self) -> str:
        """Refresh when possible; only create a new client-credentials token if none exists."""
        refresh = (self.secure.get("public_refresh_token") or "").strip()
        if refresh:
            return self.refresh_public_token(refresh)
        return self.obtain_client_credentials_token(force_new=True)

    def access_token(self) -> str:
        return self.obtain_client_credentials_token(force_new=False)

    def clear_public_tokens(self) -> None:
        self.secure.clear(PUBLIC_TOKEN_KEYS)

    def search_tracks(self, query: str, limit: int = 20) -> tuple[list[dict[str, Any]], str | None]:
        return search_tracks(query, self.access_token(), limit)

    def fetch_next_page(self, next_href: str) -> tuple[list[dict[str, Any]], str | None]:
        url = (next_href or "").strip()
        if not url:
            raise ValueError("Keine nächste Seite vorhanden.")
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != "api.soundcloud.com":
            raise ValueError("next_href verweist nicht auf https://api.soundcloud.com.")
        response = _request_with_backoff(
            self.session,
            "GET",
            url,
            operation="Nächste Suchseite",
            headers={
                "Accept": "application/json; charset=utf-8",
                "Authorization": f"OAuth {self.access_token()}",
            },
            timeout=self.config_manager.config.timeout_seconds,
        )
        try:
            data = response.json()
        except ValueError as exc:
            raise SoundCloudPublicApiError("Nächste Suchseite: ungültiges JSON.", response.status_code, response.text) from exc
        if not isinstance(data, dict) or not isinstance(data.get("collection"), list):
            raise SoundCloudPublicApiError("Nächste Suchseite: unerwartetes Pagination-Format.")
        return [item for item in data["collection"] if isinstance(item, dict)], str(data.get("next_href") or "").strip() or None

    def diagnostic(self) -> dict[str, Any]:
        token = self.access_token()
        # A single-item documented /tracks search validates API base URL, OAuth
        # header and token without touching user resources.
        results, next_href = search_tracks("soundcloud", token, 1)
        return {
            "status": "PASS",
            "mode": "CLIENT_CREDENTIALS_PUBLIC",
            "api_base": API_BASE,
            "token_host": "https://secure.soundcloud.com",
            "authorization_header": "OAuth <masked>",
            "sample_results": len(results),
            "next_href_present": bool(next_href),
            "user_resource_access": False,
            "credentials_logged": False,
        }

    def _authorized_get_json(self, url: str, *, operation: str, params: dict[str, Any] | None = None) -> Any:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https" or parsed.hostname != "api.soundcloud.com":
            raise ValueError(f"{operation}: Zielhost ist nicht api.soundcloud.com.")
        token = self.access_token()
        try:
            response = _request_with_backoff(
                self.session, "GET", url, operation=operation, params=params,
                headers={"Accept": "application/json; charset=utf-8", "Authorization": f"OAuth {token}"},
                timeout=self.config_manager.config.timeout_seconds,
            )
        except SoundCloudPublicApiError as exc:
            if exc.status != 401:
                raise
            # Einmalige Recovery: Token erneuern, niemals rekursiv/endlos.
            token = self.renew_public_token()
            response = _request_with_backoff(
                self.session, "GET", url, operation=operation, params=params,
                headers={"Accept": "application/json; charset=utf-8", "Authorization": f"OAuth {token}"},
                timeout=self.config_manager.config.timeout_seconds,
            )
        try:
            return response.json()
        except ValueError as exc:
            raise SoundCloudPublicApiError(f"{operation}: SoundCloud lieferte kein gültiges JSON.", response.status_code, response.text) from exc

    def resolve_profile(self, profile_url: str) -> dict[str, Any]:
        url = (profile_url or "").strip()
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https" or parsed.hostname not in {"soundcloud.com", "www.soundcloud.com", "on.soundcloud.com"}:
            raise ValueError("Bitte eine vollständige SoundCloud-Profil-URL eingeben (https://soundcloud.com/...).")
        token = self.access_token()
        response = self.session.get(
            f"{API_BASE}/resolve",
            params={"url": url},
            headers={"Accept": "application/json; charset=utf-8", "Authorization": f"OAuth {token}"},
            timeout=self.config_manager.config.timeout_seconds,
            allow_redirects=False,
        )
        if response.status_code == 401:
            token = self.renew_public_token()
            response = self.session.get(
                f"{API_BASE}/resolve", params={"url": url},
                headers={"Accept": "application/json; charset=utf-8", "Authorization": f"OAuth {token}"},
                timeout=self.config_manager.config.timeout_seconds, allow_redirects=False,
            )
        if response.status_code in (301, 302, 303, 307, 308):
            location = (response.headers or {}).get("Location", "")
            lp = urllib.parse.urlparse(location)
            if lp.scheme != "https" or lp.hostname != "api.soundcloud.com":
                raise SoundCloudPublicApiError("Profil-Auflösung: SoundCloud lieferte einen unerwarteten Redirect.", response.status_code, location)
            data = self._authorized_get_json(location, operation="Profil laden")
        elif response.ok:
            try:
                data = response.json()
            except ValueError as exc:
                raise SoundCloudPublicApiError("Profil-Auflösung: ungültiges JSON.", response.status_code, response.text) from exc
        else:
            raise _error_for_response(response, "Profil-Auflösung")
        if not isinstance(data, dict) or not data.get("urn"):
            raise SoundCloudPublicApiError("Profil-Auflösung: Die URL wurde nicht als SoundCloud-Benutzerprofil erkannt.")
        return data

    def fetch_paginated_public(self, url: str, *, operation: str, progress=None, cancel_event=None) -> list[dict[str, Any]]:
        next_url = url
        rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        page = 0
        while next_url:
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError("Vorgang abgebrochen.")
            if next_url in seen:
                raise RuntimeError("Pagination-Schleife erkannt; next_href wiederholt sich.")
            seen.add(next_url)
            data = self._authorized_get_json(next_url, operation=operation)
            page += 1
            if isinstance(data, list):
                rows.extend(x for x in data if isinstance(x, dict)); next_url = ""
            elif isinstance(data, dict) and isinstance(data.get("collection"), list):
                rows.extend(x for x in data["collection"] if isinstance(x, dict))
                next_url = str(data.get("next_href") or "").strip()
                if next_url:
                    np = urllib.parse.urlparse(next_url)
                    if np.scheme != "https" or np.hostname != "api.soundcloud.com":
                        raise RuntimeError("Pagination wurde wegen fremdem next_href-Host blockiert.")
            else:
                raise RuntimeError(f"{operation}: unbekanntes Pagination-Format.")
            if progress:
                progress(page, len(rows))
            if next_url:
                time.sleep(self.config_manager.config.request_delay_seconds)
        return rows

    def fetch_user_tracks(self, user_urn: str, progress=None, cancel_event=None) -> list[dict[str, Any]]:
        urn = urllib.parse.quote(str(user_urn), safe=':')
        url = f"{API_BASE}/users/{urn}/tracks?limit={self.config_manager.config.page_limit}&linked_partitioning=true"
        return self.fetch_paginated_public(url, operation="Öffentliche Profil-Tracks", progress=progress, cancel_event=cancel_event)

    def fetch_track_favoriters(self, track: dict[str, Any], cancel_event=None) -> list[dict[str, Any]]:
        identifier = track.get("urn") or track.get("id")
        if identifier in (None, ""):
            raise ValueError("Track besitzt weder URN noch ID.")
        ref = urllib.parse.quote(str(identifier), safe=':')
        url = f"{API_BASE}/tracks/{ref}/favoriters?limit={self.config_manager.config.page_limit}&linked_partitioning=true"
        return self.fetch_paginated_public(url, operation="Track-Favoriter", cancel_event=cancel_event)
