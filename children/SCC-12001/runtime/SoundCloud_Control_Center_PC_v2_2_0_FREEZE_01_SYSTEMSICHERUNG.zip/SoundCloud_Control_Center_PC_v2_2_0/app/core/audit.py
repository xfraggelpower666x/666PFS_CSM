from __future__ import annotations
import json
import platform
import sys
from datetime import datetime
from pathlib import Path
from typing import Any
from .utils import atomic_write_json, sha256_file


def run_installation_audit(project_root: Path) -> dict[str, Any]:
    required = ["START.bat", "SoundCloud_Control_Center.exe", "requirements.txt", "app/main.py",
                "source_original/SoundCloud_Control_Center_v1_3_0_Full_Account_Correction.js"]
    checks=[]
    for rel in required:
        path=project_root/rel
        checks.append({"check":rel,"status":"PASS" if path.exists() else "FAIL","bytes":path.stat().st_size if path.exists() else 0})
    py_files=list((project_root/"app").rglob("*.py"))
    compile_errors=[]
    for path in py_files:
        try: compile(path.read_text(encoding="utf-8"),str(path),"exec")
        except Exception as exc: compile_errors.append({"file":str(path.relative_to(project_root)),"error":str(exc)})
    result={"audit_type":"INSTALLATION_SELF_AUDIT","generated_at":datetime.now().isoformat(),"python":sys.version,"platform":platform.platform(),"checks":checks,"python_files":len(py_files),"compile_errors":compile_errors,"status":"PASS" if all(c["status"]=="PASS" for c in checks) and not compile_errors else "FAIL"}
    return result
