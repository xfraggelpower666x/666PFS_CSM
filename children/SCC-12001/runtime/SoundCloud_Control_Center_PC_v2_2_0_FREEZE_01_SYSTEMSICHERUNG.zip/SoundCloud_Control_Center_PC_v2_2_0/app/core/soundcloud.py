from __future__ import annotations
import base64
import hashlib
import secrets
import time
import urllib.parse
import os
import webbrowser
from typing import Any, Callable
from .config import ConfigManager
from .http_client import HttpClient
from .secure_store import SecureStore
from .desktop_oauth import register_windows_protocol, validate_redirect_uri

AUTH_URL = "https://secure.soundcloud.com/authorize"
TOKEN_URL = "https://secure.soundcloud.com/oauth/token"
API_BASE = "https://api.soundcloud.com"
KEYS = ["client_id", "client_secret", "access_token", "refresh_token", "expires_at", "pkce_verifier", "oauth_state"]


class SoundCloudClient:
    def __init__(self, config_manager: ConfigManager, secure_store: SecureStore, logger=None):
        self.config_manager = config_manager
        self.secure = secure_store
        self.logger = logger
        self.http = HttpClient(config_manager.config.timeout_seconds, self._refresh_for_http, logger)

    def credentials(self) -> dict[str, str]:
        return {
            "client_id": self.secure.get("client_id"),
            "client_secret": self.secure.get("client_secret"),
            "redirect_uri": self.config_manager.config.redirect_uri,
        }

    def save_credentials(self, client_id: str, client_secret: str, redirect_uri: str) -> None:
        self.secure.set("client_id", client_id.strip())
        self.secure.set("client_secret", client_secret.strip())
        self.config_manager.config.redirect_uri = redirect_uri.strip()
        self.config_manager.save()

    def create_authorization_url(self) -> str:
        cfg = self.credentials()
        if not cfg["client_id"] or not cfg["client_secret"] or not cfg["redirect_uri"]:
            raise ValueError("Client-ID, Client-Secret und Redirect-URI müssen gespeichert sein.")
        verifier = secrets.token_urlsafe(72)[:96]
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = secrets.token_urlsafe(40)
        self.secure.set("pkce_verifier", verifier)
        self.secure.set("oauth_state", state)
        validate_redirect_uri(cfg["redirect_uri"])
        query = urllib.parse.urlencode({
            "client_id": cfg["client_id"], "redirect_uri": cfg["redirect_uri"], "response_type": "code",
            "code_challenge": challenge, "code_challenge_method": "S256", "state": state
        })
        return f"{AUTH_URL}?{query}"

    def open_authorization(self) -> str:
        cfg = self.credentials()
        register_windows_protocol(cfg["redirect_uri"])
        url = self.create_authorization_url()
        opened = False
        if os.name == "nt":
            try:
                os.startfile(url)  # type: ignore[attr-defined]
                opened = True
            except OSError:
                opened = False
        if not opened:
            opened = bool(webbrowser.open(url, new=2))
        if not opened:
            raise RuntimeError("Der Standardbrowser konnte nicht geöffnet werden. Der Anmelde-Link wurde erzeugt und kann aus der Zwischenablage geöffnet werden.")
        return url

    def exchange_redirect_url(self, redirect_url: str) -> dict[str, Any]:
        cfg = self.credentials()
        parsed = urllib.parse.urlparse(redirect_url.strip())
        params = urllib.parse.parse_qs(parsed.query)
        if params.get("error"):
            message = params["error"][0]
            description = (params.get("error_description") or [""])[0]
            raise RuntimeError("OAuth-Fehler: " + message + ((" — " + description) if description else ""))
        code = (params.get("code") or [""])[0]
        state = (params.get("state") or [""])[0]
        if not code:
            raise ValueError("Die Redirect-URL enthält keinen Authorization Code.")
        if not state or state != self.secure.get("oauth_state"):
            raise ValueError("OAuth-State stimmt nicht überein.")
        response = self.http.request("POST", TOKEN_URL, form={
            "grant_type": "authorization_code", "client_id": cfg["client_id"], "client_secret": cfg["client_secret"],
            "redirect_uri": cfg["redirect_uri"], "code_verifier": self.secure.get("pkce_verifier"), "code": code
        }, allow_refresh=False)
        if not isinstance(response.data, dict):
            raise RuntimeError("Ungültige Token-Antwort.")
        self._save_token_response(response.data)
        self.secure.delete("pkce_verifier")
        self.secure.delete("oauth_state")
        return response.data

    def refresh_access_token(self) -> str:
        cfg = self.credentials()
        refresh = self.secure.get("refresh_token")
        if not refresh:
            raise RuntimeError("Kein Refresh-Token gespeichert.")
        response = self.http.request("POST", TOKEN_URL, form={
            "grant_type": "refresh_token", "client_id": cfg["client_id"], "client_secret": cfg["client_secret"], "refresh_token": refresh
        }, allow_refresh=False)
        if not isinstance(response.data, dict):
            raise RuntimeError("Ungültige Token-Antwort.")
        self._save_token_response(response.data)
        return self.secure.get("access_token")

    def _refresh_for_http(self) -> str:
        if not self.config_manager.config.auto_refresh_token:
            raise RuntimeError("Access-Token abgelaufen; automatische Erneuerung ist deaktiviert.")
        return self.refresh_access_token()

    def _save_token_response(self, data: dict[str, Any]) -> None:
        token = str(data.get("access_token") or "")
        if not token:
            raise RuntimeError("SoundCloud hat keinen Access-Token geliefert.")
        self.secure.set("access_token", token)
        if data.get("refresh_token"):
            self.secure.set("refresh_token", str(data["refresh_token"]))
        if data.get("expires_in"):
            self.secure.set("expires_at", str(int(time.time()) + int(data["expires_in"])))

    def access_token(self) -> str:
        token = self.secure.get("access_token")
        if not token:
            raise RuntimeError("Kein SoundCloud Access-Token gespeichert.")
        expires = self.secure.get("expires_at")
        if expires and self.config_manager.config.auto_refresh_token:
            try:
                if int(expires) <= int(time.time()) + 120:
                    token = self.refresh_access_token()
            except ValueError:
                pass
        return token

    def clear_all(self) -> None:
        self.secure.clear(KEYS)

    def api(self, method: str, path_or_url: str, cancel_event=None) -> Any:
        url = path_or_url if str(path_or_url).startswith("http") else API_BASE + str(path_or_url)
        return self.http.request(method, url, token=self.access_token(), cancel_event=cancel_event).data

    def fetch_account(self, cancel_event=None) -> dict[str, Any]:
        data = self.api("GET", "/me", cancel_event)
        if not isinstance(data, dict):
            raise RuntimeError("Ungültige Account-Antwort.")
        return data

    def fetch_paginated(self, initial_url: str, progress: Callable[[int, int], None] | None = None, cancel_event=None) -> list[dict[str, Any]]:
        next_url = initial_url
        rows: list[dict[str, Any]] = []
        page = 0
        seen_urls: set[str] = set()
        while next_url:
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError("Vorgang abgebrochen.")
            if next_url in seen_urls:
                raise RuntimeError("Pagination-Schleife erkannt; next_href wiederholt sich.")
            seen_urls.add(next_url)
            page += 1
            data = self.api("GET", next_url, cancel_event)
            if isinstance(data, list):
                rows.extend(x for x in data if isinstance(x, dict))
                next_url = ""
            elif isinstance(data, dict) and isinstance(data.get("collection"), list):
                rows.extend(x for x in data["collection"] if isinstance(x, dict))
                next_url = str(data.get("next_href") or "")
            else:
                raise RuntimeError("Unbekanntes Pagination-Format.")
            if progress:
                progress(page, len(rows))
            if next_url:
                time.sleep(self.config_manager.config.request_delay_seconds)
        return rows

    def fetch_all_tracks(self, progress=None, cancel_event=None) -> list[dict[str, Any]]:
        url = f"{API_BASE}/me/tracks?limit={self.config_manager.config.page_limit}&linked_partitioning=true"
        return self.fetch_paginated(url, progress, cancel_event)

    def fetch_favoriters(self, track: dict[str, Any], cancel_event=None) -> list[dict[str, Any]]:
        identifiers = [track.get("id")]
        if track.get("urn"):
            identifiers.append(track.get("urn"))
        last: Exception | None = None
        for identifier in identifiers:
            if identifier in (None, ""):
                continue
            try:
                url = f"{API_BASE}/tracks/{urllib.parse.quote(str(identifier), safe='')}/favoriters?limit={self.config_manager.config.page_limit}&linked_partitioning=true"
                return self.fetch_paginated(url, cancel_event=cancel_event)
            except Exception as exc:
                last = exc
        raise RuntimeError(str(last or "Favoriter konnten nicht geladen werden."))

    def delete_track(self, track_id: Any, cancel_event=None) -> None:
        self.api("DELETE", f"/tracks/{urllib.parse.quote(str(track_id), safe='')}", cancel_event)
