from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .paths import ensure_runtime_dirs
from .utils import atomic_write_json, sanitize_filename


class CheckpointStore:
    def __init__(self) -> None:
        self.root = ensure_runtime_dirs()["checkpoints"]

    def path_for(self, key: str) -> Path:
        return self.root / f"{sanitize_filename(key)}.json"

    def load(self, key: str) -> dict[str, Any] | None:
        path = self.path_for(key)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def save(self, key: str, payload: dict[str, Any]) -> Path:
        path = self.path_for(key)
        atomic_write_json(path, payload)
        return path

    def clear(self, key: str) -> None:
        path = self.path_for(key)
        if path.exists():
            path.unlink()
