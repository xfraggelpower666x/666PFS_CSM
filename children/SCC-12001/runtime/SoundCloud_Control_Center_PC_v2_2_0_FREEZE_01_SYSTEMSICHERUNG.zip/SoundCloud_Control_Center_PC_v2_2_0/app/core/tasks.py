from __future__ import annotations
import queue
import threading
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable


@dataclass
class TaskUpdate:
    task_id: str
    name: str
    status: str
    progress: float = 0.0
    message: str = ""
    result: Any = None
    error: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))


class TaskContext:
    def __init__(self, task_id: str, name: str, updates: "queue.Queue[TaskUpdate]", cancel_event: threading.Event):
        self.task_id = task_id
        self.name = name
        self._updates = updates
        self.cancel_event = cancel_event

    def update(self, progress: float, message: str, status: str = "RUNNING") -> None:
        self._updates.put(TaskUpdate(self.task_id, self.name, status, max(0.0, min(100.0, progress)), message))

    def check_cancelled(self) -> None:
        if self.cancel_event.is_set():
            raise RuntimeError("Vorgang vom Benutzer abgebrochen.")


class TaskManager:
    def __init__(self, max_workers: int = 3):
        self.updates: "queue.Queue[TaskUpdate]" = queue.Queue()
        self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="SCCWorker")
        self.cancel_events: dict[str, threading.Event] = {}

    def submit(self, name: str, func: Callable[[TaskContext], Any]) -> str:
        task_id = uuid.uuid4().hex[:12]
        cancel_event = threading.Event()
        self.cancel_events[task_id] = cancel_event
        self.updates.put(TaskUpdate(task_id, name, "QUEUED", 0, "In Warteschlange"))

        def runner() -> None:
            ctx = TaskContext(task_id, name, self.updates, cancel_event)
            try:
                ctx.update(0, "Gestartet")
                result = func(ctx)
                self.updates.put(TaskUpdate(task_id, name, "COMPLETED", 100, "Abgeschlossen", result=result))
            except Exception as exc:
                status = "CANCELLED" if cancel_event.is_set() else "FAILED"
                self.updates.put(TaskUpdate(task_id, name, status, 0, str(exc), error=traceback.format_exc()))
            finally:
                self.cancel_events.pop(task_id, None)

        self.executor.submit(runner)
        return task_id

    def cancel(self, task_id: str) -> bool:
        event = self.cancel_events.get(task_id)
        if event is None:
            return False
        event.set()
        return True
