from __future__ import annotations

import json
import os
import sys
import urllib.parse
from pathlib import Path
from typing import Optional

from .paths import ensure_runtime_dirs, project_root

CALLBACK_FILE = "oauth_callback_pending.json"


def callback_file() -> Path:
    return ensure_runtime_dirs()["config"] / CALLBACK_FILE


def validate_redirect_uri(uri: str) -> urllib.parse.ParseResult:
    value = (uri or "").strip()
    if not value:
        raise ValueError("Redirect-URI fehlt.")
    parsed = urllib.parse.urlparse(value)
    if not parsed.scheme:
        raise ValueError("Redirect-URI benötigt ein URI-Schema, z. B. sccpc://soundcloud/callback.")
    if parsed.scheme.lower() in ("http", "https") and (parsed.hostname or "").lower() == "example.com":
        raise ValueError(
            "Die Platzhalter-Redirect-URI https://example.com/callback ist nicht zulässig. "
            "Trage exakt die Redirect-URI ein, die bei deiner SoundCloud-App registriert ist. "
            "Für die PC-App wird sccpc://soundcloud/callback empfohlen."
        )
    return parsed


def is_custom_scheme(uri: str) -> bool:
    parsed = validate_redirect_uri(uri)
    return parsed.scheme.lower() not in ("http", "https")


def register_windows_protocol(redirect_uri: str) -> bool:
    """Register the custom URI scheme under HKCU without admin rights.

    Returns True when a custom protocol is registered. HTTPS redirects are left untouched.
    """
    parsed = validate_redirect_uri(redirect_uri)
    scheme = parsed.scheme.lower()
    if scheme in ("http", "https"):
        return False
    if os.name != "nt":
        return False

    import winreg  # type: ignore

    root = project_root()
    if getattr(sys, "frozen", False):
        command = f'"{sys.executable}" --oauth-callback "%1"'
    else:
        pythonw = Path(sys.executable)
        main_py = root / "app" / "main.py"
        command = f'"{pythonw}" "{main_py}" --oauth-callback "%1"'

    key_path = rf"Software\Classes\{scheme}"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
        winreg.SetValueEx(key, "", 0, winreg.REG_SZ, f"URL:{scheme} Protocol")
        winreg.SetValueEx(key, "URL Protocol", 0, winreg.REG_SZ, "")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path + r"\DefaultIcon") as key:
        winreg.SetValueEx(key, "", 0, winreg.REG_SZ, sys.executable)
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path + r"\shell\open\command") as key:
        winreg.SetValueEx(key, "", 0, winreg.REG_SZ, command)
    return True


def write_callback_url(url: str) -> Path:
    parsed = urllib.parse.urlparse((url or "").strip())
    if not parsed.scheme:
        raise ValueError("Ungültige OAuth-Callback-URL.")
    path = callback_file()
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"url": url.strip()}, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)
    return path


def consume_callback_url() -> Optional[str]:
    path = callback_file()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        value = str(data.get("url") or "").strip()
    except Exception:
        value = ""
    try:
        path.unlink()
    except OSError:
        pass
    return value or None
