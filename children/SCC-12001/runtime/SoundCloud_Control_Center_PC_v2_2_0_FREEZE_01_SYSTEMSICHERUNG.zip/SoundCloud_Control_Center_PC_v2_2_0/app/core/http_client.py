from __future__ import annotations
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class HttpResponse:
    status: int
    headers: dict[str, str]
    data: Any
    text: str
    url: str


class ApiError(RuntimeError):
    def __init__(self, message: str, status: int = 0, response_text: str = ""):
        super().__init__(message)
        self.status = status
        self.response_text = response_text


class HttpClient:
    def __init__(self, timeout: int = 120, refresh_callback: Callable[[], str] | None = None, logger=None):
        self.timeout = timeout
        self.refresh_callback = refresh_callback
        self.logger = logger

    def request(self, method: str, url: str, token: str = "", form: dict[str, Any] | None = None,
                max_attempts: int | None = None, allow_refresh: bool = True, cancel_event=None) -> HttpResponse:
        method = method.upper()
        attempts = max_attempts or (3 if method == "GET" else 1)
        refreshed = False
        last_error: Exception | None = None
        current_token = token

        for attempt in range(1, attempts + 1):
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError("Vorgang abgebrochen.")
            body = None
            headers = {"Accept": "application/json; charset=utf-8"}
            if current_token:
                headers["Authorization"] = f"OAuth {current_token}"
            if form is not None:
                body = urllib.parse.urlencode({k: v for k, v in form.items() if v not in (None, "")}).encode("utf-8")
                headers["Content-Type"] = "application/x-www-form-urlencoded"
            req = urllib.request.Request(url, data=body, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    raw = response.read()
                    text = raw.decode("utf-8", errors="replace")
                    data = self._parse(text)
                    return HttpResponse(response.status, dict(response.headers.items()), data, text, response.url)
            except urllib.error.HTTPError as exc:
                text = exc.read().decode("utf-8", errors="replace")
                status = exc.code
                headers_out = dict(exc.headers.items()) if exc.headers else {}
                if status == 401 and allow_refresh and not refreshed and self.refresh_callback is not None:
                    current_token = self.refresh_callback()
                    refreshed = True
                    continue
                if status == 429 and attempt < attempts:
                    retry_raw = headers_out.get("Retry-After", headers_out.get("retry-after", "0"))
                    try:
                        wait = min(max(int(retry_raw), 1), 120)
                    except ValueError:
                        wait = min(10 * attempt, 120)
                    time.sleep(wait)
                    continue
                last_error = ApiError(f"{method} {url} fehlgeschlagen: HTTP {status}", status, text)
            except Exception as exc:
                last_error = exc
            if attempt < attempts:
                time.sleep(1.5 * attempt)
        if isinstance(last_error, ApiError):
            raise last_error
        raise ApiError(f"{method} {url} fehlgeschlagen: {last_error}")

    @staticmethod
    def _parse(text: str) -> Any:
        if not text:
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text
