from __future__ import annotations
import logging
from logging.handlers import RotatingFileHandler
from .paths import ensure_runtime_dirs


def configure_logging() -> logging.Logger:
    logger = logging.getLogger("scc")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    log_path = ensure_runtime_dirs()["logs"] / "soundcloud_control_center.log"
    handler = RotatingFileHandler(log_path, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(threadName)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger
