from __future__ import annotations
import csv
import hashlib
import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


def sanitize_filename(value: Any) -> str:
    text = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(value or "soundcloud"))
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "soundcloud"


def format_duration(milliseconds: Any) -> str:
    try:
        value = int(float(milliseconds or 0))
    except Exception:
        return "unbekannt"
    if value <= 0:
        return "unbekannt"
    total_seconds = round(value / 1000)
    return f"{total_seconds // 60}:{total_seconds % 60:02d}"


def parse_iso(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        text = str(value).replace("Z", "+00:00")
        return datetime.fromisoformat(text)
    except Exception:
        return None


def local_datetime_text(value: Any) -> str | None:
    dt = parse_iso(value)
    if dt is None:
        return None
    return dt.astimezone().strftime("%d.%m.%Y %H:%M:%S")


def local_date_key(value: Any) -> str | None:
    dt = parse_iso(value) if not isinstance(value, datetime) else value
    if dt is None:
        return None
    return dt.astimezone().strftime("%Y-%m-%d")


def normalize_title(title: Any) -> str:
    text = unicodedata.normalize("NFKC", str(title or "")).lower().strip()
    text = re.sub(r"\s+", " ", text)
    patterns = [r"\s*\(\d+\)\s*$", r"\s*\[\d+\]\s*$", r"\s*copy\s*$", r"\s*duplicate\s*$", r"\s*dupe\s*$", r"\s*kopie\s*$", r"\s*version\s*\d+\s*$"]
    for pattern in patterns:
        text = re.sub(pattern, "", text).strip()
    return text


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="")
    tmp.replace(path)


def atomic_write_json(path: Path, obj: Any) -> None:
    atomic_write_text(path, json.dumps(obj, indent=2, ensure_ascii=False))


def csv_text(header: list[str], rows: Iterable[Iterable[Any]]) -> str:
    import io
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, delimiter=";", quotechar='"', lineterminator="\n")
    writer.writerow(header)
    for row in rows:
        writer.writerow(["" if value is None else value for value in row])
    return stream.getvalue()
