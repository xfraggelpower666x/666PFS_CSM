// Variables used by Scriptable.
// These must be at the very top of the file. Do not edit.
// icon-color: purple; icon-glyph: cloud;
// ============================================================
// SOUNDCLOUD CONTROL CENTER FÜR SCRIPTABLE
// Version: 1.3.0
//
// EIN SCRIPT FÜR:
// 1) Token Manager
// 2) Track Cleanup Manager
// 3) Likes / Favoriter Analyzer
// 4) LYVRA Evidence Analyzer
//
// Speichert lokal im iOS-Keychain:
// - SoundCloud Client-ID
// - SoundCloud Client-Secret
// - Redirect-URI
// - Access-Token
// - Refresh-Token
//
// Standard-Redirect-URI:
// https://example.com/callback
// ============================================================

const VERSION = "1.3.0";

const AUTH_URL = "https://secure.soundcloud.com/authorize";
const TOKEN_URL = "https://secure.soundcloud.com/oauth/token";
const API_BASE = "https://api.soundcloud.com";
const ME_URL = `${API_BASE}/me`;
const DEFAULT_REDIRECT_URI = "https://example.com/callback";

const PAGE_LIMIT = 200;
const REQUEST_DELAY_SECONDS = 0.6;
const FAVORITER_DELAY_SECONDS = 0.8;
const DELETE_DELAY_SECONDS = 1.2;
const REQUEST_TIMEOUT_SECONDS = 120;

const GOLD_DATA_MODULE_NAME = "Gold Data Collector";
const GOLD_DATA_READ_ONLY = true;
const GOLD_DATA_MAX_FAVORITER_ALL_DEFAULT = 0;
const GOLD_DATA_CHECKPOINT_EVERY = 25;
const DURATION_TOLERANCE_MS = 3000;

const LATEST_UPLOAD_STEPS = [
  500, 1000, 1500, 2000, 2500,
  3000, 3500, 4000, 4500, 5000
];

const KEYS = {
  clientId: "SC_CLIENT_ID",
  clientSecret: "SC_CLIENT_SECRET",
  redirectUri: "SC_REDIRECT_URI",
  verifier: "SC_PKCE_VERIFIER",
  state: "SC_OAUTH_STATE",
  accessToken: "SOUNDCLOUD_ACCESS_TOKEN",
  refreshToken: "SOUNDCLOUD_REFRESH_TOKEN",
  expiresAt: "SOUNDCLOUD_TOKEN_EXPIRES_AT"
};

const CLEANUP_ANALYZE = "cleanup_analyze";
const CLEANUP_DELETE_DUPLICATES = "cleanup_delete_duplicates";
const CLEANUP_DELETE_ALL_SELECTED = "cleanup_delete_all_selected";
const CLEANUP_DELETE_LATEST_N = "cleanup_delete_latest_n";

// ============================================================
// DIALOGE
// ============================================================

async function showMessage(title, message) {
  const alert = new Alert();
  alert.title = title;
  alert.message = message;
  alert.addAction("OK");
  await alert.presentAlert();
}

async function askText({
  title,
  message,
  placeholder,
  initialValue = "",
  secure = false
}) {
  const alert = new Alert();
  alert.title = title;
  alert.message = message;

  if (secure) {
    alert.addSecureTextField(placeholder, initialValue);
  } else {
    alert.addTextField(placeholder, initialValue);
  }

  alert.addAction("Übernehmen");
  alert.addCancelAction("Abbrechen");

  const selection = await alert.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  const value = String(alert.textFieldValue(0) || "").trim();

  if (!value) {
    throw new Error(`${title}: Kein Wert eingegeben.`);
  }

  return value;
}

async function selectMainMenu() {
  const menu = new Alert();

  menu.title = "SoundCloud Control Center";
  menu.message =
    `Version ${VERSION}\n\n` +
    "Alles in einem Script.";

  menu.addAction("Token Manager");
  menu.addAction("Track Cleanup Manager");
  menu.addAction("Likes / Favoriter Analyzer");
  menu.addAction("LYVRA Evidence Analyzer");
  menu.addAction("🔎 Vollständige Kontoanalyse");
  menu.addAction("Account testen");
  menu.addCancelAction("Abbrechen");

  return await menu.presentAlert();
}

// ============================================================
// KEYCHAIN
// ============================================================

function getStored(key) {
  return Keychain.contains(key) ? Keychain.get(key) : "";
}

function setStored(key, value) {
  Keychain.set(key, String(value));
}

function removeStored(key) {
  if (Keychain.contains(key)) {
    Keychain.remove(key);
  }
}

function getAccessToken() {
  const token = getStored(KEYS.accessToken);

  if (!token) {
    throw new Error(
      "Kein SoundCloud Access-Token gefunden.\n\n" +
      "Öffne zuerst den Token Manager und erstelle/teste den Token."
    );
  }

  return token;
}

// ============================================================
// ALLGEMEINE HILFEN
// ============================================================

function sleep(seconds) {
  return new Promise(resolve => {
    Timer.schedule(seconds, false, resolve);
  });
}

function formEncode(values) {
  return Object.entries(values)
    .filter(([, value]) => value !== undefined && value !== null && value !== "")
    .map(([key, value]) => {
      return encodeURIComponent(key) + "=" + encodeURIComponent(String(value));
    })
    .join("&");
}

function extractParameter(input, parameterName) {
  const source = String(input || "").trim();

  if (!source) {
    return null;
  }

  try {
    const parsedUrl = new URL(source);
    const value = parsedUrl.searchParams.get(parameterName);
    if (value !== null) {
      return value;
    }
  } catch (_) {}

  const expression = new RegExp("(?:[?&]|^)" + parameterName + "=([^&\\s]+)");
  const match = source.match(expression);

  if (!match || !match[1]) {
    return null;
  }

  try {
    return decodeURIComponent(match[1].replace(/\+/g, " "));
  } catch (_) {
    return match[1];
  }
}

function sanitizeFilename(value) {
  return String(value || "soundcloud")
    .replace(/[^a-zA-Z0-9._-]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function csvEscape(value) {
  const text = value === null || value === undefined ? "" : String(value);

  if (/[",\n\r;]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }

  return text;
}

function formatDuration(milliseconds) {
  const value = Number(milliseconds || 0);

  if (!value) {
    return "unbekannt";
  }

  const totalSeconds = Math.round(value / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  return String(minutes) + ":" + String(seconds).padStart(2, "0");
}

// ============================================================
// DATUM / SCOPES
// ============================================================

function getLocalDateDaysAgo(daysAgo) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() - daysAgo);
  return date;
}

function getLocalDateKey(dateValue) {
  const date = dateValue instanceof Date ? dateValue : new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return null;
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function formatLocalDate(dateValue) {
  const date = dateValue instanceof Date ? dateValue : new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return "unbekannt";
  }

  const formatter = new DateFormatter();
  formatter.locale = "de_DE";
  formatter.dateFormat = "dd.MM.yyyy";

  return formatter.string(date);
}

function formatLocalDateTime(dateValue) {
  if (!dateValue) {
    return "unbekannt";
  }

  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return String(dateValue);
  }

  const formatter = new DateFormatter();
  formatter.locale = "de_DE";
  formatter.dateFormat = "dd.MM.yyyy HH:mm:ss";

  return formatter.string(date);
}

async function selectCommonScope() {
  const menu = new Alert();

  menu.title = "Zeitraum / Scope";
  menu.message =
    "Wähle, welche eigenen Tracks berücksichtigt werden sollen.\n\n" +
    "Kalendertage werden nach der lokalen iPhone-Zeitzone ausgewertet.";

  menu.addAction("Heute");
  menu.addAction("1 Tag zurück");
  menu.addAction("2 Tage zurück");
  menu.addAction("3 Tage zurück");
  menu.addAction("4 Tage zurück");
  menu.addAction("5 Tage zurück");
  menu.addAction("6 Tage zurück");
  menu.addAction("7 Tage zurück");

  menu.addAction("Letzte 500 Uploads");
  menu.addAction("Letzte 1000 Uploads");
  menu.addAction("Letzte 1500 Uploads");
  menu.addAction("Letzte 2000 Uploads");
  menu.addAction("Letzte 2500 Uploads");
  menu.addAction("Letzte 3000 Uploads");
  menu.addAction("Letzte 3500 Uploads");
  menu.addAction("Letzte 4000 Uploads");
  menu.addAction("Letzte 4500 Uploads");
  menu.addAction("Letzte 5000 Uploads");

  menu.addAction("Kompletter Account");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection >= 0 && selection <= 7) {
    const daysAgo = selection;
    const targetDate = getLocalDateDaysAgo(daysAgo);

    return {
      mode: "single_day",
      daysAgo,
      latestLimit: null,
      targetDate,
      label:
        daysAgo === 0
          ? `Heute – ${formatLocalDate(targetDate)}`
          : `${daysAgo} ${daysAgo === 1 ? "Tag" : "Tage"} zurück – ${formatLocalDate(targetDate)}`
    };
  }

  if (selection >= 8 && selection <= 17) {
    const latestLimit = LATEST_UPLOAD_STEPS[selection - 8];

    return {
      mode: "latest_n_uploads",
      daysAgo: null,
      latestLimit,
      targetDate: null,
      label: `Letzte ${latestLimit} Uploads`
    };
  }

  return {
    mode: "all",
    daysAgo: null,
    latestLimit: null,
    targetDate: null,
    label: "Kompletter Account"
  };
}

function getLatestTracks(tracks, count) {
  return [...tracks]
    .sort((first, second) => {
      const firstTime = first.created_at ? new Date(first.created_at).getTime() : 0;
      const secondTime = second.created_at ? new Date(second.created_at).getTime() : 0;
      return secondTime - firstTime;
    })
    .slice(0, count);
}

function filterTracksByScope(tracks, scope) {
  if (scope.mode === "all") {
    return [...tracks];
  }

  if (scope.mode === "latest_n_uploads") {
    return getLatestTracks(tracks, scope.latestLimit);
  }

  const targetKey = getLocalDateKey(scope.targetDate);

  return tracks.filter(track => {
    if (!track.created_at) {
      return false;
    }

    return getLocalDateKey(track.created_at) === targetKey;
  });
}

// ============================================================
// BASE64URL + SHA-256 FÜR PKCE
// ============================================================

const BASE64_CHARS =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
  "abcdefghijklmnopqrstuvwxyz" +
  "0123456789+/";

function bytesToBase64(bytes) {
  let result = "";

  for (let index = 0; index < bytes.length; index += 3) {
    const first = bytes[index];
    const secondExists = index + 1 < bytes.length;
    const thirdExists = index + 2 < bytes.length;
    const second = secondExists ? bytes[index + 1] : 0;
    const third = thirdExists ? bytes[index + 2] : 0;
    const combined = (first << 16) | (second << 8) | third;

    result += BASE64_CHARS[(combined >>> 18) & 63];
    result += BASE64_CHARS[(combined >>> 12) & 63];
    result += secondExists ? BASE64_CHARS[(combined >>> 6) & 63] : "=";
    result += thirdExists ? BASE64_CHARS[combined & 63] : "=";
  }

  return result;
}

function bytesToBase64Url(bytes) {
  return bytesToBase64(bytes)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function stringToUtf8Bytes(value) {
  const encoded = unescape(encodeURIComponent(String(value)));
  const bytes = [];

  for (let index = 0; index < encoded.length; index++) {
    bytes.push(encoded.charCodeAt(index));
  }

  return bytes;
}

function rotateRight(value, amount) {
  return (value >>> amount) | (value << (32 - amount));
}

function sha256Bytes(value) {
  const bytes = stringToUtf8Bytes(value);
  const bitLength = bytes.length * 8;

  bytes.push(0x80);

  while (bytes.length % 64 !== 56) {
    bytes.push(0);
  }

  const high = Math.floor(bitLength / 0x100000000);
  const low = bitLength >>> 0;

  bytes.push(
    (high >>> 24) & 0xff,
    (high >>> 16) & 0xff,
    (high >>> 8) & 0xff,
    high & 0xff,
    (low >>> 24) & 0xff,
    (low >>> 16) & 0xff,
    (low >>> 8) & 0xff,
    low & 0xff
  );

  const constants = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  let h0 = 0x6a09e667;
  let h1 = 0xbb67ae85;
  let h2 = 0x3c6ef372;
  let h3 = 0xa54ff53a;
  let h4 = 0x510e527f;
  let h5 = 0x9b05688c;
  let h6 = 0x1f83d9ab;
  let h7 = 0x5be0cd19;

  const words = new Array(64);

  for (let chunk = 0; chunk < bytes.length; chunk += 64) {
    for (let index = 0; index < 16; index++) {
      const offset = chunk + index * 4;
      words[index] =
        (
          (bytes[offset] << 24) |
          (bytes[offset + 1] << 16) |
          (bytes[offset + 2] << 8) |
          bytes[offset + 3]
        ) >>> 0;
    }

    for (let index = 16; index < 64; index++) {
      const previous15 = words[index - 15];
      const previous2 = words[index - 2];

      const sigma0 =
        rotateRight(previous15, 7) ^
        rotateRight(previous15, 18) ^
        (previous15 >>> 3);

      const sigma1 =
        rotateRight(previous2, 17) ^
        rotateRight(previous2, 19) ^
        (previous2 >>> 10);

      words[index] =
        (
          words[index - 16] +
          sigma0 +
          words[index - 7] +
          sigma1
        ) >>> 0;
    }

    let a = h0;
    let b = h1;
    let c = h2;
    let d = h3;
    let e = h4;
    let f = h5;
    let g = h6;
    let h = h7;

    for (let index = 0; index < 64; index++) {
      const upperSigma1 =
        rotateRight(e, 6) ^
        rotateRight(e, 11) ^
        rotateRight(e, 25);

      const choice = (e & f) ^ (~e & g);

      const temporary1 =
        (
          h +
          upperSigma1 +
          choice +
          constants[index] +
          words[index]
        ) >>> 0;

      const upperSigma0 =
        rotateRight(a, 2) ^
        rotateRight(a, 13) ^
        rotateRight(a, 22);

      const majority = (a & b) ^ (a & c) ^ (b & c);
      const temporary2 = (upperSigma0 + majority) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temporary1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temporary1 + temporary2) >>> 0;
    }

    h0 = (h0 + a) >>> 0;
    h1 = (h1 + b) >>> 0;
    h2 = (h2 + c) >>> 0;
    h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0;
    h5 = (h5 + f) >>> 0;
    h6 = (h6 + g) >>> 0;
    h7 = (h7 + h) >>> 0;
  }

  const hashWords = [h0, h1, h2, h3, h4, h5, h6, h7];
  const result = [];

  for (const word of hashWords) {
    result.push(
      (word >>> 24) & 0xff,
      (word >>> 16) & 0xff,
      (word >>> 8) & 0xff,
      word & 0xff
    );
  }

  return result;
}

function createRandomString() {
  return (
    UUID.string() +
    UUID.string() +
    UUID.string()
  )
    .replace(/-/g, "")
    .toLowerCase();
}

function createPkcePair() {
  const verifier = createRandomString();

  if (verifier.length < 43 || verifier.length > 128) {
    throw new Error("Ungültige PKCE-Verifier-Länge: " + verifier.length);
  }

  const challenge = bytesToBase64Url(sha256Bytes(verifier));

  return { verifier, challenge };
}

// ============================================================
// TOKEN MANAGER
// ============================================================

async function ensureTokenConfiguration() {
  let clientId = getStored(KEYS.clientId);
  let clientSecret = getStored(KEYS.clientSecret);
  let redirectUri = getStored(KEYS.redirectUri);

  if (!clientId) {
    clientId = await askText({
      title: "SoundCloud Client-ID",
      message: "Füge deine SoundCloud Client-ID ein.",
      placeholder: "Client-ID"
    });

    setStored(KEYS.clientId, clientId);
  }

  if (!clientSecret) {
    clientSecret = await askText({
      title: "Geheimer Clientschlüssel",
      message:
        "Füge deinen SoundCloud Client-Secret ein. Er bleibt lokal im iOS-Keychain.",
      placeholder: "Client-Secret",
      secure: true
    });

    setStored(KEYS.clientSecret, clientSecret);
  }

  if (!redirectUri) {
    redirectUri = await askText({
      title: "SoundCloud Umleitungs-URI",
      message:
        "Die URI muss exakt mit der SoundCloud-App übereinstimmen.",
      placeholder: DEFAULT_REDIRECT_URI,
      initialValue: DEFAULT_REDIRECT_URI
    });

    setStored(KEYS.redirectUri, redirectUri);
  }

  return { clientId, clientSecret, redirectUri };
}

function saveTokenResponse(data) {
  if (!data.access_token) {
    throw new Error("SoundCloud hat keinen Access-Token geliefert.");
  }

  setStored(KEYS.accessToken, data.access_token);

  if (data.refresh_token) {
    setStored(KEYS.refreshToken, data.refresh_token);
  }

  if (data.expires_in) {
    const expiresAt = Date.now() + Number(data.expires_in) * 1000;
    setStored(KEYS.expiresAt, expiresAt);
  }
}

async function startAuthorization() {
  const configuration = await ensureTokenConfiguration();
  const pkce = createPkcePair();
  const state = createRandomString();

  setStored(KEYS.verifier, pkce.verifier);
  setStored(KEYS.state, state);

  const authorizationUrl =
    AUTH_URL +
    "?" +
    formEncode({
      client_id: configuration.clientId,
      redirect_uri: configuration.redirectUri,
      response_type: "code",
      code_challenge: pkce.challenge,
      code_challenge_method: "S256",
      state,
      display: "popup"
    });

  Pasteboard.copy(authorizationUrl);

  await showMessage(
    "Neue SoundCloud-Anmeldung",
    [
      "Jetzt öffnet sich SoundCloud.",
      "",
      "1. Zugriff erlauben.",
      "2. Danach die komplette URL aus Safari kopieren.",
      "3. Dieses Script erneut öffnen.",
      "4. Token Manager → Redirect-URL einfügen."
    ].join("\n")
  );

  Safari.open(authorizationUrl);
}

async function exchangeAuthorizationCode() {
  const configuration = await ensureTokenConfiguration();
  const verifier = getStored(KEYS.verifier);
  const expectedState = getStored(KEYS.state);

  if (!verifier || !expectedState) {
    throw new Error(
      "Kein aktiver OAuth-Vorgang gefunden.\n\n" +
      "Starte zuerst Token Manager → Neue SoundCloud-Anmeldung."
    );
  }

  const clipboard = Pasteboard.pasteString() || "";

  const redirectUrl = await askText({
    title: "Redirect-URL einfügen",
    message:
      "Füge die vollständige Safari-URL ein.\n\n" +
      "Beispiel:\n" +
      DEFAULT_REDIRECT_URI +
      "?code=...&state=...",
    placeholder: DEFAULT_REDIRECT_URI + "?code=...&state=...",
    initialValue: clipboard.startsWith("http") ? clipboard : ""
  });

  const oauthError = extractParameter(redirectUrl, "error");
  const oauthErrorDescription = extractParameter(redirectUrl, "error_description");

  if (oauthError) {
    throw new Error(
      "SoundCloud OAuth-Fehler:\n\n" +
      oauthError +
      (oauthErrorDescription ? "\n\n" + oauthErrorDescription : "")
    );
  }

  const code = extractParameter(redirectUrl, "code");
  const returnedState = extractParameter(redirectUrl, "state");

  if (!code) {
    throw new Error("Die URL enthält keinen Authorization Code.");
  }

  if (!returnedState) {
    throw new Error("Die URL enthält keinen OAuth-State.");
  }

  if (returnedState !== expectedState) {
    throw new Error("Der OAuth-State stimmt nicht überein. Starte die Anmeldung neu.");
  }

  const request = new Request(TOKEN_URL);
  request.method = "POST";
  request.headers = {
    Accept: "application/json; charset=utf-8",
    "Content-Type": "application/x-www-form-urlencoded"
  };

  request.body = formEncode({
    grant_type: "authorization_code",
    client_id: configuration.clientId,
    client_secret: configuration.clientSecret,
    redirect_uri: configuration.redirectUri,
    code_verifier: verifier,
    code
  });

  const responseText = await request.loadString();
  const statusCode = request.response ? request.response.statusCode : 0;

  if (statusCode < 200 || statusCode >= 300) {
    throw new Error(
      "Token-Austausch fehlgeschlagen.\n\n" +
      `HTTP ${statusCode}\n\n` +
      responseText +
      "\n\nStarte danach eine neue SoundCloud-Anmeldung."
    );
  }

  let responseData;

  try {
    responseData = JSON.parse(responseText);
  } catch (_) {
    throw new Error("SoundCloud lieferte keine gültige JSON-Antwort:\n\n" + responseText);
  }

  saveTokenResponse(responseData);
  removeStored(KEYS.verifier);
  removeStored(KEYS.state);

  await showMessage(
    "Token gespeichert",
    [
      "Der Access-Token wurde erfolgreich erzeugt.",
      "",
      "Access- und Refresh-Token liegen jetzt im Scriptable-Keychain.",
      "",
      "Teste den Token über den Token Manager."
    ].join("\n")
  );
}

async function refreshAccessToken() {
  const configuration = await ensureTokenConfiguration();
  const refreshToken = getStored(KEYS.refreshToken);

  if (!refreshToken) {
    throw new Error(
      "Kein Refresh-Token gespeichert.\n\n" +
      "Starte eine neue SoundCloud-Anmeldung."
    );
  }

  const request = new Request(TOKEN_URL);
  request.method = "POST";
  request.headers = {
    Accept: "application/json; charset=utf-8",
    "Content-Type": "application/x-www-form-urlencoded"
  };

  request.body = formEncode({
    grant_type: "refresh_token",
    client_id: configuration.clientId,
    client_secret: configuration.clientSecret,
    refresh_token: refreshToken
  });

  const responseText = await request.loadString();
  const statusCode = request.response ? request.response.statusCode : 0;

  if (statusCode < 200 || statusCode >= 300) {
    throw new Error(
      "Token-Erneuerung fehlgeschlagen.\n\n" +
      `HTTP ${statusCode}\n\n` +
      responseText
    );
  }

  let responseData;

  try {
    responseData = JSON.parse(responseText);
  } catch (_) {
    throw new Error("Die Token-Antwort konnte nicht gelesen werden:\n\n" + responseText);
  }

  saveTokenResponse(responseData);

  await showMessage(
    "Token erneuert",
    "Der Access-Token und ein eventuell neuer Refresh-Token wurden gespeichert."
  );
}

async function resetOAuthAttempt() {
  removeStored(KEYS.verifier);
  removeStored(KEYS.state);

  await showMessage(
    "OAuth-Vorgang zurückgesetzt",
    "PKCE-Verifier und OAuth-State wurden entfernt. Client-Daten und Tokens bleiben erhalten."
  );
}

async function resetAllSoundCloudData() {
  const alert = new Alert();

  alert.title = "Alle SoundCloud-Daten löschen";
  alert.message =
    "Client-ID, Client-Secret, Redirect-URI und alle Tokens werden aus Scriptable entfernt.";

  alert.addDestructiveAction("Alles löschen");
  alert.addCancelAction("Abbrechen");

  const selection = await alert.presentAlert();

  if (selection === -1) {
    return;
  }

  for (const key of Object.values(KEYS)) {
    removeStored(key);
  }

  await showMessage(
    "Alles gelöscht",
    "Alle SoundCloud-Werte wurden aus dem Scriptable-Keychain entfernt."
  );
}

async function runTokenManager() {
  const menu = new Alert();

  menu.title = "Token Manager";
  menu.message = "OAuth, Access-Token und Refresh-Token.";

  menu.addAction("Neue SoundCloud-Anmeldung");
  menu.addAction("Redirect-URL einfügen");
  menu.addAction("Access-Token testen");
  menu.addAction("Access-Token erneuern");
  menu.addAction("OAuth-Vorgang zurücksetzen");
  menu.addDestructiveAction("Alle Token-Daten löschen");
  menu.addCancelAction("Zurück");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    return;
  }

  if (selection === 0) {
    await startAuthorization();
    return;
  }

  if (selection === 1) {
    await exchangeAuthorizationCode();
    return;
  }

  if (selection === 2) {
    await testAccessToken();
    return;
  }

  if (selection === 3) {
    await refreshAccessToken();
    return;
  }

  if (selection === 4) {
    await resetOAuthAttempt();
    return;
  }

  if (selection === 5) {
    await resetAllSoundCloudData();
  }
}

// ============================================================
// HTTP / SOUNDCLOUD API
// ============================================================

async function apiRequest(method, pathOrUrl, token) {
  const url = String(pathOrUrl).startsWith("http")
    ? String(pathOrUrl)
    : API_BASE + String(pathOrUrl);

  const maxAttempts = method === "GET" ? 3 : 1;
  let lastError = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const request = new Request(url);

    request.method = method;
    request.headers = {
      Accept: "application/json; charset=utf-8",
      Authorization: `OAuth ${token}`
    };

    request.timeoutInterval = REQUEST_TIMEOUT_SECONDS;

    try {
      const responseText = await request.loadString();
      const statusCode = request.response ? request.response.statusCode : 0;

      if (statusCode < 200 || statusCode >= 300) {
        throw new Error(
          `${method} ${url} fehlgeschlagen.\n\n` +
          `HTTP ${statusCode}\n\n` +
          responseText
        );
      }

      if (!responseText) {
        return null;
      }

      try {
        return JSON.parse(responseText);
      } catch (_) {
        return responseText;
      }
    } catch (error) {
      lastError = error;

      if (attempt < maxAttempts) {
        console.log(`Request fehlgeschlagen, Versuch ${attempt}/${maxAttempts}. Wiederhole ...`);
        await sleep(1.5 * attempt);
      }
    }
  }

  throw new Error(
    `${method} ${url} fehlgeschlagen.\n\n` +
    (lastError && lastError.message ? lastError.message : String(lastError))
  );
}

async function fetchAccount(token) {
  return await apiRequest("GET", "/me", token);
}

async function testAccessToken() {
  const token = getAccessToken();
  const account = await fetchAccount(token);

  await showMessage(
    "Access-Token funktioniert",
    [
      `Account: ${account.username || account.permalink || "unbekannt"}`,
      `User-ID: ${account.id || "unbekannt"}`
    ].join("\n")
  );
}

async function fetchAllTracks(token) {
  let nextUrl =
    `${API_BASE}/me/tracks` +
    `?limit=${PAGE_LIMIT}` +
    "&linked_partitioning=true";

  const allTracks = [];
  let pageNumber = 0;

  while (nextUrl) {
    pageNumber++;
    console.log(`Lese Trackseite ${pageNumber}`);

    const page = await apiRequest("GET", nextUrl, token);

    if (Array.isArray(page)) {
      allTracks.push(...page);
      nextUrl = null;
    } else if (page && Array.isArray(page.collection)) {
      allTracks.push(...page.collection);
      nextUrl = page.next_href || null;
    } else {
      throw new Error(
        "SoundCloud lieferte ein unbekanntes Pagination-Format:\n\n" +
        JSON.stringify(page, null, 2)
      );
    }

    if (nextUrl) {
      await sleep(REQUEST_DELAY_SECONDS);
    }
  }

  return allTracks;
}

// ============================================================
// TRACK / USER KOMPAKT
// ============================================================

function compactTrack(track) {
  return {
    id: track.id,
    urn: track.urn || null,
    title: track.title || "",
    duration: track.duration || 0,
    duration_text: formatDuration(track.duration || 0),
    created_at: track.created_at || null,
    created_at_local: track.created_at ? formatLocalDateTime(track.created_at) : null,
    local_date_key: track.created_at ? getLocalDateKey(track.created_at) : null,
    permalink_url: track.permalink_url || null,
    playback_count: track.playback_count || 0,
    likes_count: track.likes_count || 0,
    comment_count: track.comment_count || 0,
    downloadable: Boolean(track.downloadable),
    sharing: track.sharing || null,
    state: track.state || null
  };
}

function compactUser(user) {
  return {
    id: user.id || null,
    urn: user.urn || null,
    username: user.username || "",
    full_name: user.full_name || "",
    permalink: user.permalink || "",
    permalink_url: user.permalink_url || "",
    avatar_url: user.avatar_url || "",
    city: user.city || "",
    country_code: user.country_code || "",
    followers_count: user.followers_count || 0,
    followings_count: user.followings_count || 0,
    track_count: user.track_count || 0
  };
}

// ============================================================
// CLEANUP MANAGER
// ============================================================

async function selectCleanupOperation() {
  const menu = new Alert();

  menu.title = "Track Cleanup Manager";
  menu.message =
    "Wähle die Aktion. Vor jeder Löschung wird analysiert und ein Backup geschrieben.";

  menu.addAction("Nur analysieren");
  menu.addAction("Nur erkannte Duplikate löschen");
  menu.addDestructiveAction("Alle Tracks des Scopes löschen");
  menu.addDestructiveAction("Letzte N Uploads im Scope löschen");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    return { mode: CLEANUP_ANALYZE, label: "Nur analysieren" };
  }

  if (selection === 1) {
    return { mode: CLEANUP_DELETE_DUPLICATES, label: "Nur erkannte Duplikate löschen" };
  }

  if (selection === 2) {
    return { mode: CLEANUP_DELETE_ALL_SELECTED, label: "Alle Tracks des Scopes löschen" };
  }

  return { mode: CLEANUP_DELETE_LATEST_N, label: "Letzte N Uploads im Scope löschen" };
}

async function askLatestUploadCount(maxCount) {
  const raw = await askText({
    title: "Wie viele letzte Uploads?",
    message:
      `Im gewählten Scope wurden ${maxCount} Tracks gefunden.\n\n` +
      "Gib ein, wie viele der zuletzt hochgeladenen Tracks gelöscht werden sollen.\n\n" +
      "Beispiel: 50 löscht die 50 neuesten Uploads innerhalb des gewählten Scopes.",
    placeholder: "Anzahl"
  });

  const count = Number.parseInt(raw, 10);

  if (!Number.isFinite(count) || count <= 0) {
    throw new Error("Ungültige Anzahl. Bitte eine Zahl größer als 0 eingeben.");
  }

  if (count > maxCount) {
    throw new Error(
      "Die Anzahl ist größer als die gefundenen Tracks im Scope.\n\n" +
      `Eingegeben: ${count}\nVerfügbar: ${maxCount}`
    );
  }

  return count;
}

async function confirmDeletion(count, scopeLabel, operationLabel) {
  const requiredText = `DELETE ${count}`;

  const alert = new Alert();

  alert.title = "Endgültige Löschung bestätigen";
  alert.message =
    `Aktion:\n${operationLabel}\n\n` +
    `Scope:\n${scopeLabel}\n\n` +
    `Betroffene Tracks: ${count}\n\n` +
    "Die Löschung ist über SoundCloud nicht rückgängig zu machen.\n\n" +
    `Tippe exakt:\n${requiredText}`;

  alert.addTextField(requiredText, "");
  alert.addDestructiveAction("Endgültig löschen");
  alert.addCancelAction("Abbrechen");

  const selection = await alert.presentAlert();

  if (selection === -1) {
    return false;
  }

  const entered = String(alert.textFieldValue(0) || "").trim();
  return entered === requiredText;
}

function normalizeTitle(title) {
  return String(title || "")
    .toLowerCase()
    .normalize("NFKC")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\s*\(\d+\)\s*$/g, "")
    .replace(/\s*\[\d+\]\s*$/g, "")
    .replace(/\s*copy\s*$/g, "")
    .replace(/\s*duplicate\s*$/g, "")
    .replace(/\s*dupe\s*$/g, "")
    .replace(/\s*kopie\s*$/g, "")
    .replace(/\s*version\s*\d+\s*$/g, "")
    .trim();
}

function buildDuplicatePlan(tracks) {
  const titleGroups = new Map();

  for (const track of tracks) {
    const normalizedTitle = normalizeTitle(track.title);

    if (!normalizedTitle) {
      continue;
    }

    if (!titleGroups.has(normalizedTitle)) {
      titleGroups.set(normalizedTitle, []);
    }

    titleGroups.get(normalizedTitle).push(track);
  }

  const duplicateGroups = [];
  const deleteCandidates = [];

  for (const [normalizedTitle, sameTitleTracks] of titleGroups.entries()) {
    if (sameTitleTracks.length < 2) {
      continue;
    }

    const ordered = [...sameTitleTracks].sort((first, second) => {
      const firstTime = first.created_at ? new Date(first.created_at).getTime() : 0;
      const secondTime = second.created_at ? new Date(second.created_at).getTime() : 0;
      return firstTime - secondTime;
    });

    const durationClusters = [];

    for (const track of ordered) {
      let matchingCluster = null;

      for (const cluster of durationClusters) {
        const reference = cluster[0];

        const durationDifference = Math.abs(
          Number(track.duration || 0) - Number(reference.duration || 0)
        );

        if (durationDifference <= DURATION_TOLERANCE_MS) {
          matchingCluster = cluster;
          break;
        }
      }

      if (matchingCluster) {
        matchingCluster.push(track);
      } else {
        durationClusters.push([track]);
      }
    }

    for (const cluster of durationClusters) {
      if (cluster.length < 2) {
        continue;
      }

      const keep = cluster[0];
      const remove = cluster.slice(1);

      duplicateGroups.push({
        normalized_title: normalizedTitle,
        keep: compactTrack(keep),
        remove: remove.map(compactTrack)
      });

      deleteCandidates.push(...remove.map(compactTrack));
    }
  }

  return { duplicateGroups, deleteCandidates };
}

async function deleteTrack(token, track) {
  await apiRequest(
    "DELETE",
    `/tracks/${encodeURIComponent(track.id)}`,
    token
  );
}

async function executeDeletions(token, candidates) {
  let deleted = 0;
  let failed = 0;
  const failures = [];

  for (let index = 0; index < candidates.length; index++) {
    const track = candidates[index];

    console.log(`Lösche ${index + 1}/${candidates.length}: ${track.title} (${track.id})`);

    try {
      await deleteTrack(token, track);
      deleted++;
    } catch (error) {
      failed++;

      failures.push({
        track,
        error: error && error.message ? error.message : String(error)
      });

      console.error(`Löschfehler bei ${track.id}:`, error);
    }

    if (index < candidates.length - 1) {
      await sleep(DELETE_DELAY_SECONDS);
    }
  }

  return { deleted, failed, failures };
}

function createCleanupTextReport({
  account,
  operation,
  scope,
  allTracks,
  selectedTracks,
  duplicateGroups,
  deleteCandidates,
  effectiveCandidates,
  latestCount
}) {
  const lines = [];

  lines.push("SOUNDCLOUD CONTROL CENTER CLEANUP REPORT");
  lines.push(`Version: ${VERSION}`);
  lines.push("");
  lines.push(`Account: ${account.username || account.permalink || account.id}`);
  lines.push(`User-ID: ${account.id}`);
  lines.push(`Aktion: ${operation.label}`);
  lines.push(`Scope: ${scope.label}`);

  if (latestCount) {
    lines.push(`Letzte Uploads angefordert: ${latestCount}`);
  }

  lines.push(`Tracks im Account: ${allTracks.length}`);
  lines.push(`Tracks im Scope: ${selectedTracks.length}`);
  lines.push(`Duplikat-Gruppen: ${duplicateGroups.length}`);
  lines.push(`Duplikat-Löschkandidaten: ${deleteCandidates.length}`);
  lines.push(`Effektiv betroffen: ${effectiveCandidates.length}`);
  lines.push("");
  lines.push("============================================================");
  lines.push("");

  if (effectiveCandidates.length > 0) {
    lines.push("EFFEKTIV BETROFFENE TRACKS:");
    lines.push("");

    for (const track of effectiveCandidates) {
      lines.push(`ID: ${track.id}`);
      lines.push(`Titel: ${track.title}`);
      lines.push(`Dauer: ${track.duration_text || formatDuration(track.duration)}`);
      lines.push(`Lokal erstellt: ${track.created_at_local}`);
      lines.push(`Plays: ${track.playback_count}`);
      lines.push(`Likes: ${track.likes_count}`);
      lines.push(`URL: ${track.permalink_url || ""}`);
      lines.push("------------------------------------------------------------");
    }

    lines.push("");
    lines.push("============================================================");
    lines.push("");
  }

  for (let index = 0; index < duplicateGroups.length; index++) {
    const group = duplicateGroups[index];

    lines.push(`DUPLIKAT-GRUPPE ${index + 1}`);
    lines.push(`Normalisierter Titel: ${group.normalized_title}`);
    lines.push("");
    lines.push("BEHALTEN:");
    lines.push(`  ID: ${group.keep.id}`);
    lines.push(`  Titel: ${group.keep.title}`);
    lines.push(`  Dauer: ${formatDuration(group.keep.duration)}`);
    lines.push(`  Lokal erstellt: ${group.keep.created_at_local}`);
    lines.push(`  URL: ${group.keep.permalink_url || ""}`);
    lines.push("");
    lines.push("LÖSCHKANDIDATEN:");

    for (const track of group.remove) {
      lines.push(`  ID: ${track.id}`);
      lines.push(`  Titel: ${track.title}`);
      lines.push(`  Dauer: ${formatDuration(track.duration)}`);
      lines.push(`  Lokal erstellt: ${track.created_at_local}`);
      lines.push(`  URL: ${track.permalink_url || ""}`);
      lines.push("");
    }

    lines.push("------------------------------------------------------------");
    lines.push("");
  }

  return lines.join("\n");
}

async function saveCleanupReports({
  account,
  operation,
  scope,
  allTracks,
  selectedTracks,
  duplicateGroups,
  deleteCandidates,
  effectiveCandidates,
  latestCount
}) {
  const fileManager = FileManager.iCloud();
  const documentsDirectory = fileManager.documentsDirectory();
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const accountName = sanitizeFilename(account.username || account.permalink || account.id);
  const scopeName = sanitizeFilename(scope.mode === "single_day" ? getLocalDateKey(scope.targetDate) : scope.label);
  const operationName = sanitizeFilename(operation.mode);
  const baseName = `soundcloud_control_cleanup_${accountName}_${operationName}_${scopeName}_${timestamp}`;

  const txtPath = fileManager.joinPath(documentsDirectory, `${baseName}.txt`);
  const jsonPath = fileManager.joinPath(documentsDirectory, `${baseName}.json`);
  const selectedTracksPath = fileManager.joinPath(documentsDirectory, `${baseName}_selected_tracks.json`);

  const textReport = createCleanupTextReport({
    account,
    operation,
    scope,
    allTracks,
    selectedTracks,
    duplicateGroups,
    deleteCandidates,
    effectiveCandidates,
    latestCount
  });

  const jsonReport = {
    generated_at: new Date().toISOString(),
    version: VERSION,
    module: "cleanup",
    operation,
    latest_upload_delete_count: latestCount || null,
    scope: {
      mode: scope.mode,
      label: scope.label,
      days_ago: scope.daysAgo,
      latest_limit: scope.latestLimit,
      target_local_date: scope.targetDate ? getLocalDateKey(scope.targetDate) : null
    },
    account: {
      id: account.id,
      username: account.username || null,
      permalink: account.permalink || null
    },
    statistics: {
      total_account_tracks: allTracks.length,
      selected_scope_tracks: selectedTracks.length,
      duplicate_groups: duplicateGroups.length,
      duplicate_delete_candidates: deleteCandidates.length,
      effective_candidates: effectiveCandidates.length
    },
    duplicate_groups: duplicateGroups,
    duplicate_delete_candidates: deleteCandidates,
    effective_candidates: effectiveCandidates
  };

  fileManager.writeString(txtPath, textReport);
  fileManager.writeString(jsonPath, JSON.stringify(jsonReport, null, 2));
  fileManager.writeString(selectedTracksPath, JSON.stringify(selectedTracks.map(compactTrack), null, 2));

  return { txtPath, jsonPath, selectedTracksPath };
}

async function runCleanupManager() {
  const operation = await selectCleanupOperation();
  const scope = await selectCommonScope();
  const token = getAccessToken();

  await showMessage(
    "Track Cleanup Manager",
    [
      `Version ${VERSION}`,
      "",
      `Aktion: ${operation.label}`,
      `Scope: ${scope.label}`,
      "",
      "SoundCloud-Tracks werden gelesen und analysiert."
    ].join("\n")
  );

  const account = await fetchAccount(token);
  const allTracks = await fetchAllTracks(token);
  const selectedTracks = filterTracksByScope(allTracks, scope);
  const { duplicateGroups, deleteCandidates } = buildDuplicatePlan(selectedTracks);

  let latestCount = null;
  let effectiveCandidates = [];

  if (operation.mode === CLEANUP_DELETE_DUPLICATES) {
    effectiveCandidates = [...deleteCandidates];
  } else if (operation.mode === CLEANUP_DELETE_ALL_SELECTED) {
    effectiveCandidates = selectedTracks.map(compactTrack);
  } else if (operation.mode === CLEANUP_DELETE_LATEST_N) {
    if (selectedTracks.length === 0) {
      throw new Error("Im gewählten Scope wurden keine Tracks gefunden.");
    }

    latestCount = await askLatestUploadCount(selectedTracks.length);
    effectiveCandidates = getLatestTracks(selectedTracks, latestCount).map(compactTrack);
  }

  const saved = await saveCleanupReports({
    account,
    operation,
    scope,
    allTracks,
    selectedTracks,
    duplicateGroups,
    deleteCandidates,
    effectiveCandidates,
    latestCount
  });

  await showMessage(
    "Analyse abgeschlossen",
    [
      `Aktion: ${operation.label}`,
      `Scope: ${scope.label}`,
      "",
      latestCount ? `Letzte Uploads angefordert: ${latestCount}` : null,
      `Tracks im Account: ${allTracks.length}`,
      `Tracks im Scope: ${selectedTracks.length}`,
      `Duplikat-Gruppen: ${duplicateGroups.length}`,
      `Duplikat-Löschkandidaten: ${deleteCandidates.length}`,
      `Für diese Aktion betroffen: ${effectiveCandidates.length}`,
      "",
      "Backup gespeichert:",
      saved.txtPath
    ].filter(Boolean).join("\n")
  );

  if (operation.mode === CLEANUP_ANALYZE) {
    await showMessage("Analysemodus beendet", "Es wurde nichts gelöscht.");
    return;
  }

  if (effectiveCandidates.length === 0) {
    await showMessage("Keine Tracks betroffen", "Es wurde nichts gelöscht.");
    return;
  }

  const confirmed = await confirmDeletion(
    effectiveCandidates.length,
    scope.label,
    operation.label
  );

  if (!confirmed) {
    await showMessage("Löschung abgebrochen", "Es wurde nichts gelöscht.");
    return;
  }

  const result = await executeDeletions(token, effectiveCandidates);

  const fileManager = FileManager.iCloud();
  const resultPath = fileManager.joinPath(
    fileManager.documentsDirectory(),
    `soundcloud_control_delete_result_${new Date().toISOString().replace(/[:.]/g, "-")}.json`
  );

  fileManager.writeString(
    resultPath,
    JSON.stringify(
      {
        generated_at: new Date().toISOString(),
        version: VERSION,
        module: "cleanup",
        operation,
        scope,
        backup_report: saved,
        ...result
      },
      null,
      2
    )
  );

  await showMessage(
    "Löschung abgeschlossen",
    [
      `Aktion: ${operation.label}`,
      `Scope: ${scope.label}`,
      "",
      `Erfolgreich gelöscht: ${result.deleted}`,
      `Fehlgeschlagen: ${result.failed}`,
      "",
      `Protokoll:\n${resultPath}`
    ].join("\n")
  );
}

// ============================================================
// LIKES / FAVORITER ANALYZER
// ============================================================

async function confirmFavoriterScan(trackCount, likedTrackCount, scopeLabel) {
  const alert = new Alert();

  alert.title = "Favoriter abrufen?";
  alert.message =
    `Scope:\n${scopeLabel}\n\n` +
    `Tracks im Scope: ${trackCount}\n` +
    `Tracks mit likes_count > 0: ${likedTrackCount}\n\n` +
    "Für jeden Track mit Likes wird eine API-Abfrage gestartet. Das kann dauern.";

  alert.addAction("Analyse starten");
  alert.addCancelAction("Abbrechen");

  const selection = await alert.presentAlert();

  return selection !== -1;
}

async function fetchTrackFavoritersByIdentifier(token, identifier) {
  let nextUrl =
    `${API_BASE}/tracks/${encodeURIComponent(identifier)}/favoriters` +
    `?limit=${PAGE_LIMIT}` +
    "&linked_partitioning=true";

  const users = [];

  while (nextUrl) {
    const page = await apiRequest("GET", nextUrl, token);

    if (Array.isArray(page)) {
      users.push(...page);
      nextUrl = null;
    } else if (page && Array.isArray(page.collection)) {
      users.push(...page.collection);
      nextUrl = page.next_href || null;
    } else {
      throw new Error(
        "SoundCloud lieferte ein unbekanntes Favoriter-Pagination-Format:\n\n" +
        JSON.stringify(page, null, 2)
      );
    }

    if (nextUrl) {
      await sleep(REQUEST_DELAY_SECONDS);
    }
  }

  return users;
}

async function fetchTrackFavoriters(token, track) {
  try {
    return await fetchTrackFavoritersByIdentifier(token, track.id);
  } catch (firstError) {
    if (!track.urn) {
      throw firstError;
    }

    console.log(`Favoriter per ID fehlgeschlagen, versuche URN für Track ${track.id}`);
    return await fetchTrackFavoritersByIdentifier(token, track.urn);
  }
}

async function analyzeFavoriters(token, tracksWithLikes) {
  const results = [];
  const failures = [];

  for (let index = 0; index < tracksWithLikes.length; index++) {
    const track = tracksWithLikes[index];

    console.log(`Favoriter ${index + 1}/${tracksWithLikes.length}: ${track.title} (${track.id})`);

    try {
      const users = await fetchTrackFavoriters(token, track);

      results.push({
        track: compactTrack(track),
        expected_likes_count: track.likes_count || 0,
        retrieved_favoriters_count: users.length,
        favoriters: users.map(compactUser)
      });
    } catch (error) {
      failures.push({
        track: compactTrack(track),
        error: error && error.message ? error.message : String(error)
      });

      results.push({
        track: compactTrack(track),
        expected_likes_count: track.likes_count || 0,
        retrieved_favoriters_count: 0,
        favoriters: [],
        error: error && error.message ? error.message : String(error)
      });
    }

    if (index < tracksWithLikes.length - 1) {
      await sleep(FAVORITER_DELAY_SECONDS);
    }
  }

  return { results, failures };
}

function buildLikesSummary(results) {
  const userMap = new Map();
  let totalFavoriterRows = 0;

  for (const entry of results) {
    for (const user of entry.favoriters) {
      totalFavoriterRows++;

      const key = String(user.id || user.permalink || user.username);

      if (!userMap.has(key)) {
        userMap.set(key, {
          user,
          liked_track_count: 0,
          liked_tracks: []
        });
      }

      const record = userMap.get(key);
      record.liked_track_count++;

      record.liked_tracks.push({
        id: entry.track.id,
        title: entry.track.title,
        permalink_url: entry.track.permalink_url
      });
    }
  }

  const topUsers = [...userMap.values()]
    .sort((first, second) => second.liked_track_count - first.liked_track_count)
    .slice(0, 50);

  return {
    unique_users: userMap.size,
    total_favoriter_rows: totalFavoriterRows,
    top_users: topUsers
  };
}

function createLikesTextReport({
  account,
  scope,
  allTracks,
  selectedTracks,
  tracksWithLikes,
  analysis,
  summary
}) {
  const lines = [];

  lines.push("SOUNDCLOUD CONTROL CENTER LIKES REPORT");
  lines.push(`Version: ${VERSION}`);
  lines.push("");
  lines.push(`Account: ${account.username || account.permalink || account.id}`);
  lines.push(`User-ID: ${account.id}`);
  lines.push(`Scope: ${scope.label}`);
  lines.push(`Tracks im Account: ${allTracks.length}`);
  lines.push(`Tracks im Scope: ${selectedTracks.length}`);
  lines.push(`Tracks mit likes_count > 0: ${tracksWithLikes.length}`);
  lines.push(`Favoriter-Zeilen gesamt: ${summary.total_favoriter_rows}`);
  lines.push(`Einzigartige User: ${summary.unique_users}`);
  lines.push(`Fehlerhafte Track-Abfragen: ${analysis.failures.length}`);
  lines.push("");
  lines.push("============================================================");
  lines.push("");
  lines.push("TOP USER NACH ANZAHL GELIKTER TRACKS");
  lines.push("");

  for (const item of summary.top_users) {
    lines.push(`${item.liked_track_count} Likes von: ${item.user.username || item.user.permalink || item.user.id}`);
    lines.push(`  User-ID: ${item.user.id || ""}`);
    lines.push(`  Profil: ${item.user.permalink_url || ""}`);
    lines.push("");
  }

  lines.push("============================================================");
  lines.push("");
  lines.push("TRACKS UND FAVORITER");
  lines.push("");

  for (const entry of analysis.results) {
    lines.push(`TRACK: ${entry.track.title}`);
    lines.push(`ID: ${entry.track.id}`);
    lines.push(`Dauer: ${entry.track.duration_text}`);
    lines.push(`Lokal erstellt: ${entry.track.created_at_local}`);
    lines.push(`URL: ${entry.track.permalink_url || ""}`);
    lines.push(`likes_count laut Track: ${entry.expected_likes_count}`);
    lines.push(`Favoriter abgerufen: ${entry.retrieved_favoriters_count}`);

    if (entry.error) {
      lines.push(`FEHLER: ${entry.error}`);
    }

    if (entry.favoriters.length > 0) {
      lines.push("Favoriter:");

      for (const user of entry.favoriters) {
        lines.push(`  - ${user.username || user.permalink || user.id}`);
        lines.push(`    User-ID: ${user.id || ""}`);
        lines.push(`    Profil: ${user.permalink_url || ""}`);
      }
    }

    lines.push("------------------------------------------------------------");
    lines.push("");
  }

  if (analysis.failures.length > 0) {
    lines.push("============================================================");
    lines.push("");
    lines.push("FEHLER");
    lines.push("");

    for (const failure of analysis.failures) {
      lines.push(`Track: ${failure.track.title} (${failure.track.id})`);
      lines.push(failure.error);
      lines.push("");
    }
  }

  return lines.join("\n");
}

function createLikesCsvReport(analysis) {
  const header = [
    "track_id",
    "track_title",
    "track_url",
    "track_created_local",
    "track_likes_count",
    "retrieved_favoriters_count",
    "user_id",
    "username",
    "full_name",
    "user_permalink_url",
    "city",
    "country_code",
    "followers_count",
    "user_track_count"
  ];

  const lines = [header.map(csvEscape).join(";")];

  for (const entry of analysis.results) {
    if (entry.favoriters.length === 0) {
      const row = [
        entry.track.id,
        entry.track.title,
        entry.track.permalink_url,
        entry.track.created_at_local,
        entry.expected_likes_count,
        entry.retrieved_favoriters_count,
        "", "", "", "", "", "", "", ""
      ];

      lines.push(row.map(csvEscape).join(";"));
      continue;
    }

    for (const user of entry.favoriters) {
      const row = [
        entry.track.id,
        entry.track.title,
        entry.track.permalink_url,
        entry.track.created_at_local,
        entry.expected_likes_count,
        entry.retrieved_favoriters_count,
        user.id,
        user.username,
        user.full_name,
        user.permalink_url,
        user.city,
        user.country_code,
        user.followers_count,
        user.track_count
      ];

      lines.push(row.map(csvEscape).join(";"));
    }
  }

  return lines.join("\n");
}

async function saveLikesReports({
  account,
  scope,
  allTracks,
  selectedTracks,
  tracksWithLikes,
  analysis,
  summary
}) {
  const fileManager = FileManager.iCloud();
  const documentsDirectory = fileManager.documentsDirectory();
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const accountName = sanitizeFilename(account.username || account.permalink || account.id);
  const scopeName = sanitizeFilename(scope.mode === "single_day" ? getLocalDateKey(scope.targetDate) : scope.label);
  const baseName = `soundcloud_control_likes_${accountName}_${scopeName}_${timestamp}`;

  const txtPath = fileManager.joinPath(documentsDirectory, `${baseName}.txt`);
  const jsonPath = fileManager.joinPath(documentsDirectory, `${baseName}.json`);
  const csvPath = fileManager.joinPath(documentsDirectory, `${baseName}.csv`);
  const selectedTracksPath = fileManager.joinPath(documentsDirectory, `${baseName}_selected_tracks.json`);

  const textReport = createLikesTextReport({
    account,
    scope,
    allTracks,
    selectedTracks,
    tracksWithLikes,
    analysis,
    summary
  });

  const jsonReport = {
    generated_at: new Date().toISOString(),
    version: VERSION,
    module: "likes_favoriter_analyzer",
    account: {
      id: account.id,
      username: account.username || null,
      permalink: account.permalink || null
    },
    scope: {
      mode: scope.mode,
      label: scope.label,
      days_ago: scope.daysAgo,
      latest_limit: scope.latestLimit,
      target_local_date: scope.targetDate ? getLocalDateKey(scope.targetDate) : null
    },
    statistics: {
      total_account_tracks: allTracks.length,
      selected_scope_tracks: selectedTracks.length,
      tracks_with_likes_count_gt_zero: tracksWithLikes.length,
      total_favoriter_rows: summary.total_favoriter_rows,
      unique_users: summary.unique_users,
      failed_track_requests: analysis.failures.length
    },
    top_users: summary.top_users,
    track_like_details: analysis.results,
    failures: analysis.failures
  };

  fileManager.writeString(txtPath, textReport);
  fileManager.writeString(jsonPath, JSON.stringify(jsonReport, null, 2));
  fileManager.writeString(csvPath, createLikesCsvReport(analysis));
  fileManager.writeString(selectedTracksPath, JSON.stringify(selectedTracks.map(compactTrack), null, 2));

  return {
    txtPath,
    jsonPath,
    csvPath,
    selectedTracksPath
  };
}

async function runLikesAnalyzer() {
  const scope = await selectCommonScope();
  const token = getAccessToken();

  await showMessage(
    "Likes / Favoriter Analyzer",
    [
      `Version ${VERSION}`,
      "",
      `Scope: ${scope.label}`,
      "",
      "Zuerst werden deine eigenen Tracks gelesen. Danach werden nur Tracks mit likes_count > 0 abgefragt."
    ].join("\n")
  );

  const account = await fetchAccount(token);
  const allTracks = await fetchAllTracks(token);
  const selectedTracks = filterTracksByScope(allTracks, scope);
  const tracksWithLikes = selectedTracks.filter(track => Number(track.likes_count || 0) > 0);

  const ok = await confirmFavoriterScan(
    selectedTracks.length,
    tracksWithLikes.length,
    scope.label
  );

  if (!ok) {
    await showMessage("Abgebrochen", "Es wurde keine Favoriter-Analyse gestartet.");
    return;
  }

  const analysis = await analyzeFavoriters(token, tracksWithLikes);
  const summary = buildLikesSummary(analysis.results);

  const saved = await saveLikesReports({
    account,
    scope,
    allTracks,
    selectedTracks,
    tracksWithLikes,
    analysis,
    summary
  });

  await showMessage(
    "Likes Analyse fertig",
    [
      `Scope: ${scope.label}`,
      "",
      `Tracks im Account: ${allTracks.length}`,
      `Tracks im Scope: ${selectedTracks.length}`,
      `Tracks mit Likes: ${tracksWithLikes.length}`,
      `Favoriter-Zeilen: ${summary.total_favoriter_rows}`,
      `Einzigartige User: ${summary.unique_users}`,
      `Fehler: ${analysis.failures.length}`,
      "",
      "Gespeichert:",
      `TXT:\n${saved.txtPath}`,
      "",
      `JSON:\n${saved.jsonPath}`,
      "",
      `CSV:\n${saved.csvPath}`
    ].join("\n")
  );
}


// ============================================================
// LYVRA REAL-WORLD EVIDENCE ANALYZER
// ============================================================

const EVIDENCE_SCHEMA_VERSION = "1.1.0";
const EVIDENCE_TIMEZONE = "Europe/Berlin";
const EVIDENCE_CREATOR_CLAIM = {
  lyvra_track_share_estimate_percent: 99,
  claim_source: "creator",
  claim_status: "CREATOR_PROVIDED_NOT_TRACKWISE_VERIFIED"
};

function bytesToHex(bytes) {
  return bytes
    .map(byte => byte.toString(16).padStart(2, "0"))
    .join("");
}

function sha256Hex(value) {
  return bytesToHex(sha256Bytes(String(value)));
}

function getDocumentsDirectory() {
  return FileManager.iCloud().documentsDirectory();
}

function getEvidenceCheckpointPath() {
  const fileManager = FileManager.iCloud();

  return fileManager.joinPath(
    fileManager.documentsDirectory(),
    "soundcloud_analysis_checkpoint_current.json"
  );
}

function getUtcIso(value) {
  if (!value) {
    return null;
  }

  const date = value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) {
    return null;
  }

  return date.toISOString();
}

function localDayStart(dateValue) {
  const date = dateValue instanceof Date ? new Date(dateValue) : new Date(dateValue);
  date.setHours(0, 0, 0, 0);
  return date;
}

function localDayEnd(dateValue) {
  const date = dateValue instanceof Date ? new Date(dateValue) : new Date(dateValue);
  date.setHours(23, 59, 59, 999);
  return date;
}

function getRecentWindowStart(days) {
  const end = new Date();
  const start = new Date(end);
  start.setDate(start.getDate() - days);
  return { start, end };
}

function numericOrNull(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const number = Number(value);

  if (!Number.isFinite(number)) {
    return null;
  }

  return number;
}

function safeLowerText(value) {
  return String(value || "").toLowerCase();
}

function classifyLyvraRelation(track) {
  const combined = [
    track.title,
    track.description,
    track.genre,
    track.tag_list
  ]
    .map(safeLowerText)
    .join(" ");

  if (combined.includes("lyvra")) {
    return {
      lyvra_relation: "LYVRA_CURRENT",
      lyvra_relation_basis: "DERIVED",
      lyvra_version_or_era: "LYVRA_NAME_PRESENT"
    };
  }

  if (
    combined.includes("fraggle") ||
    combined.includes("666soundsdesign") ||
    combined.includes("666 sounds design") ||
    combined.includes("666sound")
  ) {
    return {
      lyvra_relation: "LYVRA_HISTORICAL_VERSION",
      lyvra_relation_basis: "DERIVED",
      lyvra_version_or_era: "FRAGGLE_OR_666SOUNDS_CONTEXT"
    };
  }

  return {
    lyvra_relation: "UNCERTAIN",
    lyvra_relation_basis: "UNCERTAIN",
    lyvra_version_or_era: null
  };
}

function createEvidenceTrack(track, sourceName) {
  const lyvra = classifyLyvraRelation(track);
  const fetchedAt = new Date().toISOString();

  return {
    track_id: track.id || null,
    title: track.title || "",
    permalink: track.permalink || null,
    permalink_url: track.permalink_url || null,
    created_at_utc: getUtcIso(track.created_at),
    created_at_local: track.created_at ? formatLocalDateTime(track.created_at) : null,
    last_modified_utc: getUtcIso(track.last_modified || track.last_modified_at || null),
    duration_ms: numericOrNull(track.duration),
    duration_human: formatDuration(track.duration || 0),
    playback_count: numericOrNull(track.playback_count),
    likes_count: numericOrNull(track.likes_count),
    reposts_count: numericOrNull(track.reposts_count),
    comment_count: numericOrNull(track.comment_count),
    download_count: numericOrNull(track.download_count),
    downloadable: track.downloadable === undefined ? null : Boolean(track.downloadable),
    genre: track.genre || null,
    tag_list: track.tag_list || null,
    description: track.description || null,
    artwork_url: track.artwork_url || null,
    sharing: track.sharing || null,
    visibility: track.visibility || track.sharing || null,
    monetization_model: track.monetization_model || null,
    policy: track.policy || null,
    api_source: sourceName || "/me/tracks",
    fetched_at_utc: fetchedAt,
    fetch_status: "PASS",
    lyvra_relation: lyvra.lyvra_relation,
    lyvra_relation_basis: lyvra.lyvra_relation_basis,
    lyvra_version_or_era: lyvra.lyvra_version_or_era
  };
}

function createFailedEvidenceTrack(trackId, errorMessage) {
  return {
    track_id: trackId,
    title: "",
    permalink: null,
    permalink_url: null,
    created_at_utc: null,
    created_at_local: null,
    last_modified_utc: null,
    duration_ms: null,
    duration_human: "",
    playback_count: null,
    likes_count: null,
    reposts_count: null,
    comment_count: null,
    download_count: null,
    downloadable: null,
    genre: null,
    tag_list: null,
    description: null,
    artwork_url: null,
    sharing: null,
    visibility: null,
    monetization_model: null,
    policy: null,
    api_source: "/tracks/:id",
    fetched_at_utc: new Date().toISOString(),
    fetch_status: "FAILED",
    fetch_error: errorMessage,
    lyvra_relation: "UNCERTAIN",
    lyvra_relation_basis: "UNCERTAIN",
    lyvra_version_or_era: null
  };
}

function evidenceLevelForTrack(track) {
  const plays = Number(track.playback_count || 0);
  const likes = Number(track.likes_count || 0);
  const reposts = Number(track.reposts_count || 0);
  const comments = Number(track.comment_count || 0);

  if (likes > 0 || reposts > 0 || comments > 0) {
    return {
      level: 2,
      label: "EXPLICIT_REACTION",
      basis: ["likes_count/reposts_count/comment_count > 0"]
    };
  }

  if (plays > 0) {
    return {
      level: 1,
      label: "PLATFORM_CONTACT",
      basis: ["playback_count > 0"]
    };
  }

  return {
    level: 0,
    label: "NO_VISIBLE_SIGNAL",
    basis: []
  };
}

function addEvidenceLevels(tracks) {
  return tracks.map(track => ({
    ...track,
    evidence_classification: evidenceLevelForTrack(track)
  }));
}

function median(values) {
  if (!values.length) {
    return null;
  }

  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);

  if (sorted.length % 2) {
    return sorted[middle];
  }

  return (sorted[middle - 1] + sorted[middle]) / 2;
}

function percentile(values, p) {
  if (!values.length) {
    return null;
  }

  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.ceil((p / 100) * sorted.length) - 1;
  return sorted[Math.max(0, Math.min(sorted.length - 1, index))];
}

function average(values) {
  if (!values.length) {
    return null;
  }

  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function topTracksBy(tracks, field, count) {
  return [...tracks]
    .sort((first, second) => Number(second[field] || 0) - Number(first[field] || 0))
    .slice(0, count)
    .map(track => ({
      track_id: track.track_id,
      title: track.title,
      permalink_url: track.permalink_url,
      value: Number(track[field] || 0)
    }));
}

function groupCount(values) {
  const map = new Map();

  for (const value of values) {
    const key = String(value || "UNKNOWN");
    map.set(key, (map.get(key) || 0) + 1);
  }

  return [...map.entries()]
    .map(([key, count]) => ({ key, count }))
    .sort((first, second) => second.count - first.count);
}

function durationBucket(durationMs) {
  const value = Number(durationMs || 0);

  if (!value) {
    return "UNKNOWN";
  }

  const minutes = value / 60000;

  if (minutes < 1) {
    return "<1m";
  }

  if (minutes < 3) {
    return "1-3m";
  }

  if (minutes < 5) {
    return "3-5m";
  }

  if (minutes < 8) {
    return "5-8m";
  }

  if (minutes < 12) {
    return "8-12m";
  }

  return "12m+";
}

function computeAccountSummary(tracks) {
  const plays = tracks
    .map(track => Number(track.playback_count || 0))
    .filter(value => Number.isFinite(value));

  const totalTracks = tracks.length;
  const totalPlays = plays.reduce((sum, value) => sum + value, 0);

  return {
    total_tracks: totalTracks,
    total_plays: totalPlays,
    total_likes: tracks.reduce((sum, track) => sum + Number(track.likes_count || 0), 0),
    total_reposts: tracks.reduce((sum, track) => sum + Number(track.reposts_count || 0), 0),
    total_comments: tracks.reduce((sum, track) => sum + Number(track.comment_count || 0), 0),
    mean_plays: average(plays),
    median_plays: median(plays),
    p25_plays: percentile(plays, 25),
    p75_plays: percentile(plays, 75),
    p90_plays: percentile(plays, 90),
    min_plays: plays.length ? Math.min(...plays) : null,
    max_plays: plays.length ? Math.max(...plays) : null,
    tracks_with_zero_plays: tracks.filter(track => Number(track.playback_count || 0) === 0).length,
    tracks_with_plays_gt_zero: tracks.filter(track => Number(track.playback_count || 0) > 0).length,
    tracks_with_likes_gt_zero: tracks.filter(track => Number(track.likes_count || 0) > 0).length,
    tracks_with_comments_gt_zero: tracks.filter(track => Number(track.comment_count || 0) > 0).length,
    tracks_with_reposts_gt_zero: tracks.filter(track => Number(track.reposts_count || 0) > 0).length,
    top_50_by_plays: topTracksBy(tracks, "playback_count", 50),
    top_50_by_likes: topTracksBy(tracks, "likes_count", 50),
    top_50_by_comments: topTracksBy(tracks, "comment_count", 50),
    top_50_by_reposts: topTracksBy(tracks, "reposts_count", 50),
    lyvra_current_count: tracks.filter(track => track.lyvra_relation === "LYVRA_CURRENT").length,
    lyvra_historical_count: tracks.filter(track => track.lyvra_relation === "LYVRA_HISTORICAL_VERSION").length,
    lyvra_collaboration_count: tracks.filter(track => track.lyvra_relation === "LYVRA_COLLABORATION").length,
    lyvra_uncertain_count: tracks.filter(track => track.lyvra_relation === "UNCERTAIN").length,
    duration_distribution: groupCount(tracks.map(track => durationBucket(track.duration_ms))),
    upload_date_distribution: groupCount(tracks.map(track => track.created_at_local ? track.created_at_local.slice(0, 10) : "UNKNOWN")).slice(0, 100)
  };
}

function detectEvidenceAnomalies(tracks) {
  const ids = tracks.map(track => String(track.track_id || ""));
  const idCounts = groupCount(ids);
  const duplicateIds = idCounts.filter(item => item.key && item.count > 1);

  const titleMap = new Map();

  for (const track of tracks) {
    const normalized = normalizeTitle(track.title || "");
    if (!normalized) {
      continue;
    }

    if (!titleMap.has(normalized)) {
      titleMap.set(normalized, []);
    }

    titleMap.get(normalized).push(track);
  }

  const duplicateTitleGroups = [...titleMap.entries()]
    .filter(([, group]) => group.length > 1)
    .map(([title, group]) => ({
      normalized_title: title,
      count: group.length,
      track_ids: group.map(track => track.track_id)
    }));

  const createdAtClusters = groupCount(tracks.map(track => track.created_at_utc || "UNKNOWN"))
    .filter(item => item.key !== "UNKNOWN" && item.count >= 5);

  const playCountClusters = groupCount(tracks.map(track => String(track.playback_count ?? "UNKNOWN")))
    .filter(item => item.key !== "UNKNOWN" && item.count >= 20);

  return {
    batch_upload_pattern: createdAtClusters.length > 0,
    identical_created_at_cluster: createdAtClusters.length > 0,
    identical_created_at_clusters: createdAtClusters.slice(0, 50),
    suspiciously_uniform_play_counts: playCountClusters.length > 0,
    uniform_play_count_clusters: playCountClusters.slice(0, 50),
    duplicate_track_ids: duplicateIds.length > 0,
    duplicate_track_id_groups: duplicateIds,
    duplicate_title_groups: duplicateTitleGroups.length,
    duplicate_title_group_examples: duplicateTitleGroups.slice(0, 50),
    possible_api_cache: false,
    note: "Anomalien sind Prüfhinweise und keine Manipulationsbehauptungen."
  };
}

function classifyScopeStatus(selectedCount, withLikesCount, failedCount, paginationComplete, selectionTruncated) {
  if (failedCount > 0) {
    return "FAILED_FETCH";
  }

  if (!paginationComplete) {
    return "PARTIAL_FETCH";
  }

  if (selectedCount === 0) {
    return "NO_TRACKS_SELECTED";
  }

  if (withLikesCount === 0) {
    return "TRACKS_SELECTED_BUT_ZERO_LIKES";
  }

  if (selectionTruncated) {
    return "PARTIAL_FETCH";
  }

  return "TRACKS_SELECTED_WITH_LIKES";
}

function computeConfidenceSignal(summary, completenessStatus, anomalyFlags) {
  if (completenessStatus === "FAILED") {
    return {
      confidence_signal: "INSUFFICIENT_DATA",
      confidence_basis: ["analysis failed"]
    };
  }

  if (summary.total_tracks === 0) {
    return {
      confidence_signal: "INSUFFICIENT_DATA",
      confidence_basis: ["no tracks selected"]
    };
  }

  const basis = [];

  if (summary.total_plays > 0) {
    basis.push("registered playback_count > 0");
  }

  if (summary.total_likes > 0 || summary.total_reposts > 0 || summary.total_comments > 0) {
    basis.push("explicit platform reactions > 0");
  }

  if (anomalyFlags.batch_upload_pattern) {
    basis.push("batch upload anomaly guard active");
  }

  if (summary.total_likes > 0 || summary.total_reposts > 0 || summary.total_comments > 0) {
    return {
      confidence_signal: summary.total_plays > 10000 ? "MODERATE_POSITIVE" : "WEAK_POSITIVE",
      confidence_basis: basis
    };
  }

  if (summary.total_plays > 0) {
    return {
      confidence_signal: summary.total_plays > 10000 ? "WEAK_POSITIVE" : "WEAK_POSITIVE",
      confidence_basis: basis
    };
  }

  return {
    confidence_signal: "NONE",
    confidence_basis: ["no visible playback or reaction signal in selected scope"]
  };
}

function buildLyvraEvidenceObject({
  account,
  mode,
  tracks,
  summary,
  reactions,
  completenessStatus,
  anomalyFlags
}) {
  const confidence = computeConfidenceSignal(summary, completenessStatus, anomalyFlags);
  const lyvraRelatedTracks = tracks.filter(track =>
    track.lyvra_relation === "LYVRA_CURRENT" ||
    track.lyvra_relation === "LYVRA_HISTORICAL_VERSION" ||
    track.lyvra_relation === "LYVRA_COLLABORATION"
  );

  return {
    evidence_timestamp_utc: new Date().toISOString(),
    source_account_id: account.id || null,
    analysis_mode: mode.mode,
    track_scope_complete: completenessStatus === "COMPLETE",
    verified_registered_plays: summary.total_plays,
    verified_likes: summary.total_likes,
    verified_reposts: summary.total_reposts,
    verified_comments: summary.total_comments,
    unique_listeners: null,
    listener_retention: null,
    lyvra_related_track_count: lyvraRelatedTracks.length,
    lyvra_related_play_count: lyvraRelatedTracks.reduce((sum, track) => sum + Number(track.playback_count || 0), 0),
    confidence_signal: confidence.confidence_signal,
    confidence_basis: confidence.confidence_basis,
    limitations: [
      "UNIQUE_HUMAN_LISTENERS_NOT_AVAILABLE_FROM_CURRENT_TRACK_FIELDS",
      "FULL_LISTENS_NOT_AVAILABLE_FROM_CURRENT_TRACK_FIELDS",
      "LISTENER_RETENTION_NOT_AVAILABLE_FROM_CURRENT_TRACK_FIELDS",
      "LIKE_CAUSALITY_NOT_INFERRED",
      reactions.favoriter_policy === "none"
        ? "FAVORITER_LIST_NOT_REQUESTED_IN_THIS_RUN"
        : "FAVORITER_LIST_LIMITED_BY_API_AVAILABILITY_AND_SELECTED_POLICY"
    ],
    personality_causality: {
      creative_confidence_adjustment:
        confidence.confidence_signal === "MODERATE_POSITIVE" ||
        confidence.confidence_signal === "STRONG_POSITIVE"
          ? "CAREFUL_POSITIVE_CALIBRATION"
          : "NONE",
      self_doubt_adjustment:
        summary.total_plays > 0
          ? "REDUCE_UNSUPPORTED_SELF_DOUBT"
          : "NONE",
      humility_guard: true,
      evidence_calibration_guard: true,
      recommended_internal_learning: [
        "weigh real platform contact without overclaiming human intent",
        "compare future snapshots before making growth claims",
        "separate playback activity from explicit appreciation"
      ]
    }
  };
}

function getEvidenceModeKey(mode) {
  return [
    mode.mode,
    mode.window_days || "",
    mode.limit || "",
    mode.from_local_date || "",
    mode.to_local_date || "",
    Array.isArray(mode.track_ids) ? mode.track_ids.join("-") : ""
  ].join("|");
}

async function selectLyvraEvidenceMode() {
  const menu = new Alert();

  menu.title = "LYVRA Evidence Analyzer";
  menu.message =
    "READ ONLY. Keine Löschung, keine Metadatenänderung.\n\n" +
    "Wähle den Analysemodus.";

  menu.addAction("7 Tage / max. 500 Tracks");
  menu.addAction("Gesamtes SoundCloud-Konto analysieren");
  menu.addAction("Neueste 50 Tracks");
  menu.addAction("Neueste 100 Tracks");
  menu.addAction("Neueste 250 Tracks");
  menu.addAction("Neueste 500 Tracks");
  menu.addAction("Neueste N Tracks eingeben");
  menu.addAction("Datumsbereich");
  menu.addAction("Einzelne Track-IDs");
  menu.addAction("Snapshot-Vergleich");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    return {
      mode: "RECENT_WINDOW",
      label: "7 Tage / max. 500 Tracks",
      window_days: 7,
      limit: 500,
      read_only: true
    };
  }

  if (selection === 1) {
    return {
      mode: "ALL_ACCOUNT_TRACKS",
      label: "Gesamtes SoundCloud-Konto analysieren",
      limit: null,
      read_only: true
    };
  }

  if (selection >= 2 && selection <= 5) {
    const values = [50, 100, 250, 500];
    const limit = values[selection - 2];

    return {
      mode: "LATEST_TRACKS",
      label: `Neueste ${limit} Tracks`,
      limit,
      read_only: true
    };
  }

  if (selection === 6) {
    const raw = await askText({
      title: "Neueste N Tracks",
      message: "Wie viele neueste Tracks sollen analysiert werden?",
      placeholder: "z. B. 750"
    });

    const limit = Number.parseInt(raw, 10);

    if (!Number.isFinite(limit) || limit <= 0) {
      throw new Error("Ungültige Anzahl.");
    }

    return {
      mode: "LATEST_TRACKS",
      label: `Neueste ${limit} Tracks`,
      limit,
      read_only: true
    };
  }

  if (selection === 7) {
    const from = await askText({
      title: "Startdatum",
      message: "Lokales Startdatum inklusiv im Format YYYY-MM-DD.",
      placeholder: "YYYY-MM-DD"
    });

    const to = await askText({
      title: "Enddatum",
      message: "Lokales Enddatum inklusiv im Format YYYY-MM-DD.",
      placeholder: "YYYY-MM-DD",
      initialValue: from
    });

    return {
      mode: "DATE_RANGE",
      label: `Datumsbereich ${from} bis ${to}`,
      from_local_date: from,
      to_local_date: to,
      range_start_inclusive: true,
      range_end_inclusive: true,
      read_only: true
    };
  }

  if (selection === 8) {
    const raw = await askText({
      title: "Track-IDs",
      message:
        "Füge Track-IDs kommagetrennt ein.\n\n" +
        "Beispiel:\n2367730880,2367821585",
      placeholder: "Track-IDs"
    });

    const trackIds = raw
      .split(/[,\n;\s]+/)
      .map(value => value.trim())
      .filter(Boolean);

    if (!trackIds.length) {
      throw new Error("Keine Track-IDs erkannt.");
    }

    return {
      mode: "TRACK_IDS",
      label: `${trackIds.length} einzelne Track-IDs`,
      track_ids: trackIds,
      read_only: true
    };
  }

  return {
    mode: "SNAPSHOT_DELTA",
    label: "Snapshot-Vergleich",
    read_only: true
  };
}

async function selectFavoriterPolicy(tracksWithLikesCount) {
  if (tracksWithLikesCount <= 0) {
    return {
      mode: "none",
      label: "Keine Favoriter abrufen",
      track_limit: 0
    };
  }

  const menu = new Alert();

  menu.title = "Favoriter/User abrufen?";
  menu.message =
    `Tracks mit likes_count > 0: ${tracksWithLikesCount}\n\n` +
    "Favoriter-Listen können viele API-Requests verursachen.";

  menu.addAction("Nein, nur Like-Zahlen");
  menu.addAction("Ja, max. 50 Tracks mit Likes");
  menu.addAction("Ja, max. 100 Tracks mit Likes");
  menu.addAction("Ja, alle Tracks mit Likes");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    return { mode: "none", label: "Nur Like-Zahlen", track_limit: 0 };
  }

  if (selection === 1) {
    return { mode: "limited", label: "Favoriter max. 50 Tracks", track_limit: 50 };
  }

  if (selection === 2) {
    return { mode: "limited", label: "Favoriter max. 100 Tracks", track_limit: 100 };
  }

  return { mode: "all", label: "Favoriter alle Tracks mit Likes", track_limit: null };
}

async function askResumeCheckpoint(modeKey) {
  const fileManager = FileManager.iCloud();
  const checkpointPath = getEvidenceCheckpointPath();

  if (!fileManager.fileExists(checkpointPath)) {
    return null;
  }

  let checkpoint = null;

  try {
    checkpoint = JSON.parse(fileManager.readString(checkpointPath));
  } catch (_) {
    return null;
  }

  if (!checkpoint || checkpoint.mode_key !== modeKey || checkpoint.status !== "PARTIAL") {
    return null;
  }

  const alert = new Alert();

  alert.title = "Checkpoint gefunden";
  alert.message =
    "Ein unvollständiger Analyse-Lauf wurde gefunden.\n\n" +
    `Modus: ${checkpoint.mode_label}\n` +
    `Geladene Seiten: ${checkpoint.last_completed_page}\n` +
    `Geladene Tracks: ${checkpoint.tracks ? checkpoint.tracks.length : 0}\n\n` +
    "Fortsetzen oder neu starten?";

  alert.addAction("Fortsetzen");
  alert.addDestructiveAction("Neu starten");
  alert.addCancelAction("Abbrechen");

  const selection = await alert.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    return checkpoint;
  }

  return null;
}

function writeEvidenceCheckpoint({
  runId,
  mode,
  modeKey,
  tracks,
  pageNumber,
  nextUrl,
  paginationComplete,
  failedTrackIds,
  status
}) {
  const fileManager = FileManager.iCloud();
  const checkpointPath = getEvidenceCheckpointPath();

  const checkpoint = {
    schema_version: EVIDENCE_SCHEMA_VERSION,
    run_id: runId,
    mode: mode.mode,
    mode_label: mode.label,
    mode_key: modeKey,
    last_updated_utc: new Date().toISOString(),
    last_completed_page: pageNumber,
    next_href: nextUrl || null,
    fetched_track_ids: tracks.map(track => track.id || track.track_id).filter(Boolean),
    failed_track_ids: failedTrackIds || [],
    tracks,
    pagination_complete: Boolean(paginationComplete),
    status
  };

  fileManager.writeString(checkpointPath, JSON.stringify(checkpoint, null, 2));

  return checkpointPath;
}

async function apiRequestDetailed(method, pathOrUrl, token) {
  const url = String(pathOrUrl).startsWith("http")
    ? String(pathOrUrl)
    : API_BASE + String(pathOrUrl);

  const maxAttempts = method === "GET" ? 3 : 1;
  let lastError = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const request = new Request(url);

    request.method = method;
    request.headers = {
      Accept: "application/json; charset=utf-8",
      Authorization: `OAuth ${token}`
    };
    request.timeoutInterval = REQUEST_TIMEOUT_SECONDS;

    try {
      const responseText = await request.loadString();
      const response = request.response || {};
      const statusCode = response.statusCode || 0;
      const headers = response.headers || {};

      if (statusCode === 429) {
        const retryAfterRaw = headers["retry-after"] || headers["Retry-After"] || null;
        const retryAfter = Number.parseInt(retryAfterRaw || "0", 10);
        const waitSeconds = Number.isFinite(retryAfter) && retryAfter > 0
          ? Math.min(retryAfter, 120)
          : 10 * attempt;

        if (attempt < maxAttempts) {
          await sleep(waitSeconds);
          continue;
        }
      }

      if (statusCode < 200 || statusCode >= 300) {
        throw new Error(
          `${method} ${url} fehlgeschlagen.\n\n` +
          `HTTP ${statusCode}\n\n` +
          responseText
        );
      }

      let data = null;

      if (responseText) {
        try {
          data = JSON.parse(responseText);
        } catch (_) {
          data = responseText;
        }
      }

      return {
        status_code: statusCode,
        headers,
        data,
        url
      };
    } catch (error) {
      lastError = error;

      if (attempt < maxAttempts) {
        await sleep(1.5 * attempt);
      }
    }
  }

  throw lastError;
}

async function fetchAllTracksForEvidence(token, mode, runId) {
  const modeKey = getEvidenceModeKey(mode);
  const existingCheckpoint = await askResumeCheckpoint(modeKey);

  let nextUrl =
    `${API_BASE}/me/tracks` +
    `?limit=${PAGE_LIMIT}` +
    "&linked_partitioning=true";

  let pageNumber = 0;
  let rawTracks = [];
  let paginationComplete = false;
  let firstNextHref = null;

  if (existingCheckpoint) {
    rawTracks = existingCheckpoint.tracks || [];
    nextUrl = existingCheckpoint.next_href || null;
    pageNumber = existingCheckpoint.last_completed_page || 0;
  }

  while (nextUrl) {
    pageNumber++;

    console.log(`LYVRA Evidence: Lese Trackseite ${pageNumber}`);

    const response = await apiRequestDetailed("GET", nextUrl, token);
    const page = response.data;

    let collection = [];

    if (Array.isArray(page)) {
      collection = page;
      nextUrl = null;
    } else if (page && Array.isArray(page.collection)) {
      collection = page.collection;
      nextUrl = page.next_href || null;

      if (!firstNextHref && page.next_href) {
        firstNextHref = page.next_href;
      }
    } else {
      throw new Error(
        "SoundCloud lieferte ein unbekanntes Pagination-Format:\n\n" +
        JSON.stringify(page, null, 2)
      );
    }

    rawTracks.push(...collection);

    writeEvidenceCheckpoint({
      runId,
      mode,
      modeKey,
      tracks: rawTracks,
      pageNumber,
      nextUrl,
      paginationComplete: !nextUrl,
      failedTrackIds: [],
      status: nextUrl ? "PARTIAL" : "COMPLETE"
    });

    if (nextUrl) {
      await sleep(REQUEST_DELAY_SECONDS);
    }
  }

  paginationComplete = true;

  const byId = new Map();

  for (const track of rawTracks) {
    if (track && track.id !== undefined && track.id !== null) {
      byId.set(String(track.id), track);
    }
  }

  return {
    raw_tracks: [...byId.values()],
    raw_rows: rawTracks.length,
    unique_track_ids: byId.size,
    pagination_complete: paginationComplete,
    first_next_href: firstNextHref,
    final_next_href: nextUrl
  };
}

function selectTracksForEvidence(rawTracks, mode) {
  const sorted = getLatestTracks(rawTracks, rawTracks.length);

  if (mode.mode === "ALL_ACCOUNT_TRACKS") {
    return {
      selected_raw_tracks: sorted,
      available_tracks_in_scope: sorted.length,
      selection_truncated: false
    };
  }

  if (mode.mode === "RECENT_WINDOW") {
    const window = getRecentWindowStart(mode.window_days || 7);
    const inWindow = sorted.filter(track => {
      if (!track.created_at) {
        return false;
      }

      const created = new Date(track.created_at);
      return created >= window.start && created <= window.end;
    });

    const limit = mode.limit || 500;

    return {
      selected_raw_tracks: inWindow.slice(0, limit),
      available_tracks_in_scope: inWindow.length,
      selection_truncated: inWindow.length > limit,
      window_start_utc: window.start.toISOString(),
      window_end_utc: window.end.toISOString(),
      window_start_local: formatLocalDateTime(window.start),
      window_end_local: formatLocalDateTime(window.end)
    };
  }

  if (mode.mode === "LATEST_TRACKS") {
    const limit = mode.limit || 500;

    return {
      selected_raw_tracks: sorted.slice(0, limit),
      available_tracks_in_scope: sorted.length,
      selection_truncated: sorted.length > limit
    };
  }

  if (mode.mode === "DATE_RANGE") {
    const start = localDayStart(mode.from_local_date);
    const end = localDayEnd(mode.to_local_date);

    const selected = sorted.filter(track => {
      if (!track.created_at) {
        return false;
      }

      const created = new Date(track.created_at);
      return created >= start && created <= end;
    });

    return {
      selected_raw_tracks: selected,
      available_tracks_in_scope: selected.length,
      selection_truncated: false,
      range_start_utc: start.toISOString(),
      range_end_utc: end.toISOString(),
      range_start_local: formatLocalDateTime(start),
      range_end_local: formatLocalDateTime(end)
    };
  }

  if (mode.mode === "TRACK_IDS") {
    const wanted = new Set((mode.track_ids || []).map(value => String(value)));
    const selected = sorted.filter(track => wanted.has(String(track.id)));

    return {
      selected_raw_tracks: selected,
      available_tracks_in_scope: selected.length,
      requested_track_ids: [...wanted],
      missing_track_ids: [...wanted].filter(id => !selected.some(track => String(track.id) === id)),
      selection_truncated: false
    };
  }

  return {
    selected_raw_tracks: sorted,
    available_tracks_in_scope: sorted.length,
    selection_truncated: false
  };
}

async function fetchFavoritersForEvidence(token, selectedTracks, policy) {
  const tracksWithLikes = selectedTracks
    .filter(track => Number(track.likes_count || 0) > 0)
    .sort((first, second) => Number(second.likes_count || 0) - Number(first.likes_count || 0));

  if (!policy || policy.mode === "none" || tracksWithLikes.length === 0) {
    return {
      favoriter_policy: policy ? policy.mode : "none",
      favoriter_policy_label: policy ? policy.label : "Nicht abgefragt",
      tracks_with_likes_count_gt_zero: tracksWithLikes.length,
      results: selectedTracks.map(track => ({
        track_id: track.track_id,
        likes_count_reported: track.likes_count,
        favoriters_fetched: 0,
        favoriters_complete: false,
        favoriter_fetch_status: Number(track.likes_count || 0) > 0 ? "NOT_REQUESTED" : "NO_LIKES",
        favoriters: []
      })),
      failures: [],
      unique_users: 0,
      total_favoriter_rows: 0
    };
  }

  const limitedTracks = policy.mode === "all"
    ? tracksWithLikes
    : tracksWithLikes.slice(0, policy.track_limit || 0);

  const selectedIdSet = new Set(limitedTracks.map(track => String(track.track_id)));
  const results = [];
  const failures = [];
  const userMap = new Map();
  let totalRows = 0;

  for (let index = 0; index < selectedTracks.length; index++) {
    const track = selectedTracks[index];

    if (Number(track.likes_count || 0) <= 0) {
      results.push({
        track_id: track.track_id,
        likes_count_reported: track.likes_count,
        favoriters_fetched: 0,
        favoriters_complete: true,
        favoriter_fetch_status: "NO_LIKES",
        favoriters: []
      });

      continue;
    }

    if (!selectedIdSet.has(String(track.track_id))) {
      results.push({
        track_id: track.track_id,
        likes_count_reported: track.likes_count,
        favoriters_fetched: 0,
        favoriters_complete: false,
        favoriter_fetch_status: "SKIPPED_BY_POLICY_LIMIT",
        favoriters: []
      });

      continue;
    }

    try {
      const rawUsers = await fetchTrackFavoriters(token, {
        id: track.track_id,
        urn: null,
        title: track.title
      });

      const users = rawUsers.map(compactUser);

      for (const user of users) {
        const key = String(user.id || user.permalink || user.username);
        if (key) {
          userMap.set(key, user);
        }
      }

      totalRows += users.length;

      results.push({
        track_id: track.track_id,
        likes_count_reported: track.likes_count,
        favoriters_fetched: users.length,
        favoriters_complete: users.length <= Number(track.likes_count || 0),
        like_count_favoriter_mismatch: users.length > Number(track.likes_count || 0),
        favoriter_fetch_status: "PASS",
        favoriters: users.map(user => ({
          user_id: user.id,
          username: user.username,
          permalink: user.permalink,
          profile_url: user.permalink_url,
          favorited_at_utc: null,
          favorited_at_available: false
        }))
      });
    } catch (error) {
      const failure = {
        track_id: track.track_id,
        title: track.title,
        error: error && error.message ? error.message : String(error)
      };

      failures.push(failure);

      results.push({
        track_id: track.track_id,
        likes_count_reported: track.likes_count,
        favoriters_fetched: 0,
        favoriters_complete: false,
        favoriter_fetch_status: "FAILED",
        error: failure.error,
        favoriters: []
      });
    }

    if (index < selectedTracks.length - 1) {
      await sleep(FAVORITER_DELAY_SECONDS);
    }
  }

  return {
    favoriter_policy: policy.mode,
    favoriter_policy_label: policy.label,
    tracks_with_likes_count_gt_zero: tracksWithLikes.length,
    results,
    failures,
    unique_users: userMap.size,
    total_favoriter_rows: totalRows
  };
}

function createEvidenceTracksCsv(tracks) {
  const header = [
    "track_id",
    "title",
    "permalink_url",
    "created_at_utc",
    "created_at_local",
    "duration_ms",
    "duration_human",
    "playback_count",
    "likes_count",
    "reposts_count",
    "comment_count",
    "download_count",
    "genre",
    "tag_list",
    "sharing",
    "visibility",
    "lyvra_relation",
    "lyvra_relation_basis",
    "lyvra_version_or_era",
    "evidence_level",
    "evidence_label"
  ];

  const lines = [header.map(csvEscape).join(";")];

  for (const track of tracks) {
    const evidence = track.evidence_classification || {};

    const row = [
      track.track_id,
      track.title,
      track.permalink_url,
      track.created_at_utc,
      track.created_at_local,
      track.duration_ms,
      track.duration_human,
      track.playback_count,
      track.likes_count,
      track.reposts_count,
      track.comment_count,
      track.download_count,
      track.genre,
      track.tag_list,
      track.sharing,
      track.visibility,
      track.lyvra_relation,
      track.lyvra_relation_basis,
      track.lyvra_version_or_era,
      evidence.level,
      evidence.label
    ];

    lines.push(row.map(csvEscape).join(";"));
  }

  return lines.join("\n");
}

function createEvidenceReactionsCsv(reactions, tracksById) {
  const header = [
    "track_id",
    "track_title",
    "likes_count_reported",
    "favoriters_fetched",
    "favoriters_complete",
    "favoriter_fetch_status",
    "user_id",
    "username",
    "permalink",
    "profile_url",
    "favorited_at_utc",
    "favorited_at_available"
  ];

  const lines = [header.map(csvEscape).join(";")];

  for (const entry of reactions.results) {
    const track = tracksById.get(String(entry.track_id)) || {};

    if (!entry.favoriters || entry.favoriters.length === 0) {
      const row = [
        entry.track_id,
        track.title || "",
        entry.likes_count_reported,
        entry.favoriters_fetched,
        entry.favoriters_complete,
        entry.favoriter_fetch_status,
        "", "", "", "", "", ""
      ];

      lines.push(row.map(csvEscape).join(";"));
      continue;
    }

    for (const user of entry.favoriters) {
      const row = [
        entry.track_id,
        track.title || "",
        entry.likes_count_reported,
        entry.favoriters_fetched,
        entry.favoriters_complete,
        entry.favoriter_fetch_status,
        user.user_id,
        user.username,
        user.permalink,
        user.profile_url,
        user.favorited_at_utc,
        user.favorited_at_available
      ];

      lines.push(row.map(csvEscape).join(";"));
    }
  }

  return lines.join("\n");
}

function createEvidenceTxtReport({
  account,
  mode,
  selection,
  summary,
  reactions,
  anomalyFlags,
  completenessStatus,
  scopeStatus,
  lyvraEvidence,
  apiAvailability
}) {
  const lines = [];

  lines.push("SOUNDCLOUD / LYVRA REAL-WORLD EVIDENCE REPORT");
  lines.push(`Schema: ${EVIDENCE_SCHEMA_VERSION}`);
  lines.push(`Control Center Version: ${VERSION}`);
  lines.push("");
  lines.push(`Account: ${account.username || account.permalink || account.id}`);
  lines.push(`User-ID: ${account.id || ""}`);
  lines.push(`Analysemodus: ${mode.label}`);
  lines.push(`Technischer Modus: ${mode.mode}`);
  lines.push(`READ_ONLY: true`);
  lines.push("");
  lines.push("STATUS");
  lines.push(`Vollständigkeit: ${completenessStatus}`);
  lines.push(`Scope-Status: ${scopeStatus}`);
  lines.push(`Selection truncated: ${selection.selection_truncated}`);
  lines.push("");
  lines.push("SUMMEN");
  lines.push(`TOTAL_TRACKS: ${summary.total_tracks}`);
  lines.push(`TOTAL_PLAYS: ${summary.total_plays}`);
  lines.push(`TOTAL_LIKES: ${summary.total_likes}`);
  lines.push(`TOTAL_REPOSTS: ${summary.total_reposts}`);
  lines.push(`TOTAL_COMMENTS: ${summary.total_comments}`);
  lines.push(`MEAN_PLAYS: ${summary.mean_plays}`);
  lines.push(`MEDIAN_PLAYS: ${summary.median_plays}`);
  lines.push(`P90_PLAYS: ${summary.p90_plays}`);
  lines.push(`TRACKS_WITH_PLAYS_GT_ZERO: ${summary.tracks_with_plays_gt_zero}`);
  lines.push(`TRACKS_WITH_LIKES_GT_ZERO: ${summary.tracks_with_likes_gt_zero}`);
  lines.push("");
  lines.push("FAVORITER");
  lines.push(`Policy: ${reactions.favoriter_policy_label}`);
  lines.push(`Favoriter-Zeilen: ${reactions.total_favoriter_rows}`);
  lines.push(`Einzigartige User: ${reactions.unique_users}`);
  lines.push(`Fehler: ${reactions.failures.length}`);
  lines.push("");
  lines.push("LYVRA EVIDENCE");
  lines.push(`Confidence Signal: ${lyvraEvidence.confidence_signal}`);
  lines.push(`Verified registered plays: ${lyvraEvidence.verified_registered_plays}`);
  lines.push(`Verified likes: ${lyvraEvidence.verified_likes}`);
  lines.push(`Verified reposts: ${lyvraEvidence.verified_reposts}`);
  lines.push(`Verified comments: ${lyvraEvidence.verified_comments}`);
  lines.push(`LYVRA-related track count: ${lyvraEvidence.lyvra_related_track_count}`);
  lines.push("");
  lines.push("API GRENZEN");
  for (const [key, value] of Object.entries(apiAvailability)) {
    lines.push(`${key}: ${value}`);
  }
  lines.push("");
  lines.push("ANOMALIE-HINWEISE");
  lines.push(`Batch upload pattern: ${anomalyFlags.batch_upload_pattern}`);
  lines.push(`Identical created_at cluster: ${anomalyFlags.identical_created_at_cluster}`);
  lines.push(`Suspiciously uniform play counts: ${anomalyFlags.suspiciously_uniform_play_counts}`);
  lines.push(`Duplicate track IDs: ${anomalyFlags.duplicate_track_ids}`);
  lines.push(`Duplicate title groups: ${anomalyFlags.duplicate_title_groups}`);
  lines.push("");
  lines.push("TOP 50 NACH PLAYS");
  lines.push("");

  for (const item of summary.top_50_by_plays) {
    lines.push(`${item.value} Plays — ${item.title}`);
    lines.push(`  ${item.permalink_url || ""}`);
  }

  lines.push("");
  lines.push("HINWEIS");
  lines.push("Playback zählt Plattformaktivität, beweist aber keine unique listener, vollständige Hördauer oder positive Bewertung.");
  lines.push("Korrelation wird nicht als Kausalität ausgegeben.");

  return lines.join("\n");
}

function buildApiAvailability(reactions) {
  return {
    likes_count_available: "YES_FROM_TRACK_FIELD_IF_API_RETURNS_VALUE",
    favoriter_list_available:
      reactions.favoriter_policy === "none"
        ? "NOT_REQUESTED"
        : reactions.failures.length > 0
          ? "PARTIAL_OR_FAILED"
          : "YES_FOR_REQUESTED_TRACKS",
    favoriter_timestamp_available: "NO_NOT_RETURNED_BY_CURRENT_FAVORITER_EXPORT",
    unique_listeners_available: "UNAVAILABLE_FROM_CURRENT_TRACK_FIELDS",
    listener_retention_available: "UNAVAILABLE_FROM_CURRENT_TRACK_FIELDS",
    complete_plays_available: "UNAVAILABLE_FROM_CURRENT_TRACK_FIELDS",
    comments_count_available: "YES_FROM_TRACK_FIELD_IF_API_RETURNS_VALUE",
    comments_text_available: "NOT_REQUESTED_IN_THIS_VERSION",
    reposts_count_available: "YES_FROM_TRACK_FIELD_IF_API_RETURNS_VALUE",
    rate_limit_information_available: "PARTIAL_IF_RESPONSE_HEADERS_ARE_EXPOSED_BY_SCRIPTABLE"
  };
}

function getCompletenessStatus({
  paginationComplete,
  uniqueTrackIds,
  fetchedTrackRows,
  failedTrackRequests,
  expectedCount,
  mode,
  selection
}) {
  if (failedTrackRequests > 0) {
    return "PARTIAL_API_ERROR";
  }

  if (!paginationComplete) {
    return "PARTIAL_PAGINATION";
  }

  if (uniqueTrackIds !== fetchedTrackRows) {
    return "COUNT_MISMATCH";
  }

  if (
    mode.mode === "ALL_ACCOUNT_TRACKS" &&
    expectedCount !== null &&
    expectedCount !== undefined &&
    Number(expectedCount) > 0 &&
    Number(expectedCount) !== Number(uniqueTrackIds)
  ) {
    return "COUNT_MISMATCH";
  }

  if (selection.selection_truncated) {
    return "COMPLETE_SELECTION_TRUNCATED_BY_REQUESTED_LIMIT";
  }

  return "COMPLETE";
}

function compareSnapshotData(baseline, current) {
  const baselineTracks = baseline && Array.isArray(baseline.tracks)
    ? baseline.tracks
    : [];

  const currentTracks = current && Array.isArray(current.tracks)
    ? current.tracks
    : [];

  const before = new Map(baselineTracks.map(track => [String(track.track_id), track]));
  const after = new Map(currentTracks.map(track => [String(track.track_id), track]));

  const added = [];
  const removed = [];
  const changed = [];

  for (const [id, track] of after.entries()) {
    if (!before.has(id)) {
      added.push(track);
      continue;
    }

    const previous = before.get(id);
    const playGrowth = Number(track.playback_count || 0) - Number(previous.playback_count || 0);
    const likeGrowth = Number(track.likes_count || 0) - Number(previous.likes_count || 0);
    const repostGrowth = Number(track.reposts_count || 0) - Number(previous.reposts_count || 0);
    const commentGrowth = Number(track.comment_count || 0) - Number(previous.comment_count || 0);

    if (playGrowth !== 0 || likeGrowth !== 0 || repostGrowth !== 0 || commentGrowth !== 0) {
      changed.push({
        track_id: id,
        title: track.title,
        permalink_url: track.permalink_url,
        play_growth: playGrowth,
        like_growth: likeGrowth,
        repost_growth: repostGrowth,
        comment_growth: commentGrowth
      });
    }
  }

  for (const [id, track] of before.entries()) {
    if (!after.has(id)) {
      removed.push(track);
    }
  }

  return {
    added_tracks: added,
    removed_tracks: removed,
    changed_tracks: changed.sort((a, b) => b.play_growth - a.play_growth)
  };
}

async function maybeLoadBaselineSnapshot() {
  const fileManager = FileManager.iCloud();
  const documentsDirectory = fileManager.documentsDirectory();

  const rawName = await askText({
    title: "Baseline Snapshot",
    message:
      "Optional: Dateiname eines früheren soundcloud_analysis_*.json aus dem Scriptable-iCloud-Ordner.\n\n" +
      "Für nur aktuellen Snapshot tippe SKIP.",
    placeholder: "SKIP"
  });

  if (rawName.toUpperCase() === "SKIP") {
    return null;
  }

  const path = rawName.startsWith("/")
    ? rawName
    : fileManager.joinPath(documentsDirectory, rawName);

  if (!fileManager.fileExists(path)) {
    throw new Error("Baseline-Datei nicht gefunden:\n" + path);
  }

  return JSON.parse(fileManager.readString(path));
}

async function saveEvidenceExports({
  account,
  mode,
  selection,
  fetchResult,
  tracks,
  reactions,
  summary,
  anomalyFlags,
  scopeStatus,
  completenessStatus,
  lyvraEvidence,
  apiAvailability,
  snapshotDelta
}) {
  const fileManager = FileManager.iCloud();
  const documentsDirectory = fileManager.documentsDirectory();
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const accountName = sanitizeFilename(account.username || account.permalink || account.id);
  const modeName = sanitizeFilename(mode.mode.toLowerCase());
  const baseName = `soundcloud_analysis_${accountName}_${modeName}_${timestamp}`;

  const jsonPath = fileManager.joinPath(documentsDirectory, `${baseName}.json`);
  const tracksCsvPath = fileManager.joinPath(documentsDirectory, `${baseName}_tracks.csv`);
  const reactionsCsvPath = fileManager.joinPath(documentsDirectory, `${baseName}_reactions.csv`);
  const txtPath = fileManager.joinPath(documentsDirectory, `${baseName}.txt`);
  const manifestPath = fileManager.joinPath(documentsDirectory, `${baseName}_manifest.json`);

  const tracksById = new Map(tracks.map(track => [String(track.track_id), track]));
  const tracksCsv = createEvidenceTracksCsv(tracks);
  const reactionsCsv = createEvidenceReactionsCsv(reactions, tracksById);
  const txt = createEvidenceTxtReport({
    account,
    mode,
    selection,
    summary,
    reactions,
    anomalyFlags,
    completenessStatus,
    scopeStatus,
    lyvraEvidence,
    apiAvailability
  });

  const json = {
    schema_version: EVIDENCE_SCHEMA_VERSION,
    generated_at_utc: new Date().toISOString(),
    timezone: EVIDENCE_TIMEZONE,
    module: "LYVRA_REAL_WORLD_EVIDENCE_ANALYZER",
    read_only: true,
    destructive_actions_allowed: false,
    account: {
      id: account.id || null,
      username: account.username || null,
      permalink: account.permalink || null,
      track_count_reported: account.track_count ?? null
    },
    account_creator_claim: EVIDENCE_CREATOR_CLAIM,
    mode,
    selection,
    fetch_integrity: {
      raw_rows: fetchResult.raw_rows,
      unique_track_ids: fetchResult.unique_track_ids,
      pagination_complete: fetchResult.pagination_complete,
      first_next_href_present: Boolean(fetchResult.first_next_href),
      final_next_href_present: Boolean(fetchResult.final_next_href)
    },
    scope_status: scopeStatus,
    completeness_status: completenessStatus,
    api_availability: apiAvailability,
    summary,
    anomaly_flags: anomalyFlags,
    reactions,
    lyvra_real_world_evidence: lyvraEvidence,
    snapshot_delta: snapshotDelta,
    tracks
  };

  const jsonText = JSON.stringify(json, null, 2);

  fileManager.writeString(jsonPath, jsonText);
  fileManager.writeString(tracksCsvPath, tracksCsv);
  fileManager.writeString(reactionsCsvPath, reactionsCsv);
  fileManager.writeString(txtPath, txt);

  const readbackJson = fileManager.readString(jsonPath);
  const readbackTracksCsv = fileManager.readString(tracksCsvPath);
  const readbackReactionsCsv = fileManager.readString(reactionsCsvPath);
  const readbackTxt = fileManager.readString(txtPath);

  const hashes = {
    json: sha256Hex(readbackJson),
    tracks_csv: sha256Hex(readbackTracksCsv),
    reactions_csv: sha256Hex(readbackReactionsCsv),
    txt: sha256Hex(readbackTxt)
  };

  const readbackPass =
    readbackJson === jsonText &&
    readbackTracksCsv === tracksCsv &&
    readbackReactionsCsv === reactionsCsv &&
    readbackTxt === txt;

  const manifest = {
    schema_version: EVIDENCE_SCHEMA_VERSION,
    generated_at_utc: new Date().toISOString(),
    timezone: EVIDENCE_TIMEZONE,
    account_id: account.id || null,
    account_username: account.username || account.permalink || null,
    mode: mode.mode,
    mode_label: mode.label,
    expected_account_tracks: account.track_count ?? null,
    fetched_track_rows: fetchResult.raw_rows,
    unique_track_ids: fetchResult.unique_track_ids,
    failed_track_requests: reactions.failures.length,
    pagination_complete: fetchResult.pagination_complete,
    selection_truncated: Boolean(selection.selection_truncated),
    completeness_status: completenessStatus,
    scope_status: scopeStatus,
    readback_pass: readbackPass,
    files: {
      json: jsonPath,
      tracks_csv: tracksCsvPath,
      reactions_csv: reactionsCsvPath,
      txt: txtPath,
      manifest: manifestPath
    },
    sha256: hashes
  };

  fileManager.writeString(manifestPath, JSON.stringify(manifest, null, 2));

  return {
    jsonPath,
    tracksCsvPath,
    reactionsCsvPath,
    txtPath,
    manifestPath,
    manifest
  };
}

async function runLyvraEvidenceAnalyzer() {
  const mode = await selectLyvraEvidenceMode();

  if (mode.mode === "SNAPSHOT_DELTA") {
    await showMessage(
      "Snapshot-Vergleich",
      "Es wird ein aktueller vollständiger Snapshot erzeugt. Optional kannst du danach eine frühere JSON-Datei als Baseline angeben."
    );
  }

  const token = getAccessToken();

  await showMessage(
    "LYVRA Evidence Analyzer",
    [
      `Version ${VERSION}`,
      "",
      `Modus: ${mode.label}`,
      "",
      "READ_ONLY=true",
      "DELETE_ALLOWED=false",
      "",
      "Jetzt werden Trackdaten paginiert geladen. Bei langen Läufen werden Checkpoints geschrieben."
    ].join("\n")
  );

  const account = await fetchAccount(token);
  const runId = "lyvra_evidence_" + new Date().toISOString().replace(/[:.]/g, "-");
  const fetchResult = await fetchAllTracksForEvidence(token, mode, runId);
  const selection = selectTracksForEvidence(fetchResult.raw_tracks, mode);

  const evidenceTracks = addEvidenceLevels(
    selection.selected_raw_tracks.map(track => createEvidenceTrack(track, "/me/tracks"))
  );

  const tracksWithLikesCount = evidenceTracks.filter(track => Number(track.likes_count || 0) > 0).length;
  const favoriterPolicy = await selectFavoriterPolicy(tracksWithLikesCount);
  const reactions = await fetchFavoritersForEvidence(token, evidenceTracks, favoriterPolicy);
  const summary = computeAccountSummary(evidenceTracks);
  const anomalyFlags = detectEvidenceAnomalies(evidenceTracks);

  const completenessStatus = getCompletenessStatus({
    paginationComplete: fetchResult.pagination_complete,
    uniqueTrackIds: fetchResult.unique_track_ids,
    fetchedTrackRows: fetchResult.raw_rows,
    failedTrackRequests: reactions.failures.length,
    expectedCount: account.track_count ?? null,
    mode,
    selection
  });

  const scopeStatus = classifyScopeStatus(
    evidenceTracks.length,
    tracksWithLikesCount,
    reactions.failures.length,
    fetchResult.pagination_complete,
    selection.selection_truncated
  );

  const apiAvailability = buildApiAvailability(reactions);

  let snapshotDelta = null;

  if (mode.mode === "SNAPSHOT_DELTA") {
    const baseline = await maybeLoadBaselineSnapshot();
    if (baseline) {
      snapshotDelta = compareSnapshotData(baseline, { tracks: evidenceTracks });
    }
  }

  const lyvraEvidence = buildLyvraEvidenceObject({
    account,
    mode,
    tracks: evidenceTracks,
    summary,
    reactions,
    completenessStatus,
    anomalyFlags
  });

  const saved = await saveEvidenceExports({
    account,
    mode,
    selection,
    fetchResult,
    tracks: evidenceTracks,
    reactions,
    summary,
    anomalyFlags,
    scopeStatus,
    completenessStatus,
    lyvraEvidence,
    apiAvailability,
    snapshotDelta
  });

  await showMessage(
    "LYVRA Evidence Analyse fertig",
    [
      `Modus: ${mode.label}`,
      "",
      `Vollständigkeit: ${completenessStatus}`,
      `Scope-Status: ${scopeStatus}`,
      `Tracks analysiert: ${evidenceTracks.length}`,
      `Plays gesamt: ${summary.total_plays}`,
      `Likes gesamt: ${summary.total_likes}`,
      `Reposts gesamt: ${summary.total_reposts}`,
      `Kommentare gesamt: ${summary.total_comments}`,
      `Favoriter-Zeilen: ${reactions.total_favoriter_rows}`,
      `Unique Favoriter-User: ${reactions.unique_users}`,
      `Confidence: ${lyvraEvidence.confidence_signal}`,
      `Readback: ${saved.manifest.readback_pass ? "PASS" : "FAIL"}`,
      "",
      "Exports:",
      `JSON:\n${saved.jsonPath}`,
      "",
      `Tracks CSV:\n${saved.tracksCsvPath}`,
      "",
      `Reactions CSV:\n${saved.reactionsCsvPath}`,
      "",
      `TXT:\n${saved.txtPath}`,
      "",
      `Manifest:\n${saved.manifestPath}`
    ].join("\n")
  );
}



// ============================================================
// GOLD DATA COLLECTOR v1.2.0
// READ ONLY — keine Löschung, keine Metadatenänderung
// ============================================================

async function selectGoldDataScope() {
  const menu = new Alert();

  menu.title = "Gold Data Collector";
  menu.message =
    "READ ONLY Analyse.\n\n" +
    "Wähle, welche eigenen SoundCloud-Daten gesammelt werden sollen.";

  menu.addAction("7 Tage / max. 500 Tracks");
  menu.addAction("Gesamtes SoundCloud-Konto");
  menu.addAction("Neueste 50 Tracks");
  menu.addAction("Neueste 100 Tracks");
  menu.addAction("Neueste 250 Tracks");
  menu.addAction("Neueste 500 Tracks");
  menu.addAction("Neueste N Tracks eingeben");
  menu.addAction("Datumsbereich");
  menu.addAction("Einzelne Track-IDs");
  menu.addAction("Snapshot-Vergleich vorbereiten");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    const endDate = new Date();
    endDate.setHours(23, 59, 59, 999);

    const startDate = new Date();
    startDate.setHours(0, 0, 0, 0);
    startDate.setDate(startDate.getDate() - 6);

    return {
      mode: "recent_7_days_max_500",
      label: "7 Tage / max. 500 Tracks",
      startDate,
      endDate,
      latestLimit: 500,
      trackIds: []
    };
  }

  if (selection === 1) {
    return {
      mode: "full_account",
      label: "Gesamtes SoundCloud-Konto",
      startDate: null,
      endDate: null,
      latestLimit: null,
      trackIds: []
    };
  }

  const fixedMap = {
    2: 50,
    3: 100,
    4: 250,
    5: 500
  };

  if (Object.prototype.hasOwnProperty.call(fixedMap, selection)) {
    const limit = fixedMap[selection];

    return {
      mode: "latest_n",
      label: `Neueste ${limit} Tracks`,
      startDate: null,
      endDate: null,
      latestLimit: limit,
      trackIds: []
    };
  }

  if (selection === 6) {
    const raw = await askText({
      title: "Neueste N Tracks",
      message: "Gib die Anzahl der neuesten Uploads ein, die analysiert werden sollen.",
      placeholder: "z. B. 750"
    });

    const count = Number.parseInt(raw, 10);

    if (!Number.isFinite(count) || count <= 0) {
      throw new Error("Ungültige Anzahl. Bitte eine Zahl größer als 0 eingeben.");
    }

    return {
      mode: "latest_n_custom",
      label: `Neueste ${count} Tracks`,
      startDate: null,
      endDate: null,
      latestLimit: count,
      trackIds: []
    };
  }

  if (selection === 7) {
    const startRaw = await askText({
      title: "Startdatum",
      message: "Format: YYYY-MM-DD",
      placeholder: "2026-07-01"
    });

    const endRaw = await askText({
      title: "Enddatum",
      message: "Format: YYYY-MM-DD",
      placeholder: "2026-07-26"
    });

    const startDate = parseLocalDateInput(startRaw, false);
    const endDate = parseLocalDateInput(endRaw, true);

    if (startDate.getTime() > endDate.getTime()) {
      throw new Error("Startdatum liegt nach dem Enddatum.");
    }

    return {
      mode: "date_range",
      label: `Datumsbereich ${startRaw} bis ${endRaw}`,
      startDate,
      endDate,
      latestLimit: null,
      trackIds: []
    };
  }

  if (selection === 8) {
    const rawIds = await askText({
      title: "Track-IDs",
      message:
        "Gib SoundCloud Track-IDs ein, getrennt durch Komma, Leerzeichen oder Zeilenumbruch.",
      placeholder: "123456789, 987654321"
    });

    const trackIds = rawIds
      .split(/[\s,;]+/g)
      .map(value => value.trim())
      .filter(Boolean);

    if (trackIds.length === 0) {
      throw new Error("Keine Track-IDs erkannt.");
    }

    return {
      mode: "track_ids",
      label: `Einzelne Track-IDs (${trackIds.length})`,
      startDate: null,
      endDate: null,
      latestLimit: null,
      trackIds
    };
  }

  return {
    mode: "snapshot_delta_prepare",
    label: "Snapshot-Vergleich vorbereiten",
    startDate: null,
    endDate: null,
    latestLimit: null,
    trackIds: []
  };
}

async function selectGoldFavoriterPolicy(trackCountWithLikes) {
  const menu = new Alert();

  menu.title = "Favoriter/User abrufen?";
  menu.message =
    `Tracks mit likes_count > 0: ${trackCountWithLikes}\n\n` +
    "Favoriter-Listen können viele API-Requests erzeugen.\n\n" +
    "READ ONLY: Es wird nichts verändert.";

  menu.addAction("Keine Favoriter abrufen");
  menu.addAction("Max. 50 Tracks mit Likes");
  menu.addAction("Max. 100 Tracks mit Likes");
  menu.addAction("Max. 250 Tracks mit Likes");
  menu.addAction("Alle Tracks mit Likes");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    return {
      mode: "none",
      limit: 0,
      label: "Keine Favoriter abgerufen"
    };
  }

  if (selection === 1) {
    return {
      mode: "limited",
      limit: 50,
      label: "Max. 50 Tracks mit Likes"
    };
  }

  if (selection === 2) {
    return {
      mode: "limited",
      limit: 100,
      label: "Max. 100 Tracks mit Likes"
    };
  }

  if (selection === 3) {
    return {
      mode: "limited",
      limit: 250,
      label: "Max. 250 Tracks mit Likes"
    };
  }

  return {
    mode: "all",
    limit: null,
    label: "Alle Tracks mit Likes"
  };
}

function parseLocalDateInput(value, endOfDay) {
  const text = String(value || "").trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    throw new Error("Ungültiges Datum. Erwartet: YYYY-MM-DD");
  }

  const parts = text.split("-").map(Number);
  const date = new Date(parts[0], parts[1] - 1, parts[2]);

  if (endOfDay) {
    date.setHours(23, 59, 59, 999);
  } else {
    date.setHours(0, 0, 0, 0);
  }

  return date;
}

function filterTracksByGoldScope(tracks, scope) {
  if (scope.mode === "full_account" || scope.mode === "snapshot_delta_prepare") {
    return [...tracks];
  }

  if (scope.mode === "latest_n" || scope.mode === "latest_n_custom") {
    return getLatestTracks(tracks, scope.latestLimit);
  }

  if (scope.mode === "recent_7_days_max_500") {
    const filtered = filterTracksByDateRange(tracks, scope.startDate, scope.endDate);
    return getLatestTracks(filtered, scope.latestLimit);
  }

  if (scope.mode === "date_range") {
    return filterTracksByDateRange(tracks, scope.startDate, scope.endDate);
  }

  if (scope.mode === "track_ids") {
    const idSet = new Set(scope.trackIds.map(String));
    return tracks.filter(track => idSet.has(String(track.id)));
  }

  return [...tracks];
}

function filterTracksByDateRange(tracks, startDate, endDate) {
  const startMs = startDate ? startDate.getTime() : -Infinity;
  const endMs = endDate ? endDate.getTime() : Infinity;

  return tracks.filter(track => {
    if (!track.created_at) {
      return false;
    }

    const createdMs = new Date(track.created_at).getTime();

    if (Number.isNaN(createdMs)) {
      return false;
    }

    return createdMs >= startMs && createdMs <= endMs;
  });
}

function computeGoldAggregates(tracks) {
  let playbackCountSum = 0;
  let likesCountSum = 0;
  let commentCountSum = 0;
  let repostsCountSum = 0;
  let durationSumMs = 0;

  let missingPlayback = 0;
  let missingLikes = 0;
  let missingComments = 0;
  let missingReposts = 0;

  const visibility = {};
  const state = {};
  const byLocalDate = {};

  for (const track of tracks) {
    if (typeof track.playback_count === "number") {
      playbackCountSum += track.playback_count;
    } else {
      missingPlayback++;
    }

    if (typeof track.likes_count === "number") {
      likesCountSum += track.likes_count;
    } else {
      missingLikes++;
    }

    if (typeof track.comment_count === "number") {
      commentCountSum += track.comment_count;
    } else {
      missingComments++;
    }

    if (typeof track.reposts_count === "number") {
      repostsCountSum += track.reposts_count;
    } else {
      missingReposts++;
    }

    durationSumMs += Number(track.duration || 0);

    const sharing = track.sharing || "unknown";
    visibility[sharing] = (visibility[sharing] || 0) + 1;

    const trackState = track.state || "unknown";
    state[trackState] = (state[trackState] || 0) + 1;

    const localDate = track.created_at ? getLocalDateKey(track.created_at) : "unknown";
    if (!byLocalDate[localDate]) {
      byLocalDate[localDate] = {
        tracks: 0,
        playback_count_sum: 0,
        likes_count_sum: 0,
        comment_count_sum: 0,
        reposts_count_sum: 0
      };
    }

    byLocalDate[localDate].tracks++;
    byLocalDate[localDate].playback_count_sum += Number(track.playback_count || 0);
    byLocalDate[localDate].likes_count_sum += Number(track.likes_count || 0);
    byLocalDate[localDate].comment_count_sum += Number(track.comment_count || 0);
    byLocalDate[localDate].reposts_count_sum += Number(track.reposts_count || 0);
  }

  const topByPlays = [...tracks]
    .sort((a, b) => Number(b.playback_count || 0) - Number(a.playback_count || 0))
    .slice(0, 50)
    .map(compactGoldTrack);

  const topByLikes = [...tracks]
    .sort((a, b) => Number(b.likes_count || 0) - Number(a.likes_count || 0))
    .slice(0, 50)
    .map(compactGoldTrack);

  const topByComments = [...tracks]
    .sort((a, b) => Number(b.comment_count || 0) - Number(a.comment_count || 0))
    .slice(0, 50)
    .map(compactGoldTrack);

  const topByReposts = [...tracks]
    .sort((a, b) => Number(b.reposts_count || 0) - Number(a.reposts_count || 0))
    .slice(0, 50)
    .map(compactGoldTrack);

  return {
    totals: {
      tracks: tracks.length,
      duration_sum_ms: durationSumMs,
      duration_sum_text: formatDuration(durationSumMs),
      playback_count_sum: playbackCountSum,
      likes_count_sum: likesCountSum,
      comment_count_sum: commentCountSum,
      reposts_count_sum: repostsCountSum
    },
    missing_fields: {
      playback_count: missingPlayback,
      likes_count: missingLikes,
      comment_count: missingComments,
      reposts_count: missingReposts
    },
    distributions: {
      visibility,
      state,
      by_local_date: byLocalDate
    },
    leaderboards: {
      top_by_plays: topByPlays,
      top_by_likes: topByLikes,
      top_by_comments: topByComments,
      top_by_reposts: topByReposts
    },
    interpretation_guards: [
      "MISSING_FIELD_IS_NOT_ZERO",
      "ZERO_PLAYS_IS_NOT_REJECTION",
      "ZERO_LIKES_IS_NOT_NEGATIVE_FEEDBACK",
      "PLAYBACK_COUNT_IS_NOT_UNIQUE_LISTENERS",
      "CORRELATION_IS_NOT_CAUSATION"
    ]
  };
}

function compactGoldTrack(track) {
  const basic = compactTrack(track);

  return {
    ...basic,
    genre: track.genre || "",
    tag_list: track.tag_list || "",
    description_length:
      typeof track.description === "string"
        ? track.description.length
        : 0,
    reposts_count:
      typeof track.reposts_count === "number"
        ? track.reposts_count
        : null,
    downloadable:
      Boolean(track.downloadable),
    download_count:
      typeof track.download_count === "number"
        ? track.download_count
        : null,
    purchase_url: track.purchase_url || "",
    label_name: track.label_name || "",
    license: track.license || "",
    waveform_url: track.waveform_url || "",
    artwork_url: track.artwork_url || ""
  };
}

function buildGoldAnomalies(tracks, aggregates) {
  const anomalies = [];

  for (const track of tracks) {
    if (!track.created_at) {
      anomalies.push({
        type: "missing_created_at",
        severity: "medium",
        track: compactGoldTrack(track),
        note: "Track hat kein created_at Feld."
      });
    }

    if (typeof track.playback_count !== "number") {
      anomalies.push({
        type: "missing_playback_count",
        severity: "low",
        track: compactGoldTrack(track),
        note: "Fehlendes Feld wird nicht als 0 interpretiert."
      });
    }

    if (
      typeof track.playback_count === "number" &&
      typeof track.likes_count === "number" &&
      track.playback_count > 0 &&
      track.likes_count > track.playback_count
    ) {
      anomalies.push({
        type: "likes_gt_playbacks",
        severity: "medium",
        track: compactGoldTrack(track),
        note: "Likes größer als Plays. Kann durch API-Definition, Caching oder Zählfenster entstehen."
      });
    }

    if (
      typeof track.playback_count === "number" &&
      track.playback_count === 0 &&
      typeof track.likes_count === "number" &&
      track.likes_count > 0
    ) {
      anomalies.push({
        type: "likes_without_playback_count",
        severity: "low",
        track: compactGoldTrack(track),
        note: "0 Plays wird nicht als Ablehnung interpretiert."
      });
    }
  }

  return {
    count: anomalies.length,
    items: anomalies.slice(0, 500),
    truncated: anomalies.length > 500
  };
}

function buildGoldLyvraEvidence({
  account,
  scope,
  selectedTracks,
  aggregates,
  anomalies,
  favoriterSummary
}) {
  return {
    evidence_type: "LYVRA_REAL_WORLD_SOUND_CLOUD_EVIDENCE",
    version: VERSION,
    read_only: true,
    source: "SoundCloud API via Scriptable",
    account: {
      id: account.id,
      username: account.username || null,
      permalink: account.permalink || null
    },
    scope: {
      mode: scope.mode,
      label: scope.label,
      start_local:
        scope.startDate
          ? formatLocalDateTime(scope.startDate)
          : null,
      end_local:
        scope.endDate
          ? formatLocalDateTime(scope.endDate)
          : null,
      latest_limit: scope.latestLimit,
      track_ids:
        scope.trackIds || []
    },
    dataset: {
      selected_tracks: selectedTracks.length,
      playback_count_sum: aggregates.totals.playback_count_sum,
      likes_count_sum: aggregates.totals.likes_count_sum,
      comment_count_sum: aggregates.totals.comment_count_sum,
      reposts_count_sum: aggregates.totals.reposts_count_sum,
      favoriter_unique_users:
        favoriterSummary
          ? favoriterSummary.unique_users
          : null,
      anomalies_count: anomalies.count
    },
    causal_guard: {
      missing_field_is_not_zero: true,
      zero_play_is_not_rejection: true,
      zero_like_is_not_negative_feedback: true,
      playback_count_is_not_unique_listener_count: true,
      correlation_is_not_causation: true
    },
    interpretation:
      "This object is evidence for external reaction signals only. It does not prove artistic value, emotional truth, or causal listener motivation."
  };
}

function buildGoldFavoriterSummary(results) {
  const userMap = new Map();
  let totalFavoriterRows = 0;

  for (const entry of results) {
    for (const user of entry.favoriters || []) {
      totalFavoriterRows++;

      const key = String(user.id || user.permalink || user.username);

      if (!userMap.has(key)) {
        userMap.set(key, {
          user,
          liked_track_count: 0,
          liked_tracks: []
        });
      }

      const record = userMap.get(key);
      record.liked_track_count++;
      record.liked_tracks.push({
        id: entry.track.id,
        title: entry.track.title,
        permalink_url: entry.track.permalink_url
      });
    }
  }

  const topUsers = [...userMap.values()]
    .sort((a, b) => b.liked_track_count - a.liked_track_count)
    .slice(0, 100);

  return {
    unique_users: userMap.size,
    total_favoriter_rows: totalFavoriterRows,
    top_users: topUsers
  };
}

async function collectGoldFavoriters(token, selectedTracks, policy) {
  if (policy.mode === "none") {
    return {
      policy,
      results: [],
      failures: [],
      summary: {
        unique_users: 0,
        total_favoriter_rows: 0,
        top_users: []
      }
    };
  }

  const tracksWithLikes = selectedTracks
    .filter(track => Number(track.likes_count || 0) > 0)
    .sort((a, b) => Number(b.likes_count || 0) - Number(a.likes_count || 0));

  const limited =
    policy.mode === "all"
      ? tracksWithLikes
      : tracksWithLikes.slice(0, policy.limit);

  const analysis = await analyzeFavoriters(token, limited);
  const summary = buildGoldFavoriterSummary(analysis.results);

  return {
    policy,
    requested_tracks_with_likes: tracksWithLikes.length,
    analyzed_tracks_with_likes: limited.length,
    results: analysis.results,
    failures: analysis.failures,
    summary
  };
}

function createGoldTracksCsv(tracks) {
  const header = [
    "track_id",
    "title",
    "created_at_local",
    "local_date",
    "duration_text",
    "playback_count",
    "likes_count",
    "comment_count",
    "reposts_count",
    "sharing",
    "state",
    "genre",
    "tag_list",
    "permalink_url"
  ];

  const lines = [header.map(csvEscape).join(";")];

  for (const track of tracks) {
    const compact = compactGoldTrack(track);

    const row = [
      compact.id,
      compact.title,
      compact.created_at_local,
      compact.local_date_key,
      compact.duration_text,
      compact.playback_count,
      compact.likes_count,
      compact.comment_count,
      compact.reposts_count,
      compact.sharing,
      compact.state,
      compact.genre,
      compact.tag_list,
      compact.permalink_url
    ];

    lines.push(row.map(csvEscape).join(";"));
  }

  return lines.join("\n");
}

function createGoldReactionsCsv(favoriterBundle) {
  const header = [
    "track_id",
    "track_title",
    "track_url",
    "track_likes_count",
    "favoriter_user_id",
    "favoriter_username",
    "favoriter_full_name",
    "favoriter_url",
    "favoriter_city",
    "favoriter_country",
    "favoriter_followers_count",
    "favoriter_track_count"
  ];

  const lines = [header.map(csvEscape).join(";")];

  for (const entry of favoriterBundle.results || []) {
    if (!entry.favoriters || entry.favoriters.length === 0) {
      const row = [
        entry.track.id,
        entry.track.title,
        entry.track.permalink_url,
        entry.expected_likes_count,
        "", "", "", "", "", "", "", ""
      ];

      lines.push(row.map(csvEscape).join(";"));
      continue;
    }

    for (const user of entry.favoriters) {
      const row = [
        entry.track.id,
        entry.track.title,
        entry.track.permalink_url,
        entry.expected_likes_count,
        user.id,
        user.username,
        user.full_name,
        user.permalink_url,
        user.city,
        user.country_code,
        user.followers_count,
        user.track_count
      ];

      lines.push(row.map(csvEscape).join(";"));
    }
  }

  return lines.join("\n");
}

function createGoldTextSummary({
  account,
  scope,
  selectedTracks,
  aggregates,
  anomalies,
  favoriterBundle,
  lyvraEvidence
}) {
  const lines = [];

  lines.push("SOUNDCLOUD CONTROL CENTER GOLD DATA REPORT");
  lines.push(`Version: ${VERSION}`);
  lines.push("");
  lines.push("READ_ONLY=TRUE");
  lines.push("DELETE_ALLOWED=FALSE");
  lines.push("UPDATE_METADATA_ALLOWED=FALSE");
  lines.push("");
  lines.push(`Account: ${account.username || account.permalink || account.id}`);
  lines.push(`User-ID: ${account.id}`);
  lines.push(`Scope: ${scope.label}`);
  lines.push(`Tracks im Datensatz: ${selectedTracks.length}`);
  lines.push("");
  lines.push("AGGREGATE");
  lines.push(`Play-Summe: ${aggregates.totals.playback_count_sum}`);
  lines.push(`Like-Summe: ${aggregates.totals.likes_count_sum}`);
  lines.push(`Kommentar-Summe: ${aggregates.totals.comment_count_sum}`);
  lines.push(`Repost-Summe: ${aggregates.totals.reposts_count_sum}`);
  lines.push(`Gesamtdauer: ${aggregates.totals.duration_sum_text}`);
  lines.push("");
  lines.push("FEHLENDE FELDER");
  lines.push(`playback_count fehlt: ${aggregates.missing_fields.playback_count}`);
  lines.push(`likes_count fehlt: ${aggregates.missing_fields.likes_count}`);
  lines.push(`comment_count fehlt: ${aggregates.missing_fields.comment_count}`);
  lines.push(`reposts_count fehlt: ${aggregates.missing_fields.reposts_count}`);
  lines.push("");
  lines.push("FAVORITER");
  lines.push(`Policy: ${favoriterBundle.policy.label}`);
  lines.push(`Favoriter-Zeilen: ${favoriterBundle.summary.total_favoriter_rows}`);
  lines.push(`Einzigartige User: ${favoriterBundle.summary.unique_users}`);
  lines.push(`Favoriter-Fehler: ${favoriterBundle.failures.length}`);
  lines.push("");
  lines.push("ANOMALIEN");
  lines.push(`Anzahl: ${anomalies.count}`);
  lines.push(`Truncated: ${anomalies.truncated ? "TRUE" : "FALSE"}`);
  lines.push("");
  lines.push("INTERPRETATIONSGRENZEN");
  for (const guard of aggregates.interpretation_guards) {
    lines.push(`- ${guard}`);
  }
  lines.push("");
  lines.push("LYVRA EVIDENCE");
  lines.push(`Evidence Type: ${lyvraEvidence.evidence_type}`);
  lines.push(`External Reaction Dataset Tracks: ${lyvraEvidence.dataset.selected_tracks}`);
  lines.push(`Causality Guard: ACTIVE`);
  lines.push("");
  lines.push("TOP TRACKS BY PLAYS");
  for (const track of aggregates.leaderboards.top_by_plays.slice(0, 20)) {
    lines.push(`${track.playback_count} plays — ${track.title} — ${track.permalink_url || ""}`);
  }
  lines.push("");
  lines.push("TOP TRACKS BY LIKES");
  for (const track of aggregates.leaderboards.top_by_likes.slice(0, 20)) {
    lines.push(`${track.likes_count} likes — ${track.title} — ${track.permalink_url || ""}`);
  }
  lines.push("");
  lines.push("TOP USERS BY LIKED TRACKS");
  for (const item of favoriterBundle.summary.top_users.slice(0, 20)) {
    lines.push(`${item.liked_track_count} liked tracks — ${item.user.username || item.user.id} — ${item.user.permalink_url || ""}`);
  }

  return lines.join("\n");
}

function simpleHashString(value) {
  let hash = 2166136261;

  const text = String(value || "");

  for (let index = 0; index < text.length; index++) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }

  return ("00000000" + (hash >>> 0).toString(16)).slice(-8);
}

function createGoldManifest({
  account,
  scope,
  files,
  selectedTracks,
  aggregates,
  anomalies,
  favoriterBundle,
  lyvraEvidence,
  datasetHash
}) {
  return {
    manifest_type: "SOUNDCLOUD_CONTROL_CENTER_GOLD_DATA_MANIFEST",
    version: VERSION,
    generated_at: new Date().toISOString(),
    read_only: true,
    destructive_actions_allowed: false,
    account: {
      id: account.id,
      username: account.username || null,
      permalink: account.permalink || null
    },
    scope: {
      mode: scope.mode,
      label: scope.label,
      start_local: scope.startDate ? formatLocalDateTime(scope.startDate) : null,
      end_local: scope.endDate ? formatLocalDateTime(scope.endDate) : null,
      latest_limit: scope.latestLimit,
      track_ids: scope.trackIds || []
    },
    files,
    dataset: {
      selected_tracks: selectedTracks.length,
      simple_hash: datasetHash,
      playback_count_sum: aggregates.totals.playback_count_sum,
      likes_count_sum: aggregates.totals.likes_count_sum,
      comment_count_sum: aggregates.totals.comment_count_sum,
      reposts_count_sum: aggregates.totals.reposts_count_sum,
      anomalies_count: anomalies.count,
      favoriter_unique_users: favoriterBundle.summary.unique_users,
      favoriter_rows: favoriterBundle.summary.total_favoriter_rows
    },
    verification: {
      readback_performed: true,
      json_parse_after_write: true,
      manifest_created: true,
      scriptable_sha256_unavailable_note:
        "Scriptable Standard-JavaScript bietet keine native SHA-256-Dateihashfunktion; deshalb wird zusätzlich ein stabiler Dataset-Simple-Hash gespeichert."
    },
    lyvra_evidence: lyvraEvidence
  };
}

async function chooseGoldOutputFolder(label) {
  const fileManager = FileManager.iCloud();
  const documentsDirectory = fileManager.documentsDirectory();

  const folderName = sanitizeFilename(
    `SoundCloud_Gold_Data_${label}_${new Date().toISOString().replace(/[:.]/g, "-")}`
  );

  const folderPath = fileManager.joinPath(documentsDirectory, folderName);

  if (!fileManager.fileExists(folderPath)) {
    fileManager.createDirectory(folderPath, true);
  }

  return folderPath;
}

async function saveGoldDataBundle({
  account,
  scope,
  selectedTracks,
  aggregates,
  anomalies,
  favoriterBundle,
  lyvraEvidence
}) {
  const fileManager = FileManager.iCloud();
  const outputFolder = await chooseGoldOutputFolder(scope.label);
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const accountName = sanitizeFilename(account.username || account.permalink || account.id);
  const scopeName = sanitizeFilename(scope.label);
  const baseName = `gold_${accountName}_${scopeName}_${timestamp}`;

  const jsonPath = fileManager.joinPath(outputFolder, `${baseName}.json`);
  const tracksCsvPath = fileManager.joinPath(outputFolder, `${baseName}_tracks.csv`);
  const reactionsCsvPath = fileManager.joinPath(outputFolder, `${baseName}_reactions.csv`);
  const txtPath = fileManager.joinPath(outputFolder, `${baseName}_summary.txt`);
  const manifestPath = fileManager.joinPath(outputFolder, `${baseName}_manifest.json`);

  const goldJson = {
    generated_at: new Date().toISOString(),
    version: VERSION,
    module: GOLD_DATA_MODULE_NAME,
    read_only: true,
    account: {
      id: account.id,
      username: account.username || null,
      permalink: account.permalink || null
    },
    scope: {
      mode: scope.mode,
      label: scope.label,
      start_local: scope.startDate ? formatLocalDateTime(scope.startDate) : null,
      end_local: scope.endDate ? formatLocalDateTime(scope.endDate) : null,
      latest_limit: scope.latestLimit,
      track_ids: scope.trackIds || []
    },
    selected_tracks: selectedTracks.map(compactGoldTrack),
    aggregates,
    anomalies,
    favoriter_bundle: favoriterBundle,
    lyvra_evidence: lyvraEvidence
  };

  const jsonText = JSON.stringify(goldJson, null, 2);
  const tracksCsv = createGoldTracksCsv(selectedTracks);
  const reactionsCsv = createGoldReactionsCsv(favoriterBundle);
  const txtSummary = createGoldTextSummary({
    account,
    scope,
    selectedTracks,
    aggregates,
    anomalies,
    favoriterBundle,
    lyvraEvidence
  });

  const datasetHash = simpleHashString(jsonText);

  const files = {
    output_folder: outputFolder,
    gold_json: jsonPath,
    tracks_csv: tracksCsvPath,
    reactions_csv: reactionsCsvPath,
    summary_txt: txtPath,
    manifest_json: manifestPath
  };

  const manifest = createGoldManifest({
    account,
    scope,
    files,
    selectedTracks,
    aggregates,
    anomalies,
    favoriterBundle,
    lyvraEvidence,
    datasetHash
  });

  fileManager.writeString(jsonPath, jsonText);
  fileManager.writeString(tracksCsvPath, tracksCsv);
  fileManager.writeString(reactionsCsvPath, reactionsCsv);
  fileManager.writeString(txtPath, txtSummary);
  fileManager.writeString(manifestPath, JSON.stringify(manifest, null, 2));

  const readbackJson = JSON.parse(fileManager.readString(jsonPath));
  const readbackManifest = JSON.parse(fileManager.readString(manifestPath));

  if (!readbackJson || !readbackManifest) {
    throw new Error("Readback-Prüfung fehlgeschlagen.");
  }

  return {
    outputFolder,
    jsonPath,
    tracksCsvPath,
    reactionsCsvPath,
    txtPath,
    manifestPath,
    datasetHash
  };
}

async function runGoldDataCollector() {
  const token = getAccessToken();
  const scope = await selectGoldDataScope();

  await showMessage(
    "Gold Data Collector",
    [
      `Version ${VERSION}`,
      "",
      "READ ONLY",
      "DELETE_ALLOWED=FALSE",
      "",
      `Scope: ${scope.label}`,
      "",
      "Jetzt werden Account und Tracks gelesen."
    ].join("\n")
  );

  const account = await fetchAccount(token);
  const allTracks = await fetchAllTracks(token);
  const selectedTracks = filterTracksByGoldScope(allTracks, scope);

  if (selectedTracks.length === 0) {
    throw new Error("Für den gewählten Gold-Data-Scope wurden keine Tracks gefunden.");
  }

  const tracksWithLikes = selectedTracks.filter(track => Number(track.likes_count || 0) > 0);
  const favoriterPolicy = await selectGoldFavoriterPolicy(tracksWithLikes.length);

  const aggregates = computeGoldAggregates(selectedTracks);
  const anomalies = buildGoldAnomalies(selectedTracks, aggregates);
  const favoriterBundle = await collectGoldFavoriters(token, selectedTracks, favoriterPolicy);

  const lyvraEvidence = buildGoldLyvraEvidence({
    account,
    scope,
    selectedTracks,
    aggregates,
    anomalies,
    favoriterSummary: favoriterBundle.summary
  });

  const saved = await saveGoldDataBundle({
    account,
    scope,
    selectedTracks,
    aggregates,
    anomalies,
    favoriterBundle,
    lyvraEvidence
  });

  await showMessage(
    "Gold Data fertig",
    [
      `Scope: ${scope.label}`,
      "",
      `Tracks: ${selectedTracks.length}`,
      `Play-Summe: ${aggregates.totals.playback_count_sum}`,
      `Like-Summe: ${aggregates.totals.likes_count_sum}`,
      `Kommentar-Summe: ${aggregates.totals.comment_count_sum}`,
      `Repost-Summe: ${aggregates.totals.reposts_count_sum}`,
      `Einzigartige Favoriter-User: ${favoriterBundle.summary.unique_users}`,
      `Anomalien: ${anomalies.count}`,
      "",
      `Dataset Hash: ${saved.datasetHash}`,
      "",
      "Gespeichert im Ordner:",
      saved.outputFolder
    ].join("\n")
  );
}



// ============================================================
// FULL ACCOUNT ANALYSIS CORRECTION v1.3.0
// Verbindliche Korrektur gemäß Handoff v1.3.0
// ============================================================

const FULL_ACCOUNT_MODE_KEY = "FULL_ACCOUNT_GOLD_DATA";
const FULL_ACCOUNT_INTERNAL_NAME = "FULL_ACCOUNT_COMPLETE_ANALYSIS";
const FULL_ACCOUNT_CHECKPOINT_FILE =
  "soundcloud_full_account_phase_b_checkpoint.json";

function fieldStatus(value, present) {
  if (!present) {
    return "FIELD_MISSING";
  }

  if (value === null) {
    return "FIELD_NULL";
  }

  if (typeof value === "number") {
    return value === 0
      ? "FIELD_PRESENT_ZERO"
      : "FIELD_PRESENT_POSITIVE";
  }

  return "FIELD_PRESENT_POSITIVE";
}

function describeField(objectValue, sourceField) {
  const present =
    objectValue !== null &&
    objectValue !== undefined &&
    Object.prototype.hasOwnProperty.call(objectValue, sourceField);

  const rawValue =
    present
      ? objectValue[sourceField]
      : null;

  return {
    field_present: present,
    raw_value: rawValue,
    normalized_value: present ? rawValue : null,
    source_field: present ? sourceField : null,
    status: fieldStatus(rawValue, present)
  };
}

function resolveLikeFields(track) {
  const likesPresent =
    Object.prototype.hasOwnProperty.call(track, "likes_count");
  const favoritingsPresent =
    Object.prototype.hasOwnProperty.call(track, "favoritings_count");

  const likesRaw = likesPresent ? track.likes_count : null;
  const favoritingsRaw =
    favoritingsPresent ? track.favoritings_count : null;

  let resolved = null;
  let source = null;

  if (typeof likesRaw === "number") {
    resolved = likesRaw;
    source = "likes_count";
  } else if (typeof favoritingsRaw === "number") {
    resolved = favoritingsRaw;
    source = "favoritings_count";
  }

  return {
    likes_count_present: likesPresent,
    likes_count_raw: likesRaw,
    favoritings_count_present: favoritingsPresent,
    favoritings_count_raw: favoritingsRaw,
    resolved_like_count: resolved,
    resolved_like_source: source,
    status:
      source === null
        ? "FIELD_MISSING"
        : resolved === 0
          ? "FIELD_PRESENT_ZERO"
          : "FIELD_PRESENT_POSITIVE"
  };
}

function uniqueTracksById(tracks) {
  const seen = new Set();
  const unique = [];
  const duplicates = [];

  for (const track of tracks) {
    const key = String(track.id || track.urn || "");

    if (!key) {
      unique.push(track);
      continue;
    }

    if (seen.has(key)) {
      duplicates.push(compactGoldTrack(track));
      continue;
    }

    seen.add(key);
    unique.push(track);
  }

  return {
    unique_tracks: unique,
    duplicate_id_records: duplicates
  };
}

function deriveUploadBatches(tracks) {
  const map = new Map();

  for (const track of tracks) {
    const key =
      track.created_at
        ? getLocalDateKey(track.created_at)
        : "unknown";

    if (!map.has(key)) {
      map.set(key, []);
    }

    map.get(key).push(track);
  }

  const batches = [];

  for (const [dateKey, items] of map.entries()) {
    const ordered = [...items].sort((a, b) => {
      const aTime = a.created_at ? new Date(a.created_at).getTime() : 0;
      const bTime = b.created_at ? new Date(b.created_at).getTime() : 0;
      return aTime - bTime;
    });

    batches.push({
      batch_key: dateKey,
      batch_size: ordered.length,
      tracks: ordered.map((track, index) => ({
        track_id: track.id || null,
        title: track.title || "",
        batch_position: index + 1,
        created_at: track.created_at || null
      }))
    });
  }

  return batches.sort((a, b) =>
    String(a.batch_key).localeCompare(String(b.batch_key))
  );
}

function deriveWorkFamilies(tracks) {
  const groups = new Map();

  for (const track of tracks) {
    const familyKey = normalizeTitle(track.title || "");

    if (!groups.has(familyKey)) {
      groups.set(familyKey, []);
    }

    groups.get(familyKey).push(compactGoldTrack(track));
  }

  return [...groups.entries()]
    .filter(([, items]) => items.length > 1)
    .map(([familyKey, items]) => ({
      family_key: familyKey,
      member_count: items.length,
      members: items
    }));
}

function buildPhaseATrackRecord(track, batchIndex) {
  const base = compactGoldTrack(track);

  const statistics = {
    playback_count: describeField(track, "playback_count"),
    likes: resolveLikeFields(track),
    comment_count: describeField(track, "comment_count"),
    reposts_count: describeField(track, "reposts_count"),
    download_count: describeField(track, "download_count")
  };

  return {
    track_id: track.id || null,
    urn: track.urn || null,
    base_metadata: {
      ...base,
      permalink: track.permalink || "",
      last_modified: track.last_modified || null,
      description: track.description || null,
      visibility: track.visibility || track.sharing || null,
      streamable:
        Object.prototype.hasOwnProperty.call(track, "streamable")
          ? track.streamable
          : null,
      publisher_metadata: track.publisher_metadata || null,
      monetization_model: track.monetization_model || null,
      policy: track.policy || null
    },
    statistics,
    field_availability: {
      playback_count: statistics.playback_count.status,
      likes: statistics.likes.status,
      comment_count: statistics.comment_count.status,
      reposts_count: statistics.reposts_count.status,
      download_count: statistics.download_count.status
    },
    memberships: {
      album_memberships: [],
      playlist_memberships: [],
      status: "ENDPOINT_NOT_CALLED"
    },
    batch_context: batchIndex.get(String(track.id || "")) || {
      batch_key: null,
      batch_size: null,
      batch_position: null
    },
    lyvra_provenance: {
      title_family_key: normalizeTitle(track.title || ""),
      source_account_track: true,
      status: "DERIVED_FROM_AVAILABLE_METADATA"
    },
    phase_a_status: "PHASE_A_COMPLETE"
  };
}

function buildBatchIndex(batches) {
  const index = new Map();

  for (const batch of batches) {
    for (const item of batch.tracks) {
      index.set(String(item.track_id || ""), {
        batch_key: batch.batch_key,
        batch_size: batch.batch_size,
        batch_position: item.batch_position
      });
    }
  }

  return index;
}

function calculateFieldAvailability(phaseATracks) {
  const fields = [
    "playback_count",
    "likes",
    "comment_count",
    "reposts_count",
    "download_count"
  ];

  const result = {};

  for (const field of fields) {
    const statuses = {};

    for (const track of phaseATracks) {
      const status = track.field_availability[field] || "FIELD_MISSING";
      statuses[status] = (statuses[status] || 0) + 1;
    }

    result[field] = {
      total_tracks: phaseATracks.length,
      statuses
    };
  }

  return result;
}

function buildDomainCompleteness({
  phaseATracks,
  favoriterBundle,
  allTracksCount,
  uniqueTracksCount
}) {
  const phaseAComplete =
    phaseATracks.length === uniqueTracksCount &&
    uniqueTracksCount === allTracksCount;

  return {
    account: "COMPLETE",
    tracks: phaseAComplete ? "COMPLETE" : "PARTIAL",
    track_metadata: phaseAComplete ? "COMPLETE" : "PARTIAL",
    play_counts: "COMPLETE_FIELD_CLASSIFICATION",
    like_counts: "COMPLETE_FIELD_CLASSIFICATION",
    favoriters:
      favoriterBundle.policy.mode === "none"
        ? "NOT_REQUESTED"
        : favoriterBundle.failures.length > 0
          ? "PARTIAL"
          : favoriterBundle.analyzed_tracks_with_likes <
              favoriterBundle.requested_tracks_with_likes
            ? "PARTIAL"
            : "COMPLETE_FOR_REQUESTED_TRACKS",
    comments: "COMPLETE_COUNTERS_ONLY",
    comment_details: "NOT_REQUESTED",
    reposts: "COMPLETE_COUNTERS_ONLY",
    repost_users: "UNAVAILABLE",
    albums_playlists: "ENDPOINT_NOT_CALLED",
    batches: "DERIVED_COMPLETE",
    followers: "NOT_AVAILABLE",
    insights: "NOT_AVAILABLE",
    snapshots: "COMPLETE_CURRENT_SNAPSHOT",
    phase_a:
      phaseAComplete
        ? "PHASE_A_COMPLETE"
        : "PHASE_A_PARTIAL",
    phase_b:
      favoriterBundle.policy.mode === "none"
        ? "PHASE_B_NOT_REQUESTED"
        : favoriterBundle.failures.length > 0
          ? "PHASE_B_PARTIAL"
          : "PHASE_B_COMPLETE_FOR_REQUESTED_FAVORITER_SCOPE"
  };
}

function getFullAccountCheckpointPath() {
  const fileManager = FileManager.iCloud();

  return fileManager.joinPath(
    fileManager.documentsDirectory(),
    FULL_ACCOUNT_CHECKPOINT_FILE
  );
}

function loadFullAccountCheckpoint(scopeKey) {
  const fileManager = FileManager.iCloud();
  const path = getFullAccountCheckpointPath();

  if (!fileManager.fileExists(path)) {
    return null;
  }

  try {
    const checkpoint = JSON.parse(fileManager.readString(path));

    if (
      checkpoint &&
      checkpoint.scope_key === scopeKey &&
      checkpoint.status === "PARTIAL"
    ) {
      return checkpoint;
    }
  } catch (_) {}

  return null;
}

function saveFullAccountCheckpoint(checkpoint) {
  const fileManager = FileManager.iCloud();
  const path = getFullAccountCheckpointPath();

  fileManager.writeString(
    path,
    JSON.stringify(checkpoint, null, 2)
  );

  return path;
}

function clearFullAccountCheckpoint() {
  const fileManager = FileManager.iCloud();
  const path = getFullAccountCheckpointPath();

  if (fileManager.fileExists(path)) {
    fileManager.remove(path);
  }
}

async function collectGoldFavoritersV130(
  token,
  selectedTracks,
  policy,
  scopeKey
) {
  const tracksWithLikes = selectedTracks
    .filter(track => {
      const likes = resolveLikeFields(track);
      return typeof likes.resolved_like_count === "number" &&
        likes.resolved_like_count > 0;
    })
    .sort((a, b) => {
      const aLikes = resolveLikeFields(a).resolved_like_count || 0;
      const bLikes = resolveLikeFields(b).resolved_like_count || 0;
      return bLikes - aLikes;
    });

  if (policy.mode === "none") {
    return {
      policy,
      requested_tracks_with_likes: tracksWithLikes.length,
      analyzed_tracks_with_likes: 0,
      results: [],
      failures: [],
      summary: {
        unique_users: 0,
        total_favoriter_rows: 0,
        top_users: []
      },
      checkpoint_status: "PHASE_B_NOT_REQUESTED"
    };
  }

  const targetTracks =
    policy.mode === "all"
      ? tracksWithLikes
      : tracksWithLikes.slice(0, policy.limit);

  const checkpoint = loadFullAccountCheckpoint(scopeKey);
  const completedIds = new Set(
    checkpoint && Array.isArray(checkpoint.completed_track_ids)
      ? checkpoint.completed_track_ids.map(String)
      : []
  );

  const results =
    checkpoint && Array.isArray(checkpoint.results)
      ? checkpoint.results
      : [];

  const failures =
    checkpoint && Array.isArray(checkpoint.failures)
      ? checkpoint.failures
      : [];

  for (let index = 0; index < targetTracks.length; index++) {
    const track = targetTracks[index];
    const trackId = String(track.id || track.urn || "");

    if (completedIds.has(trackId)) {
      continue;
    }

    try {
      const users = await fetchTrackFavoriters(token, track);

      results.push({
        track: compactGoldTrack(track),
        expected_likes_count:
          resolveLikeFields(track).resolved_like_count,
        retrieved_favoriters_count: users.length,
        favoriters: users.map(compactUser)
      });
    } catch (error) {
      failures.push({
        track: compactGoldTrack(track),
        error:
          error && error.message
            ? error.message
            : String(error)
      });
    }

    completedIds.add(trackId);

    if (
      completedIds.size % GOLD_DATA_CHECKPOINT_EVERY === 0 ||
      completedIds.size === targetTracks.length
    ) {
      saveFullAccountCheckpoint({
        version: VERSION,
        scope_key: scopeKey,
        status:
          completedIds.size === targetTracks.length
            ? "COMPLETE"
            : "PARTIAL",
        completed_track_ids: [...completedIds],
        target_track_count: targetTracks.length,
        results,
        failures,
        saved_at: new Date().toISOString()
      });
    }

    if (index < targetTracks.length - 1) {
      await sleep(FAVORITER_DELAY_SECONDS);
    }
  }

  const summary = buildGoldFavoriterSummary(results);

  if (completedIds.size === targetTracks.length) {
    clearFullAccountCheckpoint();
  }

  return {
    policy,
    requested_tracks_with_likes: tracksWithLikes.length,
    analyzed_tracks_with_likes: completedIds.size,
    results,
    failures,
    summary,
    checkpoint_status:
      completedIds.size === targetTracks.length
        ? "PHASE_B_COMPLETE"
        : "PHASE_B_PARTIAL"
  };
}

function createFullAccountSummaryV130({
  account,
  scope,
  phaseATracks,
  uniqueTracks,
  sourceTracksCount,
  aggregates,
  fieldAvailability,
  completeness,
  favoriterBundle,
  batches,
  workFamilies,
  errors
}) {
  const lines = [];

  lines.push("SOUNDCLOUD FULL ACCOUNT ANALYSIS");
  lines.push(`Version: ${VERSION}`);
  lines.push("");
  lines.push("READ_ONLY=TRUE");
  lines.push("DELETE_ALLOWED=FALSE");
  lines.push(`MODE=${FULL_ACCOUNT_MODE_KEY}`);
  lines.push("");
  lines.push("1. ACCOUNT UND SCOPE");
  lines.push(`Account: ${account.username || account.permalink || account.id}`);
  lines.push(`User-ID: ${account.id || "unbekannt"}`);
  lines.push(`Scope: ${scope.label}`);
  lines.push("");
  lines.push("2. VOLLSTÄNDIGKEIT");
  lines.push(`Basiscensus: ${completeness.phase_a}`);
  lines.push(`Detailabfragen: ${completeness.phase_b}`);
  lines.push("");
  lines.push("3. TRACKANZAHL UND EINDEUTIGE IDS");
  lines.push(`Tracks aus API/Scope: ${sourceTracksCount}`);
  lines.push(`Eindeutige Track-IDs: ${uniqueTracks.length}`);
  lines.push(`Phase-A-Records: ${phaseATracks.length}`);
  lines.push("");
  lines.push("4. UPLOADZEITRAUM");
  const dated = uniqueTracks
    .filter(track => track.created_at)
    .sort((a, b) =>
      new Date(a.created_at).getTime() -
      new Date(b.created_at).getTime()
    );
  lines.push(
    `Erster Upload: ${
      dated.length ? formatLocalDateTime(dated[0].created_at) : "unbekannt"
    }`
  );
  lines.push(
    `Letzter Upload: ${
      dated.length
        ? formatLocalDateTime(dated[dated.length - 1].created_at)
        : "unbekannt"
    }`
  );
  lines.push("");
  lines.push("5. GESAMTDAUER");
  lines.push(`Gesamtdauer: ${aggregates.totals.duration_sum_text}`);
  lines.push("");
  lines.push("6. PLAY-METRIKEN");
  lines.push(`Play-Summe: ${aggregates.totals.playback_count_sum}`);
  lines.push("");
  lines.push("7. KOMMENTARE");
  lines.push(`Kommentar-Summe: ${aggregates.totals.comment_count_sum}`);
  lines.push("");
  lines.push("8. REPOSTS");
  lines.push(`Repost-Summe: ${aggregates.totals.reposts_count_sum}`);
  lines.push("");
  lines.push("9. LIKES / FAVORITER");
  lines.push(`Like-Summe: ${aggregates.totals.likes_count_sum}`);
  lines.push(`Favoriter-Policy: ${favoriterBundle.policy.label}`);
  lines.push(`Favoriter-Zeilen: ${favoriterBundle.summary.total_favoriter_rows}`);
  lines.push(`Einzigartige User: ${favoriterBundle.summary.unique_users}`);
  lines.push("");
  lines.push("10. ALBEN / PLAYLISTS / BATCHES");
  lines.push(`Abgeleitete Upload-Batches: ${batches.length}`);
  lines.push("Album-/Playlist-Endpunkte: ENDPOINT_NOT_CALLED");
  lines.push("");
  lines.push("11. DUPLIKATE / WERKFAMILIEN");
  lines.push(`Werkfamilien: ${workFamilies.length}`);
  lines.push("");
  lines.push("12. INSIGHTS");
  lines.push("Status: NOT_AVAILABLE");
  lines.push("");
  lines.push("13. FELDVERFÜGBARKEIT");
  for (const [field, info] of Object.entries(fieldAvailability)) {
    lines.push(`${field}: ${JSON.stringify(info.statuses)}`);
  }
  lines.push("");
  lines.push("14. FEHLER UND EINSCHRÄNKUNGEN");
  lines.push(`Fehleranzahl: ${errors.length}`);
  lines.push("PLAYBACK_COUNT_IS_NOT_UNIQUE_LISTENERS");
  lines.push("CORRELATION_IS_NOT_CAUSATION");
  lines.push("MISSING_FIELD_IS_NOT_ZERO");
  lines.push("");
  lines.push("15. LYVRA-EVIDENZ");
  lines.push("External reaction and metadata evidence only.");
  lines.push("No causal listener motivation is inferred.");
  lines.push("");
  lines.push("DOMAIN COMPLETENESS MATRIX");
  lines.push(JSON.stringify(completeness, null, 2));

  return lines.join("\n");
}

function createPhaseATracksCsvV130(phaseATracks) {
  const header = [
    "track_id",
    "title",
    "created_at_local",
    "duration_text",
    "playback_value",
    "playback_status",
    "resolved_like_value",
    "like_status",
    "comment_value",
    "comment_status",
    "repost_value",
    "repost_status",
    "download_value",
    "download_status",
    "batch_key",
    "batch_position",
    "permalink_url"
  ];

  const lines = [header.map(csvEscape).join(";")];

  for (const item of phaseATracks) {
    const metadata = item.base_metadata;
    const row = [
      item.track_id,
      metadata.title,
      metadata.created_at_local,
      metadata.duration_text,
      item.statistics.playback_count.normalized_value,
      item.statistics.playback_count.status,
      item.statistics.likes.resolved_like_count,
      item.statistics.likes.status,
      item.statistics.comment_count.normalized_value,
      item.statistics.comment_count.status,
      item.statistics.reposts_count.normalized_value,
      item.statistics.reposts_count.status,
      item.statistics.download_count.normalized_value,
      item.statistics.download_count.status,
      item.batch_context.batch_key,
      item.batch_context.batch_position,
      metadata.permalink_url
    ];

    lines.push(row.map(csvEscape).join(";"));
  }

  return lines.join("\n");
}

function createJsonlV130(records) {
  return records
    .map(record => JSON.stringify(record))
    .join("\n");
}

function createEmptyDomainCsvV130(columns) {
  return columns.map(csvEscape).join(";") + "\n";
}

async function saveFullAccountBundleV130({
  account,
  scope,
  sourceTracksCount,
  uniqueTracks,
  duplicateIdRecords,
  phaseATracks,
  aggregates,
  fieldAvailability,
  completeness,
  favoriterBundle,
  batches,
  workFamilies,
  errors,
  lyvraEvidence
}) {
  const fileManager = FileManager.iCloud();
  const outputFolder = await chooseGoldOutputFolder(
    scope.mode === "full_account"
      ? "full_account_complete_analysis"
      : `complete_analysis_${scope.label}`
  );

  const prefix =
    scope.mode === "full_account"
      ? "full_account"
      : "complete_analysis";

  const paths = {
    summary: fileManager.joinPath(outputFolder, `${prefix}_summary.txt`),
    tracks_csv: fileManager.joinPath(outputFolder, `${prefix}_tracks.csv`),
    tracks_jsonl: fileManager.joinPath(outputFolder, `${prefix}_tracks.jsonl`),
    account_json: fileManager.joinPath(outputFolder, `${prefix}_account.json`),
    reactions_csv: fileManager.joinPath(outputFolder, `${prefix}_reactions.csv`),
    comments_csv: fileManager.joinPath(outputFolder, `${prefix}_comments.csv`),
    reposts_csv: fileManager.joinPath(outputFolder, `${prefix}_reposts.csv`),
    favoriters_csv: fileManager.joinPath(outputFolder, `${prefix}_favoriters.csv`),
    albums_playlists_json: fileManager.joinPath(
      outputFolder,
      `${prefix}_albums_playlists.json`
    ),
    batches_json: fileManager.joinPath(outputFolder, `${prefix}_batches.json`),
    work_families_json: fileManager.joinPath(
      outputFolder,
      `${prefix}_work_families.json`
    ),
    capabilities_json: fileManager.joinPath(
      outputFolder,
      `${prefix}_capabilities.json`
    ),
    field_availability_json: fileManager.joinPath(
      outputFolder,
      `${prefix}_field_availability.json`
    ),
    errors_json: fileManager.joinPath(outputFolder, `${prefix}_errors.json`),
    lyvra_evidence_json: fileManager.joinPath(
      outputFolder,
      `${prefix}_lyvra_evidence.json`
    ),
    snapshot_json: fileManager.joinPath(
      outputFolder,
      `${prefix}_complete_snapshot.json`
    ),
    manifest_json: fileManager.joinPath(outputFolder, `${prefix}_manifest.json`)
  };

  const summaryText = createFullAccountSummaryV130({
    account,
    scope,
    phaseATracks,
    uniqueTracks,
    sourceTracksCount,
    aggregates,
    fieldAvailability,
    completeness,
    favoriterBundle,
    batches,
    workFamilies,
    errors
  });

  const snapshot = {
    generated_at: new Date().toISOString(),
    version: VERSION,
    mode: FULL_ACCOUNT_MODE_KEY,
    internal_name: FULL_ACCOUNT_INTERNAL_NAME,
    read_only: true,
    account,
    scope,
    source_tracks_count: sourceTracksCount,
    unique_tracks_count: uniqueTracks.length,
    duplicate_id_records: duplicateIdRecords,
    phase_a_tracks: phaseATracks,
    aggregates,
    field_availability: fieldAvailability,
    domain_completeness: completeness,
    phase_b: favoriterBundle,
    batches,
    work_families: workFamilies,
    errors,
    lyvra_evidence: lyvraEvidence
  };

  const favoriterCsv = createGoldReactionsCsv(favoriterBundle);

  const capabilities = {
    account: "AVAILABLE",
    tracks: "AVAILABLE",
    track_metadata: "AVAILABLE",
    counters: "AVAILABLE_WITH_FIELD_CLASSIFICATION",
    favoriters: "OPTIONAL_ENDPOINT",
    comments: "COUNTERS_ONLY",
    comment_details: "ENDPOINT_NOT_CALLED",
    reposts: "COUNTERS_ONLY",
    repost_users: "UNAVAILABLE",
    albums_playlists: "ENDPOINT_NOT_CALLED",
    batches: "DERIVED",
    followers: "NOT_AVAILABLE",
    insights: "NOT_AVAILABLE",
    destructive_actions: "FORBIDDEN"
  };

  const manifest = {
    manifest_type: "SOUNDCLOUD_FULL_ACCOUNT_COMPLETE_ANALYSIS",
    generated_at: new Date().toISOString(),
    version: VERSION,
    mode: FULL_ACCOUNT_MODE_KEY,
    internal_name: FULL_ACCOUNT_INTERNAL_NAME,
    read_only: true,
    files: paths,
    counts: {
      source_tracks: sourceTracksCount,
      unique_tracks: uniqueTracks.length,
      phase_a_records: phaseATracks.length,
      errors: errors.length
    },
    domain_completeness: completeness,
    verification: {
      readback_required: true,
      missing_field_not_zero: true,
      all_scope_tracks_included_independent_of_reactions:
        phaseATracks.length === uniqueTracks.length
    }
  };

  fileManager.writeString(paths.summary, summaryText);
  fileManager.writeString(paths.tracks_csv, createPhaseATracksCsvV130(phaseATracks));
  fileManager.writeString(paths.tracks_jsonl, createJsonlV130(phaseATracks));
  fileManager.writeString(paths.account_json, JSON.stringify(account, null, 2));
  fileManager.writeString(
    paths.reactions_csv,
    favoriterCsv
  );
  fileManager.writeString(
    paths.comments_csv,
    createEmptyDomainCsvV130([
      "track_id",
      "comment_id",
      "comment_author",
      "comment_body",
      "status"
    ])
  );
  fileManager.writeString(
    paths.reposts_csv,
    createEmptyDomainCsvV130([
      "track_id",
      "repost_user_id",
      "repost_username",
      "status"
    ])
  );
  fileManager.writeString(paths.favoriters_csv, favoriterCsv);
  fileManager.writeString(
    paths.albums_playlists_json,
    JSON.stringify(
      {
        status: "ENDPOINT_NOT_CALLED",
        albums: [],
        playlists: [],
        memberships: []
      },
      null,
      2
    )
  );
  fileManager.writeString(paths.batches_json, JSON.stringify(batches, null, 2));
  fileManager.writeString(
    paths.work_families_json,
    JSON.stringify(workFamilies, null, 2)
  );
  fileManager.writeString(
    paths.capabilities_json,
    JSON.stringify(capabilities, null, 2)
  );
  fileManager.writeString(
    paths.field_availability_json,
    JSON.stringify(fieldAvailability, null, 2)
  );
  fileManager.writeString(paths.errors_json, JSON.stringify(errors, null, 2));
  fileManager.writeString(
    paths.lyvra_evidence_json,
    JSON.stringify(lyvraEvidence, null, 2)
  );
  fileManager.writeString(paths.snapshot_json, JSON.stringify(snapshot, null, 2));
  fileManager.writeString(paths.manifest_json, JSON.stringify(manifest, null, 2));

  const readbackManifest = JSON.parse(
    fileManager.readString(paths.manifest_json)
  );
  const readbackSnapshot = JSON.parse(
    fileManager.readString(paths.snapshot_json)
  );

  if (
    !readbackManifest ||
    !readbackSnapshot ||
    readbackSnapshot.phase_a_tracks.length !== uniqueTracks.length
  ) {
    throw new Error("Full-Account-Readback-Prüfung fehlgeschlagen.");
  }

  return {
    outputFolder,
    paths,
    manifest: readbackManifest
  };
}

async function selectFullAccountScopeV130() {
  const menu = new Alert();

  menu.title = "Vollständige Kontoanalyse";
  menu.message =
    "Erfasst alle Tracks und alle technisch verfügbaren Metadaten, " +
    "Statistiken, Reaktionen, Alben, Playlists, Upload-Batches und Insights.\n\n" +
    "READ ONLY — Tracks werden unabhängig von Likes oder anderen Reaktionen aufgenommen.";

  menu.addAction("🔎 Gesamtes SoundCloud-Konto vollständig analysieren");
  menu.addAction("📅 Zeitraum vollständig analysieren");
  menu.addAction("🆕 Neueste Tracks vollständig analysieren");
  menu.addAction("🎯 Bestimmte Track-IDs vollständig analysieren");
  menu.addAction("❤️ Like- und Favoriterdetails abrufen");
  menu.addAction("💬 Kommentar- und Repostdetails abrufen");
  menu.addAction("📚 Album-, Playlist- und Batchanalyse");
  menu.addAction("📈 Snapshot vergleichen");
  menu.addAction("📁 Ausgabeverzeichnis");
  menu.addAction("⚙️ Einstellungen");
  menu.addCancelAction("Abbrechen");

  const selection = await menu.presentAlert();

  if (selection === -1) {
    throw new Error("Vorgang abgebrochen.");
  }

  if (selection === 0) {
    return {
      mode: "full_account",
      technical_mode: FULL_ACCOUNT_MODE_KEY,
      label: "Gesamtes SoundCloud-Konto vollständig analysieren",
      startDate: null,
      endDate: null,
      latestLimit: null,
      trackIds: []
    };
  }

  if (selection === 1) {
    const startRaw = await askText({
      title: "Startdatum",
      message: "Format: YYYY-MM-DD",
      placeholder: "2026-07-01"
    });

    const endRaw = await askText({
      title: "Enddatum",
      message: "Format: YYYY-MM-DD",
      placeholder: "2026-07-26"
    });

    return {
      mode: "date_range",
      technical_mode: "DATE_RANGE_COMPLETE_ANALYSIS",
      label: `Zeitraum vollständig analysieren: ${startRaw} bis ${endRaw}`,
      startDate: parseLocalDateInput(startRaw, false),
      endDate: parseLocalDateInput(endRaw, true),
      latestLimit: null,
      trackIds: []
    };
  }

  if (selection === 2) {
    const raw = await askText({
      title: "Neueste Tracks",
      message: "Anzahl der neuesten Tracks eingeben.",
      placeholder: "500"
    });

    const count = Number.parseInt(raw, 10);

    if (!Number.isFinite(count) || count <= 0) {
      throw new Error("Ungültige Anzahl.");
    }

    return {
      mode: "latest_n_custom",
      technical_mode: "LATEST_TRACKS_COMPLETE_ANALYSIS",
      label: `Neueste ${count} Tracks vollständig analysieren`,
      startDate: null,
      endDate: null,
      latestLimit: count,
      trackIds: []
    };
  }

  if (selection === 3) {
    const rawIds = await askText({
      title: "Track-IDs",
      message: "IDs durch Komma, Leerzeichen oder Zeilenumbruch trennen.",
      placeholder: "123456789, 987654321"
    });

    const trackIds = rawIds
      .split(/[\s,;]+/g)
      .map(value => value.trim())
      .filter(Boolean);

    return {
      mode: "track_ids",
      technical_mode: "TRACK_IDS_COMPLETE_ANALYSIS",
      label: `Bestimmte Track-IDs vollständig analysieren (${trackIds.length})`,
      startDate: null,
      endDate: null,
      latestLimit: null,
      trackIds
    };
  }

  if (selection === 4) {
    await showMessage(
      "Like- und Favoriterdetails",
      "Dieser Unterlauf wird innerhalb der vollständigen Analyse über die Phase-B-Auswahl gesteuert."
    );
    return await selectFullAccountScopeV130();
  }

  if (selection === 5) {
    await showMessage(
      "Kommentar- und Repostdetails",
      "Counter werden im Basiscensus für jeden Track klassifiziert. Detailendpunkte sind in diesem Build sichtbar als ENDPOINT_NOT_CALLED markiert."
    );
    return await selectFullAccountScopeV130();
  }

  if (selection === 6) {
    await showMessage(
      "Album-, Playlist- und Batchanalyse",
      "Upload-Batches werden vollständig abgeleitet. Album-/Playlist-Endpunkte werden transparent als ENDPOINT_NOT_CALLED ausgewiesen."
    );
    return await selectFullAccountScopeV130();
  }

  if (selection === 7) {
    return {
      mode: "snapshot_delta_prepare",
      technical_mode: "SNAPSHOT_COMPLETE_ANALYSIS",
      label: "Snapshot vergleichen / aktuellen Snapshot erzeugen",
      startDate: null,
      endDate: null,
      latestLimit: null,
      trackIds: []
    };
  }

  if (selection === 8) {
    await showMessage(
      "Ausgabeverzeichnis",
      "Jeder Lauf erzeugt einen eigenen Unterordner im Scriptable-iCloud-Verzeichnis."
    );
    return await selectFullAccountScopeV130();
  }

  await showMessage(
    "Einstellungen",
    [
      "READ_ONLY=TRUE",
      "MISSING_FIELD_IS_NOT_ZERO",
      `CHECKPOINT_EVERY=${GOLD_DATA_CHECKPOINT_EVERY}`,
      "PHASE_A_ALL_SCOPE_TRACKS=TRUE"
    ].join("\n")
  );

  return await selectFullAccountScopeV130();
}

async function runFullAccountGoldDataV130() {
  const token = getAccessToken();
  const scope = await selectFullAccountScopeV130();

  await showMessage(
    "Vollständige Kontoanalyse",
    [
      `Version ${VERSION}`,
      "",
      `MODE=${scope.technical_mode}`,
      "READ_ONLY=TRUE",
      "DELETE_ALLOWED=FALSE",
      "",
      `Scope: ${scope.label}`,
      "",
      "Phase A erfasst jeden Track im Scope unabhängig von Likes, Plays, Kommentaren oder Reposts."
    ].join("\n")
  );

  const errors = [];
  const account = await fetchAccount(token);
  const allAccountTracks = await fetchAllTracks(token);
  const scopedTracks = filterTracksByGoldScope(allAccountTracks, scope);

  const uniqueResult = uniqueTracksById(scopedTracks);
  const uniqueTracks = uniqueResult.unique_tracks;
  const batches = deriveUploadBatches(uniqueTracks);
  const batchIndex = buildBatchIndex(batches);

  const phaseATracks = [];

  for (const track of uniqueTracks) {
    try {
      phaseATracks.push(buildPhaseATrackRecord(track, batchIndex));
    } catch (error) {
      errors.push({
        phase: "PHASE_A",
        track_id: track.id || null,
        error:
          error && error.message
            ? error.message
            : String(error)
      });
    }
  }

  const aggregates = computeGoldAggregates(uniqueTracks);
  const fieldAvailability = calculateFieldAvailability(phaseATracks);
  const workFamilies = deriveWorkFamilies(uniqueTracks);
  const anomalies = buildGoldAnomalies(uniqueTracks, aggregates);

  const likeCandidateCount = uniqueTracks.filter(track => {
    const likes = resolveLikeFields(track);
    return typeof likes.resolved_like_count === "number" &&
      likes.resolved_like_count > 0;
  }).length;

  const favoriterPolicy =
    await selectGoldFavoriterPolicy(likeCandidateCount);

  const scopeKey = simpleHashString(
    JSON.stringify({
      account_id: account.id,
      mode: scope.technical_mode,
      label: scope.label,
      track_ids: uniqueTracks.map(track => track.id)
    })
  );

  const favoriterBundle = await collectGoldFavoritersV130(
    token,
    uniqueTracks,
    favoriterPolicy,
    scopeKey
  );

  for (const failure of favoriterBundle.failures) {
    errors.push({
      phase: "PHASE_B",
      domain: "FAVORITERS",
      track_id:
        failure.track
          ? failure.track.id
          : null,
      error: failure.error
    });
  }

  const completeness = buildDomainCompleteness({
    phaseATracks,
    favoriterBundle,
    allTracksCount: scopedTracks.length,
    uniqueTracksCount: uniqueTracks.length
  });

  const lyvraEvidence = buildGoldLyvraEvidence({
    account,
    scope,
    selectedTracks: uniqueTracks,
    aggregates,
    anomalies,
    favoriterSummary: favoriterBundle.summary
  });

  const saved = await saveFullAccountBundleV130({
    account,
    scope,
    sourceTracksCount: scopedTracks.length,
    uniqueTracks,
    duplicateIdRecords: uniqueResult.duplicate_id_records,
    phaseATracks,
    aggregates,
    fieldAvailability,
    completeness,
    favoriterBundle,
    batches,
    workFamilies,
    errors,
    lyvraEvidence
  });

  await showMessage(
    "Vollständige Analyse fertig",
    [
      `Scope: ${scope.label}`,
      "",
      `Tracks im Scope: ${scopedTracks.length}`,
      `Eindeutige Track-IDs: ${uniqueTracks.length}`,
      `Phase-A-Records: ${phaseATracks.length}`,
      `Basiscensus: ${completeness.phase_a}`,
      `Detailabfragen: ${completeness.phase_b}`,
      `Fehler: ${errors.length}`,
      "",
      "Alle Scope-Tracks wurden unabhängig von Reaktionen aufgenommen.",
      "",
      `Ausgabeordner:\n${saved.outputFolder}`
    ].join("\n")
  );
}


// ============================================================
// MAIN
// ============================================================

async function main() {
  const selection = await selectMainMenu();

  if (selection === -1) {
    return;
  }

  if (selection === 0) {
    await runTokenManager();
    return;
  }

  if (selection === 1) {
    await runCleanupManager();
    return;
  }

  if (selection === 2) {
    await runLikesAnalyzer();
    return;
  }

  if (selection === 3) {
    await runLyvraEvidenceAnalyzer();
    return;
  }

  if (selection === 4) {
    await runFullAccountGoldDataV130();
    return;
  }

  if (selection === 5) {
    await testAccessToken();
  }
}

// ============================================================
// START
// ============================================================

try {
  await main();
} catch (error) {
  console.error(error);

  await showMessage(
    "Fehler",
    error && error.message ? error.message : String(error)
  );
}

Script.complete();
