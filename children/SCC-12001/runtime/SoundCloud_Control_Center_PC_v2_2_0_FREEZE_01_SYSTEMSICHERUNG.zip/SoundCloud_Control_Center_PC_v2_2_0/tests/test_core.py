import json, tempfile, unittest
from pathlib import Path
from app.services.analysis import build_duplicate_plan, filter_scope
from app.core.utils import normalize_title, csv_text, atomic_write_json

class CoreTests(unittest.TestCase):
    def test_normalize_title(self): self.assertEqual(normalize_title("Track Copy"),"track")
    def test_duplicate_oldest_kept(self):
        tracks=[{'id':1,'title':'A','duration':100000,'created_at':'2025-01-01T00:00:00Z'},{'id':2,'title':'A Copy','duration':101000,'created_at':'2025-01-02T00:00:00Z'}]
        groups,candidates=build_duplicate_plan(tracks); self.assertEqual(groups[0]['keep']['id'],1); self.assertEqual(candidates[0]['id'],2)
    def test_scope_latest(self):
        tracks=[{'id':1,'created_at':'2025-01-01T00:00:00Z'},{'id':2,'created_at':'2025-01-02T00:00:00Z'}]
        self.assertEqual(filter_scope(tracks,{'mode':'latest_n','limit':1})[0]['id'],2)
    def test_csv_semicolon(self): self.assertIn(';',csv_text(['a','b'],[[1,2]]))
    def test_atomic_json(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.json'; atomic_write_json(p,{'x':1}); self.assertEqual(json.loads(p.read_text())['x'],1)

if __name__=='__main__': unittest.main()

class OAuthRepairTests(unittest.TestCase):
    def test_desktop_redirect_default(self):
        from app.core.config import AppConfig
        self.assertEqual(AppConfig().redirect_uri, "sccpc://soundcloud/callback")

    def test_placeholder_redirect_rejected(self):
        from app.core.desktop_oauth import validate_redirect_uri
        with self.assertRaises(ValueError):
            validate_redirect_uri("https://example.com/callback")

    def test_callback_roundtrip(self):
        import app.core.desktop_oauth as desktop_oauth
        with tempfile.TemporaryDirectory() as d:
            old = desktop_oauth.callback_file
            try:
                desktop_oauth.callback_file = lambda: Path(d) / "callback.json"
                url = "sccpc://soundcloud/callback?code=abc&state=xyz"
                desktop_oauth.write_callback_url(url)
                self.assertEqual(desktop_oauth.consume_callback_url(), url)
                self.assertIsNone(desktop_oauth.consume_callback_url())
            finally:
                desktop_oauth.callback_file = old

    def test_authorization_url_is_desktop_pkce_without_popup_flag(self):
        from types import SimpleNamespace
        from unittest.mock import patch
        from app.core.soundcloud import SoundCloudClient

        class DummySecure:
            def __init__(self): self.data={"client_id":"id","client_secret":"secret"}
            def get(self,k): return self.data.get(k,"")
            def set(self,k,v): self.data[k]=v
            def delete(self,k): self.data.pop(k,None)

        cfg=SimpleNamespace(config=SimpleNamespace(redirect_uri="sccpc://soundcloud/callback",timeout_seconds=10,auto_refresh_token=True))
        client=SoundCloudClient(cfg,DummySecure())
        url=client.create_authorization_url()
        self.assertIn("code_challenge_method=S256",url)
        self.assertIn("response_type=code",url)
        self.assertNotIn("display=popup",url)
