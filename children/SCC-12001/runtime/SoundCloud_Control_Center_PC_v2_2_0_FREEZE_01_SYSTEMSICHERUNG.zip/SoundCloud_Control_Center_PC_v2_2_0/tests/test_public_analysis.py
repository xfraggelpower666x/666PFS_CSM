import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from app.services.public_analysis import PublicProfileAnalysisService


class Ctx:
    cancel_event=None
    def update(self,*args,**kwargs): pass
    def check_cancelled(self): pass


class FakePublicApi:
    def resolve_profile(self,url):
        return {"urn":"soundcloud:users:123","id":123,"username":"666SOUNDsDESIGn","permalink_url":url}
    def fetch_user_tracks(self,urn,progress=None,cancel_event=None):
        rows=[
            {"urn":"soundcloud:tracks:1","id":1,"title":"A","created_at":"2026-08-08T10:00:00Z","duration":300000,"playback_count":100,"likes_count":2,"comment_count":1,"reposts_count":0,"permalink_url":"https://soundcloud.com/x/a"},
            {"urn":"soundcloud:tracks:2","id":2,"title":"B","created_at":"2026-08-07T10:00:00Z","duration":310000,"playback_count":50,"likes_count":0,"comment_count":0,"reposts_count":0,"permalink_url":"https://soundcloud.com/x/b"},
        ]
        if progress: progress(1,len(rows))
        return rows
    def fetch_track_favoriters(self,track,cancel_event=None):
        return [{"urn":"soundcloud:users:9","id":9,"username":"listener","permalink_url":"https://soundcloud.com/listener"}]


class PublicAnalysisTests(unittest.TestCase):
    def test_full_public_analysis_exports_and_readback(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=SimpleNamespace(export_root=Path(td),config=SimpleNamespace())
            svc=PublicProfileAnalysisService(FakePublicApi(),cfg)
            result=svc.full_profile_analysis(Ctx(),"https://soundcloud.com/x",{"mode":"all"},None)
            folder=Path(result["folder"])
            self.assertEqual(result["tracks"],2)
            self.assertEqual(result["favoriter_rows"],1)
            self.assertTrue((folder/"public_full_snapshot.json").exists())
            self.assertTrue((folder/"public_tracks.csv").exists())
            self.assertTrue((folder/"manifest.json").exists())

if __name__ == '__main__':
    unittest.main()
