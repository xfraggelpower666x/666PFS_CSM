import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from app.core.public_api import (
    API_BASE,
    TOKEN_URL,
    PublicApiClient,
    SoundCloudPublicApiError,
    _request_with_backoff,
    search_tracks,
)


class FakeResponse:
    def __init__(self, status=200, data=None, text="", headers=None):
        self.status_code = status
        self._data = data
        self.text = text or ("{}" if data is not None else "")
        self.headers = headers or {}
        self.ok = 200 <= status < 300

    def json(self):
        if isinstance(self._data, Exception):
            raise self._data
        return self._data


class RecordingSession:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return self.responses.pop(0)

    def post(self, url, **kwargs):
        self.calls.append(("POST", url, kwargs))
        return self.responses.pop(0)


class DummySecure:
    def __init__(self, initial=None):
        self.data = dict(initial or {})

    def get(self, key):
        return self.data.get(key, "")

    def set(self, key, value):
        self.data[key] = str(value)

    def delete(self, key):
        self.data.pop(key, None)

    def clear(self, keys):
        for key in keys:
            self.delete(key)


class DummySoundCloudClient:
    def credentials(self):
        return {"client_id": "client-id", "client_secret": "client-secret", "redirect_uri": "unused"}


class PublicApiContractTests(unittest.TestCase):
    def test_search_tracks_openapi_contract(self):
        response = FakeResponse(
            200,
            {"collection": [{"urn": "soundcloud:tracks:1", "title": "Test"}], "next_href": "https://api.soundcloud.com/tracks?cursor=abc"},
        )
        session = RecordingSession([response])
        with patch("app.core.public_api.requests.Session", return_value=session):
            rows, next_href = search_tracks("dark techno", "token-123", 20)
        self.assertEqual(rows[0]["title"], "Test")
        self.assertEqual(next_href, "https://api.soundcloud.com/tracks?cursor=abc")
        method, url, kwargs = session.calls[0]
        self.assertEqual(method, "GET")
        self.assertEqual(url, f"{API_BASE}/tracks")
        self.assertEqual(kwargs["headers"]["Authorization"], "OAuth token-123")
        self.assertEqual(kwargs["params"]["q"], "dark techno")
        self.assertEqual(kwargs["params"]["limit"], 20)
        self.assertEqual(kwargs["params"]["linked_partitioning"], "true")
        self.assertNotIn("client_secret", kwargs["params"])

    def test_search_tracks_401_is_clear(self):
        session = RecordingSession([FakeResponse(401, {"error": "unauthorized"}, "unauthorized")])
        with patch("app.core.public_api.requests.Session", return_value=session):
            with self.assertRaises(SoundCloudPublicApiError) as cm:
                search_tracks("x", "bad-token", 5)
        self.assertEqual(cm.exception.status, 401)
        self.assertIn("HTTP 401", str(cm.exception))

    def test_429_backoff_is_bounded_then_success(self):
        session = RecordingSession([
            FakeResponse(429, {"error": "rate"}, "rate", {"Retry-After": "0"}),
            FakeResponse(429, {"error": "rate"}, "rate", {"Retry-After": "0"}),
            FakeResponse(200, {"collection": [], "next_href": None}),
        ])
        with patch("app.core.public_api.time.sleep", return_value=None) as sleeper:
            response = _request_with_backoff(session, "GET", f"{API_BASE}/tracks", operation="Test", timeout=1)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(session.calls), 3)
        self.assertEqual(sleeper.call_count, 2)

    def test_429_final_failure_is_clear(self):
        session = RecordingSession([
            FakeResponse(429, None, "rate"), FakeResponse(429, None, "rate"), FakeResponse(429, None, "rate")
        ])
        with patch("app.core.public_api.time.sleep", return_value=None):
            with self.assertRaises(SoundCloudPublicApiError) as cm:
                _request_with_backoff(session, "GET", f"{API_BASE}/tracks", operation="Test", timeout=1)
        self.assertEqual(cm.exception.status, 429)
        self.assertIn("HTTP 429", str(cm.exception))

    def test_client_credentials_uses_http_basic_and_caches_refresh(self):
        secure = DummySecure({"access_token": "USER-TOKEN", "refresh_token": "USER-REFRESH"})
        cfg = SimpleNamespace(config=SimpleNamespace(timeout_seconds=10))
        client = PublicApiClient(DummySoundCloudClient(), cfg, secure)
        session = RecordingSession([FakeResponse(200, {"access_token": "PUBLIC", "refresh_token": "PUBLIC-REFRESH", "expires_in": 3600})])
        client.session = session
        token = client.obtain_client_credentials_token(force_new=True)
        self.assertEqual(token, "PUBLIC")
        method, url, kwargs = session.calls[0]
        self.assertEqual(method, "POST")
        self.assertEqual(url, TOKEN_URL)
        self.assertEqual(kwargs["data"], {"grant_type": "client_credentials"})
        self.assertEqual(kwargs["auth"], ("client-id", "client-secret"))
        self.assertEqual(secure.get("public_refresh_token"), "PUBLIC-REFRESH")
        # User delegated OAuth namespace must remain untouched.
        self.assertEqual(secure.get("access_token"), "USER-TOKEN")
        self.assertEqual(secure.get("refresh_token"), "USER-REFRESH")

    def test_cached_public_token_avoids_new_exchange(self):
        secure = DummySecure({
            "public_access_token": "CACHED",
            "public_refresh_token": "REFRESH",
            "public_expires_at": str(int(time.time()) + 1800),
        })
        cfg = SimpleNamespace(config=SimpleNamespace(timeout_seconds=10))
        client = PublicApiClient(DummySoundCloudClient(), cfg, secure)
        client.session = RecordingSession([])
        self.assertEqual(client.access_token(), "CACHED")
        self.assertEqual(client.session.calls, [])

    def test_refresh_token_single_use_replaced(self):
        secure = DummySecure({"public_refresh_token": "OLD"})
        cfg = SimpleNamespace(config=SimpleNamespace(timeout_seconds=10))
        client = PublicApiClient(DummySoundCloudClient(), cfg, secure)
        session = RecordingSession([FakeResponse(200, {"access_token": "NEW-A", "refresh_token": "NEW-R", "expires_in": 3600})])
        client.session = session
        token = client.refresh_public_token()
        self.assertEqual(token, "NEW-A")
        self.assertEqual(secure.get("public_refresh_token"), "NEW-R")
        _, _, kwargs = session.calls[0]
        self.assertEqual(kwargs["data"]["grant_type"], "refresh_token")
        self.assertEqual(kwargs["data"]["refresh_token"], "OLD")

    def test_next_href_rejects_foreign_host(self):
        secure = DummySecure({"public_access_token": "CACHED", "public_expires_at": str(int(time.time()) + 1800)})
        cfg = SimpleNamespace(config=SimpleNamespace(timeout_seconds=10))
        client = PublicApiClient(DummySoundCloudClient(), cfg, secure)
        with self.assertRaises(ValueError):
            client.fetch_next_page("https://evil.example/tracks?cursor=1")


if __name__ == "__main__":
    unittest.main()

class PublicProfileAnalyzerContractTests(unittest.TestCase):
    def test_resolve_profile_follows_only_soundcloud_api_redirect(self):
        secure = DummySecure({"public_access_token":"TOK","public_expires_at":str(int(time.time())+1800)})
        cfg = SimpleNamespace(config=SimpleNamespace(timeout_seconds=10,page_limit=200,request_delay_seconds=0))
        client = PublicApiClient(DummySoundCloudClient(), cfg, secure)
        first=FakeResponse(302,None,"",{"Location":"https://api.soundcloud.com/users/soundcloud:users:123"})
        second=FakeResponse(200,{"urn":"soundcloud:users:123","username":"Artist"})
        session=RecordingSession([first,second])
        # resolve_profile uses .get; emulate requests.Session.get
        session.get=lambda url,**kwargs: session.request("GET",url,**kwargs)
        client.session=session
        data=client.resolve_profile("https://soundcloud.com/artist")
        self.assertEqual(data["urn"],"soundcloud:users:123")
        self.assertEqual(session.calls[1][1],"https://api.soundcloud.com/users/soundcloud:users:123")

    def test_fetch_user_tracks_uses_urn_and_linked_partitioning(self):
        secure = DummySecure({"public_access_token":"TOK","public_expires_at":str(int(time.time())+1800)})
        cfg = SimpleNamespace(config=SimpleNamespace(timeout_seconds=10,page_limit=200,request_delay_seconds=0))
        client = PublicApiClient(DummySoundCloudClient(), cfg, secure)
        session=RecordingSession([FakeResponse(200,{"collection":[{"urn":"soundcloud:tracks:1"}],"next_href":None})])
        client.session=session
        rows=client.fetch_user_tracks("soundcloud:users:123")
        self.assertEqual(len(rows),1)
        self.assertIn("/users/soundcloud:users:123/tracks?limit=200&linked_partitioning=true",session.calls[0][1])
