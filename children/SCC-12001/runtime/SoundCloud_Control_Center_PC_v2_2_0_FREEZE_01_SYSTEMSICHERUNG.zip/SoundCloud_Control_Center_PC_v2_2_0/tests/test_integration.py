import json
import queue
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace

from app.core.tasks import TaskContext
from app.services.analysis import AnalysisService


class TestConfig:
    def __init__(self, root: Path):
        self.config = SimpleNamespace(
            checkpoint_every=2,
            favoriter_delay_seconds=0,
            delete_delay_seconds=0,
            request_delay_seconds=0,
        )
        self._root = root

    @property
    def export_root(self) -> Path:
        self._root.mkdir(parents=True, exist_ok=True)
        return self._root


class FakeClient:
    def __init__(self):
        self.deleted = []

    def fetch_account(self, cancel_event=None):
        return {"id": 666, "username": "FRAGGELPOWER666", "track_count": 4}

    def fetch_all_tracks(self, progress=None, cancel_event=None):
        rows = [
            {"id": 1, "urn": "soundcloud:tracks:1", "title": "Dark Signal", "duration": 360000, "created_at": "2026-07-01T10:00:00Z", "playback_count": 100, "likes_count": 2, "comment_count": 1, "reposts_count": 0, "permalink_url": "https://sc/1", "genre": "Psytechno", "tag_list": "lyvra"},
            {"id": 2, "urn": "soundcloud:tracks:2", "title": "Dark Signal Copy", "duration": 361000, "created_at": "2026-07-02T10:00:00Z", "playback_count": 50, "likes_count": 1, "comment_count": 0, "reposts_count": 0, "permalink_url": "https://sc/2"},
            {"id": 3, "urn": "soundcloud:tracks:3", "title": "No Signal", "duration": 180000, "created_at": "2026-07-03T10:00:00Z", "playback_count": 0, "likes_count": 0, "comment_count": 0, "permalink_url": "https://sc/3"},
            {"id": 4, "urn": "soundcloud:tracks:4", "title": "Missing Counter", "duration": 200000, "created_at": "2026-07-04T10:00:00Z", "permalink_url": "https://sc/4"},
        ]
        if progress:
            progress(1, len(rows))
        return rows

    def fetch_favoriters(self, track, cancel_event=None):
        if track["id"] == 2:
            return [{"id": 22, "username": "UserB", "permalink_url": "https://u/22"}]
        return [
            {"id": 11, "username": "UserA", "permalink_url": "https://u/11"},
            {"id": 22, "username": "UserB", "permalink_url": "https://u/22"},
        ]

    def delete_track(self, track_id, cancel_event=None):
        self.deleted.append(track_id)


def make_context(name: str) -> TaskContext:
    return TaskContext("test", name, queue.Queue(), threading.Event())


class IntegrationTests(unittest.TestCase):
    def test_all_pipelines_and_readback(self):
        with tempfile.TemporaryDirectory() as directory:
            config = TestConfig(Path(directory) / "exports")
            client = FakeClient()
            service = AnalysisService(client, config)

            cleanup = service.cleanup_analyze(make_context("cleanup"), {"mode": "all"}, "duplicates", 0, False)
            self.assertEqual(cleanup["candidates"], 1)
            deletion = service.cleanup_delete_from_backup(make_context("delete"), cleanup["folder"], 1)
            self.assertEqual(deletion["deleted"], 1)
            self.assertEqual(client.deleted, [2])

            likes = service.likes_analysis(make_context("likes"), {"mode": "all"}, None)
            evidence = service.evidence_analysis(make_context("evidence"), {"mode": "all"}, None)
            full = service.full_account_analysis(make_context("full"), {"mode": "all"}, None)

            for result in (cleanup, likes, evidence, full):
                folder = Path(result["folder"])
                self.assertTrue(folder.exists())
                manifest = folder / "manifest.json"
                self.assertTrue(manifest.exists())
                self.assertTrue(json.loads(manifest.read_text(encoding="utf-8"))["files"])

            snapshot = json.loads((Path(full["folder"]) / "full_account_complete_snapshot.json").read_text(encoding="utf-8"))
            self.assertEqual(snapshot["field_availability"]["playback_count"]["statuses"]["FIELD_MISSING"], 1)
            self.assertEqual(full["phase_a"], "PHASE_A_COMPLETE")


if __name__ == "__main__":
    unittest.main()
