from pathlib import Path
import compileall, json, sys
ROOT=Path(__file__).resolve().parents[1]
required=[ROOT/'app/main.py',ROOT/'source_original/SoundCloud_Control_Center_v1_3_0_Full_Account_Correction.js',ROOT/'requirements-runtime.txt']
missing=[str(p) for p in required if not p.exists()]
ok=compileall.compile_dir(str(ROOT/'app'),quiet=1)
report={'python':sys.version,'missing':missing,'compile_ok':ok,'status':'PASS' if ok and not missing else 'FAIL'}
(ROOT/'logs').mkdir(exist_ok=True)
(ROOT/'logs'/'preflight.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
raise SystemExit(0 if report['status']=='PASS' else 1)
