from pathlib import Path
import hashlib,json,zipfile,datetime,sys
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'freeze'; OUT.mkdir(exist_ok=True)
exclude={'.runtime','dist','build','__pycache__'}
exclude_files={'freeze/SYSTEM_FREEZE_MANIFEST.json','freeze/SYSTEMSICHERUNG_READBACK.json','SHA256SUMS.txt','SCC_PC_v2_2_0_SHA256SUMS.txt'}
files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or any(part in exclude for part in p.parts): continue
    if p.suffix in {'.pyc'} or p.name.endswith('.zip'): continue
    rel=p.relative_to(ROOT).as_posix()
    if rel in exclude_files: continue
    h=hashlib.sha256(p.read_bytes()).hexdigest(); files.append({'path':rel,'bytes':p.stat().st_size,'sha256':h})
manifest={'freeze_id':'SCC-PC-v2.2.0-FREEZE-01','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file_count':len(files),'files':files}
mp=OUT/'SYSTEM_FREEZE_MANIFEST.json'; mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
zip_path=ROOT.parent/'SoundCloud_Control_Center_PC_v2_2_0_FREEZE_01_SYSTEMSICHERUNG.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for item in files:
        z.write(ROOT/item['path'],arcname=f"SoundCloud_Control_Center_PC_v2_2_0/{item['path']}")
    z.write(mp,arcname='SoundCloud_Control_Center_PC_v2_2_0/freeze/SYSTEM_FREEZE_MANIFEST.json')
# Readback
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip(); names=z.namelist()
result={'zip':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'entries':len(names),'crc_pass':bad is None,'status':'PASS' if bad is None else 'FAIL'}
(ROOT/'freeze'/'SYSTEMSICHERUNG_READBACK.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['status']=='PASS' else 1)
