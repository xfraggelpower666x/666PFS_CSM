typedef unsigned long DWORD;
typedef int BOOL;
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef void *HANDLE;
typedef char *LPSTR;
typedef const char *LPCSTR;
typedef void *LPVOID;
typedef unsigned long long ULONG_PTR;
typedef struct _STARTUPINFOA {
  DWORD cb; LPSTR lpReserved; LPSTR lpDesktop; LPSTR lpTitle;
  DWORD dwX; DWORD dwY; DWORD dwXSize; DWORD dwYSize;
  DWORD dwXCountChars; DWORD dwYCountChars; DWORD dwFillAttribute;
  DWORD dwFlags; WORD wShowWindow; WORD cbReserved2; BYTE *lpReserved2;
  HANDLE hStdInput; HANDLE hStdOutput; HANDLE hStdError;
} STARTUPINFOA;
typedef struct _PROCESS_INFORMATION {
  HANDLE hProcess; HANDLE hThread; DWORD dwProcessId; DWORD dwThreadId;
} PROCESS_INFORMATION;

__declspec(dllimport) DWORD __stdcall GetModuleFileNameA(HANDLE, LPSTR, DWORD);
__declspec(dllimport) BOOL __stdcall CreateProcessA(LPCSTR, LPSTR, LPVOID, LPVOID, BOOL, DWORD, LPVOID, LPCSTR, STARTUPINFOA*, PROCESS_INFORMATION*);
__declspec(dllimport) DWORD __stdcall WaitForSingleObject(HANDLE, DWORD);
__declspec(dllimport) BOOL __stdcall CloseHandle(HANDLE);
__declspec(dllimport) void __stdcall ExitProcess(DWORD);
__declspec(dllimport) int __stdcall MessageBoxA(HANDLE, LPCSTR, LPCSTR, unsigned int);

static void zero(void *p, unsigned long n) { unsigned char *b=(unsigned char*)p; while(n--) *b++=0; }
static unsigned long slen(const char *s) { unsigned long n=0; while(s[n]) n++; return n; }
static void scat(char *dst, const char *src) { unsigned long d=slen(dst), i=0; while(src[i]) dst[d++]=src[i++]; dst[d]=0; }
static void scopy(char *dst, const char *src) { unsigned long i=0; while(src[i]) { dst[i]=src[i]; i++; } dst[i]=0; }

static char exe[4096]; static char dir[4096]; static char cmd[12288];

void __stdcall mainCRTStartup(void) {
  DWORD len;
  STARTUPINFOA si; PROCESS_INFORMATION pi; unsigned long i;
  zero(exe,sizeof(exe)); zero(dir,sizeof(dir)); zero(cmd,sizeof(cmd)); zero(&si,sizeof(si)); zero(&pi,sizeof(pi));
  len=GetModuleFileNameA((HANDLE)0,exe,sizeof(exe)-1);
  if(!len) { MessageBoxA((HANDLE)0,"Der Programmordner konnte nicht bestimmt werden.","SoundCloud Control Center",0x10); ExitProcess(2); }
  scopy(dir,exe);
  i=len; while(i>0 && dir[i-1]!='\\' && dir[i-1]!='/') i--; if(i>0) dir[i-1]=0;
  scat(cmd,"\""); scat(cmd,dir); scat(cmd,"\\.runtime\\Scripts\\pythonw.exe\" \""); scat(cmd,dir); scat(cmd,"\\app\\main.py\"");
  si.cb=sizeof(si);
  if(!CreateProcessA((LPCSTR)0,cmd,(LPVOID)0,(LPVOID)0,0,0,(LPVOID)0,dir,&si,&pi)) {
    MessageBoxA((HANDLE)0,"Die Python-Laufzeit fehlt oder konnte nicht gestartet werden. Bitte zuerst START.bat ausfuehren.","SoundCloud Control Center",0x10);
    ExitProcess(3);
  }
  WaitForSingleObject(pi.hProcess,0xFFFFFFFFUL);
  CloseHandle(pi.hThread); CloseHandle(pi.hProcess); ExitProcess(0);
}
