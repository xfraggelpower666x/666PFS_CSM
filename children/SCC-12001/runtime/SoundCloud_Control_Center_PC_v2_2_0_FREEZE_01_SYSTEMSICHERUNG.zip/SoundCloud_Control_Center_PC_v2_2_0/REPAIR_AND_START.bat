@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
call START.bat --prepare-only
if errorlevel 1 exit /b %errorlevel%
.runtime\Scripts\python.exe -m pip install --upgrade --force-reinstall -r requirements-runtime.txt
.runtime\Scripts\python.exe tools\preflight.py
if errorlevel 1 (
  echo Reparatur nicht erfolgreich. Siehe logs\bootstrap.log
  pause
  exit /b 1
)
start "" SoundCloud_Control_Center.exe
