@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set "LOG=%~dp0logs\bootstrap.log"
echo.>>"%LOG%"
echo ==== START %DATE% %TIME% ====>>"%LOG%"

set "PYTHON="
where py >nul 2>nul && set "PYTHON=py -3"
if not defined PYTHON (where python >nul 2>nul && set "PYTHON=python")

if defined PYTHON (
  %PYTHON% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >>"%LOG%" 2>&1
  if errorlevel 1 (
    echo Vorhandenes Python ist zu alt; Update auf Python 3.12 wird versucht.>>"%LOG%"
    set "PYTHON="
  )
)

if not defined PYTHON (
  where winget >nul 2>nul
  if errorlevel 1 (
    echo FEHLER: Geeignetes Python fehlt und winget ist nicht vorhanden.>>"%LOG%"
    echo Python konnte nicht automatisch installiert werden. Siehe logs\bootstrap.log
    pause
    exit /b 10
  )
  echo Prüfe/aktualisiere Python 3.12...>>"%LOG%"
  winget upgrade --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements >>"%LOG%" 2>&1
  if errorlevel 1 winget install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements >>"%LOG%" 2>&1
  set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"
  if exist "!PYEXE!" set "PYTHON=!PYEXE!"
)

if not defined PYTHON (
  echo FEHLER: Python wurde nach Installation/Update nicht gefunden.>>"%LOG%"
  pause
  exit /b 11
)

%PYTHON% -c "import sys; assert sys.version_info >= (3,10)" >>"%LOG%" 2>&1
if errorlevel 1 (
  echo FEHLER: Python 3.10 oder neuer erforderlich.>>"%LOG%"
  pause
  exit /b 12
)

if not exist ".runtime\Scripts\python.exe" (
  echo Erzeuge isolierte Python-Laufzeit...>>"%LOG%"
  %PYTHON% -m venv .runtime >>"%LOG%" 2>&1 || exit /b 20
)

set "VPY=%~dp0.runtime\Scripts\python.exe"
set "VPYW=%~dp0.runtime\Scripts\pythonw.exe"
"%VPY%" -m pip install --disable-pip-version-check --upgrade pip setuptools wheel >>"%LOG%" 2>&1
if errorlevel 1 goto :pipfail
"%VPY%" -m pip install --disable-pip-version-check --upgrade -r requirements-runtime.txt >>"%LOG%" 2>&1
if errorlevel 1 goto :pipfail

"%VPY%" tools\preflight.py >>"%LOG%" 2>&1
if errorlevel 1 (
  echo Preflight fehlgeschlagen. Siehe logs\bootstrap.log
  pause
  exit /b 30
)

if /I "%~1"=="--prepare-only" exit /b 0

if exist "SoundCloud_Control_Center.exe" (
  start "" "%~dp0SoundCloud_Control_Center.exe"
) else (
  start "" "%VPYW%" "%~dp0app\main.py"
)
exit /b 0

:pipfail
echo Abhängigkeiten konnten nicht installiert oder aktualisiert werden.>>"%LOG%"
echo Siehe logs\bootstrap.log
pause
exit /b 21
