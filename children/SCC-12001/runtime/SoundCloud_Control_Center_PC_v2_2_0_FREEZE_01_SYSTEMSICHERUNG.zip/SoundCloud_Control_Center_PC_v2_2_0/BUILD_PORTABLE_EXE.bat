@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
call START.bat --prepare-only
if not exist ".runtime\Scripts\python.exe" exit /b 1
.runtime\Scripts\python.exe -m pip install --upgrade -r requirements.txt
.runtime\Scripts\pyinstaller.exe --noconfirm --clean --windowed --onefile --name SoundCloud_Control_Center_Portable --paths . app\main.py
if errorlevel 1 exit /b 2
echo Portable EXE: dist\SoundCloud_Control_Center_Portable.exe
pause
