@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo SOUNDCLOUD CONTROL CENTER PC - DIAGNOSE
echo ============================================================
ver
where winget 2>nul
where py 2>nul
where python 2>nul
if exist ".runtime\Scripts\python.exe" (
  .runtime\Scripts\python.exe --version
  .runtime\Scripts\python.exe -m pip --version
  .runtime\Scripts\python.exe tools\preflight.py
) else (
  echo .runtime fehlt - START.bat zuerst ausfuehren.
)
if exist "SoundCloud_Control_Center.exe" (
  echo Launcher EXE: VORHANDEN
) else (
  echo Launcher EXE: FEHLT
)
echo.
echo Log: %~dp0logs\bootstrap.log
pause
