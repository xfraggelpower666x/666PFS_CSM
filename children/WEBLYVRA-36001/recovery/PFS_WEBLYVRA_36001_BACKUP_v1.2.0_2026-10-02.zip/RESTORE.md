# WEBLyvra Backup 1.2.0

Vor Wiederherstellung SHA-256 des ZIP und alle Dateien gegen PFS_BACKUP_MANIFEST.json prüfen. WEBLyvra/live/dist zunächst lokal per HTTP bedienen. Bestehende Deployment-Anleitung unter WEBLyvra/ erhalten. Produktionsquelle: GitHub, Branch lyvra. Kein automatisches Restore und kein Authority-Wechsel.

Externe Webradio-Integrationsdateien stehen separat unter external-dependencies/WebRadio. Diese sechs Dateien sind kein vollständiges Webradio-System; nur nach Vergleich mit dessen aktuellem Repository übernehmen. Stream und Backend bleiben externe Abhängigkeiten. Keine Zugangsdaten enthalten.

Neue Version umfasst die veröffentlichten Avatar-, Neon-, Player-Höhen- und HTML-Copy-Ergänzungen. Echte Audio-, Mobil-/Desktop- und Screenreader-Prüfungen bleiben offen. Frühere Releases sind unverändert enthalten.
