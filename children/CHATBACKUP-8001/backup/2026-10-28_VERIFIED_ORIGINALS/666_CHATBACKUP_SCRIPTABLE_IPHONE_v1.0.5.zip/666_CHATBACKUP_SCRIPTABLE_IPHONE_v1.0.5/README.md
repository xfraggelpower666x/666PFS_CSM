# 666 ChatBackup Scriptable iPhone v1.0.5

Targeted compatibility repair for ChatGPT shared conversations that use the newer server-rendered transcript markup.

## New supported transcript family

In addition to the older selectors, the DOM recovery path now recognizes:

- `data-conversation-transcript`
- `data-message-role="assistant"`
- `data-message-role="user"`
- `data-assistant-markdown-root`
- `data-assistant-markdown`
- `data-user-message-copy`

The old `data-message-author-role` / `conversation-turn-*` path remains preserved.

## Recovery order

1. Structured React Flight / legacy source parser
2. Fetched-source DOM recovery
3. Live WebView DOM recovery
4. Manual clipboard import

No empty or invented backup is written when no messages can be verified.
