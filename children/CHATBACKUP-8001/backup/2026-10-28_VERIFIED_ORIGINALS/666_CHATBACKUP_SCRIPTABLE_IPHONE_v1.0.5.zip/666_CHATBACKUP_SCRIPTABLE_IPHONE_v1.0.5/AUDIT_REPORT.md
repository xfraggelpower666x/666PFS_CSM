# Audit Report — 666 ChatBackup Scriptable iPhone v1.0.5

## Scope
Targeted repair after v1.0.4 returned `DOM_NO_MESSAGES` while the fetched share HTML contained the visible conversation.

## Findings
- Fetch itself: PASS (user diagnostic showed 3,423,112 HTML characters).
- v1.0.4 injected WebView JavaScript syntax: PASS after v1.0.4 fix.
- Legacy DOM selectors on failing share: NOT APPLICABLE / 0 nodes.
- New SSR transcript markup identified live: PASS.
- `data-message-role=assistant|user`: PRESENT.
- `data-conversation-transcript`: PRESENT.
- `data-assistant-markdown-root`: PRESENT.
- `data-user-message-copy`: PRESENT.

## Repair audit
- Legacy selectors preserved: PASS.
- SSR selectors added additively: PASS.
- Role inference remains fail-closed: PASS.
- Main JS syntax (`node --check`): PASS.
- Generated WebView JS syntax (`node --check`): PASS.
- Regex escape regression guard: PASS.
- Manual import preserved: PASS.
- Group support preserved: PASS.
- Image support preserved: PASS.

## Platform gate
- Real iPhone/Scriptable runtime readback: PENDING.
- Exact failing share readback in Scriptable: PENDING.
