# Repair Notes v1.0.5

## Root cause

The failing share variant was not using the DOM markers expected by v1.0.4. The fetched HTML contained the conversation under a server-rendered transcript:

- `data-conversation-transcript`
- message `<li>` nodes with `data-message-role`
- assistant content under `data-assistant-markdown-root`
- user content under `data-user-message-copy`

v1.0.4 only searched `data-message-author-role` and `data-testid^="conversation-turn-"`, so diagnostics reported 0/0 even though the transcript existed in the HTML.

## Repair

- Added the SSR transcript selector family additively.
- Preserved legacy selector support.
- Uses source-provided role only; no role guessing.
- Uses message element `id` when available.
- Assistant/user body selection is role-specific.
- Fallback attribution stripping is limited to known labels.
- Preserved v1.0.4 escaped generated-WebView JavaScript fix.

## Verification

- Main JavaScript syntax: PASS.
- Generated `evaluateJavaScript()` payload syntax: PASS.
- Live structural evidence for the failing share family: PASS.
- iPhone/Scriptable runtime readback: PENDING.
