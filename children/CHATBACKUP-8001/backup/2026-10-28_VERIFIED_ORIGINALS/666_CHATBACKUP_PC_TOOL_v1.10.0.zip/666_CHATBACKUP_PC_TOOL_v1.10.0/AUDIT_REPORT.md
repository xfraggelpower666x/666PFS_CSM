# Audit Report — 666 ChatBackup PC Tool v1.10.0

## Anlass

Am 2026-10-22 wurde live verifiziert, dass mehrere zuvor funktionierende ChatGPT-`/share/`-URLs bei einem direkten nicht authentifizierten Abruf nur noch eine Login-/Signup-Hülle liefern. Die Antworten enthalten weiterhin React-Router-Streaming-Grundstruktur, aber keinen bekannten Conversation-Payload (`mapping`, `linear_conversation`, `conversation_id`, `data-message-author-role`). Dadurch konnten sowohl PC- als auch Scriptable-Direktparser keine Gesprächsdaten extrahieren.

## Audit 1 — Befund

- bestehender React-Flight/Next/Data-Parser: **INTAKT**
- direkter Response enthält Conversation-Payload: **NICHT ZUVERLÄSSIG**
- alter Fehlertext „kein unterstütztes Share-Datenformat“ für Auth-Hülle: **IRREFÜHREND**
- Private/Manual fail-closed Transcript-Parser: **GEEIGNETER RECOVERY-BAUSTEIN**
- Cookie-/Session-Extraktion aus Browser: **NICHT ERFORDERLICH / NICHT IMPLEMENTIERT**

## Reparatur

- `AuthWallDetected` als eigener Fehler-/Zustandstyp
- `detect_auth_wall()` als konservativer Pre-Parser-Gate
- Erkennung verlangt Login-Marker bei gleichzeitig fehlenden Conversation-Payload-Markern
- Backend v1.4.0 erhält `recover_browser_transcript()`
- eigener Parserstatus `browser-assisted-transcript`
- eigener Capture-Status `BROWSER_CLIPBOARD_RECOVERY`
- Integritätsprofil führt `BROWSER_ASSISTED_RECOVERY`
- GUI erhält linken Menüpunkt `Browser Recovery / Browser-Recovery`
- nach `AUTH_WALL_DETECTED` öffnet der Recovery-Dialog automatisch
- Benutzer öffnet den Share-Link im normal angemeldeten Browser und kopiert den sichtbaren Chattext
- Zwischenablage wird mit dem bestehenden fail-closed Manual-/Gruppenchat-Parser rekonstruiert
- Struktur-Inspector öffnet nach erfolgreicher Recovery
- große Recovery-Transcripts werden chunked in den Editor eingesetzt
- keine Browser-Cookies, Tokens oder Credentials werden gelesen; keine Authentifizierung wird umgangen
- Bild-/Dateibytes werden aus reinem Clipboard-Text nicht erfunden

## Re-Audit

- Python compile core/backend/gui: **PASS**
- interne Regressionstests: **16/16 PASS**
- Pytest: **41/41 PASS**
- Auth-Wall-Erkennung Fixture: **PASS**
- Browser-Recovery Reconstruction Fixture: **PASS**
- GUI-Smoke: **PASS**
- Browser-Recovery Toplevel real erzeugt: **PASS**
- GUI-Titel v1.10.0: **PASS**
- Bootstrap-Version v1.10.0: **PASS**
- PowerShell 5.1 UTF-8 BOM: **PASS**
- PowerShell Body ASCII-only: **PASS**
- PowerShell CRLF: **PASS**
- bestehende Manual-/Private-/Group-/Image-/Structure-Funktionen: **REGRESSION PASS**
- eingebetteter Scriptable iPhone Companion: **PRESERVED**

## Offene reale Plattform-Gates

- `WINDOWS_v1.10.0_RUNTIME_READBACK=PENDING`
- echter Browser-Recovery-Readback auf dem Benutzer-Windows-PC: **PENDING**
- echte Bildwiederherstellung bei Auth-Wall: **NICHT BEHAUPTET** — Clipboard-Text enthält keine garantierten Bildbytes

## Entscheidung

`SOURCE_VERIFIED / AUTH_WALL_REPAIRED / WINDOWS_RUNTIME_READBACK_PENDING`
