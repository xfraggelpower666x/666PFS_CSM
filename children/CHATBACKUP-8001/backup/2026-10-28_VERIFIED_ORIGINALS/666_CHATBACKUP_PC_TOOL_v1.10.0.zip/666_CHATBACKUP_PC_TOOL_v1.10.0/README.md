# 666 ChatBackup PC Tool v1.10.0

Windows-Desktoptool zum Archivieren öffentlicher ChatGPT-Share-Chats sowie privater/manuell kopierter Einzel- und Gruppenverläufe. Englisch ist Standard; die gewählte Sprache bleibt persistent.


## Neu in v1.10.0 — AUTH-Wall Detection & Browser-Assisted Share Recovery

ChatGPT kann aktuell bei direkten automatisierten Abrufen eines `/share/`-Links nur noch eine Login-/Signup-Hülle liefern, obwohl derselbe Link im normal angemeldeten Browser weiterhin geöffnet werden kann. In dieser Antwort fehlen die eigentlichen Gesprächsdaten wie `mapping` und `linear_conversation`.

v1.10.0 behandelt das ausdrücklich als eigenen Zustand:

- `AUTH_WALL_DETECTED` statt irreführendem „unbekanntes Parserformat“
- konservative Erkennung: Login-Marker vorhanden, bekannte Gesprächspayload-Marker fehlen
- automatischer GUI-Übergang in **Browser Recovery**
- Share-Link im normal angemeldeten Browser öffnen
- sichtbaren vollständigen Chattext kopieren
- Zwischenablage durch ChatBackup analysieren
- fail-closed Rekonstruktion von Rollen, Gruppen-Teilnehmern, Copy/UI-Feldern und Nachrichtenstruktur
- Struktur-Inspector öffnet nach erfolgreicher Wiederherstellung
- keine Cookie-Extraktion, kein Login-Bypass, keine Browser-Credential-Nutzung
- Bild-/Dateibytes werden aus reinem Zwischenablagetext nicht erfunden

Der bisherige Direktparser bleibt Stufe 1. Nur wenn der Response keine Conversation-Daten, sondern eine Auth-Hülle enthält, wird Browser Recovery angeboten.

## Beibehalten — iPhone / Scriptable Companion

Das PC-Paket enthält weiterhin unter `mobile_scriptable/` das eigenständige `666 ChatBackup Scriptable iPhone v1.0.0` als ZIP. Die mobile Schwester bleibt getrennt versioniert; ihre Private/Manual-Funktion ist weiterhin der sichere Rettungsweg, wenn ein direkter Share-Abruf keinen Conversation-Payload erhält.

## Neu in v1.8.2 — Direkter Bilddownload im Chat-Bildbrowser

- jedes direkt erreichbare Chat-Bild hat jetzt einen eigenen **Download**-Button
- **Ausgewählte herunterladen / Download Selected** speichert alle angehakten direkt erreichbaren Bilder in einen gewählten Ordner
- **Alle erreichbaren herunterladen / Download All Reachable** speichert alle abrufbaren Chat-Bilder gemeinsam
- Download ist auch aus der Großansicht möglich
- gespeicherte Bilddateien werden bytegenau zurückgelesen und SHA-256-verifiziert, wenn Export-Verifikation aktiv ist
- Portable ZIP speichert Bildbytes als echte Binärdateien unter `assets/`, **nicht als Base64**
- Pointer-only-Bilder ohne erreichbare HTTP(S)-URL bleiben als Metadaten erhalten und können nicht erfunden werden

## Neu in v1.8.1 — Audit, Repair & Group-Chat Hardening

- vollständiger Versionskohärenz-Repair: App, VERSION.json, Bootstrap-Status und Abhängigkeitsmanifest melden jetzt denselben Stand
- strukturierte Assistant-/Custom-GPT-Identitäten werden nicht mehr pauschal zu `ChatGPT` zusammengezogen
- Teilnehmerverzeichnisse werden primär nach stabiler ID dedupliziert
- generische Rollenplatzhalter wie `user` / `assistant` werden nicht als Personennamen übernommen
- manueller Gruppenchat-Parser gegen falsche Sprecher aus normalen Markdown-Überschriften gehärtet
- `## Alice`-Sprecherüberschriften bleiben für exportierte Transcripts unterstützt, wenn sie an Transcript-Grenzen (`---`) stehen
- neue Regressionstests für Heading-False-Positives, Assistant-Identität und Versionskohärenz
- bestehende v1.8.0-Gruppenchat-, v1.7.0-Manual-, v1.6.0-Sprach-, Bildbrowser- und Raw-Source-Funktionen bleiben erhalten

## Gruppenchat / Mehrteilnehmer

- strukturierte Share-Daten: explizite Teilnehmer-IDs, Anzeigenamen und Benutzernamen werden pro Nachricht erhalten
- manuelle Transcripts: eindeutige `Name:`-Sprecherzeilen werden erkannt; Markdown-Sprecherüberschriften nur an klaren Transcript-Grenzen
- Machine JSON `666.chatbackup.machine.v1 / 1.3.0` und Structure Inspector `1.1.0` führen Teilnehmerinformationen weiter
- fehlende Identität bleibt `UNRESOLVED`; es wird nicht anhand von Stil oder Reihenfolge geraten

## Neu in v1.5.0 — ChatBackend

- eigener Backend-Orchestrator `app/chatbackup_backend.py`
- verlustarme Message-Struktur mit ID, Content-Type, Status, Recipient, `rawContent`, `rawMetadata`, `renderedText`, Warnungen und Assets
- statische Erkennung von `GenUI.copy(identifier)` und zugehörigen literalen `const`/`let`-Strings
- keine Ausführung von Chat-JavaScript; dynamische Templates bleiben ungelöst
- Parser-Provenienz mit Versuchsliste und Primärfehler
- Raw-Share-Source-Capture mit SHA-256 und 12-Millionen-Zeichen-Grenze
- Reparse-API für archiviertes Share-HTML
- neuer Struktur-Inspector in der GUI
- Maschinenexport-Schema `1.2.0`
- Portable-ZIP erhält `source/conversation.raw.json`, `source/parser_receipt.json` und optional `source/share-source.html.gz`
- Integritätsstatus trennt Quelle, Raw-Erhalt, UI-Bindungen, Assets und visuelle Parität

## Erhalten aus v1.4.0

- Cyber-Neon-GUI in Pink/Lila/Cyan
- große adaptive Fenstergröße und Neon-Hover
- Fortschrittsbalken bei großen Einfügevorgängen
- Share-Link-Parser: React Flight, `__NEXT_DATA__`, statischer DOM-Fallback
- Chat-Bildbrowser mit Auswahl pro Bild
- Asset-Pointer-Erhaltung und konservative URL-Anreicherung
- TXT, Markdown, JavaScript, JSON, JSONL
- Portable ZIP mit ausgewählten Bildern
- bytegenauer Export-Readback / SHA-256
- PowerShell-5.1-sicherer Bootstrap
- Node.js / NPM weiterhin `NOT_REQUIRED`

## Start

Unter Windows den Ordner vollständig entpacken und `START_TOOL.bat` starten. Der Bootstrap prüft Python, Tkinter und Pillow für den Quellstart. Eine gebaute Standalone-EXE bringt ihre Python-Laufzeit mit.

## Struktur-Inspector

Nach einem Share-Import über `Struktur-Inspector` erreichbar. Er zeigt pro Nachricht u. a. Message-ID, Rolle, Content-Type, Raw Content, Raw Metadata, Copy-/UI-Felder, Warnungen und gerenderten Text.

## Raw Source

In den Einstellungen ist `Original-Share-Quelldaten für Reparse/Archiv erhalten` standardmäßig aktiv. Die HTML-Quelle wird nicht als sichtbarer Export ausgegeben, sondern für das Portable-Archiv komprimiert gespeichert. Bei mehr als 12.000.000 Zeichen wird nicht still abgeschnitten, sondern der Status `RAW_TOO_LARGE_NOT_STORED` gesetzt.

## Exportformate

- TXT — Editorinhalt
- MD — lesbares Markdown mit Integritätssektion und erkannten Copy-Feldern
- JS — sicher serialisiertes Exportobjekt
- JSON — Maschinenformat `666.chatbackup.machine.v1 / 1.3.0`
- JSONL — streambares Maschinenformat
- Portable ZIP + Bilder — alle Formate, Assets und Source-/Parser-Artefakte

## Grenzen

- Öffentliche `/share/`- bzw. `/s/`-Links sind ohne Anmeldung direkt auslesbar.
- Private `/c/`-Links werden nicht authentifizierungsfrei geladen; dafür steht der strukturierte manuelle Import zur Verfügung.
- Dynamische UI-Logik wird nicht ausgeführt.
- Ein Parser-PASS ist ausdrücklich kein Nachweis pixelgenauer UI-Rekonstruktion.
- Nicht öffentlich gelieferte Bildbytes können nicht erfunden werden; Asset-Pointer bleiben aber maschinenlesbar erhalten.
- Eine echte Windows-EXE muss unter Windows gebaut und dort verifiziert werden.

## Neu in v1.5.2: Struktur-Inspector als JSON

Der Struktur-Inspector ist jetzt nicht nur eine Ansicht. Über **Nachricht JSON** lässt sich die aktuell markierte Nachricht exakt strukturiert speichern; **Komplette Struktur JSON** speichert den gesamten Inspector-Snapshot. Das stabile Schema heißt `666.chatbackup.structure-inspector.v1`. Portable ZIPs enthalten denselben Gesamtsnapshot zusätzlich als `source/structure_inspector.json`.


## Neu in v1.8.0 — Gruppenchat- / Mehrteilnehmer-Backend

- explizite Teilnehmer-IDs, Anzeigenamen und Benutzernamen aus strukturierten Share-Daten bleiben erhalten
- automatische Gruppenchat-Erkennung nur anhand expliziter Metadaten oder mindestens zweier explizit unterscheidbarer menschlicher Teilnehmer
- manuelle Gruppenverläufe mit eindeutigen Sprecherzeilen wie `Alice:`, `Bob:`, `ChatGPT:` werden strukturiert rekonstruiert
- keine Identität wird geraten; fehlende Zuordnung bleibt `UNRESOLVED`
- Machine JSON/JSONL, Raw Source und Structure Inspector enthalten Teilnehmerverzeichnis und Teilnehmerbezug je Nachricht
- Machine-Schema `666.chatbackup.machine.v1` jetzt `schemaVersion=1.3.0`
- Structure-Inspector-Schema jetzt `schemaVersion=1.1.0`

Hinweis: Die Funktion dient auch zur Archivierung bestehender/älterer Gruppenchat-Verläufe. Wenn ChatGPT keinen öffentlichen Share-Link anbietet, kann der sichtbare Verlauf über den Private-/Manual-Workflow importiert werden.
