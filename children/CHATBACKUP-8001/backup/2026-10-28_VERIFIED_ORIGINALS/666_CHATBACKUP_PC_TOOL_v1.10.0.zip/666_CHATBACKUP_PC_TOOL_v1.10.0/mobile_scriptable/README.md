# Scriptable iPhone Companion

This PC-tool release bundles the separately usable mobile companion:

- `666_CHATBACKUP_SCRIPTABLE_IPHONE_v1.0.0.zip`
- matching SHA-256 sidecar

Unpack the mobile ZIP and copy `666_CHATBACKUP_SCRIPTABLE_IPHONE.js` into Scriptable on iPhone/iPad.

The iPhone companion is intentionally a native Scriptable workflow, not a Tkinter clone. It provides guided public-share import, private/manual clipboard analysis, group-chat participants, structure JSON, image browsing/direct download, EN/DE language selection, bilingual help, and machine exports compatible with the PC schema family.

Runtime gates are separate: Windows runtime readback does not prove iOS/Scriptable runtime and vice versa.
