from __future__ import annotations

import hashlib
import html as html_lib
import json
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlsplit, urlunsplit

APP_VERSION = "1.1.1"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/150.0.0.0 Safari/537.36"
)

CITATION_MARKER_RE = re.compile(
    r"(?:cite|filecite|navlist|filenavlist)[^]*"
)


@dataclass(slots=True)
class ExportStats:
    source_entries: int = 0
    exported: int = 0
    skipped_hidden: int = 0
    skipped_role: int = 0
    skipped_recipient: int = 0
    skipped_empty: int = 0
    skipped_duplicate: int = 0
    possibly_incomplete: int = 0

    @property
    def skipped_total(self) -> int:
        return (
            self.skipped_hidden
            + self.skipped_role
            + self.skipped_recipient
            + self.skipped_empty
        )

    @property
    def integrity_status(self) -> str:
        return "PASS" if self.possibly_incomplete == 0 else "WATCH"


@dataclass(slots=True)
class ChatMessage:
    role: str
    author: str
    text: str
    created_at: float | None = None


@dataclass(slots=True)
class ChatBackup:
    title: str
    source_url: str
    share_id: str = "shared"
    model: str = ""
    updated_at: float | None = None
    messages: list[ChatMessage] = field(default_factory=list)
    parser: str = ""
    parser_details: str = ""
    warnings: list[str] = field(default_factory=list)
    stats: ExportStats = field(default_factory=ExportStats)


class ChatBackupError(RuntimeError):
    """User-facing error while loading or parsing a backup."""


def normalize_and_validate_share_url(raw_url: str) -> str:
    url = str(raw_url or "").strip()
    if not url:
        raise ChatBackupError("Bitte einen ChatGPT-Share-Link eingeben.")

    url = re.sub(r"^http://", "https://", url, flags=re.IGNORECASE)
    url = url.split("#", 1)[0]

    try:
        parsed = urlsplit(url)
    except ValueError as exc:
        raise ChatBackupError("Der eingegebene Link ist ungültig.") from exc

    host = parsed.netloc.lower().split("@")[-1].split(":")[0]
    if host not in {"chatgpt.com", "www.chatgpt.com", "chat.openai.com", "www.chat.openai.com"}:
        raise ChatBackupError("Der Link gehört nicht zu ChatGPT.")

    path = parsed.path or "/"
    if re.search(r"/c/", path, re.IGNORECASE):
        raise ChatBackupError(
            "Das ist ein privater Chat-Link (/c/...). Bitte im Chat über „Teilen“ "
            "einen öffentlichen Share-Link erstellen."
        )

    if not re.search(r"/(?:share|s)/", path, re.IGNORECASE):
        raise ChatBackupError(
            "Benötigt wird ein öffentlicher ChatGPT-Share-Link wie "
            "https://chatgpt.com/share/..."
        )

    return urlunsplit(("https", parsed.netloc, parsed.path, parsed.query, ""))


def fetch_share_page(
    url: str,
    timeout_seconds: int = 60,
    retries: int = 3,
) -> str:
    last_error: Exception | None = None
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "de-DE,de;q=0.9,en;q=0.8",
        "Referer": "https://chatgpt.com/",
        "Cache-Control": "no-cache",
    }

    for attempt in range(1, max(1, retries) + 1):
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
                status = getattr(response, "status", 200) or 200
                body = response.read()
                encoding = response.headers.get_content_charset() or "utf-8"
                text = body.decode(encoding, errors="replace")

            if status >= 400:
                raise ChatBackupError(
                    f"ChatGPT-Share-Seite konnte nicht geladen werden. HTTP {status}."
                )
            if len(text) < 500:
                raise ChatBackupError(
                    "Die ChatGPT-Share-Seite war leer oder unvollständig."
                )
            return text
        except urllib.error.HTTPError as exc:
            last_error = ChatBackupError(
                f"ChatGPT-Share-Seite konnte nicht geladen werden. HTTP {exc.code}."
            )
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            last_error = ChatBackupError(f"Netzwerkfehler: {reason}")
        except TimeoutError:
            last_error = ChatBackupError("Zeitüberschreitung beim Laden des Share-Links.")
        except Exception as exc:  # pragma: no cover - defensive boundary
            last_error = exc

        if attempt < max(1, retries):
            time.sleep(attempt * 0.75)

    if isinstance(last_error, ChatBackupError):
        raise last_error
    raise ChatBackupError(str(last_error or "Unbekannter Downloadfehler."))


def load_chat_backup(url: str) -> ChatBackup:
    normalized = normalize_and_validate_share_url(url)
    page = fetch_share_page(normalized)
    return parse_shared_conversation(page, normalized)


def parse_shared_conversation(page_html: str, source_url: str) -> ChatBackup:
    errors: list[str] = []

    for loader_index, loader in enumerate(extract_react_flight_loaders(page_html), start=1):
        try:
            decoded = decode_react_flight_loader(loader)
            route = find_share_route(decoded)
            if not route:
                continue
            server_response = route.get("serverResponse") if isinstance(route, dict) else None
            server_response = server_response if isinstance(server_response, dict) else {}
            data = server_response.get("data")
            if not isinstance(data, dict):
                data = route.get("data") if isinstance(route, dict) else None
            if not isinstance(data, dict):
                data = {}
            chat = chat_from_data(data, route, source_url)
            chat.parser = "react-flight"
            chat.parser_details = f"React-Flight-Loader {loader_index}"
            finalize_chat_stats(chat)
            return chat
        except Exception as exc:
            errors.append(f"React-Flight: {exc}")

    try:
        legacy = extract_legacy_next_data(page_html)
        if legacy:
            chat = chat_from_data(legacy["data"], legacy["route"], source_url)
            chat.parser = "legacy-next-data"
            chat.parser_details = "Legacy __NEXT_DATA__"
            finalize_chat_stats(chat)
            return chat
    except Exception as exc:
        errors.append(f"Legacy: {exc}")

    try:
        chat = extract_static_dom_conversation(page_html, source_url)
        if chat.messages:
            chat.parser = "static-dom-fallback"
            chat.parser_details = "Statisch gerenderte sichtbare Nachrichten"
            chat.warnings.append(
                "DOM-Fallback verwendet: Formatierungen, Links oder Anhänge können unvollständig sein."
            )
            finalize_chat_stats(chat)
            return chat
    except Exception as exc:
        errors.append(f"DOM-Fallback: {exc}")

    details = " | ".join(errors[-3:])
    suffix = f" Details: {details}" if details else ""
    raise ChatBackupError(
        "Im Share-Link wurden keine unterstützten Gesprächsdaten gefunden. "
        "Prüfe, ob der öffentliche Link noch gültig ist." + suffix
    )


def extract_react_flight_loaders(page_html: str) -> list[list[Any]]:
    loaders: list[list[Any]] = []
    scripts = re.findall(r"<script\b[^>]*>([\s\S]*?)</script>", page_html, re.IGNORECASE)

    for script in scripts:
        for marker in ("streamController.enqueue(", "self.__next_f.push(", "__next_f.push("):
            start = 0
            while True:
                index = script.find(marker, start)
                if index < 0:
                    break
                arg_start = index + len(marker)
                literal = read_json_value_literal(script, arg_start)
                if literal is None:
                    start = arg_start + 1
                    continue
                raw_literal, end_index = literal
                start = end_index + 1
                try:
                    parsed_argument = json.loads(raw_literal)
                except json.JSONDecodeError:
                    continue

                candidates: list[Any] = []
                if isinstance(parsed_argument, str):
                    stripped = parsed_argument.strip()
                    if stripped.startswith("["):
                        try:
                            candidates.append(json.loads(stripped))
                        except json.JSONDecodeError:
                            pass
                else:
                    candidates.append(parsed_argument)

                for candidate in candidates:
                    if isinstance(candidate, list):
                        # __next_f commonly wraps the actual payload in [id, "..."]
                        if (
                            len(candidate) >= 2
                            and isinstance(candidate[1], str)
                            and candidate[1].lstrip().startswith("[")
                        ):
                            try:
                                nested = json.loads(candidate[1].strip())
                                if isinstance(nested, list):
                                    loaders.append(nested)
                            except json.JSONDecodeError:
                                pass
                        loaders.append(candidate)
    return loaders


def read_json_value_literal(text: str, start_index: int) -> tuple[str, int] | None:
    index = start_index
    while index < len(text) and text[index].isspace():
        index += 1
    if index >= len(text):
        return None

    first = text[index]
    if first == '"':
        escaped = False
        for pos in range(index + 1, len(text)):
            char = text[pos]
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                return text[index : pos + 1], pos
        return None

    if first not in "[{":
        return None

    stack = [first]
    pairs = {"[": "]", "{": "}"}
    in_string = False
    escaped = False
    for pos in range(index + 1, len(text)):
        char = text[pos]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "[{":
            stack.append(char)
        elif char in "]}":
            if not stack or pairs[stack[-1]] != char:
                return None
            stack.pop()
            if not stack:
                return text[index : pos + 1], pos
    return None


def decode_react_flight_loader(loader: list[Any]) -> dict[str, Any]:
    cache: dict[int, Any] = {}
    resolving: set[int] = set()

    def decode_key(raw_key: Any) -> str:
        if isinstance(raw_key, str) and re.fullmatch(r"_\d+", raw_key):
            index = int(raw_key[1:])
            if 0 <= index < len(loader) and isinstance(loader[index], str):
                return loader[index]
        return str(raw_key)

    def resolve(value: Any) -> Any:
        if isinstance(value, int) and not isinstance(value, bool):
            if value in cache:
                return cache[value]
            if not 0 <= value < len(loader):
                return value
            if value in resolving:
                return None
            resolving.add(value)
            resolved = resolve(loader[value])
            resolving.remove(value)
            cache[value] = resolved
            return resolved
        if isinstance(value, list):
            return [resolve(item) for item in value]
        if isinstance(value, dict):
            return {decode_key(key): resolve(item) for key, item in value.items()}
        return value

    decoded: dict[str, Any] = {}
    for index in range(1, len(loader) - 1, 2):
        key = loader[index]
        if isinstance(key, str) and key not in decoded:
            decoded[key] = resolve(loader[index + 1])
    return decoded


def find_share_route(decoded: Any) -> dict[str, Any] | None:
    if not isinstance(decoded, dict):
        return None

    loader_data = decoded.get("loaderData")
    if isinstance(loader_data, dict):
        for key in (
            "routes/share.$shareId.($action)",
            "routes/share.$shareId",
            "routes/s.$shareId.($action)",
            "routes/s.$shareId",
        ):
            route = loader_data.get(key)
            if isinstance(route, dict):
                return route

    seen: set[int] = set()

    def search(value: Any, depth: int) -> dict[str, Any] | None:
        if depth > 12 or not isinstance(value, (dict, list)):
            return None
        marker = id(value)
        if marker in seen:
            return None
        seen.add(marker)

        if isinstance(value, dict):
            direct_data = value.get("data")
            server = value.get("serverResponse")
            server_data = server.get("data") if isinstance(server, dict) else None
            if looks_like_conversation_data(direct_data) or looks_like_conversation_data(server_data):
                return value
            children: Iterable[Any] = value.values()
        else:
            children = value

        for child in children:
            found = search(child, depth + 1)
            if found:
                return found
        return None

    return search(decoded, 0)


def looks_like_conversation_data(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and isinstance(value.get("mapping"), dict)
        and isinstance(value.get("linear_conversation"), list)
    )


def extract_legacy_next_data(page_html: str) -> dict[str, Any] | None:
    match = re.search(
        r"<script\b[^>]*id=[\"']__NEXT_DATA__[\"'][^>]*>([\s\S]*?)</script>",
        page_html,
        re.IGNORECASE,
    )
    if not match:
        return None
    payload = json.loads(html_lib.unescape(match.group(1)))
    props = payload.get("props") if isinstance(payload, dict) else None
    props = props if isinstance(props, dict) else {}
    page_props = props.get("pageProps")
    page_props = page_props if isinstance(page_props, dict) else {}
    server = page_props.get("serverResponse")
    server = server if isinstance(server, dict) else {}
    data = server.get("data")
    data = data if isinstance(data, dict) else {}
    return {
        "route": {
            "sharedConversationId": data.get("conversation_id", "shared"),
            "serverResponse": {"data": data},
        },
        "data": data,
    }


def chat_from_data(data: dict[str, Any], route: dict[str, Any], source_url: str) -> ChatBackup:
    if not isinstance(data, dict):
        raise ChatBackupError("Keine Gesprächsdaten im Share-Link.")

    mapping = data.get("mapping") if isinstance(data.get("mapping"), dict) else {}
    sequence = data.get("linear_conversation") if isinstance(data.get("linear_conversation"), list) else []
    stats = ExportStats(source_entries=len(sequence))
    messages: list[ChatMessage] = []
    seen_ids: set[str] = set()

    for entry in sequence:
        node: dict[str, Any] | None = None
        if isinstance(entry, dict) and isinstance(entry.get("id"), str):
            candidate = mapping.get(entry["id"])
            if isinstance(candidate, dict):
                node = candidate
        if node is None and isinstance(entry, dict) and isinstance(entry.get("message"), dict):
            node = entry
        if not isinstance(node, dict) or not isinstance(node.get("message"), dict):
            stats.skipped_empty += 1
            continue

        message = node["message"]
        metadata = message.get("metadata") if isinstance(message.get("metadata"), dict) else {}
        if metadata.get("is_visually_hidden_from_conversation") is True:
            stats.skipped_hidden += 1
            continue

        author = message.get("author") if isinstance(message.get("author"), dict) else {}
        role = author.get("role") if isinstance(author.get("role"), str) else "assistant"
        if role in {"system", "developer", "tool"}:
            stats.skipped_role += 1
            continue

        recipient = message.get("recipient") if isinstance(message.get("recipient"), str) else "all"
        if role == "assistant" and recipient not in {"all", ""}:
            stats.skipped_recipient += 1
            continue

        message_id = message.get("id") if isinstance(message.get("id"), str) else ""
        if message_id and message_id in seen_ids:
            stats.skipped_duplicate += 1
            continue

        content = message.get("content") if isinstance(message.get("content"), dict) else {}
        text = flatten_message_content(content, message).strip()
        if not text:
            stats.skipped_empty += 1
            continue

        if message_id:
            seen_ids.add(message_id)

        status = message.get("status") if isinstance(message.get("status"), str) else ""
        if role == "assistant" and status and status != "finished_successfully":
            stats.possibly_incomplete += 1
        if has_unclosed_code_fence(text):
            stats.possibly_incomplete += 1

        created = message.get("create_time")
        created_at = float(created) if isinstance(created, (int, float)) else None
        messages.append(
            ChatMessage(
                role=role,
                author=author_name_for_role(role),
                text=text,
                created_at=created_at,
            )
        )

    stats.exported = len(messages)
    model_data = data.get("model") if isinstance(data.get("model"), dict) else {}
    model = model_data.get("slug") if isinstance(model_data.get("slug"), str) else ""
    route_share_id = route.get("sharedConversationId") if isinstance(route, dict) else ""
    share_id = (
        route_share_id
        if isinstance(route_share_id, str) and route_share_id
        else data.get("conversation_id")
        if isinstance(data.get("conversation_id"), str)
        else extract_share_id(source_url) or "shared"
    )
    title = data.get("title") if isinstance(data.get("title"), str) else ""
    updated = data.get("update_time")

    chat = ChatBackup(
        title=title.strip() or "ChatGPT Gespräch",
        source_url=source_url,
        share_id=share_id,
        model=model,
        updated_at=float(updated) if isinstance(updated, (int, float)) else None,
        messages=messages,
        stats=stats,
    )
    if not messages:
        raise ChatBackupError("Im Share-Link wurden keine sichtbaren Nachrichten gefunden.")
    return chat


def flatten_message_content(content: dict[str, Any], message: dict[str, Any]) -> str:
    content_type = content.get("content_type") if isinstance(content.get("content_type"), str) else ""
    chunks: list[str] = []

    if content_type == "text" or (not content_type and isinstance(content.get("parts"), list)):
        for part in content.get("parts", []):
            value = extract_text_part(part)
            if value:
                chunks.append(value)
    elif content_type == "code":
        language = content.get("language") if isinstance(content.get("language"), str) else ""
        if language == "unknown":
            language = ""
        code = content.get("text") if isinstance(content.get("text"), str) else ""
        code = code.rstrip()
        if code:
            chunks.append(f"```{language}\n{code}\n```")
    elif content_type == "reasoning_recap":
        recap = content.get("content") if isinstance(content.get("content"), str) else ""
        if recap.strip():
            chunks.append(f"_{recap.strip()}_")
    elif content_type == "thoughts":
        thoughts = content.get("thoughts") if isinstance(content.get("thoughts"), list) else []
        for thought in thoughts:
            if isinstance(thought, dict) and isinstance(thought.get("summary"), str):
                summary = thought["summary"].strip()
                if summary:
                    chunks.append(f"_{summary}_")
    elif content_type == "multimodal_text":
        parts = content.get("parts") if isinstance(content.get("parts"), list) else []
        for part in parts:
            if isinstance(part, str):
                cleaned = clean_export_text(part)
                if cleaned:
                    chunks.append(cleaned)
                continue
            if not isinstance(part, dict):
                continue
            part_type = str(part.get("content_type") or part.get("type") or "")
            if part_type == "text":
                text_value = part.get("text")
                if isinstance(text_value, list):
                    for item in text_value:
                        if isinstance(item, str) and item.strip():
                            chunks.append(clean_export_text(item))
                elif isinstance(text_value, str) and text_value.strip():
                    chunks.append(clean_export_text(text_value))
            elif part_type in {"image_asset_pointer", "file"}:
                pointer = part.get("asset_pointer") if isinstance(part.get("asset_pointer"), str) else ""
                label = "Bild aus dem Originalchat" if part_type == "image_asset_pointer" else "Datei aus dem Originalchat"
                if re.match(r"^https?://", pointer, re.IGNORECASE):
                    chunks.append(f"![{label}]({pointer})" if part_type == "image_asset_pointer" else f"[{label}]({pointer})")
                else:
                    chunks.append(f"*[{label} – nicht direkt downloadbar]*")
    elif isinstance(content.get("text"), str):
        cleaned = clean_export_text(content["text"])
        if cleaned:
            chunks.append(cleaned)

    attachments = extract_attachment_markdown(message)
    if attachments:
        chunks.append("\n".join(attachments))
    return re.sub(r"\n{4,}", "\n\n\n", "\n\n".join(filter(None, chunks))).strip()


def extract_text_part(part: Any) -> str:
    if isinstance(part, str):
        cleaned = clean_export_text(part)
        trimmed = cleaned.strip()
        if trimmed.startswith("{") and trimmed.endswith("}"):
            try:
                parsed = json.loads(trimmed)
                if isinstance(parsed, dict):
                    for key in ("response", "content"):
                        value = parsed.get(key)
                        if isinstance(value, str):
                            return clean_export_text(value)
            except json.JSONDecodeError:
                pass
        return cleaned
    if isinstance(part, dict):
        text = part.get("text")
        if isinstance(text, str):
            return clean_export_text(text)
        if isinstance(text, list):
            return "\n".join(
                clean_export_text(item)
                for item in text
                if isinstance(item, str) and clean_export_text(item)
            )
    return ""


def extract_attachment_markdown(message: dict[str, Any]) -> list[str]:
    metadata = message.get("metadata") if isinstance(message.get("metadata"), dict) else {}
    attachments = metadata.get("attachments") if isinstance(metadata.get("attachments"), list) else []
    result: list[str] = []
    for attachment in attachments:
        if not isinstance(attachment, dict):
            continue
        url = attachment.get("download_url") or attachment.get("file_url") or ""
        name = str(attachment.get("name") or "Anhang").strip() or "Anhang"
        mime = str(attachment.get("mime_type") or "")
        label = escape_markdown_label(name)
        if isinstance(url, str) and re.match(r"^https?://", url, re.IGNORECASE):
            result.append(f"![{label}]({url})" if mime.lower().startswith("image/") else f"[{label}]({url})")
        else:
            result.append(f"*[Anhang: {label} – nicht direkt downloadbar]*")
    return result


def clean_export_text(text: Any) -> str:
    output = str(text or "")
    output = re.sub(r"[\uE000-\uF8FF]", "", output)
    output = output.replace("\x00", "")
    output = CITATION_MARKER_RE.sub("", output)
    output = re.sub(r"[ \t]+\n", "\n", output)
    output = re.sub(r"\n{4,}", "\n\n\n", output)
    return output.strip()


def finalize_chat_stats(chat: ChatBackup) -> None:
    chat.stats.exported = len(chat.messages)
    if chat.stats.possibly_incomplete > 0:
        warning = f"{chat.stats.possibly_incomplete} Nachricht(en) könnten unvollständig sein."
        if warning not in chat.warnings:
            chat.warnings.append(warning)


def build_markdown(chat: ChatBackup, include_integrity: bool = True) -> str:
    lines: list[str] = [f"# {sanitize_heading(chat.title)}", ""]
    lines.append(f"- **Quelle:** {chat.source_url}")
    lines.append(f"- **Exportiert:** {format_local_datetime(datetime.now())}")
    if chat.model:
        lines.append(f"- **Modell:** {chat.model}")
    if chat.updated_at:
        lines.append(f"- **Chat aktualisiert:** {format_unix_timestamp(chat.updated_at)}")
    lines.append(f"- **Nachrichten:** {len(chat.messages)}")
    if chat.parser:
        lines.append(f"- **Parser:** {chat.parser}")
    if chat.parser_details:
        lines.append(f"- **Parser-Details:** {chat.parser_details}")
    for warning in chat.warnings:
        lines.append(f"- **Warnung:** {warning}")
    lines.extend(["", "---", ""])

    for index, message in enumerate(chat.messages):
        lines.append(f"## {message.author}")
        lines.append("")
        lines.append(message.text.strip())
        lines.append("")
        if index < len(chat.messages) - 1:
            lines.extend(["---", ""])

    if include_integrity:
        append_integrity_section(lines, chat)

    return re.sub(r"\n{4,}", "\n\n\n", "\n".join(lines)).strip() + "\n"


def append_integrity_section(lines: list[str], chat: ChatBackup) -> None:
    stats = chat.stats
    lines.extend(
        [
            "",
            "---",
            "",
            "## Export-Integrität",
            "",
            f"- **Quellsequenz:** {stats.source_entries}",
            f"- **Exportiert:** {stats.exported}",
            f"- **Übersprungen:** {stats.skipped_total}",
            f"- **Versteckt:** {stats.skipped_hidden}",
            f"- **Rollenfilter:** {stats.skipped_role}",
            f"- **Empfängerfilter:** {stats.skipped_recipient}",
            f"- **Leer/ungültig:** {stats.skipped_empty}",
            f"- **Duplikate:** {stats.skipped_duplicate}",
            f"- **Möglicherweise unvollständig:** {stats.possibly_incomplete}",
            f"- **Parser:** {chat.parser or 'unbekannt'}",
            f"- **Status:** {stats.integrity_status}",
            "",
            "=== EXPORT COMPLETE ===",
        ]
    )


def build_javascript_export(
    content: str,
    title: str,
    source_url: str = "",
    source_mode: str = "manual",
) -> str:
    payload = {
        "schemaVersion": "1.0.0",
        "tool": "666_CHATBACKUP_PC_TOOL",
        "toolVersion": APP_VERSION,
        "title": title or "ChatGPT Backup",
        "sourceMode": source_mode,
        "sourceUrl": source_url,
        "exportedAt": datetime.now().astimezone().isoformat(timespec="seconds"),
        "content": content,
    }
    encoded = json.dumps(payload, ensure_ascii=False, indent=2)
    encoded = encoded.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return (
        "/* Generated by 666_CHATBACKUP_PC_TOOL. */\n"
        f"const CHAT_BACKUP_EXPORT = Object.freeze({encoded});\n\n"
        "if (typeof module !== \"undefined\" && module.exports) {\n"
        "  module.exports = CHAT_BACKUP_EXPORT;\n"
        "}\n"
    )


def write_verified(path: str | Path, content: str, encoding: str = "utf-8") -> Path:
    """Schreibt den Export bytegenau und prüft ihn ohne Newline-Normalisierung.

    Textmodus-Readback mit ``newline=None`` normalisiert CRLF/CR zu LF und kann
    deshalb bei längeren Chats mit gemischten Zeilenenden einen falschen
    Integritätsfehler auslösen. Die Verifikation arbeitet bewusst auf Byte-Ebene.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    expected = content.encode(encoding)
    target.write_bytes(expected)
    if not target.exists():
        raise ChatBackupError("Die Datei wurde nach dem Schreiben nicht gefunden.")

    expected_size = len(expected)
    actual_size = target.stat().st_size
    if actual_size != expected_size:
        raise ChatBackupError(
            "Die gespeicherte Datei besitzt nach dem Rücklesen eine abweichende Byte-Länge. "
            f"Erwartet: {expected_size}, gelesen: {actual_size}."
        )

    expected_hash = hashlib.sha256(expected).hexdigest()
    actual_hash = hashlib.sha256()
    with target.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            actual_hash.update(chunk)

    if actual_hash.hexdigest() != expected_hash:
        raise ChatBackupError(
            "Die gespeicherte Datei stimmt nach dem bytegenauen SHA-256-Rücklesen "
            "nicht mit dem Export überein."
        )
    return target


def unique_path(directory: str | Path, base_name: str, extension: str) -> Path:
    folder = Path(directory)
    folder.mkdir(parents=True, exist_ok=True)
    extension = extension if extension.startswith(".") else f".{extension}"
    candidate = folder / f"{base_name}{extension}"
    counter = 2
    while candidate.exists():
        candidate = folder / f"{base_name}_{counter}{extension}"
        counter += 1
    return candidate


def sanitize_heading(value: str) -> str:
    return re.sub(r"\s{2,}", " ", re.sub(r"[\r\n]+", " ", str(value or ""))).strip()


def sanitize_file_name(value: str) -> str:
    name = str(value or "ChatGPT_Gespraech")
    name = re.sub(r"[\\/:*?\"<>|]", "-", name)
    name = re.sub(r"[\r\n\t]+", " ", name)
    name = re.sub(r"\s+", "_", name)
    name = re.sub(r"_+", "_", name)
    name = re.sub(r"^[-_. ]+|[-_. ]+$", "", name)[:80]
    return name or "ChatGPT_Gespraech"


def escape_markdown_label(value: str) -> str:
    return re.sub(r"[\[\]]", lambda match: "\\" + match.group(0), str(value or ""))


def extract_share_id(url: str) -> str:
    match = re.search(r"/(?:share|s)/([^/?#]+)", str(url or ""), re.IGNORECASE)
    return match.group(1) if match else ""


def author_name_for_role(role: str) -> str:
    if role == "user":
        return "Benutzer"
    if role == "tool":
        return "Tool"
    return "ChatGPT"


def has_unclosed_code_fence(text: str) -> bool:
    return len(re.findall(r"```", str(text or ""))) % 2 != 0


def format_local_datetime(value: datetime) -> str:
    return value.astimezone().strftime("%d.%m.%Y, %H:%M:%S")


def format_unix_timestamp(timestamp: float) -> str:
    seconds = timestamp / 1000 if timestamp > 100_000_000_000 else timestamp
    return format_local_datetime(datetime.fromtimestamp(seconds).astimezone())


def file_date_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


class _StaticMessageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.active_depth: int | None = None
        self.active_role: str | None = None
        self.active_chunks: list[str] = []
        self.messages: list[tuple[str, str]] = []
        self.title = ""
        self._in_title = False

    _VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag_lower = tag.lower()
        attrs_dict = {key: value or "" for key, value in attrs}

        if tag_lower in self._VOID_TAGS:
            if self.active_depth is not None and tag_lower in {"br", "hr"}:
                self.active_chunks.append("\n")
            return

        self.depth += 1
        if tag_lower == "title":
            self._in_title = True
        if self.active_depth is None:
            role = attrs_dict.get("data-message-author-role", "")
            if role in {"user", "assistant"}:
                self.active_depth = self.depth
                self.active_role = role
                self.active_chunks = []
        elif tag_lower in {"p", "div", "article", "li", "pre", "h1", "h2", "h3"}:
            self.active_chunks.append("\n")

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self.active_depth is not None and tag.lower() in {"br", "hr"}:
            self.active_chunks.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag_lower = tag.lower()
        if tag_lower in self._VOID_TAGS:
            return
        if tag_lower == "title":
            self._in_title = False
        if self.active_depth == self.depth and self.active_role:
            text = clean_export_text("".join(self.active_chunks))
            text = re.sub(r"\n{3,}", "\n\n", text).strip()
            if text:
                self.messages.append((self.active_role, text))
            self.active_depth = None
            self.active_role = None
            self.active_chunks = []
        self.depth = max(0, self.depth - 1)

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title += data
        if self.active_depth is not None:
            self.active_chunks.append(data)


def extract_static_dom_conversation(page_html: str, source_url: str) -> ChatBackup:
    parser = _StaticMessageParser()
    parser.feed(page_html)
    seen: set[tuple[str, str]] = set()
    messages: list[ChatMessage] = []
    for role, text in parser.messages:
        key = (role, text)
        if key in seen:
            continue
        seen.add(key)
        messages.append(ChatMessage(role=role, author=author_name_for_role(role), text=text))
    title = re.sub(r"^ChatGPT\s*[-–—:]\s*", "", parser.title, flags=re.IGNORECASE).strip()
    stats = ExportStats(source_entries=len(messages), exported=len(messages))
    return ChatBackup(
        title=title or "ChatGPT Gespräch",
        source_url=source_url,
        share_id=extract_share_id(source_url) or "shared",
        messages=messages,
        stats=stats,
    )
