from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk



def _redirect_direct_source_start_through_bootstrap() -> None:
    """Route direct .py/.pyw starts through the Windows dependency bootstrap."""
    if os.name != "nt" or getattr(sys, "frozen", False):
        return
    if os.environ.get("CHATBACKUP_BOOTSTRAP_STATUS") == "PASS":
        return

    project_root = Path(__file__).resolve().parent.parent
    bootstrap = project_root / "bootstrap" / "bootstrap.ps1"
    if not bootstrap.exists():
        return

    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoLogo",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(bootstrap),
                "-Mode",
                "Run",
                "-ForceSource",
                "-LaunchHidden",
            ],
            cwd=str(project_root),
            creationflags=creation_flags,
        )
    except OSError:
        return
    raise SystemExit(0)


_redirect_direct_source_start_through_bootstrap()

from chatbackup_core import (
    APP_VERSION,
    ChatBackupError,
    build_javascript_export,
    build_markdown,
    file_date_stamp,
    load_chat_backup,
    sanitize_file_name,
    unique_path,
    write_verified,
)


class ChatBackupApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"666 ChatBackup PC Tool v{APP_VERSION}")
        self.geometry("1180x780")
        self.minsize(900, 620)
        self.configure(bg="#10131a")

        self.result_queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self.current_source_url = ""
        self.current_source_mode = "manual"
        self.current_title = "ChatGPT Backup"
        self.editor_programmatic_change = False
        self.last_directory = str(Path.home() / "Documents")
        self.bootstrap_status_file = os.environ.get("CHATBACKUP_BOOTSTRAP_STATUS_FILE", "")

        self._build_style()
        self._build_ui()
        self.after(150, self._poll_result_queue)

    def _build_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#10131a")
        style.configure("Panel.TFrame", background="#171c26")
        style.configure("TLabel", background="#10131a", foreground="#eef3ff")
        style.configure("Panel.TLabel", background="#171c26", foreground="#eef3ff")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground="#f3f6ff")
        style.configure("Hint.TLabel", foreground="#aeb8cf")
        style.configure("Status.TLabel", background="#0b0e14", foreground="#b8c7e8", padding=(10, 7))
        style.configure("TButton", font=("Segoe UI", 10, "bold"), padding=(10, 7))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 8))
        style.configure("Danger.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 8))
        style.configure("TEntry", padding=7)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=16)
        outer.pack(fill="both", expand=True)

        header = ttk.Frame(outer)
        header.pack(fill="x", pady=(0, 12))
        ttk.Label(header, text="666 ChatBackup PC Tool", style="Title.TLabel").pack(side="left")
        ttk.Label(
            header,
            text="Share-Link laden oder Chattext direkt einfügen",
            style="Hint.TLabel",
        ).pack(side="left", padx=(16, 0), pady=(6, 0))
        ttk.Button(
            header,
            text="Systemstatus",
            command=self.show_system_status,
        ).pack(side="right")

        link_panel = ttk.Frame(outer, style="Panel.TFrame", padding=12)
        link_panel.pack(fill="x", pady=(0, 10))
        ttk.Label(link_panel, text="Öffentlicher ChatGPT-Share-Link", style="Panel.TLabel").grid(
            row=0, column=0, columnspan=5, sticky="w", pady=(0, 6)
        )
        self.url_var = tk.StringVar()
        self.url_entry = ttk.Entry(link_panel, textvariable=self.url_var)
        self.url_entry.grid(row=1, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(link_panel, text="Aus Zwischenablage", command=self.paste_link).grid(row=1, column=1, padx=4)
        self.load_button = ttk.Button(link_panel, text="Link laden", style="Accent.TButton", command=self.start_link_load)
        self.load_button.grid(row=1, column=2, padx=4)
        ttk.Button(link_panel, text="Link leeren", command=lambda: self.url_var.set("")).grid(row=1, column=3, padx=4)
        link_panel.columnconfigure(0, weight=1)

        meta_panel = ttk.Frame(outer, style="Panel.TFrame", padding=12)
        meta_panel.pack(fill="x", pady=(0, 10))
        ttk.Label(meta_panel, text="Titel / Dateiname", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        self.title_var = tk.StringVar(value=self.current_title)
        self.title_entry = ttk.Entry(meta_panel, textvariable=self.title_var)
        self.title_entry.grid(row=1, column=0, sticky="ew", padx=(0, 10), pady=(5, 0))
        self.mode_var = tk.StringVar(value="Modus: manuell")
        ttk.Label(meta_panel, textvariable=self.mode_var, style="Panel.TLabel").grid(row=1, column=1, sticky="e")
        meta_panel.columnconfigure(0, weight=1)

        editor_panel = ttk.Frame(outer, style="Panel.TFrame", padding=12)
        editor_panel.pack(fill="both", expand=True, pady=(0, 10))
        editor_header = ttk.Frame(editor_panel, style="Panel.TFrame")
        editor_header.pack(fill="x", pady=(0, 7))
        ttk.Label(editor_header, text="Chatbackup / manueller Text", style="Panel.TLabel").pack(side="left")
        ttk.Button(editor_header, text="Text einfügen", command=self.paste_text).pack(side="right", padx=(6, 0))
        ttk.Button(editor_header, text="Alles markieren", command=self.select_all).pack(side="right", padx=(6, 0))
        ttk.Button(editor_header, text="Inhalt leeren", command=self.clear_editor).pack(side="right", padx=(6, 0))

        text_frame = tk.Frame(editor_panel, bg="#171c26")
        text_frame.pack(fill="both", expand=True)
        self.editor = tk.Text(
            text_frame,
            wrap="word",
            undo=True,
            bg="#0d1118",
            fg="#edf2ff",
            insertbackground="#ffffff",
            selectbackground="#4e5f86",
            relief="flat",
            padx=12,
            pady=10,
            font=("Consolas", 10),
        )
        yscroll = ttk.Scrollbar(text_frame, orient="vertical", command=self.editor.yview)
        xscroll = ttk.Scrollbar(text_frame, orient="horizontal", command=self.editor.xview)
        self.editor.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.editor.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        text_frame.rowconfigure(0, weight=1)
        text_frame.columnconfigure(0, weight=1)
        self.editor.bind("<<Modified>>", self._on_editor_modified)

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(0, 8))
        ttk.Button(actions, text="Speichern als TXT", command=lambda: self.save_single("txt")).pack(side="left", padx=(0, 7))
        ttk.Button(actions, text="Speichern als MD", command=lambda: self.save_single("md")).pack(side="left", padx=7)
        ttk.Button(actions, text="Speichern als JavaScript", command=lambda: self.save_single("js")).pack(side="left", padx=7)
        ttk.Button(actions, text="Alle 3 in Ordner speichern", style="Accent.TButton", command=self.save_all).pack(side="left", padx=7)
        ttk.Button(actions, text="Beenden", style="Danger.TButton", command=self.destroy).pack(side="right")

        self.status_var = tk.StringVar(value="SYSTEMPRÜFUNG PASS — Link laden oder Text direkt einfügen.")
        ttk.Label(outer, textvariable=self.status_var, style="Status.TLabel", anchor="w").pack(fill="x")

    def show_system_status(self) -> None:
        status_path = Path(self.bootstrap_status_file) if self.bootstrap_status_file else None
        if not status_path or not status_path.exists():
            messagebox.showinfo(
                "Systemstatus",
                "Standalone-Start oder kein Bootstrap-Protokoll gefunden.\n\n"
                "Die Anwendung selbst ist gestartet; Node.js und NPM werden nicht benötigt.",
            )
            return

        try:
            payload = json.loads(status_path.read_text(encoding="utf-8-sig"))
            details = payload.get("details", {})
            python_info = details.get("python", {}) if isinstance(details, dict) else {}
            tkinter_info = details.get("tkinter", {}) if isinstance(details, dict) else {}
            lines = [
                f"Status: {payload.get('status', 'UNBEKANNT')}",
                f"Zusammenfassung: {payload.get('summary', '')}",
                f"Modus: {payload.get('mode', '')}",
            ]
            if isinstance(python_info, dict):
                if python_info.get("required") is False:
                    lines.append("Python: für die Standalone-EXE nicht erforderlich")
                elif python_info.get("version"):
                    lines.append(f"Python: {python_info.get('version')}")
            if isinstance(tkinter_info, dict) and tkinter_info.get("present"):
                lines.append(f"Tkinter/Tk: {tkinter_info.get('version', 'verfügbar')}")
            lines.extend([
                "Node.js: NOT_REQUIRED",
                "NPM: NOT_REQUIRED",
                f"Protokoll: {payload.get('logPath', '')}",
            ])
            messagebox.showinfo("Automatischer Systemstatus", "\n".join(lines))
        except Exception as exc:
            messagebox.showerror("Systemstatus", f"Statusdatei konnte nicht gelesen werden:\n\n{exc}")

    def paste_link(self) -> None:
        try:
            self.url_var.set(self.clipboard_get().strip())
            self.status_var.set("ZWISCHENABLAGE — Link übernommen.")
        except tk.TclError:
            messagebox.showwarning("Zwischenablage", "Die Zwischenablage enthält keinen Text.")

    def paste_text(self) -> None:
        try:
            text = self.clipboard_get()
        except tk.TclError:
            messagebox.showwarning("Zwischenablage", "Die Zwischenablage enthält keinen Text.")
            return
        self.editor.insert("insert", text)
        self.current_source_mode = "manual"
        self.current_source_url = ""
        self.mode_var.set("Modus: manuell / bearbeitet")
        self.status_var.set("MANUELL — Text eingefügt und kann direkt exportiert werden.")

    def clear_editor(self) -> None:
        if self.editor.get("1.0", "end-1c").strip() and not messagebox.askyesno(
            "Inhalt leeren", "Soll der komplette Textbereich wirklich geleert werden?"
        ):
            return
        self._set_editor_text("")
        self.current_source_mode = "manual"
        self.current_source_url = ""
        self.mode_var.set("Modus: manuell")
        self.status_var.set("BEREIT — Textbereich geleert.")

    def select_all(self) -> str:
        self.editor.tag_add("sel", "1.0", "end-1c")
        self.editor.mark_set("insert", "1.0")
        self.editor.see("insert")
        return "break"

    def _on_editor_modified(self, _event: tk.Event) -> None:
        if self.editor.edit_modified():
            self.editor.edit_modified(False)
            if not self.editor_programmatic_change:
                self.current_source_mode = "manual" if not self.current_source_url else "share-link-edited"
                self.mode_var.set(
                    "Modus: manuell" if not self.current_source_url else "Modus: Share-Link / nachbearbeitet"
                )

    def start_link_load(self) -> None:
        url = self.url_var.get().strip()
        if not url:
            messagebox.showwarning("Link fehlt", "Bitte zuerst einen öffentlichen ChatGPT-Share-Link eingeben.")
            self.url_entry.focus_set()
            return
        self.load_button.configure(state="disabled")
        self.status_var.set("LADEN — Share-Link wird geprüft und verarbeitet …")
        worker = threading.Thread(target=self._load_worker, args=(url,), daemon=True)
        worker.start()

    def _load_worker(self, url: str) -> None:
        try:
            chat = load_chat_backup(url)
            markdown = build_markdown(chat)
            self.result_queue.put(("success", (chat, markdown)))
        except Exception as exc:
            self.result_queue.put(("error", exc))

    def _poll_result_queue(self) -> None:
        try:
            while True:
                kind, payload = self.result_queue.get_nowait()
                self.load_button.configure(state="normal")
                if kind == "success":
                    chat, markdown = payload  # type: ignore[misc]
                    self.current_source_url = chat.source_url
                    self.current_source_mode = "share-link"
                    self.current_title = chat.title
                    self.title_var.set(chat.title)
                    self.mode_var.set(f"Modus: Share-Link · Parser: {chat.parser}")
                    self._set_editor_text(markdown)
                    self.status_var.set(
                        f"VERIFIZIERT — {len(chat.messages)} Nachrichten geladen · Integrität {chat.stats.integrity_status}."
                    )
                else:
                    exc = payload
                    text = str(exc)
                    if isinstance(exc, ChatBackupError):
                        text = str(exc)
                    self.status_var.set("FEHLER — Share-Link konnte nicht verarbeitet werden.")
                    messagebox.showerror("Chat-Export fehlgeschlagen", text)
        except queue.Empty:
            pass
        self.after(150, self._poll_result_queue)

    def _set_editor_text(self, text: str) -> None:
        self.editor_programmatic_change = True
        try:
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", text)
            self.editor.edit_reset()
            self.editor.edit_modified(False)
        finally:
            self.editor_programmatic_change = False

    def _content(self) -> str:
        return self.editor.get("1.0", "end-1c")

    def _title(self) -> str:
        title = self.title_var.get().strip()
        return title or "ChatGPT Backup"

    def _default_name(self, extension: str) -> str:
        return f"{sanitize_file_name(self._title())}_{file_date_stamp()}.{extension}"

    def _content_for_extension(self, extension: str) -> str:
        content = self._content()
        if extension == "js":
            return build_javascript_export(
                content=content,
                title=self._title(),
                source_url=self.current_source_url,
                source_mode=self.current_source_mode,
            )
        return content if content.endswith("\n") or not content else content + "\n"

    def save_single(self, extension: str) -> None:
        if not self._content().strip():
            messagebox.showwarning("Kein Inhalt", "Bitte zuerst einen Link laden oder Chattext einfügen.")
            return
        file_types = {
            "txt": [("Textdatei", "*.txt"), ("Alle Dateien", "*.*")],
            "md": [("Markdown-Datei", "*.md"), ("Alle Dateien", "*.*")],
            "js": [("JavaScript-Datei", "*.js"), ("Alle Dateien", "*.*")],
        }
        target = filedialog.asksaveasfilename(
            title=f"Chatbackup als {extension.upper()} speichern",
            initialdir=self.last_directory,
            initialfile=self._default_name(extension),
            defaultextension=f".{extension}",
            filetypes=file_types[extension],
        )
        if not target:
            self.status_var.set("ABGEBROCHEN — Es wurde keine Datei gespeichert.")
            return
        try:
            path = write_verified(target, self._content_for_extension(extension))
            self.last_directory = str(path.parent)
            self.status_var.set(f"VERIFIZIERT GESPEICHERT — {path}")
            messagebox.showinfo("Gespeichert", f"Datei erfolgreich gespeichert und zurückgelesen:\n\n{path}")
        except Exception as exc:
            self.status_var.set("FEHLER — Datei konnte nicht gespeichert werden.")
            messagebox.showerror("Speichern fehlgeschlagen", str(exc))

    def save_all(self) -> None:
        if not self._content().strip():
            messagebox.showwarning("Kein Inhalt", "Bitte zuerst einen Link laden oder Chattext einfügen.")
            return
        directory = filedialog.askdirectory(
            title="Zielordner für TXT, MD und JavaScript auswählen",
            initialdir=self.last_directory,
            mustexist=True,
        )
        if not directory:
            self.status_var.set("ABGEBROCHEN — Es wurde kein Zielordner ausgewählt.")
            return
        base_name = f"{sanitize_file_name(self._title())}_{file_date_stamp()}"
        saved: list[Path] = []
        try:
            for extension in ("txt", "md", "js"):
                path = unique_path(directory, base_name, extension)
                saved.append(write_verified(path, self._content_for_extension(extension)))
            self.last_directory = directory
            self.status_var.set(f"VERIFIZIERT GESPEICHERT — 3 Dateien in {directory}")
            messagebox.showinfo(
                "Alle Formate gespeichert",
                "TXT, MD und JavaScript wurden gespeichert und zurückgelesen:\n\n"
                + "\n".join(str(path) for path in saved),
            )
        except Exception as exc:
            self.status_var.set("FEHLER — Nicht alle Dateien konnten gespeichert werden.")
            messagebox.showerror("Speichern fehlgeschlagen", str(exc))


def main() -> None:
    app = ChatBackupApp()
    try:
        icon = Path(__file__).resolve().parent.parent / "assets" / "chatbackup.ico"
        if icon.exists():
            app.iconbitmap(default=str(icon))
    except tk.TclError:
        pass
    app.mainloop()


if __name__ == "__main__":
    main()
