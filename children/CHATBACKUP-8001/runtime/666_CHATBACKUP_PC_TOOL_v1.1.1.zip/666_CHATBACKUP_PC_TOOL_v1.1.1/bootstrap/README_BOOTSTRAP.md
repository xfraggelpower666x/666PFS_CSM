# Automatischer Bootstrap v1.1.1

Der Bootstrap läuft vor dem Python-Start und vor dem EXE-Build.

## Prüf- und Reparaturreihenfolge

1. Abhängigkeitsmanifest lesen.
2. Node.js und NPM erkennen, aber als `NOT_REQUIRED` weder installieren noch aktualisieren.
3. Bei vorhandener Standalone-EXE direkt starten; dafür ist keine externe Python-Laufzeit nötig.
4. Beim Quellstart Python erkennen und gegen die Mindestversion prüfen.
5. Fehlendes oder zu altes Python bevorzugt per `winget` im Benutzerkontext installieren.
6. Falls `winget` nicht funktioniert, den aktuellen Patchstand der vorgesehenen Python-Linie direkt von `python.org` laden.
7. Vor direkter Installation die Authenticode-Signatur und den Herausgeber `Python Software Foundation` verifizieren.
8. Vorhandenes Python auf Updates derselben Major/Minor-Linie prüfen und notwendige Patch-/Sicherheitsupdates installieren.
9. Tkinter testen und bei Bedarf durch eine offizielle Python-Reparatur mit Tcl/Tk ergänzen.
10. Im Build-Modus die isolierte `.venv-build`-Umgebung erstellen, pip-Werkzeuge aktualisieren, PyInstaller installieren/aktualisieren und `pip check` ausführen.
11. Ergebnis und vollständiges Protokoll unter `%LOCALAPPDATA%\666SOUNDsDESIGn\666_CHATBACKUP_PC_TOOL\` speichern.

## Sicherheitsgrenzen

- Keine Tokens oder Zugangsdaten.
- Keine Installation unnötiger Komponenten.
- Keine ungeprüften Downloadquellen.
- Keine automatische Node.js-/NPM-Installation.
- Python-Updates bleiben innerhalb der bereits verwendeten Major/Minor-Linie; ein erzwungener Major-Wechsel erfolgt nur, wenn Python fehlt oder die Mindestversion unterschritten wird.


## v1.1.1 Hinweis

Der Bootstrap selbst wurde funktional nicht verändert. v1.1.1 repariert ausschließlich die bytegenaue Speicher-/Readback-Prüfung des Chat-Exports.
