@echo off
cd /d "%~dp0"
start "" wscript.exe "%~dp0START_WINDOWS_SILENT.vbs"
