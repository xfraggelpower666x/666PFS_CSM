# 666 ChatBackup PC Tool v1.1.1

Windows-Desktoptool zum Laden öffentlicher ChatGPT-Share-Links sowie zum manuellen Einfügen, Bearbeiten und Exportieren von Chattext.


## Reparatur v1.1.1 — lange Chats

Bei langen oder technisch komplexen Chats können gemischte Zeilenenden (`LF`, `CRLF`, `CR`) vorkommen. v1.1.0 schrieb den Inhalt korrekt, las ihn zur Integritätsprüfung jedoch im Textmodus zurück. Python normalisiert dabei `CRLF`/`CR` zu `LF`; dadurch konnte die Prüfung fälschlich melden, die gespeicherte Datei stimme nicht mit dem Export überein.

v1.1.1 schreibt und verifiziert Exporte deshalb **bytegenau**. Nach dem Speichern werden Dateigröße und SHA-256 über die Rohbytes geprüft. Dadurch bleiben auch lange Chats mit gemischten Zeilenenden unverändert erhalten.

## Wichtigster Start

Nach dem Entpacken nur diese Datei doppelklicken:

```text
START_TOOL.bat
```

Alternativ kann `AUTO_SETUP_AND_START.bat` direkt verwendet werden. Beide Wege führen durch denselben automatischen Systemstart.

## Automatischer Systemstart

Vor dem eigentlichen Programmstart wird automatisch geprüft, was das Tool wirklich benötigt.

### Runtime-Prüfung

- Vorhandene Standalone-EXE erkennen
- Python erkennen
- Python-Mindestversion prüfen
- Fehlendes oder zu altes Python automatisch installieren
- Vorhandenes Python auf notwendige Patch- und Sicherheitsupdates derselben Major/Minor-Linie prüfen
- Tkinter/Tcl-Tk prüfen und bei Bedarf reparieren
- Node.js erkennen, aber als `NOT_REQUIRED` nicht installieren oder verändern
- NPM erkennen, aber als `NOT_REQUIRED` nicht installieren oder verändern
- Status und Logdatei unter `%LOCALAPPDATA%\666SOUNDsDESIGn\666_CHATBACKUP_PC_TOOL\` speichern

Die Anwendung nutzt für den normalen Quellstart ausschließlich Python-Standardbibliothek und Tkinter. Externe Runtime-Pakete sind nicht erforderlich.

### Installationsquellen und Sicherheit

1. Bevorzugt wird Python per Windows Package Manager `winget` installiert oder aktualisiert.
2. Falls `winget` nicht verfügbar ist oder fehlschlägt, wird die aktuelle stabile Patchversion der vorgesehenen Python-Linie direkt von `python.org` bezogen.
3. Vor der stillen Installation wird die Authenticode-Signatur geprüft.
4. Der Herausgeber muss `Python Software Foundation` sein.
5. Ungeprüfte Downloadquellen werden nicht verwendet.

Fehlt die Internetverbindung, kann ein bereits kompatibles Python weiterhin verwendet werden. Eine zwingend nötige Neuinstallation kann ohne Internet nicht durchgeführt werden und wird klar als `BLOCKIERT` protokolliert.

## Programmfunktionen

- Grafische Windows-Oberfläche
- Eingabefeld für öffentliche ChatGPT-Share-Links
- Link aus der Zwischenablage übernehmen
- Share-Link laden und sichtbare Nachrichten in ein lesbares Backup umwandeln
- Chattext manuell einfügen, schreiben, ergänzen oder korrigieren
- Großes editierbares Textfeld
- Titel und Dateiname frei setzen
- Speichern-unter-Dialog für `.txt`
- Speichern-unter-Dialog für `.md`
- Speichern-unter-Dialog für `.js`
- Alle drei Formate mit gemeinsamer Zielordnerauswahl speichern
- Rückleseprüfung nach jedem Speichervorgang
- Systemstatus direkt aus der Oberfläche anzeigen
- Beenden-Knopf

## Startdateien

| Datei | Funktion |
|---|---|
| `START_TOOL.bat` | Empfohlener normaler Start mit automatischer Prüfung |
| `AUTO_SETUP_AND_START.bat` | Direkter sichtbarer Bootstrap und Start |
| `START_WINDOWS_SILENT.bat` | Automatischer Start ohne dauerhaft sichtbares Konsolenfenster |
| `START_PYTHON.bat` | Erzwingt den geprüften Python-Quellstart |
| `START_EXE.bat` | Startet ausschließlich die gebaute EXE nach EXE-Prüfung |
| `SYSTEM_CHECK_ONLY.bat` | Prüft, installiert und aktualisiert Voraussetzungen, startet aber nicht die GUI |
| `BUILD_EXE.bat` | Prüft Buildvoraussetzungen und erzeugt die Windows-EXE |
| `CLEAN_BUILD.bat` | Entfernt nur Buildordner und lässt Quellen unverändert |

Auch ein direktes Starten von `app\chatbackup_gui.pyw` wird unter Windows automatisch zurück durch den Bootstrap geleitet. Dadurch gibt es keinen ungeprüften Python-Nebenstart.

## EXE erzeugen

1. `BUILD_EXE.bat` doppelklicken.
2. Python und Tkinter werden geprüft, installiert oder aktualisiert.
3. Die isolierte Umgebung `.venv-build` wird erstellt oder weiterverwendet.
4. `pip`, `setuptools` und `wheel` werden aktualisiert.
5. Die passende PyInstaller-Version wird installiert oder aktualisiert.
6. `pip check` prüft die Buildumgebung.
7. PyInstaller erzeugt die EXE.

Ergebnis:

```text
dist\666_CHATBACKUP_PC_TOOL.exe
```

Die Standalone-EXE bringt ihre Python-Laufzeit mit und benötigt auf dem Ziel-PC weder Python noch Node.js noch NPM. Eine Windows-EXE muss weiterhin auf Windows gebaut werden.

## Bedienung

### Share-Link importieren

1. Öffentlichen ChatGPT-Share-Link einfügen.
2. `Link laden` drücken.
3. Der geladene Chat erscheint im Textfeld.
4. Inhalt bei Bedarf nachbearbeiten.
5. Speicherformat auswählen.
6. Im Speichern-unter-Dialog Zielordner und Dateinamen festlegen.

Private `/c/`-Links sind nicht öffentlich auslesbar. Dafür im Chat zuerst einen öffentlichen `/share/`-Link erstellen.

### Chattext manuell einfügen

1. Text direkt in das große Feld schreiben oder über `Text einfügen` übernehmen.
2. Titel oder Dateinamen festlegen.
3. Als TXT, Markdown, JavaScript oder in allen drei Formaten speichern.
4. Für jedes Einzelformat erscheint eine eigene Speicherortauswahl.
5. Beim Dreifach-Export erscheint eine Zielordnerauswahl.

## Exportformate

- **TXT:** vollständiger Inhalt als UTF-8-Text
- **MD:** vollständiger Inhalt als Markdown-Datei
- **JS:** JavaScript-Datenobjekt mit Metadaten und sicher JSON-kodiertem Inhalt

## Share-Link-Parser

Der Import versucht nacheinander:

1. React-Flight-Daten
2. älteres `__NEXT_DATA__`-Format
3. statisch gerenderte sichtbare DOM-Nachrichten

Versteckte Nachrichten, Systemrollen, Developerrollen und nicht freigegebene Toolnachrichten werden nicht als normaler Chattext exportiert. Eine Integritätssektion dokumentiert die Verarbeitung.

## Projektstruktur

```text
666_CHATBACKUP_PC_TOOL_v1.1.1/
├─ app/
│  ├─ chatbackup_core.py
│  ├─ chatbackup_gui.py
│  └─ chatbackup_gui.pyw
├─ assets/
│  └─ chatbackup.ico
├─ bootstrap/
│  ├─ bootstrap.ps1
│  ├─ dependencies.json
│  └─ README_BOOTSTRAP.md
├─ source_reference/
│  └─ ORIGINAL_SCRIPTABLE_CHAT_EXPORT.js
├─ tests/
│  ├─ test_core.py
│  ├─ run_tests.py
│  └─ RUN_TESTS.bat
├─ START_TOOL.bat
├─ AUTO_SETUP_AND_START.bat
├─ START_WINDOWS_SILENT.bat
├─ START_WINDOWS_SILENT.vbs
├─ START_PYTHON.bat
├─ START_EXE.bat
├─ SYSTEM_CHECK_ONLY.bat
├─ BUILD_EXE.bat
├─ CLEAN_BUILD.bat
├─ 666_CHATBACKUP_PC_TOOL.spec
├─ requirements-runtime.txt
├─ requirements-build.txt
├─ AUDIT_REPORT.md
├─ CHANGELOG.md
└─ VERSION.json
```

## Grenzen

- Nur öffentliche ChatGPT-Share-Links können ohne Anmeldung geladen werden.
- Änderungen an der öffentlichen Share-Seitenstruktur können spätere Parser-Anpassungen erfordern.
- Anhänge ohne öffentlich erreichbare Downloadadresse bleiben als Hinweis im Backup erhalten.
- Eine tatsächlich lauffähige Windows-EXE kann nur in einer Windows-Buildumgebung verifiziert werden.
