import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from chatbackup_core import (  # noqa: E402
    build_javascript_export,
    build_markdown,
    extract_legacy_next_data,
    normalize_and_validate_share_url,
    parse_shared_conversation,
    write_verified,
)


def fixture_html() -> str:
    data = {
        "conversation_id": "abc123",
        "title": "Test Chat",
        "mapping": {
            "m1": {
                "message": {
                    "id": "m1",
                    "author": {"role": "user"},
                    "recipient": "all",
                    "status": "finished_successfully",
                    "content": {"content_type": "text", "parts": ["Hallo"]},
                    "metadata": {},
                }
            },
            "m2": {
                "message": {
                    "id": "m2",
                    "author": {"role": "assistant"},
                    "recipient": "all",
                    "status": "finished_successfully",
                    "content": {"content_type": "text", "parts": ["Hallo zurück"]},
                    "metadata": {},
                }
            },
        },
        "linear_conversation": [{"id": "m1"}, {"id": "m2"}],
    }
    payload = {"props": {"pageProps": {"serverResponse": {"data": data}}}}
    return '<html><script id="__NEXT_DATA__" type="application/json">' + json.dumps(payload) + "</script></html>"


def test_normalize_share_url():
    assert normalize_and_validate_share_url("http://chatgpt.com/share/abc#x") == "https://chatgpt.com/share/abc"


def test_parse_legacy_fixture():
    html = fixture_html()
    assert extract_legacy_next_data(html)
    chat = parse_shared_conversation(html, "https://chatgpt.com/share/abc")
    assert chat.title == "Test Chat"
    assert len(chat.messages) == 2
    markdown = build_markdown(chat)
    assert "Hallo zurück" in markdown
    assert "Export-Integrität" in markdown


def test_javascript_export_is_structurally_safe():
    js = build_javascript_export("Backtick ` und ${x}", "Titel")
    assert "const CHAT_BACKUP_EXPORT" in js
    assert '"content": "Backtick ` und ${x}"' in js


def test_verified_write(tmp_path):
    target = tmp_path / "backup.md"
    write_verified(target, "abc\n")
    assert target.read_text(encoding="utf-8") == "abc\n"


def test_verified_write_preserves_mixed_line_endings(tmp_path):
    content = "A\r\nB\rC\nD\r\n"
    target = tmp_path / "mixed.md"
    write_verified(target, content)
    assert target.read_bytes() == content.encode("utf-8")


def test_verified_write_long_chat_exact(tmp_path):
    block = "Benutzer\r\nZeile 1\nAssistant\rZeile 2 — äöü 🚀\n"
    content = block * 50000
    target = tmp_path / "long_chat.md"
    write_verified(target, content)
    assert target.stat().st_size == len(content.encode("utf-8"))
    assert target.read_bytes() == content.encode("utf-8")


def test_static_dom_fallback():
    html = '''<html><head><title>ChatGPT - DOM Test</title></head><body>
    <article data-message-author-role="user"><div>Zeile 1<br>Zeile 2</div></article>
    <article data-message-author-role="assistant"><div>Antwort</div></article>
    </body></html>'''
    chat = parse_shared_conversation(html, "https://chatgpt.com/share/dom")
    assert chat.parser == "static-dom-fallback"
    assert len(chat.messages) == 2
    assert "Zeile 2" in chat.messages[0].text


def test_dependency_manifest_and_bootstrap_contract():
    manifest_path = ROOT / "bootstrap" / "dependencies.json"
    bootstrap_path = ROOT / "bootstrap" / "bootstrap.ps1"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    bootstrap = bootstrap_path.read_text(encoding="utf-8")

    assert manifest["toolVersion"] == "1.1.1"
    assert manifest["runtime"]["python"]["minimumVersion"] == "3.10.0"
    assert manifest["runtime"]["python"]["preferredInstallLine"] == "3.14"
    assert manifest["runtime"]["nodejs"]["required"] is False
    assert manifest["runtime"]["npm"]["required"] is False
    assert manifest["build"]["pyinstaller"]["versionSpec"] == ">=6.17,<7.0"

    assert "Get-AuthenticodeSignature" in bootstrap
    assert "Python Software Foundation" in bootstrap
    assert "Update-PythonIfRequired" in bootstrap
    assert "Include_tcltk=1" in bootstrap
    assert "NOT_REQUIRED" in bootstrap


def test_all_launchers_route_through_bootstrap():
    expected = {
        "AUTO_SETUP_AND_START.bat",
        "START_PYTHON.bat",
        "START_EXE.bat",
        "SYSTEM_CHECK_ONLY.bat",
        "BUILD_EXE.bat",
    }
    for name in expected:
        content = (ROOT / name).read_text(encoding="utf-8")
        assert "bootstrap\\bootstrap.ps1" in content


def test_version_is_updated():
    from chatbackup_core import APP_VERSION

    assert APP_VERSION == "1.1.1"
