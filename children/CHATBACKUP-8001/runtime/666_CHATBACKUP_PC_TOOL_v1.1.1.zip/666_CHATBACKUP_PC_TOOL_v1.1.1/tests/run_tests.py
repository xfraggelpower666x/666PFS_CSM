from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from chatbackup_core import (  # noqa: E402
    APP_VERSION,
    build_javascript_export,
    build_markdown,
    normalize_and_validate_share_url,
    parse_shared_conversation,
    write_verified,
)


def main() -> None:
    checks = 0

    assert APP_VERSION == "1.1.1"
    checks += 1

    assert normalize_and_validate_share_url("http://chatgpt.com/share/abc#x") == "https://chatgpt.com/share/abc"
    checks += 1

    data = {
        "conversation_id": "abc123",
        "title": "Test Chat",
        "mapping": {
            "m1": {"message": {"id": "m1", "author": {"role": "user"}, "recipient": "all", "status": "finished_successfully", "content": {"content_type": "text", "parts": ["Hallo"]}, "metadata": {}}},
            "m2": {"message": {"id": "m2", "author": {"role": "assistant"}, "recipient": "all", "status": "finished_successfully", "content": {"content_type": "text", "parts": ["Hallo zurück"]}, "metadata": {}}},
        },
        "linear_conversation": [{"id": "m1"}, {"id": "m2"}],
    }
    payload = {"props": {"pageProps": {"serverResponse": {"data": data}}}}
    html = '<html><script id="__NEXT_DATA__" type="application/json">' + json.dumps(payload) + "</script></html>"
    chat = parse_shared_conversation(html, "https://chatgpt.com/share/abc")
    markdown = build_markdown(chat)
    assert len(chat.messages) == 2
    assert "Hallo zurück" in markdown
    checks += 1

    js = build_javascript_export("Backtick ` und ${x}", "Titel")
    assert "CHAT_BACKUP_EXPORT" in js
    checks += 1

    with tempfile.TemporaryDirectory() as folder:
        target = Path(folder) / "backup.md"
        write_verified(target, markdown)
        assert target.read_text(encoding="utf-8") == markdown
    checks += 1

    with tempfile.TemporaryDirectory() as folder:
        content = ("Benutzer\r\nZeile\nAssistant\rAntwort — äöü 🚀\n" * 50000)
        target = Path(folder) / "long_mixed_chat.md"
        write_verified(target, content)
        assert target.read_bytes() == content.encode("utf-8")
    checks += 1

    manifest = json.loads((ROOT / "bootstrap" / "dependencies.json").read_text(encoding="utf-8"))
    assert manifest["runtime"]["nodejs"]["required"] is False
    assert manifest["runtime"]["npm"]["required"] is False
    assert manifest["runtime"]["python"]["preferredInstallLine"] == "3.14"
    checks += 1

    bootstrap = (ROOT / "bootstrap" / "bootstrap.ps1").read_text(encoding="utf-8")
    for required_fragment in (
        "Get-AuthenticodeSignature",
        "Python Software Foundation",
        "Update-PythonIfRequired",
        "Include_tcltk=1",
        "NOT_REQUIRED",
    ):
        assert required_fragment in bootstrap
    checks += 1

    for launcher in (
        "AUTO_SETUP_AND_START.bat",
        "START_PYTHON.bat",
        "START_EXE.bat",
        "SYSTEM_CHECK_ONLY.bat",
        "BUILD_EXE.bat",
    ):
        assert "bootstrap\\bootstrap.ps1" in (ROOT / launcher).read_text(encoding="utf-8")
    checks += 1

    print(f"ALL TESTS PASSED ({checks}/9)")


if __name__ == "__main__":
    main()
