# Audit-Bericht — 666 ChatBackup PC Tool v1.1.1

Datum: 2026-08-14

## Gesamtstatus

`VERIFIZIERTER SOURCE-REPAIR / RE-AUDIT PASS / WINDOWS-v1.1.1-READBACK-PENDING`

## Ausgangsfehler

Der Nutzer meldete bei längeren Chats den Dialog `Speichern fehlgeschlagen` mit der Meldung, dass die gespeicherte Datei nach dem Rücklesen nicht mit dem Export übereinstimme.

## Root Cause — VERIFIZIERT

Die v1.1.0-Funktion `write_verified()` schrieb den String mit `newline="\n"`, las ihn danach aber über normalen Textmodus zurück. Universal-Newline-Readback normalisiert `CRLF` und einzelnes `CR` zu `LF`. Dadurch war ein falscher Integritätsfehler möglich, sobald ein längerer Export gemischte Zeilenenden enthielt.

Der Fehler wurde gegen unveränderten v1.1.0-Code reproduziert:

- reines LF: PASS
- CRLF: reproduzierbarer FAIL
- einzelnes CR: reproduzierbarer FAIL
- langer gemischter Export: reproduzierbarer FAIL

## Reparatur

- `write_verified()` minimalinvasiv auf Byte-Write umgestellt.
- Erwartete Byte-Länge wird mit tatsächlicher Dateigröße verglichen.
- SHA-256 des erwarteten Payloads wird mit gestreamtem SHA-256 des gespeicherten Files verglichen.
- Keine Textmodus-Newline-Normalisierung mehr im Integritäts-Readback.
- Parser, GUI, Exportformate, Bootstrap und Startwege funktional erhalten.

## Re-Audit

- Python-Kompilierung: PASS
- Core-Test-Runner: 9/9 PASS
- Pytest: 10 PASS
- LF-Write/Readback: PASS
- CRLF-Write/Readback: PASS
- einzelnes CR: PASS
- Unicode/Emoji: PASS
- 740.000-Byte Mixed-Newline-Test: PASS
- Byte-Länge: PASS
- SHA-256-Readback: PASS

## Erhalten

- öffentlicher Share-Link-Import
- React-Flight / Legacy / DOM-Fallback
- manuelle Texteingabe
- editierbares Textfeld
- Speichern-unter für TXT/MD/JS
- Dreifach-Export mit Ordnerwahl
- Systemstatus und automatischer Bootstrap
- Beenden-Knopf
- Original-Scriptable-Referenz

## Offene Plattformprüfung

`WINDOWS_V1_1_1_RUNTIME_READBACK=READBACK_PENDING`

Der v1.1.0-Fehler ist anhand des Quellcodes und reproduzierbarer Tests erklärt und repariert. Der neue v1.1.1-Build muss anschließend auf dem Nutzer-Windows-PC praktisch getestet werden; erst dann wird dessen Windows-Readback als PASS geführt.
