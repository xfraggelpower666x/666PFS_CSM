# Quellen- und Funktionszuordnung v1.1.1

## Erhaltene Grundlage

Die bereitgestellte Scriptable-Datei bleibt unverändert unter:

```text
source_reference/ORIGINAL_SCRIPTABLE_CHAT_EXPORT.js
```

Aus ihr wurden konzeptionell erhalten:

- Validierung öffentlicher ChatGPT-Share-Links
- Ablehnung privater `/c/`-Links
- Wiederholte Downloadversuche
- React-Flight-Auswertung
- Legacy-`__NEXT_DATA__`-Auswertung
- sichtbarer Nachrichtenfallback
- Rollen-, Empfänger- und Sichtbarkeitsfilter
- Markdown-Ausgabe
- Integritätssektion
- Rückleseprüfung nach Speicherung

## Windows-Erweiterungen v1.0.0

- Tkinter-GUI
- Manuelle Texteingabe und Bearbeitung
- Speicherortauswahl
- TXT-, MD- und JS-Export
- Dreifach-Export
- Windows-Start- und EXE-Buildroutinen

## Windows-Erweiterungen v1.1.0

- Automatische Abhängigkeitsprüfung vor dem Start
- Automatische Python-Installation
- Automatische Python-Patchupdateprüfung
- Tkinter-Prüfung und Reparatur
- Signaturprüfung offizieller Installer
- Isolierte und aktualisierte PyInstaller-Buildumgebung
- Ausdrückliche Nicht-Abhängigkeit von Node.js und NPM
- Zentralisiertes Routing aller Startwege
- GUI-Systemstatus

## Nicht verändert

- Das Originalskript im Referenzordner
- Die bestehenden Exportformate und Parserreihenfolge
- Die manuelle Texteingabe
- Die freie Speicherortwahl

## Reparatur v1.1.1 — Speicher-Readback

- Ursache: Textmodus-Readback normalisierte gemischte CRLF/CR/LF-Zeilenenden.
- Reparatur: `write_verified()` schreibt Rohbytes und verifiziert Byte-Länge + SHA-256.
- Parser, GUI, Bootstrap und Exportformate bleiben funktional unverändert.
