# Änderungsprotokoll

## v1.1.1 — 2026-08-14

Status: VERIFIZIERTER QUELLCODE-REPAIR / WINDOWS-READBACK-PENDING

### Reparatur: längere Chats

- Falschen Integritätsfehler beim Speichern längerer Chats mit gemischten Zeilenenden reproduziert.
- Ursache in `write_verified()` lokalisiert: Textmodus-Rücklesen normalisierte `CRLF` und `CR` zu `LF`.
- Speicherung auf bytegenauen UTF-Encoding-Write umgestellt.
- Readback auf Byte-Länge und SHA-256-Prüfung umgestellt.
- Regressionstest für `CRLF`, einzelnes `CR`, Unicode und großen Chattext ergänzt.
- Keine Parser-, GUI-, Bootstrap- oder Exportfunktion entfernt oder vereinfacht.

## v1.1.0 — 2026-07-30

Status: VERIFIZIERTES QUELLPaket / WINDOWS-RUNTIME-READBACK-PENDING / EXE-BUILD-READY

### Automatischer Bootstrap

- Zentralen Windows-Bootstrap vor allen relevanten Startwegen ergänzt
- Abhängigkeitsmanifest `bootstrap/dependencies.json` ergänzt
- Python-Erkennung über Launcher, PATH und bekannte Installationspfade ergänzt
- Windows-Store-Alias als falsche Python-Laufzeit ausgeschlossen
- Python-Mindestversion `3.10.0` festgelegt
- Bevorzugte Neuinstallation auf stabile Python-Linie `3.14` gesetzt
- Automatische Patch- und Sicherheitsupdateprüfung innerhalb der installierten Python-Linie ergänzt
- Installation und Update bevorzugt über `winget` ergänzt
- Offiziellen `python.org`-Fallback ergänzt
- Authenticode-Prüfung des Python-Installers ergänzt
- Herausgeberprüfung auf `Python Software Foundation` ergänzt
- Tkinter-Prüfung und kontrollierte Reparatur ergänzt
- Node.js und NPM als ausdrücklich nicht erforderliche Komponenten festgelegt
- Bootstrap-Status und Logdateien im Benutzerprofil ergänzt

### Start- und Buildwege

- `START_TOOL.bat` als empfohlene Ein-Klick-Startdatei ergänzt
- `AUTO_SETUP_AND_START.bat` ergänzt
- `SYSTEM_CHECK_ONLY.bat` ergänzt
- `START_PYTHON.bat` auf Bootstrap-Routing umgestellt
- `START_WINDOWS_SILENT.bat` und VBS auf Bootstrap-Routing umgestellt
- `START_EXE.bat` auf EXE-Prüfung über Bootstrap umgestellt
- `BUILD_EXE.bat` auf denselben Bootstrap und isolierte Buildumgebung umgestellt
- Direkten `.pyw`-Start automatisch zum Bootstrap zurückgeleitet
- PyInstaller-Anforderung auf Python-3.14-kompatible Linie `>=6.17,<7.0` angehoben

### GUI

- `Systemstatus`-Knopf ergänzt
- Letzten Bootstrapstatus, Pythonversion, Tkinterstatus und Logpfad in der GUI sichtbar gemacht
- Startstatus auf erfolgreiche Systemprüfung abgestimmt

### Erhaltene Funktionen

- Share-Link-Import
- Manuelle Texteingabe
- Editierbarer Chatbackup-Bereich
- Speicherortauswahl für TXT, MD und JS
- Zielordnerauswahl für Dreifach-Export
- Rückleseprüfung
- Beenden-Knopf
- React-Flight-, Legacy- und DOM-Fallback

## v1.0.0 — 2026-07-30

- Erste Windows-PC-Umsetzung des bereitgestellten Scriptable-Exports
- Tkinter-GUI, Share-Link-Import, manuelle Texteingabe und drei Exportformate
