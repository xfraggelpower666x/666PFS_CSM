@echo off
call "%~dp0AUTO_SETUP_AND_START.bat"
